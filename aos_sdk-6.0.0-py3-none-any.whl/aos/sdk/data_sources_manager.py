# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=redefined-builtin
from aos.sdk.collection_utils import find
import logging
LOGGER = logging.getLogger(__name__)

class DataSourcesManager(object):
    class SourceInfo(object):
        def __init__(self, type, id):
            self.type = type
            # pylint: disable=invalid-name
            self.id = id
            self.subject = None
            self.agents = []

    def __init__(self):
        self._source_infos = []
        self._providers = {}

    def register_provider(self, type, provider):
        if type in self._providers:
            raise ValueError('Multiple data providers for same type \"%s\"' % type)
        self._providers[type] = provider

    def attach(self, type, agent, id=None):
        info = None
        for source_info in self._source_infos:
            if source_info.type == type and \
                    (id is None or source_info.id == id):
                info = source_info
                break

        if info is None:
            if type not in self._providers:
                raise ValueError('Unknown source type: %s' % type)

            info = self.SourceInfo(type, id=id)
            self._source_infos.append(info)
            def attached(graph):
                assert info.subject is None, 'Attach should only happen once for ' \
                                             '%s graph %s' % (info.type, info.id)
                info.subject = graph
                for agent in info.agents:
                    agent.on_attach(info.type, info.subject)

            self._providers[type].attach(id, attached)

        info.agents.append(agent)
        if info.subject is not None:
            agent.on_attach(info.type, info.subject)

    def detach(self, type, agent, id=None):
        info = None
        for source_info in self._source_infos:
            if source_info.type == type and source_info.id == id \
                    and agent in source_info.agents:
                info = source_info
                break

        if info is None:
            LOGGER.info('source info not found for %s, %s, %s', type, agent, id)
            return

        if info.subject:
            agent.on_detach(info.type, info.subject)
        else:
            LOGGER.info(
                'skipping unmounted source %s, %s, for agent %s',
                info.type, info.id, agent)

        if len(info.agents) <= 1:
            self._source_infos.remove(info)
            self._providers[type].detach(info.id)
        else:
            info.agents.remove(agent)

    def detach_all(self, agent):
        for info in self._source_infos[:]:
            if agent not in info.agents:
                continue

            if info.subject:
                agent.on_detach(info.type, info.subject)
            else:
                LOGGER.info(
                    'skipping unmounted source %s, %s, for agent %s',
                    info.type, info.id, agent)

            info.agents.remove(agent)
            if not info.agents:
                self._source_infos.remove(info)
                self._providers[info.type].detach(info.id)

    def get_source(self, type, id=None):
        info = find(
            lambda info: info.type == type and info.id == id,
            self._source_infos)
        return info.subject if info else None
