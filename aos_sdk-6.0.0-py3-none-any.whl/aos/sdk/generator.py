# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=redefined-builtin,missing-docstring,invalid-name
# pylint: disable=dangerous-default-value,redefined-outer-name
# pylint: disable=line-too-long

from __future__ import annotations

import json
import logging
import copy
import itertools
import typing as t
from collections import defaultdict

from aos.sdk.types import (
    BP_DEFAULT_L3_MTU,
    DEFAULT_DUP_MAC_RECOVERY_TIME,
    DEFAULT_ESI_MAC_MSB,
    DEFAULT_SVI_L3_MTU,
    DEFAULT_FABRIC_EVI_RT,
    ValidationErrorBuilder,
)
from aos.sdk.generator_helpers import compact_dict, gen_id, \
    gen_short_id, port_speed, normalize_port_speed, format_speed
from aos.sdk.generator_helpers import deserialize_port_speed  # pylint: disable=unused-import
import six
from six.moves import map
from six.moves import range

if t.TYPE_CHECKING:
    import typing_extensions as te
    import lollipop.errors
    import _typeshed as tsd

    from aos.sdk import typing as tt

    _MAGIC: t.Any
    aos: t.Any

    T = t.TypeVar('T')
    V = t.TypeVar('V')

    class PoolRange(t.TypedDict):
        first: int
        last: int

    class IpPoolSubnetsSpec(t.TypedDict):
        network: tt.IPNetwork

    class GenAsnPoolSpec(t.TypedDict, total=False):
        display_name: str
        id: str
        ranges: list[PoolRange]
        tags: list[tt.Tag]

    class GenIpPoolSpec(t.TypedDict, total=False):
        id: str
        display_name: str
        subnets: list[IpPoolSubnetsSpec]
        tags: list[tt.Tag]

    class GenTelemetryServiceRegistrySpec(t.TypedDict, total=False):
        service_name: str
        version: str
        storage_schema_path: str
        description: str
        application_schema: dict

    class GenPropertySetsSpec(t.TypedDict):
        label: str
        values: dict[str, t.Any]

    class GenBlueprintSpec(t.TypedDict):
        design: tt.RefDesign
        init_type: str
        label: str
        template_id: str | None

    class GenAgentProfilesSpec(t.TypedDict):
        open_options: dict
        label: str

    class GenExternalRouterSpec(t.TypedDict, total=False):
        id: str
        display_name: str
        address: tt.IPv4Address
        ipv6_address: tt.IPv6Address
        asn: tt.ASN
        tags: list[tt.Tag]

    class GenSyslogsSpec(t.TypedDict):
        address: tt.IPAddress
        port: tt.PortNo
        protocol: tt.NetworkProtocol
        facility: tt.SyslogFacility
        timezone: tt.Timezone

    class GenProvidersSpec(t.TypedDict):
        vendor: str
        hostname_fqdn_ip: tt.HostName | tt.IPAddress
        encryption: str
        provider_name: str
        port: tt.PortNo
        groups_search_dn: str
        users_search_dn: str

    class GenAuthProviderTACACSSpec(t.TypedDict):
        provider_name: str
        vendor: str
        hostname_fqdn_ip: list[tt.HostName | tt.IPAddress]
        port: tt.PortNo
        shared_key: str
        auth_mode: str
        active: bool

    class GenClusterSpec(t.TypedDict):
        ranges: list[dict]
        label: str
        tags: list[tt.Tag]
        address: tt.IPAddress
        username: str
        password: str

    class GenPortSettingSpec(t.TypedDict):
        type: str
        param: str

    class GenStreamConfigSpec(t.TypedDict):
        protocol: str
        hostname: tt.HostName | tt.IPv4Address
        port: tt.PortNo
        streaming_type: str
        sequencing_mode: str
        tls_enabled: bool | None
        tls_bypass_validation: bool | None
        tls_trusted_certificate_ids: list[str] | None

    class GenStreamCertSpec(t.TypedDict):
        label: str
        description: str | None
        pem_b64: str

    class GenHclHwCapsSpec(t.TypedDict, total=False):
        userland: int
        form_factor: str
        ecmp_limit: int
        asic: str
        cpu: str
        ram: int

    class GenHclSwCapsSpec(t.TypedDict, total=False):
        onie: bool
        lxc_support: bool
        config_apply_support: str

    class GenDpRefDesignCapsSpec(t.TypedDict):
        freeform: tt.RefDesignCaps
        datacenter: tt.RefDesignCaps

    class GenLogicalDevicePanelPortGroupSpec(t.TypedDict):
        count: int
        speed: tt.PortSpeed
        roles: list[str]

    class GenLogicalDevicePanelPortIndexingSpec(t.TypedDict):
        schema: str
        order: str
        start_index: int

    class GenLogicalDevicePanelLayoutSpec(t.TypedDict):
        row_count: int
        column_count: int

    class GenLogicalDevicePanelSpec(t.TypedDict):
        port_groups: list[GenLogicalDevicePanelPortGroupSpec]
        port_indexing: GenLogicalDevicePanelPortIndexingSpec
        panel_layout: GenLogicalDevicePanelLayoutSpec

    class GenLogicalDeviceSpec(t.TypedDict):
        id: str
        display_name: str
        panels: list[GenLogicalDevicePanelSpec]

    class GenTransformationSpec(t.TypedDict):
        from_count: int
        from_speed: tt.PortSpeed
        to_count: int
        to_speed: tt.PortSpeed

    class GenInterfaceMapIntfSettingSpec(t.TypedDict):
        param: str

    class GenInterfaceMapIntfMappingSpec(t.TypedDict):
        name: str
        state: t.Literal['active', 'inactive']
        roles: list[str]
        position: int
        speed: tt.PortSpeed
        setting: GenInterfaceMapIntfSettingSpec
        mapping: list[int | None]  # 5 elements - no way to enforce this

    class GenInterfaceMapSpec(t.TypedDict):
        label: str
        interfaces: list[GenInterfaceMapIntfMappingSpec]
        device_profile_id: str
        logical_device_id: str

    class GenSystemAgentsSpec(t.TypedDict):
        management_ip: tt.IPAddress
        agent_type: str
        username: str
        password: str
        operation_mode: tt.ManagementLevel
        open_options: dict

    class GenBlueprintConfigletConfigletGeneratorSpec(t.TypedDict, total=False):
        config_style: str
        template_text: str
        negation_template_text: str
        section: str
        section_condition: str
        filename: str

    class GenBlueprintConfigletConfigletSpec(t.TypedDict):
        display_name: str
        generators: list[GenBlueprintConfigletConfigletGeneratorSpec]

    class GenBlueprintConfigletSpec(t.TypedDict):
        condition: str
        configlet: GenBlueprintConfigletConfigletSpec
        label: str

    class GenConfigletSpec(t.TypedDict):
        ref_archs: list[tt.RefDesign]
        generators: list[GenBlueprintConfigletConfigletGeneratorSpec]
        display_name: str

    class GenTagSpec(t.TypedDict):
        id: str
        label: str
        description: str
        created_at: tt.ISOTimestamp
        last_modified_at: tt.ISOTimestamp

    class GenRackTypeAccessSwitchUplinkSpec(t.TypedDict):
        label: str
        target_switch_label: str
        link_per_switch_count: int
        link_speed: tt.PortSpeed
        attachment_type: tt.LagAttachmentType
        switch_peer: str | None
        tags: list[tt.Tag]
        lag_mode: tt.LagMode
        # rail index is not applicable for Access Switch links, however
        # they share the same schema
        rail_index: tt.RailIndex | None

    class GenRackTypeServerLinkSpec(t.TypedDict):
        label: str
        target_switch_label: str
        link_per_switch_count: int
        link_speed: tt.PortSpeed
        attachment_type: tt.LagAttachmentType
        switch_peer: str | None
        lag_mode: tt.LagMode | None
        tags: list[tt.Tag]
        rail_index: tt.RailIndex | None

    class GenRackTypeAccessSwitchSpec(t.TypedDict):
        label: str
        logical_device: GenLogicalDeviceSpec
        instance_count: int
        links: list[GenRackTypeAccessSwitchUplinkSpec]
        access_access_link_count: int
        access_access_link_speed: tt.PortSpeed | None
        access_access_link_port_channel_id_min: int
        access_access_link_port_channel_id_max: int
        redundancy_protocol: tt.RedundancyProtocol | None
        tags: list[tt.Tag]

    class GenRackTypeServerSpec(t.TypedDict, total=False):
        label: str
        logical_device: GenLogicalDeviceSpec
        connectivity_type: tt.ConnectivityType
        links: list[GenRackTypeServerLinkSpec]
        count: int
        ip_version: t.Literal['ipv4', 'ipv6']
        port_channel_id_min: int
        port_channel_id_max: int
        lag_mode: tt.LagMode

    class GenRackTypeGenericSystemSpec(t.TypedDict, total=False):
        label: str
        logical_device: GenLogicalDeviceSpec
        links: list[GenRackTypeServerLinkSpec]
        count: int
        management_level: tt.ManagementLevel
        port_channel_id_min: int
        port_channel_id_max: int
        loopback: tt.EnabledDisabled
        asn_domain: tt.EnabledDisabled
        tags: list[tt.Tag]

    class GenExternalRouterLinkSpec(t.TypedDict):
        count: int
        speed: tt.PortSpeed

    class GenRackTypeLeafSpec(t.TypedDict):
        label: str
        logical_device: GenLogicalDeviceSpec
        link_per_spine_count: int
        link_per_spine_speed: tt.PortSpeed | None
        leaf_leaf_link_count: int
        leaf_leaf_link_speed: tt.PortSpeed | None
        leaf_leaf_l3_link_count: int
        leaf_leaf_l3_link_speed: tt.PortSpeed | None
        leaf_leaf_link_port_channel_id: int
        leaf_leaf_l3_link_port_channel_id: int
        mlag_vlan_id: int
        redundancy_protocol: tt.RedundancyProtocol | None
        tags: list[tt.Tag]

    class GenSpineTypeSpec(t.TypedDict, total=False):
        logical_device: GenLogicalDeviceSpec
        count: int
        tags: list[tt.Tag]
        link_per_superspine_count: int
        link_per_superspine_speed: tt.PortSpeed

    class GenRackType_LeafsSpec(GenRackTypeLeafSpec):
        logical_device: str  # type: ignore[misc]

    class GenRackType_AccessSwitchesSpec(GenRackTypeAccessSwitchSpec):
        logical_device: str  # type: ignore[misc]

    class GenRackType_GenericSystemsSpec(GenRackTypeGenericSystemSpec):
        logical_device: str  # type: ignore[misc]

    class GenRackTypeSpec(t.TypedDict):
        id: str
        display_name: str
        description: str
        fabric_connectivity_design: tt.FabricConnectivityDesign
        leafs: list[GenRackType_LeafsSpec]
        access_switches: list[GenRackType_AccessSwitchesSpec]
        generic_systems: list[GenRackType_GenericSystemsSpec]
        logical_devices: list[GenLogicalDeviceSpec]
        tags: list[tt.Tag]
        preferences: dict

    class GetPortsWithRolePortGroupSpec(t.TypedDict):
        count: int
        speed: tt.PortSpeed
        roles: list[str]

    class ValidateSpinePortGroups_RackTypeCountSpec(t.TypedDict):
        count: int
        rack_type_id: str

    class GenSuperspineTypeSpec(t.TypedDict, total=False):
        logical_device: GenLogicalDeviceSpec
        plane_count: int
        superspine_per_plane_count: int
        tags: list[tt.Tag]

    class GenExportPolicySpec(t.TypedDict):
        loopbacks: bool
        spine_leaf_links: bool
        spine_superspine_links: bool
        l2edge_subnets: bool
        static_routes: bool

    class GenPrefixListEntrySpec(t.TypedDict):
        prefix: tt.IPAddress
        le_mask: int | None
        ge_mask: int | None
        action: tt.PrefixListAction
        description: str | None

    class GenOSImageSpec(t.TypedDict):
        platform: str | None
        image_url: tt.Url | None
        description: str
        checksum: str

    class GenRouteTargetPolicySpec(t.TypedDict):
        import_RTs: list[str] | None
        export_RTs: list[str] | None

    class GenRoutingPolicy_GenPrefixListEntrySpec(t.TypedDict, total=False):
        prefix: te.Required[tt.IPAddress]
        le_mask: int | None
        ge_mask: int | None
        action: tt.PrefixListAction
        description: str | None

    class GenRoutingPolicySpec(t.TypedDict):
        label: str
        policy_type: str
        description: str | None
        import_policy: tt.RoutingImportPolicyType
        export_policy: GenExportPolicySpec | None
        aggregate_prefixes: list[tt.IPNetwork]
        extra_import_routes: list[GenPrefixListEntrySpec]
        extra_export_routes: list[GenPrefixListEntrySpec]
        expect_default_ipv4_route: bool
        expect_default_ipv6_route: bool

    class GenZtpLogSpec(t.TypedDict):
        system_id: str
        log: str

    class GenZtpDeviceStatusSpec(t.TypedDict):
        ip_addr: tt.IPAddress
        system_id: str
        last_log: str

    class GenVirtualNetworkPolicySpec(t.TypedDict):
        overlay_control_protocol: t.Literal['evpn'] | None

    class GenSecurityZoneSpec(t.TypedDict):
        label: str | None
        routing_policy_id: str | None
        rt_policy: GenRouteTargetPolicySpec | None
        sz_type: tt.SecurityZoneType | None
        vni_id: str | None
        vlan_id: str | None
        vrf_name: str | None
        route_target: str | None
        junos_evpn_irb_mode: tt.JunosEvpnIrbMode | None
        vrf_description: str | None

    class GenAntiAffinitySpec(t.TypedDict):
        mode: t.Literal['disabled', 'enabled_loose', 'enabled_strict']
        algorithm: t.Literal['heuristic']
        max_links_per_slot: int
        max_links_per_port: int
        max_per_system_links_per_slot: int
        max_per_system_links_per_port: int

    class GenFabricPolicySpec(t.TypedDict):
        spine_leaf_links: tt.LinkIpv4Ipv6All
        spine_superspine_links: tt.LinkIpv4Ipv6All
        leaf_loopbacks: tt.LinkIpv4Ipv6
        spine_loopbacks: tt.LinkIpv4Ipv6
        mlag_svi_subnets: tt.LinkIpv4Ipv6
        leaf_l3_peer_links: tt.LinkIpv4Ipv6
        esi_mac_msb: int
        fabric_l3_mtu: int
        anti_affinity: GenAntiAffinitySpec
        optimise_sz_footprint: tt.EnabledDisabled
        junos_evpn_routing_instance_type: tt.JunosEvpnRoutingInstanceType
        junos_evpn_max_nexthop_and_interface_number: tt.EnabledDisabled
        junos_graceful_restart: tt.EnabledDisabled
        junos_ex_overlay_ecmp: tt.EnabledDisabled
        junos_evpn_duplicate_mac_recovery_time: int
        overlay_control_protocol: t.Literal['evpn'] | None
        external_router_mtu: int | None
        max_fabric_routes: int
        max_external_routes: int
        max_mlag_routes: int
        max_evpn_routes: int
        default_fabric_evi_route_target: str | None
        evpn_generate_type5_host_routes: tt.EnabledDisabled
        frr_rd_vlan_offset: tt.EnabledDisabled
        default_svi_l3_mtu: int

    class GenAsnAllocationPolicySpec(t.TypedDict):
        spine_asn_scheme: t.Literal['distinct', 'single']

    class GenValidationPolicy_IpOverlapSpec(t.TypedDict):
        base_level: tt.ValidationSeverity | None
        svi: tt.ValidationSeverity | None
        uncontrolled_generic_loopback: tt.ValidationSeverity | None

    class GenValidationPolicy_RouteTargetOverlapSpec(t.TypedDict):
        internal: tt.ValidationSeverity | None

    class GenValidationPolicy_AsnOverlapSpec(t.TypedDict):
        base_level: tt.ValidationSeverity | None

    class GenValidationPolicy_OsVersionSpec(t.TypedDict):
        sonic_esi_min_version: tt.ValidationSeverity | None

    class GenValidationPolicy_AsicFeaturesSpec(t.TypedDict):
        subinterfaces: tt.ValidationSeverity | None
        load_balancing_policy: tt.ValidationSeverity | None

    class GenValidationPolicy_LoadBalancingPolicy(t.TypedDict):
        glb_mode: tt.ValidationSeverity | None

    class GenValidationPolicy_RailOptimizedDesign(t.TypedDict):
        rail_vlan_misconfiguration: tt.ValidationSeverity | None

    class GenValidationPolicySpec(t.TypedDict):
        ip_overlap: GenValidationPolicy_IpOverlapSpec
        route_target_overlap: GenValidationPolicy_RouteTargetOverlapSpec
        asn_overlap: GenValidationPolicy_AsnOverlapSpec
        os_version: GenValidationPolicy_OsVersionSpec
        asic_features: GenValidationPolicy_AsicFeaturesSpec
        load_balancing_policy: GenValidationPolicy_LoadBalancingPolicy
        rail_optimized_design: GenValidationPolicy_RailOptimizedDesign

    class GenRackBasedTemplate_DhcpServiceIntentSpec(t.TypedDict):
        active: bool

    class GenRackBasedTemplateSpec(t.TypedDict):
        type: str
        id: str
        display_name: str
        spine: GenSpineTypeSpec
        rack_types: list[GenRackTypeSpec]
        rack_type_counts: list[dict]
        dhcp_service_intent: GenRackBasedTemplate_DhcpServiceIntentSpec
        virtual_network_policy: GenVirtualNetworkPolicySpec
        asn_allocation_policy: GenAsnAllocationPolicySpec

    class GenPodBasedTemplateSpec(t.TypedDict):
        type: str
        id: str
        display_name: str
        superspine: GenSuperspineTypeSpec
        rack_based_templates: list[GenRackBasedTemplateSpec]
        rack_based_template_counts: list[dict]

    class GenL3CollapsedTemplateSpec(t.TypedDict):
        type: str
        id: str
        mesh_link_count: int
        mesh_link_speed: tt.PortSpeed
        display_name: str
        rack_types: list[GenRackTypeSpec]
        rack_type_counts: list[dict]
        dhcp_service_intent: GenRackBasedTemplate_DhcpServiceIntentSpec
        virtual_network_policy: GenVirtualNetworkPolicySpec

    class GenRailCollapsedTemplateSpec(t.TypedDict):
        type: str
        id: str
        display_name: str
        rack_types: list[GenRackTypeSpec]
        rack_type_counts: list[dict]
        dhcp_service_intent: GenRackBasedTemplate_DhcpServiceIntentSpec
        virtual_network_policy: GenVirtualNetworkPolicySpec

    GenVniPoolSpec: te.TypeAlias = GenAsnPoolSpec
    GenIntegerPoolSpec: te.TypeAlias = GenAsnPoolSpec

    class GenInterfacePolicySpec(t.TypedDict):
        label: str
        dot1x_auth_mode: tt.Dot1xPolicyAuthMode
        dot1x_port_control: tt.Dot1xPolicyPortControl
        dot1x_mac_auth_bypass: bool
        dot1x_reauthentication_timeout: int | None

    class GenRemoteGw_LocalGwNodeSpec(t.TypedDict):
        node_id: str
        label: str

    class GenRemoteGwSpec(t.TypedDict, total=False):
        gw_name: str
        gw_ip: tt.IPAddress
        gw_asn: tt.ASN
        password: str
        ttl: int
        keepalive_timer: int
        holdtime_timer: int
        local_gw_nodes: list[GenRemoteGw_LocalGwNodeSpec]
        evpn_route_types: t.Literal['all', 'type5_only']
        evpn_interconnect_group_id: str

    class GenEvpnInterconnectVirtualNetworkSpec(t.TypedDict):
        l2: bool
        l3: bool
        translation_vni: int | None
        extra_import_rts: list[str] | None
        extra_export_rts: list[str] | None

    class GenEvpnInterconnectSecurityZoneSpec(t.TypedDict):
        routing_policy_id: str
        interconnect_route_target: str
        enabled_for_l3: bool

    class GenEvpnInterconnectGroupSpec(t.TypedDict):
        label: str
        interconnect_route_target: str
        remote_gateway_node_ids: list[tt.GraphNodeId] | None
        interconnect_virtual_networks: dict[tt.GraphNodeId, GenEvpnInterconnectVirtualNetworkSpec] | None
        interconnect_security_zones: dict[tt.GraphNodeId, GenEvpnInterconnectSecurityZoneSpec] | None
        interconnect_esi_mac: str | None

    class GenAaaServerSpec(t.TypedDict):
        label: str
        hostname: tt.HostName
        key: str
        auth_port: tt.PortNo | None
        acct_port: tt.PortNo | None
        server_type: str

    class GenFlowletReassignmentSpec(t.TypedDict):
        quality_delta: int | None
        probability_threshold: int | None

    class GenEgressQuantizationSpec(t.TypedDict):
        quantization_min: int | None
        quantization_max: int | None
        rate_weightage: int | None

    class GenFlowletOptionsSpec(t.TypedDict):
        inactivity_interval: int | None
        flowset_table_size: tt.LBPolicyFlowsetTableSize | None
        reassignment: GenFlowletReassignmentSpec | None


    class GenLoadBalancingDLBPolicySpec(t.TypedDict):
        dlb_mode: tt.LBPolicyDLBMode
        flowlet_options: GenFlowletOptionsSpec | None
        egress_quantization: GenEgressQuantizationSpec | None
        glb_options: GenLoadBalancingGLBPolicySpec | None
        sampling_rate: int | None

    class GenLoadBalancingGLBPolicySpec(t.TypedDict):
        glb_mode: tt.LBPolicyGLBMode
        msg_tx_interval: int | None
        monitor_interval: int | None
        update_interval: int | None

    class GenLoadBalancingPolicySpec(t.TypedDict):
        label: str
        mode: tt.LBPolicyMode
        dlb_options: GenLoadBalancingDLBPolicySpec | None
        policy_type: tt.LBPolicyPolicyType

    GenLoadBalancingPolicyAssignmentSpec: t.TypeAlias = t.Mapping[
        tt.GraphNodeId, list[tt.GraphNodeId]]

LOGGER: t.Final[logging.Logger] = logging.getLogger(__name__)

DEFAULT_ROUTING_POLICY_DESCRIPTION: t.Final[str] = \
    'Associated with routing zones by default, cannot be updated or deleted.'


class LeafGenericLinkGroupInfo(t.NamedTuple):
    leaf_type_idx: int
    generic_system_group_idx: int
    link_idx: int
    leaf_peer_idx: int


class LeafAccessLinkGroupInfo(t.NamedTuple):
    leaf_type_idx: int
    access_switch_type_idx: int
    link_idx: int
    leaf_peer_idx: int


class AccessGenericLinkGroupInfo(t.NamedTuple):
    access_switch_type_idx: int
    generic_system_group_idx: int
    link_idx: int
    access_switch_peer_idx: int


class RackSystemsDistribution(t.NamedTuple):
    leaf_generic: t.MutableMapping[LeafGenericLinkGroupInfo, int]
    leaf_access: t.MutableMapping[LeafAccessLinkGroupInfo, int]
    access_generic: t.MutableMapping[AccessGenericLinkGroupInfo, int]


class LeafUplinks(t.NamedTuple):
    count: int  # type: ignore[assignment]
    speed: tt.PortSpeed
    links_per_neighbor: int
    neighbors_count: int
    type: str


NOT_ENOUGH_PORTS_FOR_MESH_LINKS_ERROR: t.Final[str] = (
    'Not enough {} ports on leaf to connect {} mesh links per leaf, for total of '
    '{} mesh links to {} leafs.')

NOT_ENOUGH_PORTS_FOR_LINKS_ERROR: t.Final[str] = (
    'Not enough {} ports on {} to connect {} links per system, for total of {} '
    'links to {} systems.')

connector_type_to_max_speed: t.Mapping[str, tt.PortSpeedValue] = {
    '10GBaseT': 10,
    'rj45-1g': 1,
    'sfp': 10,
    'sfp28': 25,
    'qsfp': 40,
    'qsfp28': 100,
    'sfpdd': 100,
    'mxp': 100,
    'cfp': 100,
    'cfp2': 100,
    'cfp4': 100,
    'cxp': 100,
    '1GBaseT': 1,
    'rj45': 10,
    'rj45-10g': 10,
    'qsfp+': 40,
    'qsfp100': 100,
    'qsfp56': 200,
    'qsfp56dd': 400,
    'qsfpdd': 800,
    'sfp+': 40,
    'osfp': 800,
    'sfp56': 50,
    'sfp56dd': 200,
}


def get_supported_connector_types() -> list[str]:
    return list(connector_type_to_max_speed)


def get_connector_max_speed(connector_type: str) -> tt.PortSpeedValue | None:
    return connector_type_to_max_speed.get(connector_type)


def get_supported_speeds() -> list[tt.PortSpeed]:
    return [
        {"value": 10,  "unit": "M"},
        {"value": 100, "unit": "M"},
        {"value": 1,   "unit": "G"},
        {"value": 5,   "unit": "G"},
        {"value": 10,  "unit": "G"},
        {"value": 25,  "unit": "G"},
        {"value": 40,  "unit": "G"},
        {"value": 50,  "unit": "G"},
        {"value": 100, "unit": "G"},
        {"value": 200, "unit": "G"},
        {"value": 400, "unit": "G"},
        {"value": 800, "unit": "G"},
    ]


def groupby(
    key: t.Callable[[T], tsd.SupportsRichComparisonT],
    items: t.Sequence[T]
) -> itertools.groupby[tsd.SupportsRichComparisonT, T]:
    """
    Returns items grouped by results of given key func.
    """
    return itertools.groupby(sorted(items, key=key), key)


def dict_merge(
    d1: tsd.SupportsKeysAndGetItem[str, T],
    d2: t.Mapping[str, V]
) -> dict[str, T | V]:
    """Merge two dictionaries into one. Last one takes precedence"""
    return dict(d1, **d2)


def gen_asn_pool(
    name: str,
    ranges: t.Optional[t.Iterable[tuple[int, int]]] = None,
    tags: t.Optional[list[tt.Tag]] = None
) -> GenAsnPoolSpec:
    """Returns JSON for ASN Pool

       Example ASN Pool with 1 range 65412-65534

       gen_asn_pool(
           'asn_pool_name',
           [
                {'first': 65412, 'last': 65534},
           ],
           ['tag1', 'tag2']
       )
    """
    def create_ranges(groups: t.Iterable[tuple[int, int]]) -> list[PoolRange]:
        """ converts [ (first, last), (first, last) ] to dictionary """
        return [{'first': r[0], 'last': r[1]} for r in groups]

    rv = compact_dict({
        'display_name': name,
        'id': name,
        'ranges': create_ranges(ranges or []),
        'tags': tags or [],
    })
    if t.TYPE_CHECKING:
        return t.cast(GenAsnPoolSpec, rv)
    return rv


def gen_ip_pool(
    name: t.Optional[str] = None,
    subnets: t.Optional[list[tt.IPNetwork]] = None,
    tags: t.Optional[list[tt.Tag]] = None,
    display_name: t.Optional[str] = None,
) -> GenIpPoolSpec:
    """ Returns JSON for IP Pool

        Example IP Pool with 2 ranges 192.168.0.0/16 and 10.0.0.0/8

        gen_ip_pool(
            'ip_pool_name',
            [
                '192.168.0.0/16',
                '10.0.0.0/8'
            ],
            'tag1'
        )
    """
    if name is None:
        name = gen_id()

    rv = compact_dict({
        'id': name,
        'display_name': display_name or name,
        'subnets': [{'network': n} for n in subnets or ()],
        'tags': tags or [],
    })
    if t.TYPE_CHECKING:
        return t.cast(GenIpPoolSpec, rv)
    return rv


def gen_telemetry_service_registry(
    name: t.Optional[str] = None,
    version: t.Optional[str] = None,
    storage_schema_path: t.Optional[str] = None,
    description: t.Optional[str] = None,
    application_schema: t.Optional[dict] = None
) -> GenTelemetryServiceRegistrySpec:
    """ Returns body dictionary for service registry entry by specifying
    the application schema, the storage schema path and version
        Example:
            {
                "service_name": "name",
                "version": "version no",
                "storage_schema_path": "aos.sdk.telemetry.schemas.generic",
                "description": "description_field",
                "application_schema": {}
            }
    """
    if name is None:
        name = gen_id()
    rv = compact_dict({
        'service_name': name,
        'version': version or '',
        'storage_schema_path': storage_schema_path,
        'description': description or name,
        'application_schema': application_schema or {}
    })
    if t.TYPE_CHECKING:
        return t.cast(GenTelemetryServiceRegistrySpec, rv)
    return rv


def gen_property_sets(
    name: t.Optional[str] = None,
    values: t.Optional[t.Any] = None
) -> GenPropertySetsSpec:
    """
    Returns JSON for Property sets
    Example property_sets:
    gen_property_sets(
            "values": 3,
            "label": "name"
        )
    """
    if name is None:
        name = gen_id()
    if values is None:
        values = 1
    return {
        "values": {"additionalProp{}".format(i): str(i) for i in range(values)},
        "label": name
    }


def gen_blueprint(
    name: t.Optional[str] = None,
    template_id: t.Optional[str] = None
) -> GenBlueprintSpec:
    if name is None:
        name = gen_id()
    return {
        "design": "two_stage_l3clos",
        "init_type": "template_reference",
        "label": name,
        "template_id": template_id
    }


def gen_agent_profiles(name: t.Optional[str] = None) -> GenAgentProfilesSpec:
    if name is None:
        name = gen_id()
    return {
        "open_options":{},
        "label": name
    }


def gen_external_router(
    name: str,
    loopback_ip: tt.IPv4Address,
    asn: tt.ASN,
    loopback_ipv6: t.Optional[tt.IPv6Address] = None,
    tags: t.Optional[list[tt.Tag]] = None
) -> GenExternalRouterSpec:
    rv = compact_dict({
        'id': name or gen_id(),
        'display_name': name,
        'address': loopback_ip,
        'ipv6_address': loopback_ipv6,
        'asn': asn,
        'tags': tags or []
    })
    if t.TYPE_CHECKING:
        return t.cast(GenExternalRouterSpec, rv)
    return rv


def gen_syslogs(
    protocol: tt.NetworkProtocol,
    facility: tt.SyslogFacility,
    address: tt.IPAddress,
    port: tt.PortNo,
    timezone: tt.Timezone = 'UTC'
) -> GenSyslogsSpec:
    """ Returns JSON for syslogs
        gen_syslog(
        'address':'11.33.10.1',
        port: 514,
        'protocol': 'tcp',
        'facility': 'user',
        'timezone': 'US/Pacific'
        )
        """
    return {
        'address': address,
        'port': port,
        'protocol': protocol,
        'facility': facility,
        'timezone': timezone,
    }



def gen_providers(
    name: str,
    fqdn: tt.HostName | tt.IPAddress,
    l4_port: tt.PortNo
) -> GenProvidersSpec:
    # Requires rework after discussion with Alessandro
    rv = compact_dict({
        'vendor': 'LDAP',
        'hostname_fqdn_ip': fqdn,
        'encryption': "None",
        'provider_name': name or gen_id(),
        'port': l4_port,
        'groups_search_dn': 'CN=Users,CN=Builtin,DC=MyDomain,DC=com',
        'users_search_dn': 'CN=Users,CN=Builtin,DC=MyDomain,DC=com'
    })
    if t.TYPE_CHECKING:
        return t.cast(GenProvidersSpec, rv)
    return rv


def gen_auth_provider_tacacs(
    name: str,
    hostnames_or_ips: list[tt.HostName | tt.IPAddress],
    shared_key: str,
    auth_mode: str,
    active: bool = False,
    port: tt.PortNo = 49
) -> GenAuthProviderTACACSSpec:
    return {
        'provider_name': name,
        'vendor': 'TACACS+',
        'hostname_fqdn_ip': hostnames_or_ips,
        'port': port,
        'shared_key': shared_key,
        'auth_mode': auth_mode,
        'active': active,
    }


def gen_cluster(
    name: t.Optional[str] = None,
    tags: t.Optional[list[tt.Tag]] = None,
    address: t.Optional[tt.IPAddress] = None,
    username: t.Optional[str] = None,
    password: t.Optional[str] = None
) -> GenClusterSpec:
    """
    :return: {"ranges":[{}],"label":"an_label","tags":["iba","offbox"],
                "address":"10.10.10.10","username":"username","password":"password"}
    """
    rv: dict = compact_dict({
        'label': name or gen_id(),
        'tags': tags or [],
        'address': address,
        'username': username,
        'password': password,
        "ranges": [{}],
    })
    if t.TYPE_CHECKING:
        return t.cast(GenClusterSpec, rv)
    return rv


def gen_port_setting(
    param: str = '{}',
    setting_type: t.Optional[str] = None,
) -> GenPortSettingSpec:
    """setting_type not used for AOS versions >= 2.2"""
    rv = compact_dict({
        'type': setting_type,
        'param': param,
    })
    if t.TYPE_CHECKING:
        return t.cast(GenPortSettingSpec, rv)
    return rv


def gen_streaming_config(
    hostname: tt.HostName | tt.IPv4Address, # not allowing IPv6 yet
    port: tt.PortNo,
    streaming_type: t.Literal['perfmon', 'events', 'alerts'],
    sequencing_mode: t.Literal['unsequenced', 'sequenced'],
    tls_enabled: t.Optional[bool] = False,
    tls_bypass_validation: t.Optional[bool] = False,
    tls_trusted_certificate_ids: t.Optional[list[str]] = None,
) -> GenStreamConfigSpec:
    # due to AOS-38338 'port' type needs to be integer
    rv: dict = compact_dict({
        'protocol': 'protoBufOverTcp',
        'hostname': hostname,
        'port': port,
        'streaming_type': streaming_type,
        'sequencing_mode': sequencing_mode,
        'tls_enabled': tls_enabled,
        'tls_bypass_validation': tls_bypass_validation,
        'tls_trusted_certificate_ids': tls_trusted_certificate_ids or [],
    })
    if t.TYPE_CHECKING:
        return t.cast(GenStreamConfigSpec, rv)
    return rv


def gen_streaming_certificate(
    label: str,
    pem_b64: str,
    description: t.Optional[str] = None,
) -> GenStreamCertSpec:
    rv: dict = compact_dict({
        'label': label,
        'pem_b64': pem_b64,
        'description': description or '',
    })
    if t.TYPE_CHECKING:
        return t.cast(GenStreamCertSpec, rv)
    return rv


def gen_hcl_hw_caps(
    userland: int = 32,
    form_factor: str = '1RU',
    ecmp_limit: int = 64,
    asic: str = 'T2',
    cpu: str = 'x86',
    ram: int = 16
) -> GenHclHwCapsSpec:
    rv = compact_dict({
        'userland': userland,
        'form_factor': form_factor,
        'ecmp_limit': ecmp_limit,
        'asic': asic,
        'cpu': cpu,
        'ram': ram,
    })
    if t.TYPE_CHECKING:
        return t.cast(GenHclHwCapsSpec, rv)
    return rv


def gen_hcl_sw_caps(
    onie: bool = False,
    lxc: bool = False,
    config_apply_support: str = 'complete_only',
) -> GenHclSwCapsSpec:
    rv = compact_dict({
        'onie': onie,
        'lxc_support': lxc,
        'config_apply_support': config_apply_support
    })
    if t.TYPE_CHECKING:
        return t.cast(GenHclSwCapsSpec, rv)
    return rv


def gen_dp_ref_design_caps(
    freeform: tt.RefDesignCaps = 'full_support',
    datacenter: tt.RefDesignCaps = 'full_support'
) -> GenDpRefDesignCapsSpec:
    rv = compact_dict({
        'freeform': freeform,
        'datacenter': datacenter
    })
    if t.TYPE_CHECKING:
        return t.cast(GenDpRefDesignCapsSpec, rv)
    return rv


def gen_logical_device(
    name: str,
    panels: list[list[t.Tuple[int, tt.PortSpeedValue | tt.PortSpeed, list[str]]]],
    display_name: t.Optional[str] = None,
    order: t.Optional[t.Literal['L-R, T-B', 'T-B, L-R']] = None,
    row_count: t.Optional[int] = None,
) -> GenLogicalDeviceSpec:
    """
    Returns JSON for logical device.

    :param name - logical device name
    :param panels - list of lists of tuples (count, speed, roles)
    :param display_name - display name
    :param order - one of ('L-R, T-B', 'T-B, L-R')

    Example:

        gen_logical_device(
            'AOS-48x10_6x40',
            [
                [(48, 10, ['generic'])],
                [(6, 40, ['spine'])],
            ]
        )
        # logical device with two panels
    """

    def make_port_group(
        group: tuple[int, tt.PortSpeedValue | tt.PortSpeed, list[str]]
    ) -> GenLogicalDevicePanelPortGroupSpec:
        count, speed, roles = group
        return {
            'count': count,
            'speed': normalize_port_speed(speed),
            'roles': roles,
        }

    def make_panel(
        panel: list[tuple[int, tt.PortSpeedValue | tt.PortSpeed, list[str]]],
        row_count: int | None
    ) -> GenLogicalDevicePanelSpec:
        total_ports = sum([count for (count, _, _) in panel])  # pylint: disable=consider-using-generator
        row_count = row_count or (1 if total_ports % 2 == 1 else 2)
        return {
            'port_groups': [make_port_group(group) for group in panel],
            'port_indexing': {
                'schema': 'absolute',
                'order': order or 'L-R, T-B',
                'start_index': 1,
            },
            'panel_layout': {
                'row_count': row_count,
                'column_count': total_ports // row_count,
            }
        }

    return {
        'id': name,
        'display_name': display_name or name,
        'panels': [make_panel(panel, row_count) for panel in panels],
    }


def gen_transformation(
    transformation: tuple[
        int,
        tt.PortSpeedValue | tt.PortSpeed,
        int,
        tt.PortSpeedValue | tt.PortSpeed
    ]
) -> GenTransformationSpec:
    from_count, from_speed, to_count, to_speed = transformation
    return {
        'from_count': from_count,
        'from_speed': normalize_port_speed(from_speed),
        'to_count': to_count,
        'to_speed': normalize_port_speed(to_speed),
    }


def gen_interface_map(
    name: t.Optional[str] = None,
    intf_mappings: t.Optional[list[tuple[
        int,
        int,
        tt.PortSpeedValue,
        tt.PortSpeedUnit,
        list[str]
    ]]] = None,
) -> GenInterfaceMapSpec:
    if name is None:
        name = gen_id()
    if intf_mappings is None:
        intf_mappings = [(1, 1, 10, "G", ["leaf", "access"]),
                         (2, 2, 10, "G", ["leaf", "access"])]
    total_intf_count = 7
    intf_mapping_list: list[GenInterfaceMapIntfMappingSpec] = []
    for intf_id in range(total_intf_count):
        roles = intf_mappings[intf_id][4] if intf_id < len(intf_mappings) else ["unused"]
        if not isinstance(roles, list):
            roles = [roles]

        intf_mapping_dict: GenInterfaceMapIntfMappingSpec = {
            "name": "Ethernet" + str(intf_id + 1),
            "state": "active",
            "roles": roles,
            "position": intf_id + 1,
            "speed": {
                "value": intf_mappings[intf_id][2] if intf_id < len(intf_mappings) else 10,
                "unit": intf_mappings[intf_id][3] if intf_id < len(intf_mappings) else "G"},
            "setting": {
                "param": ""
            },
            "mapping":
                [intf_mappings[intf_id][0], 1, 1, 1, intf_mappings[intf_id][1]]
                if intf_id < len(intf_mappings) else [intf_id + 1, 1, 1, None, None]
        }
        intf_mapping_list.append(intf_mapping_dict)

    return {
        "label": name,
        "interfaces": intf_mapping_list,
        "device_profile_id": "Arista_vEOS",
        "logical_device_id": "AOS-2x10-1"
    }


def gen_system_agents(management_ip: tt.IPAddress) -> GenSystemAgentsSpec:
    return {
        "management_ip": management_ip,
        "agent_type": "onbox",
        "username": "admin",
        "password": "admin",
        "operation_mode": "full_control",
        "open_options": {}
    }


def gen_blueprint_configlet(
    display_name: str,
    condition: str,
    generators: t.Iterable[GenBlueprintConfigletConfigletGeneratorSpec]
) -> GenBlueprintConfigletSpec:
    return {
        'condition': condition,
        'configlet': {
            'display_name': display_name,
            'generators': [generator for generator in generators]
        },
        #display_name is defaulted to label for now
        'label': display_name,
    }


def make_configlet_generator(
    config_style: str,
    section: str,
    template_text: str,
    negation_template_text: str,
    section_condition: t.Optional[str] = None,
    filename: t.Optional[str] = None
) -> GenBlueprintConfigletConfigletGeneratorSpec:
    """Creates API payload for a configlet generator to be included in one of:

       1. Global catalog configlet's 'generators' list
       2. Blueprint configlet CRUD facade request payloads

       When used for creating the payload for a global configlet, section_condition
       argument must be None because it is not defined for global configlets.
    """
    rv = compact_dict({
        'config_style': config_style,
        'template_text': template_text,
        'section': section,
        'negation_template_text': negation_template_text,
        'section_condition': section_condition,
        'filename': filename,
    })
    if t.TYPE_CHECKING:
        return t.cast(GenBlueprintConfigletConfigletGeneratorSpec, rv)
    return rv


def gen_configlet(
    display_name: str,
    generators: t.Optional[list[GenBlueprintConfigletConfigletGeneratorSpec]] = None,
    ref_archs: t.Optional[list[tt.RefDesign]] = None
) -> GenConfigletSpec:
    if generators is None:
        generators = [
            make_configlet_generator('eos', 'system',
                                     'ntp server vrf management 10.0.0.1',
                                     'no ntp server vrf management 10.0.0.1')
        ]
    if ref_archs is None:
        ref_archs = ['two_stage_l3clos']
    return {
        'ref_archs': ref_archs,
        'generators': generators,
        'display_name': display_name,
    }


def gen_tag(name: t.Optional[str] = None,
            label: str = 'Tag Label',
            description: str = 'Description',
            created_at: tt.ISOTimestamp = '1970-01-01T00:00:00Z',
            last_modified_at: tt.ISOTimestamp = '1970-01-01T00:00:00Z') -> GenTagSpec:
    return {
        'id': name or gen_id(),
        'label': label,
        'description': description,
        'created_at': created_at,
        'last_modified_at': last_modified_at}


AOS_32x40: t.Final = gen_logical_device(
    'AOS-32x40',
    [
        [(32, 40, ['leaf', 'superspine'])],
    ]
)
AOS_32x40_superspine: t.Final = gen_logical_device(
    'AOS-32x40_superspine',
    [
        [(32, 40, ['spine'])],
    ]
)
AOS_48x10_6x40: t.Final = gen_logical_device(
    'AOS-48x10_6x40',
    [
        [(48, 10, ['access', 'generic', 'leaf'])],
        [(6, 40, ['spine', 'peer'])],
    ]
)
AOS_6x10_access_switch: t.Final = gen_logical_device(
    'AOS-6x10_access_switch',
    [
        [(6, 10, ['leaf', 'generic', 'peer'])],
    ]
)
AOS_20x10_access_switch: t.Final = gen_logical_device(
    'AOS-20x10_access_switch',
    [
        [(20, 10, ['leaf', 'generic', 'peer'])],
    ]
)
AOS_1x10: t.Final = gen_logical_device(
    'AOS-1x10',
    [
        [(1, 10, ['leaf', 'access'])],
    ]
)


def get_links_per_node(node_count: int, link_count: int) -> int:
    if node_count >= link_count:
        return 1
    links_per_node = 2
    ans = link_count
    while links_per_node * links_per_node <= link_count \
            and links_per_node <= node_count:
        nodes = link_count // links_per_node
        if links_per_node * nodes == link_count:
            if nodes <= node_count:
                return links_per_node
            ans = nodes
        links_per_node += 1
    return ans


def gen_rack_type_access_switch_uplink(
    label: str = 'link',
    target_switch_label: str = 'leaf',
    link_per_switch_count: int = 1,
    link_speed: tt.PortSpeedValue | tt.PortSpeed = 10,
    attachment_type: tt.LagAttachmentType = 'singleAttached',
    switch_peer: t.Optional[str] = None,
    tags: t.Optional[list[tt.Tag]] = None,
    rail_index: tt.RailIndex | None = None
) -> GenRackTypeAccessSwitchUplinkSpec:
    return {
        'label': label,
        'target_switch_label': target_switch_label,
        'link_per_switch_count': link_per_switch_count,
        'link_speed': normalize_port_speed(link_speed),
        'attachment_type': attachment_type,
        'switch_peer': switch_peer,
        'tags': tags or [],
        'lag_mode': 'lacp_active',
        # rail index is not currently applicable for access switches links
        # (only to leaf-generic links), but the schema is one for both
        'rail_index': rail_index,
    }


def gen_rack_type_server_link(
    label: str = 'link',
    target_switch_label: str = 'leaf',
    link_per_switch_count: int = 1,
    link_speed: tt.PortSpeedValue | tt.PortSpeed = 10,
    attachment_type: tt.LagAttachmentType = 'singleAttached',
    switch_peer: t.Optional[str] = None,
    lag_mode: t.Optional[tt.LagMode] = None,
    tags: t.Optional[list[tt.Tag]] = None,
    rail_index: tt.RailIndex | None = None
) -> GenRackTypeServerLinkSpec:
    return {
        'label': label,
        'target_switch_label': target_switch_label,
        'link_per_switch_count': link_per_switch_count,
        'link_speed': normalize_port_speed(link_speed),
        'attachment_type': attachment_type,
        'switch_peer': switch_peer,
        'lag_mode': lag_mode,
        'tags': tags or [],
        'rail_index': rail_index,
    }


def gen_rack_type_access_switch(
    label: str = 'access',
    logical_device: GenLogicalDeviceSpec = AOS_6x10_access_switch,
    instance_count: int = 1,
    links: t.Optional[list[GenRackTypeAccessSwitchUplinkSpec]] = None,
    access_access_link_count: int = 0,
    access_access_link_speed: t.Optional[tt.PortSpeed | tt.PortSpeedValue] = None,
    redundancy_protocol: t.Optional[tt.RedundancyProtocol] = None,
    access_access_link_port_channel_id_min: int = 0,
    access_access_link_port_channel_id_max: int = 0,
    tags: t.Optional[list[tt.Tag]] = None
) -> GenRackTypeAccessSwitchSpec:
    if not links:
        links = [gen_rack_type_access_switch_uplink()]

    data: GenRackTypeAccessSwitchSpec = {
        'label': label,
        'logical_device': logical_device,
        'instance_count': instance_count,
        'links': links,
        'access_access_link_count': access_access_link_count,
        'access_access_link_speed': None,
        'access_access_link_port_channel_id_min': access_access_link_port_channel_id_min,
        'access_access_link_port_channel_id_max': access_access_link_port_channel_id_max,
        'redundancy_protocol': redundancy_protocol,
        'tags': tags or [],
    }
    if redundancy_protocol == 'esi':
        data['access_access_link_speed'] = normalize_port_speed(
            access_access_link_speed)  # type: ignore[arg-type]  # we have test that uses this

    return data


# FIXME: This function was used in deprecated ptest. Please consider cleanup.
def gen_rack_type_server(
    label: str = 'server',
    logical_device: GenLogicalDeviceSpec = AOS_1x10,
    connectivity_type: tt.ConnectivityType = 'l3',
    links: t.Optional[list[GenRackTypeServerLinkSpec]] = None,
    count: int = 1,
    ip_version: t.Literal['ipv4', 'ipv6'] = 'ipv4',
    port_channel_id_min: int = 0,
    port_channel_id_max: int = 0,
    lag_mode: t.Optional[tt.LagMode] = None
) -> GenRackTypeServerSpec:
    if not links:
        links = [gen_rack_type_server_link(lag_mode=lag_mode)]
    data = {
        'label': label,
        'logical_device': logical_device,
        'connectivity_type': connectivity_type,
        'ip_version': ip_version,
        'links': links,
        'count': count,
        'port_channel_id_min': port_channel_id_min,
        'port_channel_id_max': port_channel_id_max,
    }
    rv = compact_dict(data)
    if t.TYPE_CHECKING:
        return t.cast(GenRackTypeServerSpec, rv)
    return rv


def gen_rack_type_generic_system(
    label: str = 'generic',
    logical_device: GenLogicalDeviceSpec = AOS_1x10,
    links: t.Optional[list[GenRackTypeServerLinkSpec]] = None,
    count: int = 1,
    port_channel_id_min: int = 0,
    port_channel_id_max: int = 0,
    lag_mode: t.Optional[tt.LagMode] = None,
    management_level: tt.ManagementLevel = 'unmanaged',
    loopback: tt.EnabledDisabled = 'disabled',
    asn_domain: tt.EnabledDisabled = 'disabled',
    tags: t.Optional[list[tt.Tag]] = None
) -> GenRackTypeGenericSystemSpec:
    if not links:
        links = [gen_rack_type_server_link(lag_mode=lag_mode)]
    return {
        'label': label,
        'logical_device': logical_device,
        'links': links,
        'count': count,
        'management_level': management_level,
        'port_channel_id_min': port_channel_id_min,
        'port_channel_id_max': port_channel_id_max,
        'loopback': loopback,
        'asn_domain': asn_domain,
        'tags': tags or [],
    }


def gen_external_router_link(
    count: int = 1,
    speed: tt.PortSpeedValue | tt.PortSpeed = 10
) -> GenExternalRouterLinkSpec:
    return {
        'count': count,
        'speed': normalize_port_speed(speed)
    }


def gen_rack_type_leaf(
    label: str = 'leaf',
    logical_device: GenLogicalDeviceSpec = AOS_48x10_6x40,
    link_per_spine_count: int = 1,
    link_per_spine_speed: t.Optional[tt.PortSpeedValue | tt.PortSpeed] = 40,
    leaf_leaf_link_count: int = 0,
    leaf_leaf_link_speed: t.Optional[tt.PortSpeedValue | tt.PortSpeed] = 40,
    leaf_leaf_l3_link_count: int = 0,
    leaf_leaf_l3_link_speed: t.Optional[tt.PortSpeedValue | tt.PortSpeed] = 40,
    redundancy_protocol: t.Optional[tt.RedundancyProtocol] = None,
    leaf_leaf_link_port_channel_id: int = 0,
    leaf_leaf_l3_link_port_channel_id: int = 0,
    mlag_vlan_id: int = 0,
    tags: t.Optional[list[tt.Tag]] = None
) -> GenRackTypeLeafSpec:
    data: GenRackTypeLeafSpec = {
        'label': label,
        'logical_device': logical_device,
        'link_per_spine_count': link_per_spine_count,
        'link_per_spine_speed': normalize_port_speed(
            link_per_spine_speed) if link_per_spine_speed else None,
        'leaf_leaf_link_count': leaf_leaf_link_count,
        'leaf_leaf_link_speed': None,
        'leaf_leaf_l3_link_count': leaf_leaf_l3_link_count,
        'leaf_leaf_l3_link_speed': None,
        'leaf_leaf_link_port_channel_id': leaf_leaf_link_port_channel_id,
        'leaf_leaf_l3_link_port_channel_id': leaf_leaf_l3_link_port_channel_id,
        'mlag_vlan_id': mlag_vlan_id,
        'redundancy_protocol': redundancy_protocol,
        'tags': tags or [],
    }
    if redundancy_protocol == 'mlag':
        data.update({'leaf_leaf_link_speed': normalize_port_speed(
            leaf_leaf_link_speed)})
        if leaf_leaf_l3_link_count > 0:
            data.update({'leaf_leaf_l3_link_speed': normalize_port_speed(
                leaf_leaf_l3_link_speed)})
        data['mlag_vlan_id'] = data['mlag_vlan_id'] or 2999

    return data


def gen_spine_type(
    logical_device: t.Optional[GenLogicalDeviceSpec] = None,
    count: int = 2,
    link_per_superspine_count: int = 0,
    link_per_superspine_speed: t.Optional[tt.PortSpeedValue | tt.PortSpeed] = None,
    tags: t.Optional[list[tt.Tag]] = None
) -> GenSpineTypeSpec:
    if logical_device is None:
        logical_device = AOS_32x40

    params: GenSpineTypeSpec = {
        'logical_device': logical_device,
        'count': count,
        'tags': tags or []
    }

    if link_per_superspine_count:
        link_per_superspine_speed = normalize_port_speed(
            link_per_superspine_speed or port_speed(40))
        params.update({
            'link_per_superspine_count': link_per_superspine_count,
            'link_per_superspine_speed': link_per_superspine_speed,
        })

    rv = compact_dict(params)
    if t.TYPE_CHECKING:
        return t.cast(GenSpineTypeSpec, rv)
    return rv


def gen_rack_type(
    name: t.Optional[str] = None,
    leafs: t.Optional[t.Iterable[GenRackTypeLeafSpec]] = None,
    access_switches: t.Optional[t.Iterable[GenRackTypeAccessSwitchSpec]] = None,
    generic_systems: t.Optional[t.Iterable[GenRackTypeGenericSystemSpec]] = None,
    logical_devices: t.Optional[list[GenLogicalDeviceSpec]] = None,
    display_name: t.Optional[str] = None,
    description: t.Optional[str] = None,
    fabric_connectivity_design: tt.FabricConnectivityDesign = 'l3clos',
    tags: t.Optional[list[tt.Tag]] = None,
    preferences: t.Optional[dict] = None,
) -> GenRackTypeSpec:
    # Restriction of 24Char is due to NXOS hostname limitation. (PR4476)
    if not name or len(name) > 24:
        name = gen_short_id()
    leafs = leafs or [gen_rack_type_leaf()]
    access_switches = access_switches or []
    if generic_systems is None:
        generic_systems = [
            gen_rack_type_generic_system(logical_device=AOS_1x10, count=10)
        ]
    logical_devices = logical_devices or []

    # Filter out duplicating logical devices
    ld_ids = set(ld['id'] for ld in logical_devices)
    for system in list(leafs) + list(generic_systems) + list(access_switches):
        if isinstance(system['logical_device'], dict):
            if system['logical_device']['id'] not in ld_ids:
                ld_ids.add(system['logical_device']['id'])
                logical_devices.append(system['logical_device'])

    def convert_logical_devices_to_ids(node):
        if isinstance(node['logical_device'], dict):
            return dict(node, logical_device=node['logical_device']['id'])
        return node

    name = t.cast(str, name)

    return {
        'id': name,
        'display_name': display_name or name[:17],
        'description': description or '',
        'fabric_connectivity_design': fabric_connectivity_design,
        'leafs': list(map(convert_logical_devices_to_ids, leafs)),
        'access_switches': list(map(convert_logical_devices_to_ids, access_switches)),
        'generic_systems': list(map(convert_logical_devices_to_ids, generic_systems)),
        'logical_devices': copy.deepcopy(logical_devices),
        'tags': tags or [],
        'preferences': preferences or {},
    }


def gen_l3_collapsed_rack_type_leaf(
    label: str = 'leaf',
    logical_device: GenLogicalDeviceSpec = AOS_48x10_6x40,
    link_per_spine_count: int = 1,
    link_per_spine_speed: tt.PortSpeedValue | tt.PortSpeed = 40,
    leaf_leaf_link_count: int = 0,
    leaf_leaf_link_speed: tt.PortSpeedValue | tt.PortSpeed = 40,
    leaf_leaf_l3_link_count: int = 0,
    leaf_leaf_l3_link_speed: tt.PortSpeedValue | tt.PortSpeed = 40,
    redundancy_protocol: t.Optional[tt.RedundancyProtocol] = None,
    leaf_leaf_link_port_channel_id: int = 0,
    leaf_leaf_l3_link_port_channel_id: int = 0,
    mlag_vlan_id: int = 0,
    tags: t.Optional[list[tt.Tag]] = None
) -> GenRackTypeLeafSpec:
    return gen_rack_type_leaf(
        label=label,
        logical_device=logical_device,
        link_per_spine_count=0,
        link_per_spine_speed=None,
        leaf_leaf_link_count=leaf_leaf_link_count,
        leaf_leaf_link_speed=leaf_leaf_link_speed,
        leaf_leaf_l3_link_count=leaf_leaf_l3_link_count,
        leaf_leaf_l3_link_speed=leaf_leaf_l3_link_speed,
        redundancy_protocol=redundancy_protocol,
        leaf_leaf_link_port_channel_id=leaf_leaf_link_port_channel_id,
        leaf_leaf_l3_link_port_channel_id=leaf_leaf_l3_link_port_channel_id,
        mlag_vlan_id=mlag_vlan_id,
        tags=tags,
    )


def gen_rail_collapsed_rack_type_leaf(
    label: str = 'leaf',
    # TODO: consider different LD (specific to rail-optimized)
    logical_device: GenLogicalDeviceSpec = AOS_48x10_6x40,
    link_per_spine_count: int = 0,
    link_per_spine_speed: t.Optional[tt.PortSpeedValue | tt.PortSpeed] = None,
    leaf_leaf_link_count: int = 0,
    leaf_leaf_link_speed: t.Optional[tt.PortSpeedValue | tt.PortSpeed] = None,
    leaf_leaf_l3_link_count: int = 0,
    leaf_leaf_l3_link_speed: t.Optional[tt.PortSpeedValue | tt.PortSpeed] = None,
    redundancy_protocol: t.Optional[tt.RedundancyProtocol] = None,
    leaf_leaf_link_port_channel_id: int = 0,
    leaf_leaf_l3_link_port_channel_id: int = 0,
    mlag_vlan_id: int = 0,
    tags: t.Optional[list[tt.Tag]] = None
) -> GenRackTypeLeafSpec:
    return gen_rack_type_leaf(
        label=label,
        logical_device=logical_device,
        link_per_spine_count=0,
        link_per_spine_speed=None,
        leaf_leaf_link_count=0,
        leaf_leaf_link_speed=None,
        leaf_leaf_l3_link_count=0,
        leaf_leaf_l3_link_speed=None,
        redundancy_protocol=None,
        leaf_leaf_link_port_channel_id=0,
        leaf_leaf_l3_link_port_channel_id=0,
        mlag_vlan_id=0,
        tags=tags,
    )


def gen_l3_collapsed_rack_type(
    name: t.Optional[str] = None,
    leafs: t.Optional[list[GenRackTypeLeafSpec]] = None,
    access_switches: t.Optional[list[GenRackTypeAccessSwitchSpec]] = None,
    generic_systems: t.Optional[list[GenRackTypeGenericSystemSpec]] = None,
    logical_devices: t.Optional[list[GenLogicalDeviceSpec]] = None,
    display_name: t.Optional[str] = None,
    description: t.Optional[str] = None,
    fabric_connectivity_design: tt.FabricConnectivityDesign = 'l3collapsed',
    tags: t.Optional[list[tt.Tag]] = None,
    preferences: t.Optional[dict] = None,
) -> GenRackTypeSpec:
    return gen_rack_type(
        name=name,
        leafs=[gen_l3_collapsed_rack_type_leaf()] if leafs is None else leafs,
        access_switches=access_switches,
        generic_systems=generic_systems,
        logical_devices=logical_devices,
        display_name=display_name,
        description=description,
        fabric_connectivity_design='l3collapsed',
        tags=tags,
        preferences=preferences,
    )


def gen_rail_collapsed_rack_type(
    name: t.Optional[str] = None,
    leafs: t.Optional[list[GenRackTypeLeafSpec]] = None,
    access_switches: t.Optional[list[GenRackTypeAccessSwitchSpec]] = None,
    generic_systems: t.Optional[list[GenRackTypeGenericSystemSpec]] = None,
    logical_devices: t.Optional[list[GenLogicalDeviceSpec]] = None,
    display_name: t.Optional[str] = None,
    description: t.Optional[str] = None,
    fabric_connectivity_design: tt.FabricConnectivityDesign = 'rail_collapsed',
    tags: t.Optional[list[tt.Tag]] = None,
    preferences: t.Optional[dict] = None,
) -> GenRackTypeSpec:
    return gen_rack_type(
        name=name,
        leafs=[gen_rail_collapsed_rack_type_leaf()] if leafs is None else leafs,
        access_switches=None,
        generic_systems=generic_systems,
        logical_devices=logical_devices,
        display_name=display_name,
        description=description,
        fabric_connectivity_design='rail_collapsed',
        tags=tags,
        preferences=preferences,
    )


def gen_rail_collapsed_template(
    name: t.Optional[str] = None,
    rack_types: t.Optional[list[GenRackTypeSpec]] = None,
    rack_type_counts: t.Optional[dict | list[dict]] = None,
    dhcp_enabled: bool = True,
    display_name: t.Optional[str] = None,
    virtual_network_policy: t.Optional[GenVirtualNetworkPolicySpec] = None,
) -> GenRailCollapsedTemplateSpec:
    if rack_types is None:
        rack_types = [gen_rail_collapsed_rack_type('rack-1', leafs=[
            gen_rail_collapsed_rack_type_leaf()])]
    if rack_type_counts is None:
        rack_type_counts = {'rack-1': 1}
    return {
        'type': 'rail_collapsed',
        'id': name or gen_id(),
        'display_name': display_name or name or gen_id(),
        'rack_types': rack_types,
        'rack_type_counts': listify_counts(rack_type_counts),
        'dhcp_service_intent': {'active': dhcp_enabled},
        'virtual_network_policy': copy.deepcopy(
            virtual_network_policy or gen_virtual_network_policy(
                overlay_control_protocol=None)
        ),
    }


def get_ports_with_role(
    port_groups: list[GetPortsWithRolePortGroupSpec],
    roles: str | list[str],
    speed: tt.PortSpeed | None,
    order_roles: t.Optional[list[str]] = None,
) -> list[GetPortsWithRolePortGroupSpec]:
    """Returns list of port groups that match at least one of given roles
    and given speed. Results are ordered as follows: port_groups are
    ordered by number of roles from `order_roles` that they have,
    starting from no roles and up to all roles in `order_roles`.
    Port groups that have same number of roles, contained in
    `order_roles`, are ordered by position of roles in order_roles.
    E.g. if `order_roles` is [role1, role2], you will get port groups
    that have no role1 and no role2, then port groups that have only
    role1, than those that have only role2 and then those that have
    both role1 and role2."""
    if isinstance(roles, str):
        roles = [roles]

    if order_roles is None:
        order_roles = []

    def role_sort_key(port_group: GetPortsWithRolePortGroupSpec) -> list[int]:
        return [
            sum([1 for role in port_group['roles'] if role in order_roles])  # pylint: disable=consider-using-generator
        ] + [0 if role in port_group['roles'] else 1 for role in order_roles]

    result = sorted([port_group
                     for port_group in port_groups
                     if any(role in port_group['roles'] for role in roles) \
                     and port_group['speed'] == speed \
                     and port_group['count'] > 0],
                    key=role_sort_key)
    return result


def reserve_ports(
    port_groups: list[GetPortsWithRolePortGroupSpec],
    roles: str | list[str],
    speed: tt.PortSpeed | None,
    count: int,
    order_roles: t.Optional[list[str]] = None,
) -> tuple[bool, int]:
    """Iterates over matching port groups and reduces their port count
    until the number of reduced ports is equal to given count. Uses
    `order_roles` to try port groups that share given ports that share
    the required port roles, starting from those that have the smallest
    number of possible port roles to minimize consumption of ports that
    can satisfy other port role requirements."""
    for port_group in get_ports_with_role(port_groups, roles,
                                          speed, order_roles):
        if count <= port_group['count']:  # pylint: disable=no-else-break
            port_group['count'] -= count
            count = 0
            break
        else:
            count -= port_group['count']
            port_group['count'] = 0

    return count == 0, count


def _reserve_leaf_spine_links(
    leaf_idx: int,
    leaf: GenRackTypeLeafSpec | GenRackType_LeafsSpec,
    leaf_port_groups: list[GetPortsWithRolePortGroupSpec],
    spine_count: int,
    errors: lollipop.errors.ValidationErrorBuilder,
) -> None:
    leaf_spine_link_count = spine_count * leaf['link_per_spine_count']
    link_per_spine_speed = leaf.get('link_per_spine_speed')

    if not (leaf_spine_link_count and link_per_spine_speed):
        # This is valid case for L3Collapsed templates
        return

    success, _ = reserve_ports(leaf_port_groups,
                               roles='spine',
                               speed=link_per_spine_speed,
                               count=leaf_spine_link_count,
                               order_roles=['peer', 'access',
                                            'generic'])
    if leaf_spine_link_count and link_per_spine_speed and not success:
        errors.add_errors({'leafs': {leaf_idx: {
            'link_per_spine_count': (
                'Not enough uplink links with speed {} to connect {} '
                'links per spine, for total of {} links to {} spines.'.format(
                    format_speed(link_per_spine_speed),
                    leaf['link_per_spine_count'],
                    leaf_spine_link_count,
                    spine_count,
                )
            ),
        }}})


def _reserve_mesh_links(
    leaf_idx: int,
    leaf_port_groups: list[GetPortsWithRolePortGroupSpec],
    mesh_links: LeafUplinks,
    errors: lollipop.errors.ValidationErrorBuilder,
) -> None:
    success, _ = reserve_ports(leaf_port_groups,
                               roles='leaf',
                               speed=mesh_links.speed,
                               count=mesh_links.count,
                               order_roles=['peer', 'access',
                                            'generic'])
    if mesh_links.count and not success:
        errors.add_errors({'leafs': {leaf_idx: (
            NOT_ENOUGH_PORTS_FOR_MESH_LINKS_ERROR.format(
                format_speed(mesh_links.speed), mesh_links.links_per_neighbor,
                mesh_links.count, mesh_links.neighbors_count)
        )}})


def _reserve_uplinks(
    leaf_idx: int,
    leaf_port_groups: list[GetPortsWithRolePortGroupSpec],
    uplinks: LeafUplinks | None,
    errors: lollipop.errors.ValidationErrorBuilder,
) -> None:
    if not uplinks:
        return

    if uplinks.type == 'mesh':
        _reserve_mesh_links(leaf_idx, leaf_port_groups, uplinks, errors)


def rack_type_systems_distribution(
    leafs: list[GenRackType_LeafsSpec],
    access_switches: list[GenRackType_AccessSwitchesSpec],
    generic_systems: list[GenRackType_GenericSystemsSpec],
    logical_devices: dict[str, GenLogicalDeviceSpec],
    spine_count: int = 0,
    uplinks: t.Optional[LeafUplinks] = None,
) -> tuple[RackSystemsDistribution, dict[str, dict[str, str]], list[GenLogicalDeviceSpec]]:
    """Calculates distribution between rack leafs, access switches, generic systems

    Arguments:
        leafs: A list of dicts where each dict represents leaf parameters.
        access_switches: A list of dicts where each dict represents access switch
                        group parameters.
        generic_systems: A list of dicts where each dict represents
                         generic system group parameters, generic system links are
                         stored in the `links` parameter as a list of dicts.
        logical_devices: A mapping from logical devices IDs to logical
                         devices (dicts).
        spine_count: A total number of spines this rack type is connected to.
        uplinks: Different types of uplinks from leafs. Currently supported type is
                 mesh which represents connection in L3 Collapsed template
                 between each pair of leafs. mesh_links.count represent total
                 number of outgoing links for each leaf.

    Returns a 3 item tuple:
        1st field is a RackSystemsDistribution namedtuple where
            `leaf_generic` - is a mapping of LeafGenericLinkGroupInfo tuple with leaf
                index, generic system group index, link index and leaf peer index
                to number of generic systems to take from that group to connect leaf
                with that index through link with that index.
                (leaf_type_idx, generic_systems_group_idx, link_idx, leaf_peer_idx)
                -> generic_system_count

            `leaf_access` - is a mapping of LeafAccessLinkGroupInfo tuple with leaf
                index, access switch group index, link index and leaf peer index to
                number of access switches to take from that group to connect leaf
                with that index through link with that index.
                (leaf_type_idx, access_switch_type_idx, link_idx, leaf_peer_idx) ->
                access_switch_count

            'access_generic' - is a mapping of AccessGenericLinkGroupInfo tuple with
                access switch group index, generic systems group index, link index
                and access switch peer index to number of generic_systems from that
                group to connect each access switch from group with that index
                through link with that index.
                (access_switch_type_idx, generic_system_group_idx, link_idx,
                access_switch_peer_idx) -> generic_count
                Note that this will be different from leaf_generic: leaf_generic has
                single leaf index and server GROUP index, while here both
                access_switch and generic are GROUPS

        2nd field is a mapping of field name to field errors.

        3rd field is a list of leafs logical devices after distribution.
    """
    LOGGER.debug(
        'Rack type system distribution: %s leafs (leaf pairs), '
        '%s access switches (access pairs), %s generics, %s spines.',
        len(leafs), len(access_switches), len(generic_systems), spine_count)

    errors = ValidationErrorBuilder()

    def get_system_port_groups(system):
        return [
            {'speed': port_group['speed'],
             'count': port_group['count'],
             'roles': port_group['roles']}
            for panel in logical_devices[system['logical_device']]['panels']
            for port_group in panel['port_groups']
        ]

    def build_leaf_idx_to_access_switches():
        # make mapping from leafs/leaf-pairs to attached access switches
        # [leaf_idx][attachment_type] -> list of access switch indexes
        leaf_idx_to_access_switches = defaultdict(lambda: defaultdict(list))
        for access_switch_idx, access_switch in enumerate(access_switches):
            first_link = access_switch['links'][0]
            target_label = first_link['target_switch_label']
            attachment_type = first_link['attachment_type']
            leaf_idx = leaf_label_to_idx[target_label]

            if not leafs[leaf_idx].get('redundancy_protocol') and\
                attachment_type == 'dualAttached':
                errors.add_errors({'access_switches': {access_switch_idx: {'links': {
                    0: 'Dual attachment is allowed only for MLAG/ESI leafs'}}}})

            leaf_idx_to_access_switches[leaf_idx][attachment_type].append(
                access_switch_idx)

        return leaf_idx_to_access_switches

    access_switches_port_groups = {
        access_switch_idx: get_system_port_groups(access_switch)
        for access_switch_idx, access_switch in enumerate(access_switches)
    }

    # Generic system can be added to either ToR leafs or access switches,
    # but not both.
    distribution = RackSystemsDistribution(
        defaultdict(int), defaultdict(int), defaultdict(int))

    leaf_label_to_idx = {
        leaf['label']: idx
        for idx, leaf in enumerate(leafs)
    }
    access_switch_label_to_idx = {
        access_switch['label']: idx
        for idx, access_switch in enumerate(access_switches)
    }

    # mapping [leaf_idx][attachment_type][generic_system_idx] -> list of link indexes
    # of corresponding generic systems
    leaf_idx_to_generic_systems: \
        t.Mapping[int, t.Mapping[tt.LagAttachmentType, t.Mapping[int, list[int]]]] = \
        defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    # mapping [leaf_idx][attachment_type] -> list of access switch indexes
    leaf_idx_to_access_switches = build_leaf_idx_to_access_switches()
    # mapping [access_switch_idx][attachment_type][generic_system_idx] -> list of
    # link indexes of corresponding generic systems
    access_switch_idx_to_generic_systems: \
        t.Mapping[int, t.Mapping[tt.LagAttachmentType, t.Mapping[int, list[int]]]] = \
        defaultdict(lambda: defaultdict(lambda: defaultdict(list)))

    def process_dual_attached_access_switch_uplinks(leaf_idx, leaf_port_groups):
        for access_switch_idx in leaf_idx_to_access_switches[leaf_idx][
                'dualAttached']:
            access_switch = access_switches[access_switch_idx]
            # Access switches can have only single uplink group, thus link index is
            # always 0
            link_idx = 0
            instance_count = access_switch['instance_count']
            link = access_switches[access_switch_idx]['links'][link_idx]
            link_count = link['link_per_switch_count'] * instance_count
            esi_access_multiplier = \
                2 if access_switch['redundancy_protocol'] == 'esi' else 1
            success_leaf, _ = reserve_ports(
                leaf_port_groups,
                roles=['access'],
                speed=link['link_speed'],
                count=link_count * esi_access_multiplier,
            )
            success_access_switch, _ = reserve_ports(
                access_switches_port_groups[access_switch_idx],
                roles=['leaf'],
                speed=link['link_speed'],
                count=2 * link['link_per_switch_count'],
                order_roles=['leaf', 'peer', 'generic'],
            )

            if not (success_leaf and success_access_switch):
                # TODO: be more precise which type (access switch, leaf,
                #  both) has no enough ports
                errors.add_errors({'access_switches': {access_switch_idx: {
                    'links': {
                        link_idx: (
                            'Not enough {} ports on leaf/access switch to '
                            'connect {} links per access switch, for total '
                            'of {} links to {} access switches.'
                            .format(
                                format_speed(link['link_speed']),
                                link['link_per_switch_count'],
                                link_count,
                                instance_count,
                            )
                        ),
                    }
                }}})
                continue

            distribution.leaf_access[LeafAccessLinkGroupInfo(
                leaf_idx, access_switch_idx, link_idx, 0)] += instance_count
            distribution.leaf_access[LeafAccessLinkGroupInfo(
                leaf_idx, access_switch_idx, link_idx, 1)] += instance_count

    def process_single_attached_access_switch_uplinks(leaf_idx,
                                                      peer_leaf_port_groups):
        access_switch_idxs = leaf_idx_to_access_switches[leaf_idx]['singleAttached']
        for access_switch_idx in access_switch_idxs:
            access_switch = access_switches[access_switch_idx]
            link_idx = 0
            link = access_switches[access_switch_idx]['links'][link_idx]
            instance_count = access_switch['instance_count']
            success_access_switch, _ = reserve_ports(
                access_switches_port_groups[access_switch_idx],
                roles=['leaf'],
                speed=link['link_speed'],
                count=link['link_per_switch_count'],
                order_roles=['leaf', 'peer', 'generic'],
            )
            if access_switch['redundancy_protocol'] == 'esi':
                link_count = link['link_per_switch_count'] * instance_count
                for peer_idx in (0, 1):
                    success_leaf, _ = reserve_ports(
                        peer_leaf_port_groups[peer_idx],
                        roles=['access'],
                        speed=link['link_speed'],
                        count=link_count,
                    )

                if not (success_leaf and success_access_switch):
                    errors.add_errors({'access_switches': {access_switch_idx: {
                        'links': {
                            link_idx: (
                                'Not enough {} ports on leaf/access switch to '
                                'connect {} links per access switch, for total '
                                'of {} links to {} access switches.'
                                .format(
                                    format_speed(link['link_speed']),
                                    link['link_per_switch_count'],
                                    link_count,
                                    instance_count,
                                )
                            ),
                        }
                    }}})
                    continue

                distribution.leaf_access[LeafAccessLinkGroupInfo(
                    leaf_idx, access_switch_idx, link_idx, 0
                )] += link['link_per_switch_count']
                distribution.leaf_access[LeafAccessLinkGroupInfo(
                    leaf_idx, access_switch_idx, link_idx, 1
                )] += link['link_per_switch_count']
                continue

            if not success_access_switch:
                errors.add_errors({'access_switches': {
                    access_switch_idx: (
                        'Not enough {} ports on access switch to '
                        'connect {} links per access switch, for total of '
                        '{} links to {} leafs.'
                        .format(
                            format_speed(link['link_speed']),
                            link['link_per_switch_count'],
                            link['link_per_switch_count'] * instance_count,
                            instance_count,
                        )
                    )
                }})

            leaf_peer_index = 1 if link.get('switch_peer') == 'second' else 0
            for _ in range(instance_count):
                success, _ = reserve_ports(
                    peer_leaf_port_groups[leaf_peer_index], roles=['access'],
                    speed=link['link_speed'],
                    count=link['link_per_switch_count'],
                )
                if not success:
                    errors.add_errors({'leafs': {
                        leaf_idx: (
                            'Not enough {} ports on leaf/access switch to'
                            ' connect {} links per access switch, for total of '
                            '{} links to {} access switch.'
                            .format(
                                format_speed(link['link_speed']),
                                link['link_per_switch_count'],
                                link['link_per_switch_count'] * instance_count,
                                instance_count,
                            )
                        )
                    }})
                    break

                distribution.leaf_access[LeafAccessLinkGroupInfo(
                    leaf_idx, access_switch_idx, link_idx, leaf_peer_index)] += 1

    leaf_ld_mapping = []
    # make mapping from systems to attached generic systems
    for generic_system_idx, generic in enumerate(generic_systems):
        attached_to_leaf = False
        attached_to_access_switch = False
        attached_access_switch_label = None
        for link_idx, link in enumerate(generic['links']):
            target_label = link['target_switch_label']
            if target_label in access_switch_label_to_idx:
                if not attached_to_access_switch:
                    attached_to_access_switch = True
                    attached_access_switch_label = target_label
                elif attached_access_switch_label != target_label:
                    errors.add_errors({
                        'generic_systems': {generic_system_idx: {'links': {
                            link_idx: 'System is not allowed to be connected to '
                                      'more than one access switch at a time'
                        }}}})
                    continue

                access_switch_idx = access_switch_label_to_idx[target_label]
                attachment_type = link['attachment_type']
                redundancy_protocol = \
                    access_switches[access_switch_idx].get('redundancy_protocol')

                if redundancy_protocol == 'esi' and attachment_type == 'dualAttached':
                    access_switch_idx_to_generic_systems[access_switch_idx][
                        'dualAttached'][generic_system_idx].append(link_idx)
                elif attachment_type == 'singleAttached':
                    access_switch_idx_to_generic_systems[access_switch_idx][
                        'singleAttached'][generic_system_idx].append(link_idx)
                else:
                    errors.add_errors({'generic_systems': {generic_system_idx: {
                        'links': 'Dual attachment is allowed only for ESI '
                                 'access switches'
                    }}})
            else:
                attached_to_leaf = True
                leaf_idx = leaf_label_to_idx[target_label]
                leaf = leafs[leaf_idx]
                if (leaf.get('redundancy_protocol') in ('mlag', 'esi') and
                        link['attachment_type'] == 'dualAttached'):
                    leaf_idx_to_generic_systems[leaf_idx]['dualAttached'][
                        generic_system_idx].append(link_idx)
                elif link['attachment_type'] == 'singleAttached':
                    leaf_idx_to_generic_systems[leaf_idx]['singleAttached'][
                        generic_system_idx].append(link_idx)
                else:
                    errors.add_errors({'generic_systems': {generic_system_idx: {
                        'links': 'Dual attachment is allowed only for MLAG/ESI leafs'
                    }}})

        if attached_to_access_switch and attached_to_leaf:
            errors.add_errors({'generic_systems': {generic_system_idx: {
                'links': 'Systems are not allowed to be attached to both ToR '
                         'leafs and access switches.'}}})
        if not attached_to_access_switch and not attached_to_leaf:
            errors.add_errors({'generic_systems': {generic_system_idx: {
                'links': 'System is not attached to any ToR leaf or access switch.'
            }}})

    def process_dual_attached_links_switch_to_generic(switch_idx,
                                                      generic_system_idx,
                                                      system_role,
                                                      links,
                                                      switch_port_group,
                                                      group_info,
                                                      distribution_handler):
        generic = generic_systems[generic_system_idx]
        for link_idx in links:
            link = generic['links'][link_idx]
            link_count = link['link_per_switch_count'] * generic['count']
            success, _ = reserve_ports(
                switch_port_group,
                roles=['generic'],
                speed=link['link_speed'],
                count=link_count,
            )
            if not success:
                errors.add_errors({
                    'generic_systems': {generic_system_idx: {'links': {
                        link_idx: (
                            NOT_ENOUGH_PORTS_FOR_LINKS_ERROR
                            .format(
                                format_speed(link['link_speed']),
                                system_role,
                                link['link_per_switch_count'],
                                link_count,
                                generic['count'],
                            )
                        ),
                    }}}})
                continue

            distribution_handler[group_info(
                switch_idx, generic_system_idx, link_idx, 0)] += generic['count']
            distribution_handler[group_info(
                switch_idx, generic_system_idx, link_idx, 1)] += generic['count']

    def process_single_attached_links_switch_to_generic(switch_idx,
                                                        generic_system_idx,
                                                        system_role,
                                                        links,
                                                        peer_switch_port_groups,
                                                        group_info,
                                                        distribution_handler):
        generic = generic_systems[generic_system_idx]
        for link_idx in links:
            link = generic['links'][link_idx]

            # pylint: disable=cell-var-from-loop
            switch_peer_index = 1 if link.get('switch_peer') == 'second' else 0
            for _ in range(generic['count']):
                success, _ = reserve_ports(
                    peer_switch_port_groups[switch_peer_index],
                    roles=['generic'],
                    speed=link['link_speed'],
                    count=link['link_per_switch_count'],
                )
                if not success:
                    errors.add_errors({
                        'generic_systems': {generic_system_idx: {'links': {
                            link_idx: (
                                NOT_ENOUGH_PORTS_FOR_LINKS_ERROR
                                .format(
                                    format_speed(link['link_speed']),
                                    system_role,
                                    link['link_per_switch_count'],
                                    link['link_per_switch_count'] * generic['count'],
                                    generic['count'],
                                )
                            ),
                        }}}})
                    break

                distribution_handler[group_info(
                    switch_idx, generic_system_idx, link_idx, switch_peer_index
                )] += 1

    for leaf_idx, leaf in enumerate(leafs):
        leaf_port_groups = get_system_port_groups(leaf)

        _reserve_leaf_spine_links(leaf_idx, leaf, leaf_port_groups, spine_count,
                                  errors)
        _reserve_uplinks(leaf_idx, leaf_port_groups, uplinks, errors)

        if leaf.get('redundancy_protocol') == 'mlag':
            # Reserve ports for peer links
            leaf_leaf_link_count = leaf['leaf_leaf_link_count']
            leaf_leaf_link_speed = leaf.get('leaf_leaf_link_speed')
            success, _ = reserve_ports(leaf_port_groups, roles='peer',
                                       speed=leaf_leaf_link_speed,
                                       count=leaf_leaf_link_count,
                                       order_roles=['access',
                                                    'generic'])
            if leaf_leaf_link_count and leaf_leaf_link_speed and not success:
                errors.add_errors({'leafs': {leaf_idx: {
                    'leaf_leaf_link_count': (
                        'Not enough peer links with speed {} to connect {} links.'
                        .format(
                            format_speed(leaf_leaf_link_speed),
                            leaf_leaf_link_count,
                        )
                    ),
                }}})

            # Reserve ports for L3 peer links
            leaf_leaf_l3_link_count = leaf['leaf_leaf_l3_link_count']
            leaf_leaf_l3_link_speed = leaf.get('leaf_leaf_l3_link_speed')
            success, _ = reserve_ports(leaf_port_groups, roles='peer',
                                       count=leaf_leaf_l3_link_count,
                                       speed=leaf_leaf_l3_link_speed,
                                       order_roles=['access',
                                                    'generic'])
            if leaf_leaf_l3_link_count and leaf_leaf_l3_link_speed and not success:
                errors.add_errors({'leafs': {leaf_idx: {
                    'leaf_leaf_l3_link_count': (
                        'Not enough peer links with speed {} to '
                        'connect {} L3 links.'
                        .format(
                            format_speed(leaf_leaf_l3_link_speed),
                            leaf_leaf_l3_link_count,
                        )
                    ),
                }}})

        if leaf.get('redundancy_protocol') in ('mlag', 'esi'):
            # Reserve ports for dual-attached generic system links
            dual_attached_links = \
                leaf_idx_to_generic_systems[leaf_idx]['dualAttached']
            for generic_system_idx, links in six.iteritems(dual_attached_links):
                process_dual_attached_links_switch_to_generic(
                    leaf_idx, generic_system_idx, 'leaf',
                    links, leaf_port_groups,
                    group_info=LeafGenericLinkGroupInfo,
                    distribution_handler=distribution.leaf_generic
                )

            # Reserve ports for dual-attached access switch links
            process_dual_attached_access_switch_uplinks(leaf_idx, leaf_port_groups)

        # Distribute all single-attached generic system/access switch links between
        # given number of leafs while they fit into remaining leaf ports
        second_leaf_peer_port_groups = copy.deepcopy(leaf_port_groups)
        peer_leaf_port_groups = [leaf_port_groups, second_leaf_peer_port_groups]

        single_attached_links = \
            leaf_idx_to_generic_systems[leaf_idx]['singleAttached']
        for generic_system_idx, links in six.iteritems(single_attached_links):
            process_single_attached_links_switch_to_generic(
                leaf_idx, generic_system_idx, 'leaf',
                links,
                peer_switch_port_groups=peer_leaf_port_groups,
                group_info=LeafGenericLinkGroupInfo,
                distribution_handler=distribution.leaf_generic
            )

        # Distribute access switch links to ToR leafs
        process_single_attached_access_switch_uplinks(leaf_idx,
                                                      peer_leaf_port_groups)
        leaf_ld_mapping.append(leaf_port_groups)

    # Add access switch - generic system links
    for access_switch_idx, access_switch in enumerate(access_switches):
        access_switch_port_groups = access_switches_port_groups[access_switch_idx]

        if access_switch.get('redundancy_protocol') == 'esi':
            # Reserve ports for peer links
            access_access_link_count = access_switch['access_access_link_count']
            access_access_link_speed = access_switch.get('access_access_link_speed')
            success, _ = reserve_ports(access_switch_port_groups, roles='peer',
                                       count=access_access_link_count,
                                       speed=access_access_link_speed)
            if access_access_link_count and access_access_link_speed and not success:
                errors.add_errors({'access_switches': {access_switch_idx: {
                    'access_access_link_count': (
                        'Not enough peer links with speed {} to connect {} links.'
                        .format(
                            format_speed(access_access_link_speed),
                            access_access_link_count
                        )
                    )
                }}})

        # Process dual attached links to generic systems
        dual_attached_links = \
            access_switch_idx_to_generic_systems[access_switch_idx]['dualAttached']
        for generic_system_idx, links in six.iteritems(dual_attached_links):
            process_dual_attached_links_switch_to_generic(
                access_switch_idx, generic_system_idx, 'access switch',
                links, access_switch_port_groups,
                group_info=AccessGenericLinkGroupInfo,
                distribution_handler=distribution.access_generic
            )

        # Process single attached links to generic systems
        second_access_peer_port_groups = copy.deepcopy(access_switch_port_groups)
        peer_access_port_groups = [
            access_switch_port_groups, second_access_peer_port_groups]
        single_attached_links = \
            access_switch_idx_to_generic_systems[access_switch_idx]['singleAttached']
        for generic_system_idx, links in six.iteritems(single_attached_links):
            process_single_attached_links_switch_to_generic(
                access_switch_idx, generic_system_idx, 'access switch',
                links,
                peer_switch_port_groups=peer_access_port_groups,
                group_info=AccessGenericLinkGroupInfo,
                distribution_handler=distribution.access_generic
            )

    return (
        distribution,
        t.cast(dict[str, dict[str, str]], errors.errors),
        leaf_ld_mapping
    )


def validate_spine_port_groups(
    spine: GenSpineTypeSpec,
    rack_types: list[GenRackTypeSpec],
    rack_type_counts: list[ValidateSpinePortGroups_RackTypeCountSpec],
    errors: lollipop.errors.ValidationErrorBuilder,
    pod_index: t.Optional[int] = None,
    superspine_count: int = 0,
    link_per_superspine_count: int = 0,
    superspine_link_speed: t.Optional[tt.PortSpeed]=None
) -> None:
    def speed_to_spec(
        speed: tt.PortSpeed
    ) -> tuple[tt.PortSpeedValue, tt.PortSpeedUnit]:
        return (speed['value'], speed['unit'])

    def spec_to_speed(
        spec: tuple[tt.PortSpeedValue, tt.PortSpeedUnit]
    ) -> tt.PortSpeed:
        return {'value': spec[0], 'unit': spec[1]}

    rack_type_counts_by_id = {
        entry['rack_type_id']: entry['count']
        for entry in rack_type_counts
    }

    # Map (speed value, speed unit) -> count of links needed
    rack_uplink_speed_counts: t.MutableMapping[tuple[
        tt.PortSpeedValue,
        tt.PortSpeedUnit
    ], int] = defaultdict(int)
    for rack_type in rack_types:

        if rack_type['fabric_connectivity_design'] != 'l3clos':
            continue

        rack_count = rack_type_counts_by_id[rack_type['id']]
        for leaf in rack_type['leafs']:
            link_per_spine_count = leaf['link_per_spine_count']
            if leaf.get('redundancy_protocol') in ('esi', 'mlag'):
                link_per_spine_count *= 2
            assert leaf['link_per_spine_speed']
            speed_spec = speed_to_spec(leaf['link_per_spine_speed'])
            rack_uplink_speed_counts[speed_spec] += link_per_spine_count * rack_count

    spine_logical_device = spine['logical_device']
    spine_port_groups: list[GetPortsWithRolePortGroupSpec] = [
        {'speed': port_group['speed'],
         'count': port_group['count'],
         'roles': port_group['roles']}
        for panel in spine_logical_device['panels']
        for port_group in panel['port_groups']
    ]

    # Verify spine device's ports are sufficient for leaf
    spine_count = spine['count']
    speeds_with_insufficient_ports = []
    for speed_spec, leaf_ports_required in six.iteritems(rack_uplink_speed_counts):
        link_speed = spec_to_speed(speed_spec)
        success, unreserved_count = reserve_ports(
            spine_port_groups,
            roles='leaf',
            speed=link_speed,
            count=leaf_ports_required,
            order_roles=['generic', 'superspine'])
        if not success:
            speeds_with_insufficient_ports.append((
                format_speed(link_speed),
                leaf_ports_required * spine_count,
                (leaf_ports_required - unreserved_count) * spine_count,
            ))

    if speeds_with_insufficient_ports:
        # Sort error by speed for predictable message order
        speeds_with_insufficient_ports.sort(key=lambda spec: spec[0])
        msg: dict[str, t.Any] = {'spine': {
            'count':
            'Insufficient leaf-facing ports on spines ' + \
            ' '.join(
                '(total {} {} ports needed, {} available)'
                .format(required, speed, available)
                for speed, required, available in speeds_with_insufficient_ports
            )
        }}
        if pod_index is not None:
            msg = {'rack_based_template': {pod_index: msg}}
        errors.add_errors(msg)

    if superspine_count:
        superspine_link_count = link_per_superspine_count * superspine_count
        success, unreserved_count = reserve_ports(
            spine_port_groups,
            roles='superspine',
            speed=superspine_link_speed,
            count=superspine_link_count)
        if not success:
            msg = {
                'spine': {
                    'logical_device':
                    'Insufficient superspine-facing %s ports on spine' % \
                    format_speed(superspine_link_speed) + \
                    ' (%d needed, but only %d available)' % \
                    (superspine_link_count, superspine_link_count - unreserved_count)
                }
            }
            if pod_index is not None:
                msg = {'rack_based_template': {pod_index: msg}}
            errors.add_errors(msg)


def gen_superspine_type(
    plane_count: int = 1,
    superspine_per_plane: int = 2,
    logical_device: t.Optional[GenLogicalDeviceSpec] = None,
    tags: t.Optional[list[tt.Tag]] = None
) -> GenSuperspineTypeSpec:
    if logical_device is None:
        logical_device = AOS_32x40_superspine
    params = {
        'plane_count': plane_count,
        'superspine_per_plane': superspine_per_plane,
        'logical_device': logical_device,
        'tags': tags or [],
    }

    rv = compact_dict(params)
    if t.TYPE_CHECKING:
        return t.cast(GenSuperspineTypeSpec, rv)
    return rv


def gen_export_policy(
    loopbacks: bool = True,
    spine_leaf_links: bool = False,
    spine_superspine_links: bool = False,
    l2edge_subnets: bool = True,
    static_routes: bool = False
) -> GenExportPolicySpec:
    return {
        'loopbacks': loopbacks,
        'spine_leaf_links': spine_leaf_links,
        'spine_superspine_links': spine_superspine_links,
        'l2edge_subnets': l2edge_subnets,
        'static_routes': static_routes,
    }


def gen_prefix_list_entry(
    prefix: tt.IPAddress,
    le_mask: t.Optional[int] = None,
    ge_mask: t.Optional[int] = None,
    action: tt.PrefixListEntryAction = 'permit',
    description: t.Optional[str] = None
) -> GenPrefixListEntrySpec:
    return {
        'prefix': prefix,
        'le_mask': le_mask,
        'ge_mask': ge_mask,
        'action': action,
        'description': description,
    }


def gen_os_image(
    platform: t.Optional[str] = None,
    image_url: t.Optional[str] = None,
    description: t.Optional[str] = None,
    checksum: t.Optional[str] = None,
) -> GenOSImageSpec:
    return {
        'platform': platform,
        'image_url': image_url,
        'description': description or "",
        'checksum': checksum or ""
    }


def gen_route_target_policy(
    import_RTs: t.Optional[list[str]] = None,
    export_RTs: t.Optional[list[str]] = None
) -> GenRouteTargetPolicySpec:
    return {
        'import_RTs': copy.deepcopy(import_RTs),
        'export_RTs': copy.deepcopy(export_RTs),
    }


def gen_routing_policy(
    import_policy: tt.RoutingImportPolicyType = 'all',
    export_policy: t.Optional[GenExportPolicySpec] = None,
    policy_type: str = 'user_defined',
    description: t.Optional[str] = None,
    aggregate_prefixes: t.Optional[list[tt.IPNetwork]] = None,
    extra_import_routes: t.Optional[list[GenPrefixListEntrySpec]] = None,
    extra_export_routes: t.Optional[list[GenPrefixListEntrySpec]] = None,
    label: t.Optional[str] = None,
    expect_default_ipv4_route: bool = True,
    expect_default_ipv6_route: bool = True
) -> GenRoutingPolicySpec:
    export_policy = export_policy or gen_export_policy()
    label = label or gen_short_id(18)
    extra_import_routes = [gen_prefix_list_entry(
        **entry) for entry in extra_import_routes] if extra_import_routes else []
    extra_export_routes = [gen_prefix_list_entry(
        **entry) for entry in extra_export_routes] if extra_export_routes else []
    return dict(
        label=label,
        policy_type=policy_type,
        description=description,
        import_policy=import_policy,
        export_policy=copy.deepcopy(export_policy),
        aggregate_prefixes=aggregate_prefixes or [],
        extra_import_routes=extra_import_routes,
        extra_export_routes=extra_export_routes,
        expect_default_ipv4_route=expect_default_ipv4_route,
        expect_default_ipv6_route=expect_default_ipv6_route,
    )


def gen_default_routing_policy(
    import_policy: tt.RoutingImportPolicyType = 'all',
    export_policy: t.Optional[GenExportPolicySpec] = None,
    policy_type: str = 'user_defined',
    description: t.Optional[str] = None,
    aggregate_prefixes: t.Optional[list[tt.IPNetwork]] = None,
    extra_import_routes: t.Optional[list[GenPrefixListEntrySpec]] = None,
    extra_export_routes: t.Optional[list[GenPrefixListEntrySpec]] = None,
    label: t.Optional[str] = None,
    expect_default_ipv4_route: bool = True,
    expect_default_ipv6_route: bool = True
) -> GenRoutingPolicySpec:
    label = 'Default_immutable' if label is None else label
    description = 'Associated with routing zones by default, cannot be updated ' \
        if description is None else description
    return gen_routing_policy(
        import_policy=import_policy,
        export_policy=export_policy,
        policy_type=policy_type,
        description=description,
        aggregate_prefixes=aggregate_prefixes,
        extra_import_routes=extra_import_routes,
        extra_export_routes=extra_export_routes,
        label=label,
        expect_default_ipv4_route=expect_default_ipv4_route,
        expect_default_ipv6_route=expect_default_ipv6_route
    )


def gen_ztp_log(name: str, log_info: str) -> GenZtpLogSpec:
    return {
        'system_id': name or gen_id(),
        'log': log_info}


def gen_ztp_device_status(
    ip_addr: tt.IPAddress,
    name: str,
    log_info: str,
) -> GenZtpDeviceStatusSpec:
    return {
        'ip_addr': ip_addr,
        'system_id': name or gen_id(),
        'last_log': log_info}


def gen_virtual_network_policy(
    overlay_control_protocol: t.Optional[t.Literal['evpn']] = None
) -> GenVirtualNetworkPolicySpec:
    return {
        'overlay_control_protocol': overlay_control_protocol,
    }


def gen_security_zone(
    label: t.Optional[str] = None,
    sz_type: t.Optional[tt.SecurityZoneType] = None,
    vni_id: t.Optional[str] = None,
    vlan_id: t.Optional[str] = None,
    vrf_name: t.Optional[str] = None,
    routing_policy_id: t.Optional[str]=None,
    rt_policy: t.Optional[GenRouteTargetPolicySpec] = None,
    route_target: t.Optional[str] = None,
    junos_evpn_irb_mode: t.Optional[tt.JunosEvpnIrbMode] = None,
    vrf_description: t.Optional[str] = None,
) -> GenSecurityZoneSpec:
    return {
        'label': label,
        'routing_policy_id': routing_policy_id,
        'rt_policy': rt_policy,
        'sz_type': sz_type,
        'vni_id': vni_id,
        'vlan_id': vlan_id,
        'vrf_name': vrf_name,
        # route_target is optional in GET response, and is ignored in
        # PUT, POST, PATCH
        'route_target': route_target,
        'junos_evpn_irb_mode': junos_evpn_irb_mode,
        'vrf_description': vrf_description,
    }


def gen_fabric_policy(
    spine_leaf_links: tt.LinkIpv4Ipv6All = 'ipv4',
    spine_superspine_links: tt.LinkIpv4Ipv6All = 'ipv4',
    leaf_loopbacks: tt.LinkIpv4Ipv6 = 'ipv4',
    spine_loopbacks: tt.LinkIpv4Ipv6 = 'ipv4',
    mlag_svi_subnets: tt.LinkIpv4Ipv6 = 'ipv4',
    leaf_l3_peer_links: tt.LinkIpv4Ipv6 = 'ipv4',
    esi_mac_msb: int = DEFAULT_ESI_MAC_MSB,
    fabric_l3_mtu: int = BP_DEFAULT_L3_MTU,
    anti_affinity: t.Optional[GenAntiAffinitySpec] = None,
    optimise_sz_footprint: tt.EnabledDisabled = 'enabled',
    # junos_evpn_routing_instance_type on pre-4.2.0 will retain 'default',
    # New blueprint construction will default to vlan_aware based evpn
    # for evpn-1 routing instance.
    junos_evpn_routing_instance_type: tt.JunosEvpnRoutingInstanceType = 'vlan_aware',
    junos_evpn_max_nexthop_and_interface_number: tt.EnabledDisabled = 'enabled',
    junos_graceful_restart: tt.EnabledDisabled = 'enabled',
    junos_ex_overlay_ecmp: tt.EnabledDisabled = 'enabled',
    junos_evpn_duplicate_mac_recovery_time: int = DEFAULT_DUP_MAC_RECOVERY_TIME,
    overlay_control_protocol: t.Optional[t.Literal['evpn']] = None,
    external_router_mtu: t.Optional[int] = None,
    max_fabric_routes: int = 0,
    max_external_routes: int = 0,
    max_mlag_routes: int = 0,
    max_evpn_routes: int = 0,
    default_fabric_evi_route_target: t.Optional[str] = None,
    evpn_generate_type5_host_routes: tt.EnabledDisabled = 'disabled',
    frr_rd_vlan_offset: tt.EnabledDisabled = 'enabled',
    default_svi_l3_mtu: int = DEFAULT_SVI_L3_MTU,
) -> GenFabricPolicySpec:
    if anti_affinity is None:
        anti_affinity = gen_anti_affinity()

    default_fabric_evi_route_target = default_fabric_evi_route_target or (
        DEFAULT_FABRIC_EVI_RT if overlay_control_protocol == 'evpn' else None)

    return {
        'spine_leaf_links': spine_leaf_links,
        'spine_superspine_links': spine_superspine_links,
        'leaf_loopbacks': leaf_loopbacks,
        'spine_loopbacks': spine_loopbacks,
        'mlag_svi_subnets': mlag_svi_subnets,
        'leaf_l3_peer_links': leaf_l3_peer_links,
        'esi_mac_msb': esi_mac_msb,
        'fabric_l3_mtu': fabric_l3_mtu,
        'anti_affinity': anti_affinity,
        'optimise_sz_footprint': optimise_sz_footprint,
        'junos_evpn_routing_instance_type': junos_evpn_routing_instance_type,
        'junos_evpn_max_nexthop_and_interface_number': (
            junos_evpn_max_nexthop_and_interface_number),
        'junos_graceful_restart': junos_graceful_restart,
        'junos_ex_overlay_ecmp': junos_ex_overlay_ecmp,
        'junos_evpn_duplicate_mac_recovery_time': (
            junos_evpn_duplicate_mac_recovery_time),
        'overlay_control_protocol': overlay_control_protocol,
        'external_router_mtu': external_router_mtu,
        'max_fabric_routes': max_fabric_routes,
        'max_external_routes': max_external_routes,
        'max_mlag_routes': max_mlag_routes,
        'max_evpn_routes': max_evpn_routes,
        'default_fabric_evi_route_target': default_fabric_evi_route_target,
        'evpn_generate_type5_host_routes': evpn_generate_type5_host_routes,
        'frr_rd_vlan_offset': frr_rd_vlan_offset,
        'default_svi_l3_mtu': default_svi_l3_mtu,
    }


def gen_asn_allocation_policy(
    spine_asn_scheme: t.Literal['distinct', 'single'] = 'distinct',
) -> GenAsnAllocationPolicySpec:
    return {
        'spine_asn_scheme': spine_asn_scheme,
    }


def gen_anti_affinity(
    mode: t.Literal['disabled', 'enabled_loose', 'enabled_strict'] = 'disabled',
    algorithm: t.Literal['heuristic'] = 'heuristic',
    max_links_per_slot: int = 0,
    max_links_per_port: int = 0,
    max_per_system_links_per_slot: int = 0,
    max_per_system_links_per_port: int = 0,
) -> GenAntiAffinitySpec:
    return {
        'mode': mode,
        'algorithm': algorithm,
        'max_links_per_slot': max_links_per_slot,
        'max_links_per_port': max_links_per_port,
        'max_per_system_links_per_slot': max_per_system_links_per_slot,
        'max_per_system_links_per_port': max_per_system_links_per_port,
    }


def gen_validation_policy(
    ip_overlap: t.Optional[GenValidationPolicy_IpOverlapSpec] = None,
    route_target_overlap: t.Optional[GenValidationPolicy_RouteTargetOverlapSpec] = None,
    asn_overlap: t.Optional[GenValidationPolicy_AsnOverlapSpec] = None,
    os_version: t.Optional[GenValidationPolicy_OsVersionSpec] = None,
    asic_features: t.Optional[GenValidationPolicy_AsicFeaturesSpec] = None,
    load_balancing_policy: t.Optional[GenValidationPolicy_LoadBalancingPolicy] = None,
    rail_optimized_design: t.Optional[GenValidationPolicy_RailOptimizedDesign] = None,
) -> GenValidationPolicySpec:
    if ip_overlap is None:
        ip_overlap = {
            'base_level': 'error',
            'svi': None,
            'uncontrolled_generic_loopback': None,
        }
    if route_target_overlap is None:
        route_target_overlap = {
            'internal': 'error',
        }
    if asn_overlap is None:
        asn_overlap = {
            'base_level': 'error',
        }
    if os_version is None:
        os_version = {
            'sonic_esi_min_version': 'error',
        }
    if asic_features is None:
        asic_features = {
            'subinterfaces': 'error',
            'load_balancing_policy': 'error',
        }
    if load_balancing_policy is None:
        load_balancing_policy = {
            'glb_mode': 'warning',
        }
    if rail_optimized_design is None:
        rail_optimized_design = {
            'rail_vlan_misconfiguration': 'warning',
        }

    return {
        'ip_overlap': ip_overlap,
        'route_target_overlap': route_target_overlap,
        'asn_overlap': asn_overlap,
        'os_version': os_version,
        'asic_features': asic_features,
        'load_balancing_policy': load_balancing_policy,
        'rail_optimized_design': rail_optimized_design,
    }


def format_index(idx: int, total: t.Optional[int] = None) -> str:
    s = str(idx)

    if total is not None:
        l = 0
        while total:
            l += 1
            total //= 10
        s = '0' * max(0, l - len(s)) + s

    return s


def listify_counts(
    counts: dict | list[dict],
    entity_type: str = 'rack_type_id',
) -> list[dict]:
    if not counts:
        return []

    if isinstance(counts, list):
        return counts

    return [{
        entity_type: entity,
        'count': count,
    } for entity, count in six.iteritems(counts)]


def gen_rack_based_template(
    name: t.Optional[str] = None,
    spine: t.Optional[GenSpineTypeSpec] = None,
    rack_types: t.Optional[list[GenRackTypeSpec]] = None,
    rack_type_counts: t.Optional[dict | list[dict]] = None,
    dhcp_enabled: bool = True,
    display_name: t.Optional[str] = None,
    virtual_network_policy: GenVirtualNetworkPolicySpec = gen_virtual_network_policy(),
    asn_allocation_policy: GenAsnAllocationPolicySpec = gen_asn_allocation_policy(),
    link_per_superspine_count: int = 0,
) -> GenRackBasedTemplateSpec:
    spine = spine or \
            gen_spine_type(link_per_superspine_count=link_per_superspine_count)
    if rack_types is None:
        rack_types = [gen_rack_type('rack-1')]
    if rack_type_counts is None:
        rack_type_counts = {'rack-1': 2}
    return {
        'type': 'rack_based',
        'id': name or gen_id(),
        'display_name': display_name or name or gen_id(),
        'spine': spine,
        'rack_types': rack_types,
        'rack_type_counts': listify_counts(rack_type_counts),
        'dhcp_service_intent': {'active': dhcp_enabled},
        'virtual_network_policy': copy.deepcopy(virtual_network_policy),
        'asn_allocation_policy': copy.deepcopy(asn_allocation_policy),
    }


def gen_pod_based_template(
    name: t.Optional[str] = None,
    superspine: t.Optional[GenSuperspineTypeSpec] = None,
    rack_based_templates: t.Optional[list[GenRackBasedTemplateSpec]] = None,
    rack_based_template_counts: t.Optional[dict | list[dict]] = None,
    display_name: t.Optional[str] = None,
) -> GenPodBasedTemplateSpec:
    superspine = superspine or gen_superspine_type()
    if rack_based_templates is None:
        rack_based_templates = [
            gen_rack_based_template('pod-1', link_per_superspine_count=1)]
    rack_based_template_counts = rack_based_template_counts or {'pod-1': 2}
    return {
        'type': 'pod_based',
        'id': name or gen_id(),
        'display_name': display_name or name or gen_id(),
        'superspine': copy.deepcopy(superspine),
        'rack_based_templates': copy.deepcopy(rack_based_templates),
        'rack_based_template_counts': listify_counts(rack_based_template_counts,
                                                     'rack_based_template_id'),
    }


def gen_l3_collapsed_template(
    name: t.Optional[str] = None,
    rack_types: t.Optional[list[GenRackTypeSpec]] = None,
    rack_type_counts: t.Optional[dict | list[dict]] = None,
    mesh_link_count: int = 1,
    mesh_link_speed: int = 10,
    dhcp_enabled: bool = True,
    display_name: t.Optional[str] = None,
    virtual_network_policy: t.Optional[GenVirtualNetworkPolicySpec] = None,
) -> GenL3CollapsedTemplateSpec:
    if rack_types is None:
        rack_types = [gen_l3_collapsed_rack_type('rack-1', leafs=[
            gen_rack_type_leaf(link_per_spine_count=0, link_per_spine_speed=None)])]
    if rack_type_counts is None:
        rack_type_counts = {'rack-1': 1}
    return {
        'type': 'l3_collapsed',
        'id': name or gen_id(),
        'mesh_link_count': mesh_link_count,
        'mesh_link_speed': port_speed(mesh_link_speed),
        'display_name': display_name or name or gen_id(),
        'rack_types': rack_types,
        'rack_type_counts': listify_counts(rack_type_counts),
        'dhcp_service_intent': {'active': dhcp_enabled},
        'virtual_network_policy': copy.deepcopy(
            virtual_network_policy or gen_virtual_network_policy(
                overlay_control_protocol='evpn')
        ),
    }


def gen_vni_pool(
    name: str,
    ranges: t.Optional[t.Iterable[tuple[int, int]]] = None,
    tags: t.Optional[list[tt.Tag]] = None
) -> GenVniPoolSpec:
    """Returns JSON for VNI Pool

       Example VNI Pool with 1 range 10000-20000

       gen_vni_pool(
           'display_name',
           [
                (10000, 20000),
           ],
           ['tag1', 'tag2']
       )
    """
    def create_ranges(groups: t.Iterable[tuple[int, int]]) -> list[PoolRange]:
        """ converts [ (first, last), (first, last) ] to dictionary """
        return [{'first': r[0], 'last': r[1]} for r in groups]

    rv = compact_dict({
        'display_name': name,
        'id': name,
        'ranges': create_ranges(ranges or []),
        'tags': tags or [],
    })
    if t.TYPE_CHECKING:
        return t.cast(GenVniPoolSpec, rv)
    return rv


def gen_integer_pool(
    name: str,
    ranges: t.Optional[t.Iterable[tuple[int, int]]] = None,
    tags: t.Optional[list[tt.Tag]]=None
) -> GenIntegerPoolSpec:
    """Returns JSON for Integer Pool

       Example VNI Pool with 1 range 1-4000

       gen_vni_pool(
           'display_name',
           [
                (1, 4000),
           ],
           ['tag1', 'tag2']
       )
    """
    def create_ranges(groups: t.Iterable[tuple[int, int]]) -> list[PoolRange]:
        """ converts [ (first, last), (first, last) ] to dictionary """
        return [{'first': r[0], 'last': r[1]} for r in groups]

    rv = compact_dict({
        'display_name': name,
        'id': name,
        'ranges': create_ranges(ranges or []),
        'tags': tags or [],
    })
    if t.TYPE_CHECKING:
        return t.cast(GenIntegerPoolSpec, rv)
    return rv


def gen_interface_policy(
    label: str,
    dot1x_auth_mode: tt.Dot1xPolicyAuthMode = 'multi_host',
    dot1x_port_control: tt.Dot1xPolicyPortControl = 'force_authorized',
    dot1x_mac_auth_bypass: bool = False,
    dot1x_reauthentication_timeout: t.Optional[int] = None
) -> GenInterfacePolicySpec:
    return {
        'label': label,
        'dot1x_auth_mode': dot1x_auth_mode,
        'dot1x_port_control': dot1x_port_control,
        'dot1x_mac_auth_bypass': dot1x_mac_auth_bypass,
        'dot1x_reauthentication_timeout': dot1x_reauthentication_timeout,
    }

def gen_remote_gw(
    gw_name: str,
    gw_ip: tt.IPAddress,
    gw_asn: tt.ASN,
    password: t.Optional[str] = None,
    ttl: int = 30,
    keepalive_timer: int = 10,
    holdtime_timer: int = 30,
    local_gw_nodes: t.Optional[list[GenRemoteGw_LocalGwNodeSpec]]=None,
    evpn_route_types: t.Literal['all', 'type5_only'] = 'all',
    evpn_interconnect_group_id: str='_MISSING_',
) -> GenRemoteGwSpec:
    '''
    Generate remote gateway dict
    '''
    resp = compact_dict({
        'gw_name': gw_name,
        'gw_ip': gw_ip,
        'gw_asn': gw_asn,
        'password': password,
        'ttl': ttl,
        'keepalive_timer': keepalive_timer,
        'holdtime_timer': holdtime_timer,
        'local_gw_nodes': local_gw_nodes,
        'evpn_route_types': evpn_route_types,
    })
    if evpn_interconnect_group_id != '_MISSING_':
        resp['evpn_interconnect_group_id'] = evpn_interconnect_group_id

    if t.TYPE_CHECKING:
        return t.cast(GenRemoteGwSpec, resp)
    return resp


def gen_evpn_interconnect_virtual_network(
    l2: bool = True,
    l3: bool = False,
    translation_vni: t.Optional[int] = None,
    extra_import_rts: t.Optional[list[str]] = None,
    extra_export_rts: t.Optional[list[str]] =None,
) -> GenEvpnInterconnectVirtualNetworkSpec:
    """ Generates payload for EVPN interconnect group virtual networks.
    :param (bool) l2: If true, VN is enabled for L2 interconnect
    :param (bool) l3: If true, VN is enabled for L3 interconnect
    :param (:obj:`int`, optional) translation_vni: If specified, this VN is
        translated through the interconnect
    :param (:obj:`list`, optional) extra_import_rts: If specified, contains a list of
        extra user-defined import route-targets associated with the L2 VNI.
    :param (:obj:`list`, optional) extra_export_rts: If specified, contains a list of
        extra user-defined export route-targets associated with the L2 VNI.
    :return (dict): Payload required for EVPN Interconnect group virtual networks
        in the format:
        {
            'enabled_for_interconnect': <bool>,
            'translation_vni': <int, optional>,
            'extra_import_rts': [<rt>, <rt>] optional,
            'extra_export_rts': [<rt>, <rt>] optional,
        }
    """
    return dict(
        l2=l2,
        l3=l3,
        translation_vni=int(translation_vni) if translation_vni else None,
        extra_import_rts=extra_import_rts,
        extra_export_rts=extra_export_rts,
    )


def gen_evpn_interconnect_security_zone(
    routing_policy_id: str,
    interconnect_route_target: str,
    enabled_for_l3: bool,
) -> GenEvpnInterconnectSecurityZoneSpec:
    return {
        'routing_policy_id': routing_policy_id,
        'interconnect_route_target': interconnect_route_target,
        'enabled_for_l3': enabled_for_l3,
    }


def gen_evpn_interconnect_group(
    label: str,
    interconnect_route_target: str,
    remote_gateway_node_ids: list[tt.GraphNodeId] | None = None,
    interconnect_virtual_networks: dict[tt.GraphNodeId, GenEvpnInterconnectVirtualNetworkSpec] | None = None,
    interconnect_security_zones: dict[tt.GraphNodeId, GenEvpnInterconnectSecurityZoneSpec] | None = None,
    interconnect_esi_mac: str | None = None,
) -> GenEvpnInterconnectGroupSpec:
    return dict(
        label=label,
        interconnect_route_target=interconnect_route_target,
        remote_gateway_node_ids=remote_gateway_node_ids or [],
        interconnect_virtual_networks=interconnect_virtual_networks or {},
        interconnect_security_zones=interconnect_security_zones or {},
        interconnect_esi_mac=interconnect_esi_mac,
    )

def gen_aaa_server(
    label: str,
    hostname: tt.HostName,
    key: str,
    auth_port: t.Optional[tt.PortNo] = None,
    acct_port: t.Optional[tt.PortNo] = None,
    server_type: str = 'radius_dot1x',
) -> GenAaaServerSpec:
    return {
        'label': label,
        'hostname': hostname,
        'key': key,
        'server_type': server_type,
        'acct_port': acct_port,
        'auth_port': auth_port,
    }


def calculate_mesh_links_per_leaf(
    rack_types: t.Sequence[GenRackTypeSpec],
    rack_type_counts: t.Mapping[str, int],
    mesh_link_count: int,
    mesh_link_speed: tt.PortSpeed,
) -> LeafUplinks:
    def get_total_number_of_leafs() -> int:
        leaf_count = 0
        for rack_type in rack_types:
            # Currently supported redundancy protocols (mlag, esi) use exactly 2
            # leafs
            rack_leaf_count = sum(2 if leaf_type['redundancy_protocol'] else 1
                                  for leaf_type in rack_type['leafs'])
            leaf_count += rack_leaf_count * rack_type_counts[rack_type['id']]
        return leaf_count

    leafs_count = get_total_number_of_leafs()
    neighbors_count = leafs_count - 1
    total_mesh_link_count_per_leaf = mesh_link_count * neighbors_count
    return LeafUplinks(
        speed=mesh_link_speed,
        count=total_mesh_link_count_per_leaf,
        neighbors_count=neighbors_count,
        links_per_neighbor=mesh_link_count,
        type='mesh',
    )


def gen_logical_device_node(
    blueprint: tt.Graph,
    label: str,
    logical_device: _MAGIC.lollipop_type[
        'aos.scotch.schemas.logical_device.LOGICAL_DEVICE_SCHEMA'
    ]
) -> tt.GraphNode:
    if 'global_id' in blueprint.schema.get_node_schema('logical_device').properties:
        return blueprint.add_node(
            'logical_device',
            label=label,
            global_id=logical_device.get('id'),
            json=json.dumps(logical_device)
        )
    return blueprint.add_node(
        'logical_device',
        label=label,
        json=json.dumps(logical_device)
    )


def gen_device_profile_node(
    blueprint: tt.Graph,
    device_profile: _MAGIC.lollipop_type[
        'aos.sdk.device_profile.device_profile_schema.device_profile_schema'
    ]
) -> tt.GraphNode:
    return blueprint.add_node('device_profile',
                              device_profile_id=device_profile['id'],
                              label=device_profile['label'],
                              selector=device_profile['selector'],
                              hardware_capabilities=device_profile[
                                  'hardware_capabilities'],
                              ports=device_profile['ports'],
                              software_capabilities=device_profile[
                                  'software_capabilities'],
                              chassis_count=device_profile.get(
                                  'chassis_count', None),
                              device_profile_type=device_profile.get(
                                  'device_profile_type', 'monolithic'),
                              slot_count=device_profile['slot_count'],
                              slot_configuration=device_profile.get('slot_configuration'),
                              chassis_profile_id=device_profile.get('chassis_profile_id'),
                              chassis_info=device_profile.get('chassis_info'),
                              linecards_info=device_profile.get('linecards_info'),
                              predefined=device_profile['predefined'],
                              reference_design_capabilities=device_profile.get(
                                  'reference_design_capabilities'),
                              physical_device=device_profile['physical_device'],
                              dual_routing_engine=device_profile['dual_routing_engine'])


def gen_interface_map_node(
    blueprint: tt.Graph,
    interface_map: dict,
    ld_nodes: list[tt.GraphNode],
    dp_node: tt.GraphNode,
) -> tt.GraphNode:
    im_id = interface_map.get('id')
    if im_id and blueprint.get_node(im_id):
        # If interface map with the same ID already exists, arbitrary ID will be
        # generated. AOS-27525 describes possible scenario
        im_id = None

    im_node = blueprint.add_node(
        'interface_map',
        id=im_id,
        device_profile_id=interface_map['device_profile_id'],
        logical_device_id=interface_map['logical_device_id'],
        label=interface_map['label'],
        interfaces=interface_map['interfaces']
    )
    blueprint.add_relationship('device_profile', im_node, dp_node)
    for ld_node in ld_nodes:
        blueprint.add_relationship('logical_device', im_node, ld_node)
    return im_node


def gen_flowlet_reassignment_options(
        quality_delta: int,
        probability_threshold: int,
) -> GenFlowletReassignmentSpec:
    """ Generates a payload representing reactive path rebalancing
    reassignment options. This is intended for use as an argument to
    gen_flowlet_options(reassignment=gen_flowlet_reassignment_options(...))

    When flowlet reassignment options are configured, both quality_delta and
    probability_threshold are required to be configured together.

    :param (int) quality_delta: A better link-quality member link is available whose
        quality is equal to or greater than the current member's quality plus
        the configured reassignment quality delta value.
        Configure the quality-delta option to set the difference in quality
        between the current stream member and the member available for
        reassignment. Values are 0-8, with the value 0 disabling reassignment.

        This corresponds to the Juniper command
        set forwarding-options enhanced-hash-key ecmp-dlb flowlet reassignment quality-delta <quality_delta>
    :param (int) probability_threshold: The packet random value that the system
        generates is lower than the reassignment probability threshold value.
        Configure the prob-threshold option to set the probability threshold that
        reactive path load balancing users to reassign the existing flow to a
        better available member.

        This corresponds to the Juniper command
        set forwarding-options enhanced-hash-key ecmp-dlb flowlet reassignment prob-threshold <probability_threshold>

    :return (GenFlowletReassignmentSpec): Dictionary response for flowlet
        reassignment, in the format:

        {
            "quality_delta": <quality_delta>,
            "probability_threshold": <probability_threshold>
        }

    Example:
        Reassignment options are used as an argument to gen_flowlet_options:

        gen_flowlet_options(
            reassignment=gen_flowlet_reassignment_options(
                quality_delta=5,
                probability_threshold=50,
            )
        )

        Which is part of a larger load balancing policy assignment:

        payload = gen_load_balancing_policy(
            label="example_policy",
            mode="dlb",
            dlb_options=gen_dlb_options(
                dlb_mode="flowlet",
                flowlet_options=gen_flowlet_options(
                    reassignment=gen_flowlet_reassignment_options(
                        quality_delta=5,
                        probability_threshold=5,
                    )
                )
            )
        )
    """
    rv = dict(
        quality_delta=quality_delta,
        probability_threshold=probability_threshold,
    )
    if t.TYPE_CHECKING:
        return t.cast(GenFlowletReassignmentSpec, rv)
    return rv


def gen_egress_quantization(
        quantization_min: int | None = None,
        quantization_max: int | None = None,
        rate_weightage: int | None = None,
) -> GenEgressQuantizationSpec:
    """ Generates a payload corresponding to the egress_quantization parameter
    of gen_dlb_options(egress_quantization=gen_egress_quantization(...)).

    Dynamic load balancing (DLB) selects an optimal link based on the quality
    of the link so that traffic flows are evenly distributed across your
    network. You (the network administrator) can customize the way DLB assigns
    quality metrics of egress ports so that DLB selects the optimal link.

    DLB assigns each egress port that is part of equal-cost multipath (ECMP) to a
    quality band. Quality bands are numbered from 0 through 7, where 0 is the
    lowest quality and 7 is the highest quality. DLB tracks two metrics on each
    of the ports, and it uses these metrics to compute the link quality:

    Port load metric: The amount of traffic recently transmitted over each ECMP link,
    measured in bytes.

    Port queue metric: The amount of traffic enqueued on each ECMP link for
    transmission, measured in number of cells

    Based on the member port load and queue size, DLB assigns one of the quality
    bands to the member port. The port-to-quality band mapping changes based on
    the instantaneous port load and queue size metrics.

    :param (int) quantization_min: Minimum port load in percentage (1-100). DLB
        assigns any egress port with a port load falling below this minimum to the
        highest quality band (7)

        This corresponds to the Juniper command:
        set forwarding-options enhanced-hash-key ecmp-dlb egress-quantization min <quantization_min>

    :param (int) quantization_max: Maximum port load in percentage (1-100). DLB
        assigns any egress port with a port load above this maximum to the lowest
        quality band (0).

        This corresponds to the Juniper command:
        set forwarding-options enhanced-hash-key ecmp-dlb egress-quantization max <quantization_max>

    :param (int) rate_weightage: How much weight DLB puts on the port load metric,
        or amount of traffic, when determining the link quality. The range is 0-100,
        where 100 means that DLB bases link quality 100% on the port load.

        This corresponds to the Juniper command:
        set forwarding-options enhanced-hash-key ecmp-dlb egress-quantization rate-weightage <rate_weightage>

    :return (GenEgressQuantizationSpec): Dictionary response intended for use
        with a load balancing dlb_options key in the format:

        {
            "quantizastion_max": <quantization_max>,
            "quantization_min": <quantization_min>,
            "rate_weightage": <rate_weightage>,
        }

    """
    rv = dict(
        quantization_min=quantization_min,
        quantization_max=quantization_max,
        rate_weightage=rate_weightage,
    )
    if t.TYPE_CHECKING:
        return t.cast(GenEgressQuantizationSpec, rv)
    return rv


def gen_glb_options(
        glb_mode: tt.LBPolicyGLBMode,
        msg_tx_interval: int | None = None,
        monitor_interval: int | None = None,
        update_interval: int | None = None,
) -> GenLoadBalancingGLBPolicySpec:
    """ Configures Global Load Balancing (GLB) policies when in DLB mode

    :param (tt.LBPolicyGLBMode) glb_mode: The GLB mode indicates the desired
        operating mode of GLB.
        * both: System operates in both load-balancing and helper modes.
            (Not supported, earmarked for future use)

            This means this node works as both load-balancer and helper. BGP sends
            NNHN capability for the route it advertises. BGP instructs GLB App to
            monitor the link qualities of all local links with EBGP sessions and
            flood them to all direct neighbors. GLB App receives link qualities
            from neighboring nodes and use the combine link quality of the
            next-hops and next-next-hops to make load balancing decisions.

            This is usually configured on the spines and super spines
            of 5-CLOS or 7-CLOS.

            This corresponds to the Juniper command:
            set protocols bgp global-load-balancing

        * helper_only:
            helper-only is configured: BGP sends NNHN capability for the routes
            it advertises. BGP instructs GLB  App to monitor the link qualities
            of all local links with EBGP sessions and flood them to all direct
            neighbors. GBP App does not process link qualities from neighboring
            nodes and do not do GLB.
            This is usually configured on the 3-CLOS spines.

            This corresponds to the Juniper command:
            set protocols bgp global-load-balancing helper-only

        * load_balancer_only:
            BGP does not send NNHN capability for the route it advertises. BGP
            does not instruct GLB App to monitor the link qualities of local links
            either. GLB App only receives link qualities from neighboring nodes
            and use the combined link quality of next-hops and next-next-hops
            to make load balancing decisions.

            This is usually configured on the leaves (any-CLOS).

            This corresponds to the Juniper command:
            set protocols bgp global-load-balancing helper-only

    :param (int) msg_tx_interval: Specifies the time in microseconds between
        GLB messages. This supports an optional value between 10-1000 microseconds.

        GLB app wakes up every msg_tx_interval microseconds and transmits GLB
        messages regardless of whether quality info has changed from the previous
        state or not. The platform default value is 10 microseconds.

        This corresponds to the Juniper command:
        set forwarding-options global-load-balancing msg-tx-interval <msg_tx_interval>

    :param (int) monitor_interval: Specifies the time in microseconds between
        GLB message transmission upon update. This supports an optional value
        between 5-1000 microseconds.

        GLB app wakes up every monitor_interval microseconds and transmits GLB
        messages if quality info has changed from the previous state. This is
        independent of the msg_tx_interval. The platform default value is 20
        microseconds.

        This corresponds to the Juniper command:
        set forwarding-options global-load-balancing msg-tx-interval <monitor_interval>

    :param (int) update_interval: Specifies interval for hardware link quality
        updates in microseconds. This supports an optional value between 10-1000
        microseconds.

        GLB app wakes up every update_interval microseconds and updates the remote
        quality in hardware. The platform default value is 20 microseconds.

        This corresponds to the Juniper command:
        set forwarding-options global-load-balancing update-interval <update_interval>
    :return (GenLoadBalancingGLBPolicySpec): Payload compatible with
        gen_dlb_options(glb_options=gen_glb_options(...))

        in the format:
        {
            "glb_mode": <glb_mode>,
            "msg_tx_interval": <msg_tx_interval> or None,
            "monitor_interval": <monitor_interval> or None,
            "update_interval": <update_interval> or None,
        }
    """
    rv = dict(
        glb_mode=glb_mode,
        msg_tx_interval=msg_tx_interval,
        monitor_interval=monitor_interval,
        update_interval=update_interval,
    )
    if t.TYPE_CHECKING:
        return t.cast(GenLoadBalancingGLBPolicySpec, rv)
    return rv

def gen_flowlet_options(
        inactivity_interval: int | None = None,
        flowset_table_size: tt.LBPolicyFlowsetTableSize | None = None,
        reassignment: GenFlowletReassignmentSpec | None = None,
) -> GenFlowletOptionsSpec:
    """ This function generates part of the payload to create a load balancing
        policy with non-default flowlet options. It is intended for use
        as an argument to gen_dlb_options(flowlet_options=gen_flowlet_options(...)).

    :param (int) inactivity_interval:
        Configurable value for the flowlet inactivity timer. When this timer
        expires, the flowlet traffic tuple is removed from the software and
        hardware caches and freed from allocations.
        The platform default inactivity timer on TH5 systems is 256 microseconds.

        This corresponds to the Junos cli command:
        set forwarding-options enhanced-hash-key ecmp-dlb flowlet
            inactivity-interval <inactivity_interval>

        Valid values are integers between 16-4096. If this value is None, then
        nothing is rendered on the device.

        This value is intended to be configured in addition with the reassignment
        values to implement reactive load balancing.
    :param (tt.LBPolicyFlowsetTableSize) flowset_table_size: Number of flowset
        (MacroFlow) entries in DLB hash bucket. The platform default hash bucket
        size is 256 entries on TH5 hardware.

        This corresponds to the Junos cli command:
        set forwarding-options enhanced-hash-key ecmp-dlb flowlet
            flowset-table-size <flowset_table_size>

        Values from 256->32768 are supported in increasing powers of 2:
        256, 512, 1024, 2048, 4096, 8192, 16384, 32768.

    :param (GenFlowletReassignmentSpec) reassignment: Reassignment options
        correspond to reactive load balancing quality and probability
        thresholding. This argument is optional.

        If this key is specified, then the values within
        gen_flowlet_reassignment_options() must all be specified.

        See gen_flowlet_reassignment_options() for more details.

    Example:

        payload = gen_load_balancing_policy(
            label='example_dlb_policy',
            mode='dlb',
            dlb_options=gen_dlb_options(
                dlb_mode='flowlet',
                flowlet_options=gen_flowlet_options(
                    inactivity_interval=16,
                    flowset_table_size=2048,
                    reassignment=gen_flowlet_reassignment_options(
                        probability_threshold=30,
                        quality_delta=5,
                    )
                )
            )
        bp_client.load_balancing_policies.create(**payload)

    :return (GenFlowletOptionsSpec): Flowlet options in a dictionary format,
        intended for use as an argument to
        gen_dlb_options(flowlet_options=gen_flowlet_options(...))

        This will return a dictionary in the format:

        {
            "inactivity_interval": <inactivity_interval>,
            "flowset_table_size": <flowset_table_size>,
            "reassignment": <reassignment dict> or None,
        }

    """
    rv = dict(
        inactivity_interval=inactivity_interval,
        flowset_table_size=flowset_table_size,
        reassignment=reassignment,
    )
    if t.TYPE_CHECKING:
        return t.cast(GenFlowletOptionsSpec, rv)
    return rv


def gen_dlb_options(
        dlb_mode: tt.LBPolicyDLBMode,
        flowlet_options: GenFlowletOptionsSpec | None = None,
        egress_quantization: GenEgressQuantizationSpec | None = None,
        glb_options: GenLoadBalancingGLBPolicySpec | None = None,
        sampling_rate: t.Optional[int] | None = None,
) -> GenLoadBalancingDLBPolicySpec:
    """ Generates a payload intended for use with load balancing policy mode=dlb
        This function is intended for use with
        gen_load_balancing_policy(mode='dlb', dlb_options=gen_dlb_options(...))

        :param (tt.LBPolicyDLBMode) dlb_mode: DLB (Dynamic Load Balancing) mode
            DLB can be configured in multiple load-balancing modes. per_packet
            will add per-packet load balancing. flowlet mode renders a
            non-reactive flowlet load balancing strategy. DLB can also operate in
            reactive mode which requires additional configuration for
            reactive path reassignment thresholds within flowlet_options.

        :param (GenFlowletOptionsSpec) flowlet_options: Options specific to
            dlb_mode='flowlet'. flowlet_options are not applicable for
            dlb_mode='per_packet'.

            See gen_flowlet_options() for more details.
        :param (GenEgressQuantizationSpec) egress_quantization: Specifies options for
            egress quantization in per-packet and flowlet modes.
            If this value is None, then no egress quantization values will be
            used.

            See gen_egress_quantization() for more details.
        :param (GenLoadBalancingGLBPolicySpec) glb_options: Specifies options
            specific to GLB (Global Load Balancing). This key is optional.
            If this key is not specified then GLB will not be included in the policy.

            See gen_glb_options() for more details.

        :param (int) sampling_rate: Optionally defines the sampling rate for egress
            port load on ECMP members for updating link quality
        :return (GenLoadBalancingDLBPolicySpec): A dictionary response in the
            format:

            {
                "dlb_mode": <dlb_mode>,
                "flowlet_options": <flowlet_options> or None,
                "egress_quantization": <egress_quantization> or None,
                "glb_options": <glb_options> or None,
                "sampling_rate": <sampling_rate> or None,
            }

        Example:

            dlb_options=gen_dlb_options(
                dlb_mode='flowlet',
                flowlet_options=gen_flowlet_options(
                    inactivity_interval=16,
                    flowset_table_size=2048,
                    reassignment=gen_flowlet_reassignment_options(
                        probability_threshold=30,
                        quality_delta=5,
                    )
                ),
                egress_quantization=gen_egress_quantization(
                    quantization_min=30,
                    quantization_max=50,
                    rate_weightage=20,
                ),
                glb_options=gen_glb_options(
                    glb_mode='load_balancer_only',
                    monitor_interval=500,
                    msg_tx_interval=603,
                    update_interval=732,
                ),
                sampling_rate=62500,
            )

            Generates a payload:

            {
                "dlb_mode": "flowlet",
                "flowlet_options": {
                    "inactivity_interval": 16,
                    "flowset_table_size": 2048,
                    "reassignment": {
                        "quality_delta": 5,
                        "probability_threshold": 30
                    }
                },
                "egress_quantization": {
                    "quantization_min": 30,
                    "quantization_max": 50,
                    "rate_weightage": 20
                },
                "glb_options": {
                    "glb_mode": "load_balancer_only",
                    "msg_tx_interval": 603,
                    "monitor_interval": 500,
                    "update_interval": 732
                },
                "sampling_rate": 62500,
            }

            payload = gen_load_balancing_policy(
               mode='dlb',
               label='example_policy',
               dlb_options=dlb_options,
            )
            lb_policy_id = bp_client.load_balancing_policies.create(**payload)['id']

    """
    rv = dict(
        dlb_mode=dlb_mode,
        flowlet_options=flowlet_options,
        egress_quantization=egress_quantization,
        glb_options=glb_options,
        sampling_rate=sampling_rate,
    )
    if t.TYPE_CHECKING:
        return t.cast(GenLoadBalancingDLBPolicySpec, rv)
    return rv


def gen_load_balancing_policy(
        label: str,
        mode: tt.LBPolicyMode,
        dlb_options: GenLoadBalancingDLBPolicySpec | None = None,
        policy_type: tt.LBPolicyPolicyType = 'user_defined',
) -> GenLoadBalancingPolicySpec:
    """ Creates a payload compatible with a load balancing policy.

    This generator function creates payloads compatible with PUT and POST for
    a load balancing policy.

    :param (str) label: Label of the load balancing policy
        Load balancing policy labels must be unique within the blueprint.
    :param (tt.LBPolicyMode) mode: Operating mode of the load balancing policy
        A load balancing policy may be in one of two modes:
        * 'disabled': No load balancing policies will be rendered on the system
        * 'dlb': Indicates a Dynamic Load Balancing (DLB) policy is required.
                 This requires additional configuration of dlb_options.
    :param (tt.LBPolicyPolicyType) policy_type: Defines whether or not the policy
        is a user-defined policy (user_defined) or a built-in default policy
        (default_immutable). Users can only create user_defined policies.
    :param (GenLoadBalancingDLBPolicy_Spec) dlb_options: Specifies options for
        load balancing policies operating in DLB (Dynamic Load Balancing) mode.
        This requires the parameter mode='dlb'.

        See gen_dlb_options() for more details.
    :return (GenLoadBalancingPolicySpec): Generated dict payload compatible with
        load balancing API endpoints:
        POST /api/blueprints/{blueprint_id}/load-balancing-policies
        PUT /api/blueprints/{blueprint_id}/load-balancing-policies/{load_balancing_policy_id}

    Example:
        payload = gen_load_balancing_policy(
            label='test_everything_configured',
            mode='dlb',
            dlb_options=gen_dlb_options(
                dlb_mode='flowlet',
                flowlet_options=gen_flowlet_options(
                    inactivity_interval=16,
                    flowset_table_size=2048,
                    reassignment=gen_flowlet_reassignment_options(
                        probability_threshold=30,
                        quality_delta=5,
                    )
                ),
                egress_quantization=gen_egress_quantization(
                    quantization_min=30,
                    quantization_max=50,
                    rate_weightage=20,
                ),
                glb_options=gen_glb_options(
                    glb_mode='load_balancer_only',
                    monitor_interval=500,
                    msg_tx_interval=603,
                    update_interval=732,
                ),
            )
        )

        Generates a payload:
        {
            "label": "test_everything_configured",
            "mode": "dlb",
            "dlb_options": {
                "dlb_mode": "flowlet",
                "flowlet_options": {
                    "inactivity_interval": 16,
                    "flowset_table_size": 2048,
                    "reassignment": {
                        "quality_delta": 5,
                        "probability_threshold": 30
                    }
                },
                "egress_quantization": {
                    "quantization_min": 30,
                    "quantization_max": 50,
                    "rate_weightage": 20
                },
                "glb_options": {
                    "glb_mode": "load_balancer_only",
                    "msg_tx_interval": 603,
                    "monitor_interval": 500,
                    "update_interval": 732
                }
            },
            "policy_type": "user_defined"
        }

        Which can then be posted to the API as a new load balancing policy:

        lb_policy_id = bp_client.load_balancing_policies.create(**payload)['id']

        or used to update an existing policy:

        bp_client.load_balancing_policies[lb_policy_id].update(**payload)

        If the operation is successful, the ID of the new load balancing
        policy node will be returned.
    """
    rv = dict(
        label=label,
        mode=mode,
        dlb_options=dlb_options,
        policy_type=policy_type,
    )
    if t.TYPE_CHECKING:
        return t.cast(GenLoadBalancingPolicySpec, rv)
    return rv


def gen_load_balancing_assignment_payload(
        policy_assignments: GenLoadBalancingPolicyAssignmentSpec
) -> GenLoadBalancingPolicyAssignmentSpec:
    """ Creates a mapping of load balancing policy IDs to system node IDs.

    This function is only intended for use with type checking of the
    dictionary payloads passed in the policy_assignments argument.

    Note that API semantics require definition of all the load balancing
    policy nodes and their system IDs. An update of a single mapping of
    load balancing policy to system IDs is not supported.

    This generator is intended for use with the

    PUT /api/blueprints/{blueprint_id}/load_balancing_policies/assignments
    endpoint
    which can be invoked with the aos-sdk-client blueprint object:

    :param (GenLoadBalancingPolicyAssignmentSpec) policy_assignments: Mapping
    of policy IDs to list of system node IDs.

    :return (GenLoadBalancingPolicyAssignmentSpec): Generated dict payload compatible with
        load balancing API system assignment
        PUT /api/blueprints/{blueprint_id}/load-balancing-policies/assignments

    Example:
        bp_client.load_balancing_policies.update_assignments(
            policy_assignments=gen_load_balancing_assignment_payload(
                policy_assignments={
                    policy1_id: [system1_node_id, system2_node_id],
                    policy2_id: [],
                    policy3_id: [system3_node_id]
                }
            )
        )
    """
    if t.TYPE_CHECKING:
        return t.cast(GenLoadBalancingPolicyAssignmentSpec, policy_assignments)
    return policy_assignments
