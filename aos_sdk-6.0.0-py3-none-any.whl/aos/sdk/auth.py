#!/usr/bin/env python3
# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


def associate_granular_permission(required_permissions, scope_override=None):
    """
    The decorator adds `required_permissions` attribute to the function it decorates.
    These permissions provide fine grained rbac in addition to global permissions in
    the Auth module. Thus, accessing API associated with the decorated function would
    require the user to have ANY of the `required_permissions` in their role. These
    permissions are only effective in the absence of core permissions for the
    corresponding resource type.

    Args:
        required_permissions (list(str)): granular permissions of type list(str)
            Example ['rbac.blueprint.read', 'rbac.blueprint.read']
        scope_override (str): When this override is associated with an API,
            all requests accessing this API will be using the scope_override value
            in place of the scope in all granular permissions of the user's role(s).
    """
    def wrapper(func):
        func.granular_permissions = required_permissions
        func.scope_override = scope_override
        return func

    return wrapper


def delegate_authorization_to_application(func):
    """This decorator marks HTTP endpoint to skip authorization within
    Auth Agent.

    Auth Agent authorizes each request to Scotch, but it cannot look into request
    bodies easily. It uses data provided in HTTP headers only: HTTP verb,
    path to access, headers (including user JWT token) but it cannot do
    an introspection of HTTP body that easily.

    If we need to do a special authorization of the operation that introspects
    an HTTP request body, Auth Agent usually useless and we can skip any validation
    that is performed there.
    """

    func.delegate_authorization_to_application = True

    return func
