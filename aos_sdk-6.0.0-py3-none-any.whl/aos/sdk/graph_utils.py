# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from aos.sdk.collection_utils import get_only_item
from aos.sdk.graph import is_node
from aos.sdk.schema import ValidationError


def update_node(graph, node_id, node_type=None, **data):
    """ Idempotent node updating
    If the node doesn't exist in the graph, it is added
    If the node exists in the graph, it is updated

    :param graph: (object) Graph object
    :param node_id: (string) Id of node to update or create
    :param node_type: (string) Type of node to be created, only required if node
        doesn't exist
    :param data: (dict) Node custom property values
    :return: updated Node object
    :raises: aos.sdk.schema.ValidationError
    """
    node = graph.get_node(node_id)
    if node is not None:
        if node_type is not None and node_type != node.type:
            raise ValidationError('Mismatch in node type')
        return graph.set_node(node_id, **data)
    else:
        if node_type is None:
            raise ValidationError('Missing required node type')
        return graph.add_node(node_type, node_id, **data)


def ensure_relationship(graph, source, rel_type, target):
    rel_iter = graph.get_relationships(
        type=rel_type,
        source_id=source,
        target_id=target)
    rel_count = rel_iter.count
    if rel_count == 0:
        return graph.add_relationship(
            type=rel_type, source=source, target=target)
    elif rel_count == 1:
        rel_iter = graph.get_relationships(
            type=rel_type, source_id=source, target_id=target)
        return rel_iter.first
    else:
        assert False


def get_node_of_type(blueprint, node_type, node):
    """ Helper function for facade and api libraries to allow usage of either a
        node by ID or by node object in function usage.

    Args:
        blueprint (graph): AOS Graph object corresponding to the blueprint
        node_type (string): Node type to search for, eg, 'system' or 'interface'
        node (string, node): The node, by either node ID or Graph.Node type

    Returns:
        (node): Node object corresponding to provided node or node ID

    Raises:
        ValidationError: Raised if the node or node ID is not valid in the blueprint
                         or is an unexpected node type

    Examples:
        Given leaf_node as an AOS Node object (eg low-level API)

        >>> _node(blueprint, node_type='system', node=leaf_node)

        Given the node is only known by node ID (eg, http facade api)

        >>> _node(blueprint, node_type='system', node='leaf1_node_id')
    """
    original_node = node
    if not is_node(node):
        node = get_only_item(blueprint.get_nodes(node_type, id=node))
        if not node:
            raise ValidationError(
                'Not a valid %s node object or node id: %s' %
                (node_type, original_node))
    if node.type != node_type:
        raise ValidationError(
            'Node %s is an invalid type: (%s != %s)' %
            (original_node, node.type, node_type))
    return node
