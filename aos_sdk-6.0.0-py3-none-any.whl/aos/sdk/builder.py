# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import absolute_import
from __future__ import division

import aos.sdk.py3compat  # pylint: disable=unused-import

__all__ = [
    'BuilderPlugin',
    'Builder',

    'rule',
    'match',
    'node'
]

import logging

from six.moves import process_time

from aos.sdk.errors import Errors, get_resource_allocation_error_type
from aos.sdk.graph import BatchUpdateGraph
from aos.sdk.graph.query import QueryEngine, match, node
from aos.sdk.profiling.stats_manager import NoopStatsManager
from aos.sdk.profiling.instrument import instrument
from aos.sdk.validator import MemoryErrorReporter, Severity
from aos.sdk.time_profiler import make_profiler
from aos.sdk.graph.query import utils

# pylint: disable=redefined-builtin

LOGGER = logging.getLogger(__name__)
PROFILE = make_profiler(LOGGER.info)
instrument = instrument.nested(source=__name__)
rule = utils.rule


class BuilderError(Exception):
    pass


class BuilderPlugin(object):
    """Base class for plugin being run in a Builder instance (see below).
       Reference designs should define a class that derives from this class,
       and implement build logic in the derived class.
    """
    def __init__(self, builder):
        self.builder = builder

    def start(self):
        pass

    def stop(self):
        pass

    @property
    def input(self):
        return self.builder.input

    @property
    def output(self):
        return self.builder.output

    @property
    def asn_pool(self):
        return self.builder.asn_pool

    @property
    def device_pool(self):
        return self.builder.device_pool

    @property
    def ipv6_pool(self):
        return self.builder.ipv6_pool

    @property
    def ip_pool(self):
        return self.builder.ip_pool

    @property
    def vlan_pool(self):
        return self.builder.vlan_pool

    @property
    def vni_pool(self):
        return self.builder.vni_pool

    @property
    def integer_pool(self):
        return self.builder.integer_pool

    @property
    def errors(self):
        return self.builder.errors

    @property
    def builder_lib(self):
        return self.builder.builder_lib

    def on_commit(self):
        """Can be overridden by derived classes to perform any on commit logic"""

    def commit(self):
        self.builder.commit()

    # Note: we might want to override this method in reference design builder to have
    #  more specific error types and resolutions
    # pylint: disable=redefined-outer-name
    def set_resource_allocation_errors(self, group_name, group_type, node, messages):
        """Ensures that resource allocation-related errors are set to the given
           messages. This removes any stale allocation-related messages.
        """
        if not node:
            return

        if not isinstance(messages, list):
            # Are there cases when "messages" is actually a list?
            messages = [messages]

        assert len(messages) <= 1, 'Found resource allocation error with multiple' \
                                   'errors: %s' % messages

        related_entity_ids = [group_name, group_type]

        self.errors.clear_node_errors(
            node, [Errors.RESOURCE_ALLOCATION_ERROR], related_entity_ids)
        self.errors.clear_node_errors(
            node, [Errors.RESOURCE_ALREADY_ALLOCATED], related_entity_ids)

        if messages:
            error_type = get_resource_allocation_error_type(messages[0])
            context = dict(group_name=group_name, group_type=group_type,
                           message=messages[0])
            self.errors.toggle_node_error(node, error_type, severity=Severity.ERROR,
                                          context=context,
                                          related_entity_ids=related_entity_ids)

    # pylint: disable=redefined-outer-name
    def clear_resource_allocation_errors(self, group_name, group_type, node):
        self.set_resource_allocation_errors(group_name, group_type, node, [])

    def set_output_node(self, node_id, **kwargs):
        if self.output.get_node(node_id):
            return self.output.set_node(node_id, **kwargs)

    def cleanup(self):
        pass


class Builder(object):
    def __init__(self, plugin_class, input, output,
                 ip_pool, ipv6_pool, asn_pool, vlan_pool, vni_pool, device_pool,
                 integer_pool, errors=None, builder_lib=None,
                 input_source_name=None, output_source_name=None,
                 stats_manager=None, query_engine_type=QueryEngine):
        self.input = input
        self.output = output
        self.ip_pool = ip_pool
        self.ipv6_pool = ipv6_pool
        self.asn_pool = asn_pool
        self.vlan_pool = vlan_pool
        self.vni_pool = vni_pool
        self.device_pool = device_pool
        self.integer_pool = integer_pool
        self._pool_clients = [
            ip_pool, ipv6_pool, asn_pool, vlan_pool, vni_pool, device_pool,
            integer_pool]
        self.errors = errors or MemoryErrorReporter()
        self.builder_lib = builder_lib
        self.input_source_name = input_source_name
        self.output_source_name = output_source_name

        self._stats_manager = stats_manager or NoopStatsManager()
        self._stats_commit = self._stats_manager.create_namespace('commit')
        self._stats_qe = self._stats_manager.create_namespace('QueryEngine')

        self.plugin = plugin_class(self)

        self._engine = query_engine_type(stats_manager=self._stats_qe)

        utils.register_rules(self.plugin, self._engine)

        self._initial = True
        self._is_committing = False

    def _wrap_with_batch_update_graph(self, graph):
        if not isinstance(graph, BatchUpdateGraph):
            return BatchUpdateGraph(graph)
        return graph

    def start(self):
        self.plugin.start()

        for pool_client in self._pool_clients:
            pool_client.start()
        self.input.add_observer(self)
        self._initial = True

        LOGGER.info('starting builder, is input committed? %s',
                    self.input.is_committed())

        if self.input.is_committed():
            self.output = self._wrap_with_batch_update_graph(self.output)
            self.on_graph(self.input)

    def stop(self):
        self.input.remove_observer(self)
        for pool_client in self._pool_clients:
            pool_client.stop()

        self.plugin.stop()

    def cleanup(self):
        for pool_client in self._pool_clients:
            pool_client.cleanup()
        self.plugin.cleanup()

    def on_commit(self):
        self.plugin.on_commit()

    def _initial_sync(self):
        for obj in self.output.get_nodes():
            if self.input.get_node(obj.id) is None:
                self.output.del_node(obj)

        for relationship in self.output.get_relationships():
            if self.input.get_relationship(relationship.id) is None:
                self.output.del_relationship(relationship)

        with PROFILE('%s initial sync nodes:' % self.output.id):
            for obj in self.input.get_nodes():
                self._sync_node(obj)

        with PROFILE('%s initial sync relationships:' % self.output.id):
            for relationship in self.input.get_relationships():
                self._sync_relationship(relationship)

    def commit(self):
        LOGGER.info('commit, initial? %s, graph ID %s', self._initial, self.input.id)
        activity_id = instrument.begin(
            'builder commit', graph_id=self.input.id,
            input_version=self.input.version, output_version=self.output.version)

        if self._is_committing:
            # This check ensures that the commit is not called recursively due
            # to wrong implementation of a plugin. If the plugin calls builder
            # commit recursively, pool clients will be committed before the
            # plugin finishes all its on commit processing. In this case,
            # unaccounted allocations will be considered as stale and
            # deallocated on the first commit. This can result in unwanted
            # reallocations.
            raise BuilderError('Called commit inside commit')

        self._is_committing = True
        ts_begin = process_time()

        if self._initial:
            self._initial_sync()

            with PROFILE('%s initial execute all:' % self.output.id):
                self._engine.execute_all(self.input)
                instrument.checkpoint(activity_id, 'QE execute_all')

            if hasattr(self.input, 'reset_snapshot'):
                # This applies only to cpp graph, and only to unit test.
                #
                # Cpp graph provider automatically instantiates a snapshot
                # graph on top of input config blueprint to keep track of
                # changes as they are serialized from sysdb. It's possible
                # for a unit test to do following:
                #   1) construct an empty config blueprint
                #   2) start builder constrainer
                #   3) add nodes/relationships to config blueprint
                #   4) commit config blueprint
                # At step 4, builder.commit() will be invoked, we'd first
                # call self._engine.execute_all() which notifies all observers
                # of added nodes/relationships, followed by self._engine.on_graph()
                # which sends the same set of notification again. We reset the
                # snapshot graph below to avoid this double notification.
                #
                # Note that the scenario described above will not happen in
                # production environment. builder.commit() is guaranteed to be
                # invoked within transaction. We will never see an empty or
                # partially initialized graph in transaction because we do not
                # have a writer who would commit an empty or partial graph.
                #
                # SDK has a different behavior. It relies on query engine's
                # on_graph() call to create a SnapshotGraph. So the first call
                # to self._engine.on_graph() will not generate any notification
                # since a freshly instantiated SnapshotGraph contains no change.
                self.input.reset_snapshot()

            self._initial = False

        ts_engine_graph = process_time()

        self._engine.on_graph(self.input)

        instrument.checkpoint(activity_id, 'QE on_graph')
        ts_on_commit = process_time()

        # This has to be done after executing queries to ensure callbacks are invoked
        # and before pool commits to ensure derived classes can (de)allocate
        with PROFILE('%s rule engine on_commit():' % self.output.id):
            self.on_commit()

        ts_pool_commit = process_time()

        self.ip_pool.commit()
        self.ipv6_pool.commit()
        self.asn_pool.commit()
        self.vlan_pool.commit()
        self.vni_pool.commit()
        self.integer_pool.commit()
        self.device_pool.commit()

        if self.input_source_name:
            source_versions = {
                self.input_source_name: self.input.version
            }
        else:
            source_versions = None

        ts_output_commit = process_time()

        # errors might be committed as the result of the output graph commit
        # and if that was the case we do not want to commit errors again
        errors_version_before_output_commit = self.errors.version

        gai = getattr(self.output, 'gai', None)
        if gai:
            # we guarantee that all GAI indexes will be updated _before_
            # any other observer (like, validator or deployer). So, even
            # graph is dirty, we are fine to expose indexes to consumers if
            # these consumers do not modify a staging graph.
            with gai.indexes_are_up_to_date():
                self.output.commit(source_versions=source_versions)
        else:
            self.output.commit(source_versions=source_versions)

        if self.errors.version == errors_version_before_output_commit:
            # we want to make sure that we commit errors during the builder commit
            # to flush any changes that errors might incur as the result of the
            # Builder Plugin execution -- even if output graph did not change itself
            source_versions = None
            if self.output_source_name:
                source_versions = {
                    self.output_source_name: self.output.version,
                }
            self.errors.commit(source_versions=source_versions)

        self.output = self._wrap_with_batch_update_graph(self.output)

        ts_end = process_time()

        instrument.end(activity_id)

        self._stats_commit.add_entry({
            # Metadata
            'tags': {
                'graph_id': self.input.id,
                'input_version': self.input.version,
                'output_version': self.output.version,
            },
            # Stats
            'init_sync': ts_engine_graph - ts_begin,
            'engine_on_graph': ts_on_commit - ts_engine_graph,
            'on_commit': ts_pool_commit - ts_on_commit,
            'pool_commit': ts_output_commit - ts_pool_commit,
            'output_commit': ts_end - ts_output_commit,
        })
        self._is_committing = False

    def _sync_node(self, obj):
        if self.output.get_node(obj.id) is None:
            self.output.add_node(obj.type, id=obj.id, **obj.properties)
        else:
            self.output.set_node(obj.id, **obj.properties)

    def _sync_relationship(self, rel):
        if self.output.get_relationship(rel.id) is None:
            self.output.add_relationship(rel.type, rel.source_id, rel.target_id,
                                         id=rel.id, **rel.properties)
        else:
            self.output.set_relationship(rel.id, **rel.properties)

    def on_graph(self, graph):
        with PROFILE('%s rule engine commit():' % self.output.id):
            self.commit()

    def on_node(self, graph, old_node, new_node):
        if self._initial:
            return

        if new_node:
            self._sync_node(new_node)
        else:
            self.output.del_node(old_node.id)
        self._engine.on_node(graph, old_node, new_node)

    def on_relationship(self, graph, old_rel, new_rel):
        if self._initial:
            return

        if new_rel:
            self._sync_relationship(new_rel)
        else:
            self.output.del_relationship(old_rel.id)
        self._engine.on_relationship(graph, old_rel, new_rel)
