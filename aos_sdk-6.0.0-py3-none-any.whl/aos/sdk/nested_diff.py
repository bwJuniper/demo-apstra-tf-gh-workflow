# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import six


def get_diff(old, new):

    def _diff(old, new, result):
        for ok, ov in six.iteritems(old):
            if ok not in new:
                result.setdefault('removed', {})[ok] = ov
            else:
                nv = new[ok]
                if isinstance(ov, dict) and isinstance(nv, dict):
                    value_diff = _diff(ov, nv, {})
                    if value_diff:
                        result.setdefault('changed', {})[ok] = value_diff
                elif ov != nv:
                    result.setdefault('changed', {})[ok] = {
                        'old': ov,
                        'new': nv
                    }

        for nk, nv in six.iteritems(new):
            if nk not in old:
                result.setdefault('added', {})[nk] = nv

        return result

    return _diff(old, new, dict(old=old, new=new, added={}, removed={}, changed={}))
