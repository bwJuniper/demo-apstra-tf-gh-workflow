# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula
# pylint: disable=redefined-builtin, missing-docstring

import logging
import weakref

from aos.sdk.utils import cachedproperty

LOGGER = logging.getLogger(__name__)


def weak_ref(observer):
    """
    Create weakref wrapper for the observer.

    This wrapper handles the edge case with bound methods where weakref.ref is
    unable to work as expected because when bound method is retrieved Python
    creates a new wrapping object every time, so that "weakref.ref(obj.method)" is
    dead-on-arrival, meaning such weak ref is dead immediately.
    """
    try:
        return weakref.WeakMethod(observer)
    except TypeError:
        return weakref.ref(observer)


class AosLibraryResources(object):
    def __init__(self):
        self._observers = set()

    def list(self):
        raise NotImplementedError()

    def get(self, id):
        raise NotImplementedError()

    def __iter__(self):
        for item in self.list():
            yield item

    def __getitem__(self, id):
        return self.get(id)

    def _notify(self, item, action):
        self._remove_dead_observers()
        for observer_weak_ref in self._observers:
            observer = observer_weak_ref()
            # it is still possible to encounter dead weakref if GC runs in between
            # and cleans up some observers
            if observer is not None:
                observer(item, action)

    def stop(self):
        pass

    def add_ref(self, id, referral_type, referral_id):
        raise NotImplementedError()

    def remove_ref(self, id, referral_type, referral_id):
        raise NotImplementedError()

    def add_observer(self, observer):
        self._observers.add(weak_ref(observer))

    def remove_observer(self, observer):
        self._observers.discard(weak_ref(observer))

    def _remove_dead_observers(self):
        for observer_weak_ref in list(self._observers):
            if observer_weak_ref() is None:
                LOGGER.warning(
                    'Detected dead observer which was not explicitly removed')
                self._observers.discard(observer_weak_ref)

    def has_observers(self):
        self._remove_dead_observers()
        return bool(self._observers)


class AosLibraryBase(object):
    """Helper class to obtain AOS artifacts such as design templates,
       logical devices, device profiles, property sets, config templates and
       various device info.
    """
    def start(self):
        pass

    def stop(self):
        pass

    @cachedproperty
    def logical_devices(self):
        return AosLibraryResources()

    @cachedproperty
    def interface_maps(self):
        return AosLibraryResources()

    @cachedproperty
    def interface_maps_digest(self):
        return AosLibraryResources()

    @cachedproperty
    def device_profiles(self):
        return AosLibraryResources()

    @cachedproperty
    def design_templates(self):
        return AosLibraryResources()

    @property
    def property_sets(self):
        return AosLibraryResources()

    @cachedproperty
    def config_templates(self):
        return AosLibraryResources()

    @cachedproperty
    def device_infos(self):
        return AosLibraryResources()

    @cachedproperty
    def device_statuses(self):
        return AosLibraryResources()

    @cachedproperty
    def onbox_device_id_index(self):
        return object()

    @cachedproperty
    def offbox_admin_configs(self):
        return AosLibraryResources()

    @cachedproperty
    def offbox_admin_statuses(self):
        return AosLibraryResources()

    @cachedproperty
    def devices_pristine_config(self):
        return AosLibraryResources()
