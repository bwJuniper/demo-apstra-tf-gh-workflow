# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

class InvalidInterfaceNameError(Exception):
    pass

class InvalidInterfaceSpeedError(Exception):
    pass

class InvalidInterfaceError(Exception):
    pass

class UnsupportedHclError(Exception):
    pass
