# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import absolute_import
from __future__ import annotations
from __future__ import division

from enum import Enum
import typing as t

if t.TYPE_CHECKING:
    from aos.sdk import typing as tt


class GraphCyclicError(Exception):
    message: t.ClassVar[str] = (
        "Found a cycle in the graph. The path: [{path}]."
    )
    path: list[tt.GraphNode]

    def __init__(self, path: list[tt.GraphNode]) -> None:
        super(GraphCyclicError, self).__init__(
            self.message.format(path=', '.join(str(path))))
        self.path = path


class ProcessingStatus(Enum):
    NOT_VISITED: t.Final[int] = 0
    IN_PROCESSING: t.Final[int] = 1
    PROCESSED: t.Final[int] = 2


# TODO(Sergey Arkhipov)
# Eventually switch to https://docs.python.org/3/library/graphlib.html
def sort_topologically(graph: dict[tt.GraphNode, t.Iterable[tt.GraphNode]]
                       ) -> list[tt.GraphNode]:
    """
    Input graph should be represented as a dict, where key is a graph node
    and value is a collection of its adjacent nodes:
    {
        v1: [v3, v4],
        v2: [],
        v3: [v2],
        v4: [v2]
    }
    Returns a list of topologically sorted nodes:
    [v1, v4, v3, v2]

    Algorithm uses both graph dict and lists of adjacent nodes
    as generic collections and iterates over them using "for x in v".
    If it is important to preserve deterministic behaviour of the algorithm,
    it is encouraged to use OrderedDict for the graph and sort the lists of
    adjacent nodes.
    """

    node_status: dict[tt.GraphNode, ProcessingStatus] = {}
    path_parent: dict[tt.GraphNode, tt.GraphNode | None] = {}
    ordered_graph = []

    def restore_path(start_node: tt.GraphNode, end_node: tt.GraphNode
                     ) -> list[tt.GraphNode]:
        """
        Back-tracking path restoration
        """
        path = []
        while end_node != start_node:
            path.append(end_node)
            parent = path_parent[end_node]
            if t.TYPE_CHECKING:
                parent = t.cast(tt.GraphNode, parent)
            end_node = parent
        path.append(start_node)
        path.reverse()
        return path

    def dfs(node: tt.GraphNode, parent: t.Optional[tt.GraphNode] = None
            ) -> None:
        color = node_status.get(node, ProcessingStatus.NOT_VISITED)
        if color == ProcessingStatus.PROCESSED:
            return
        if color == ProcessingStatus.IN_PROCESSING:
            if t.TYPE_CHECKING:
                parent = t.cast(tt.GraphNode, parent)
            cyclic_path = restore_path(node, parent)
            raise GraphCyclicError(cyclic_path)

        node_status[node] = ProcessingStatus.IN_PROCESSING
        path_parent[node] = parent

        for adjacent_node in graph[node]:
            if adjacent_node in graph:
                dfs(adjacent_node, parent=node)

        node_status[node] = ProcessingStatus.PROCESSED
        ordered_graph.append(node)

    for node in graph:
        dfs(node)

    ordered_graph.reverse()
    return ordered_graph
