# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=missing-docstring,undefined-variable,invalid-name
# pylint: disable=attribute-defined-outside-init
# pylint: disable=redefined-builtin,deprecated-lambda

from __future__ import annotations

import uuid
from itertools import chain
import typing as t

from .graph import Node, Relationship, NodeIterator, RelationshipIterator, \
    extract_candidate_ids, is_node, is_relationship, normalize_id, \
    sanitize_traverse_nodes, dump_graph
from .matchers import is_matcher, eq
from .index import CompactRelationshipIndex, GraphIndex
from .utils import properties_equal
from aos.sdk.types import ValidationError
import six
from six.moves import filter

if t.TYPE_CHECKING:
    import collections
    import typing_extensions as te
    from aos.sdk import typing as tt

    class NodeKwargs(t.TypedDict, total=False):
        tag: str

    class RelationshipKwargs(t.TypedDict, total=False):
        tag: str

    class MatcherKwargs(t.TypedDict, total=False):
        id: str | tt.PropertyMatcher | None
        source_id: str | tt.PropertyMatcher | None
        target_id: str | tt.PropertyMatcher | None
        tag: str


class UpdateGraphBase(object):
    _graph: tt.Graph
    _updated_nodes: dict[str, tt.GraphNode]
    _removed_nodes: set[str]
    _updated_relationships: dict[str, tt.GraphRelationship]
    _removed_relationships: set[str]
    _node_indexes: list[GraphIndex]
    _node_indexes_by_type: dict[str, list[GraphIndex]]
    _relationship_indexes: list[CompactRelationshipIndex]

    def __init__(self, graph: tt.Graph) -> None:
        self._graph = graph
        self._reset()

    def _reset(self) -> None:
        self._updated_nodes = {}
        self._removed_nodes = set()
        self._updated_relationships = {}
        self._removed_relationships = set()

        self._node_indexes = [GraphIndex(['type'])]
        self._node_indexes_by_type = {
            node_schema.type: [
                GraphIndex(columns)
                for columns in node_schema.indexes
            ]
            for node_schema in six.itervalues(self._graph.schema.nodes)
            if node_schema.indexes
        }

        self._relationship_indexes = [CompactRelationshipIndex()]

    @property
    def schema(self) -> tt.Schema:
        return self._graph.schema

    @property
    def id(self) -> str:
        return self._graph.id

    @property
    def version(self) -> int:
        return self._graph.version

    @property
    def source_versions(self) -> collections.abc.Mapping[
        tt.BlueprintType, tt.BlueprintVersion
    ]:
        return self._graph.source_versions

    def is_dirty(self) -> bool:
        if not self._graph.is_committed():
            return True
        return bool(
            self._updated_nodes or
            self._updated_relationships or
            self._removed_nodes or
            self._removed_relationships
        )

    def is_committed(self) -> bool:
        return self._graph.is_committed()

    def _make_matcher(
            self,
            type: t.Optional[str] = None,
            **kwargs: te.Unpack[MatcherKwargs]
    ) -> t.Callable[[tt.GraphNode | tt.GraphRelationship],
    bool]:
        type_matcher = None
        if type is not None:
            type_matcher = type if is_matcher(type) else eq(type)

        unpacked_kwargs = {k: v if is_matcher(v) else eq(v)
                           for k, v in six.iteritems(kwargs)
                           if v is not None}
        tag_matcher = unpacked_kwargs.pop('tag', None)

        def matcher(obj):
            # Need to process type first as the rest can refer to type specific
            # attributes
            if type_matcher and not type_matcher(obj.type):
                return False
            if tag_matcher and not tag_matcher(self.get_tags(obj)):
                return False
            return all(v(getattr(obj, k)) for k, v in six.iteritems(unpacked_kwargs))

        return matcher

    def get_node(self, node_id: tt.GraphNode | tt.GraphNodeId
                 ) -> t.Optional[tt.GraphNode]:
        if is_node(node_id):
            node_id = node_id.id

        if node_id in self._removed_nodes:
            return None

        if t.TYPE_CHECKING:
            node_id = t.cast(tt.GraphNodeId, node_id)
        return (
            self._updated_nodes.get(node_id) or
            self._graph.get_node(node_id)
        )

    def get_nodes(self, type: t.Optional[tt.GraphNodeType] = None,
                  id: t.Optional[tt.GraphNode | tt.GraphNodeId] = None,
                  **kwargs: te.Unpack[tt.KwargsDict]
                  ) -> tt.GraphNodeIterator:
        if not self._removed_nodes and not self._updated_nodes:
            return self._graph.get_nodes(type=type, id=id, **kwargs)

        normalized_id = normalize_id(id, predicate=is_node)
        candidate_ids = extract_candidate_ids(normalized_id)

        if candidate_ids == []:
            return NodeIterator(self, [])

        matcher = self._make_matcher(
            type=type,
            id=normalized_id if candidate_ids is None else None,
            **kwargs
        )

        if candidate_ids is None:
            node_indexes_by_type = (self._node_indexes_by_type.get(type, [])
                                    if type else [])
            lookup_results = [
                (len(self._updated_nodes), six.iterkeys(self._updated_nodes))
            ] + [
                index.lookup(type=type, id=normalized_id, **kwargs)
                for index in
                self._node_indexes + node_indexes_by_type
            ]
            _, candidate_ids = min(  # type: ignore
                (x for x in lookup_results if x is not None),
                key=lambda x: x[0]
            )
            assert(candidate_ids is not None)
            candidate_ids = list(candidate_ids)

        return NodeIterator(
            self,
            chain(
                filter(lambda node:
                       node.id not in self._removed_nodes and
                       node.id not in self._updated_nodes,
                       self._graph.get_nodes(
                           type=type,
                           id=normalized_id,
                           **kwargs
                       )),
                filter(
                    matcher,
                    (node
                     for node_id in candidate_ids
                     for node in [self._updated_nodes.get(node_id)]
                     if node is not None)
                )
            )
        )

    def get_relationship(self, rel_id: tt.GraphRelationship | tt.GraphRelationshipId
                         ) -> t.Optional[tt.GraphRelationship]:
        if is_relationship(rel_id):
            rel_id = rel_id.id

        if rel_id in self._removed_relationships:
            return None

        if t.TYPE_CHECKING:
            rel_id = t.cast(tt.GraphRelationshipId, rel_id)
        return (
            self._updated_relationships.get(rel_id) or
            self._graph.get_relationship(rel_id)
        )

    def get_relationships(
            self,
            type: t.Optional[tt.GraphRelationshipType] = None,
            source_id: t.Optional[tt.GraphNode | tt.GraphNodeId] = None,
            target_id: t.Optional[tt.GraphNode | tt.GraphNodeId] = None,
            id: t.Optional[tt.GraphRelationship | tt.GraphRelationshipId] = None,
            **kwargs: te.Unpack[tt.KwargsDict]
        ) -> tt.GraphRelationshipIterator:
        if not self._removed_relationships and not self._updated_relationships:
            return self._graph.get_relationships(
                type=type,
                source_id=source_id,
                target_id=target_id,
                id=id,
                **kwargs
            )

        normalized_source_id = normalize_id(source_id, predicate=is_node)
        normalized_target_id = normalize_id(target_id, predicate=is_node)
        normalized_id = normalize_id(id, predicate=is_relationship)
        if t.TYPE_CHECKING:
            normalized_source_id = t.cast(
                tt.GraphNodeId | None, normalized_source_id)
            normalized_target_id = t.cast(
                tt.GraphNodeId | None, normalized_target_id)
            normalized_id = t.cast(
                tt.GraphRelationshipId | None, normalized_id)

        candidate_ids = extract_candidate_ids(normalized_id)

        if candidate_ids == []:
            return RelationshipIterator(self, [])

        matcher = self._make_matcher(
            type=type,
            source_id=normalized_source_id,
            target_id=normalized_target_id,
            id=normalized_id if candidate_ids is None else None,
            **kwargs
        )

        if candidate_ids is None:
            lookup_results = [(
                len(self._updated_relationships),
                six.iterkeys(self._updated_relationships)
            )]
            for index in self._relationship_indexes:
                index_result = index.lookup(
                    type=type,
                    source_id=normalized_source_id,
                    target_id=normalized_target_id,
                    id=normalized_id,
                    **kwargs
                )
                if index_result:
                    lookup_results.append(index_result)
            _, candidate_ids = min(  # type: ignore
                (x for x in lookup_results if x is not None),
                key=lambda x: x[0]
            )
            assert(candidate_ids is not None)
            candidate_ids = list(candidate_ids)

        return RelationshipIterator(
            self,
            chain(
                filter(lambda rel:
                       rel.id not in self._removed_relationships and
                       rel.id not in self._updated_relationships,
                       self._graph.get_relationships(
                           type=type,
                           source_id=normalized_source_id,
                           target_id=normalized_target_id,
                           id=normalized_id,
                           **kwargs
                       )),
                filter(
                    matcher,
                    (rel
                     for rel_id in candidate_ids
                     for rel in [self._updated_relationships.get(rel_id)]
                     if rel is not None)
                )
            )
        )

    def get_tags(self, node: tt.GraphNode | tt.GraphNodeId) -> set[str]:
        """ Get tags for a given node.
        """
        graph_node = self.get_node(node)
        return {
            tag_node.lowercased
            for tag_node in self.traverse(graph_node).in_('tag').node('tag')
        }

    def traverse(self,
                 nodes: t.Optional[t.Iterable[tt.GraphNode] | tt.GraphNode] = None,
                 node_type: t.Optional[str] = None
                 ) -> tt.GraphNodeIterator:
        if not nodes and node_type is None:
            return NodeIterator(self, [])

        if nodes is None:
            return self.get_nodes(type=node_type)

        nodes = sanitize_traverse_nodes(nodes)
        if t.TYPE_CHECKING:
            nodes = t.cast(t.Iterable[tt.GraphNode], nodes)

        return NodeIterator(self, nodes)


class BatchUpdateGraph(UpdateGraphBase):
    _observers: list[tt.GraphObserver]
    _building_batch: bool

    def __init__(self, graph: tt.Graph) -> None:
        super(BatchUpdateGraph, self).__init__(graph)
        self._observers = []
        self._building_batch = False

    def add_observer(self, observer: tt.GraphObserver) -> None:
        self._observers.append(observer)

    def remove_observer(self, observer: tt.GraphObserver) -> None:
        if observer in self._observers:
            self._observers.remove(observer)

    def commit(self, source_versions: t.Optional[tt.SourceVersions] = None) -> None:
        updated = False
        for rel_id in self._removed_relationships:
            updated = True
            self._graph.del_relationship(rel_id)
        for node_id in self._removed_nodes:
            updated = True
            self._graph.del_node(node_id)
        for node in self._updated_nodes.values():
            old_node = self._graph.get_node(node.id)
            if old_node is None:
                updated = True
                self._graph.add_node(node.type, id=node.id, **node.properties)
            elif not properties_equal(node.properties, old_node.properties):
                updated = True
                self._graph.set_node(node.id, **node.properties)
        for rel in self._updated_relationships.values():
            old_rel = self._graph.get_relationship(rel.id)
            if old_rel is None:
                updated = True
                self._graph.add_relationship(
                    rel.type, rel.source_id, rel.target_id, id=rel.id,
                    **rel.properties
                )
            elif not properties_equal(rel.properties, old_rel.properties):
                updated = True
                self._graph.set_relationship(rel.id, **rel.properties)

        self._reset()
        source_versions_updated = (source_versions is not None and
                                   source_versions != self._graph.source_versions)
        if updated or source_versions_updated or not self._graph.version:
            self._graph.commit(source_versions=source_versions)
            for observer in self._observers:
                observer.on_graph(self)

    def add_node(self,
                 type: str,
                 id: t.Optional[str] = None,
                 **data: object
                 ) -> tt.GraphNode:
        if id and self.get_node(id):
            raise ValueError('Node with id %s already exists' % id)

        node_id = id or str(uuid.uuid4())
        schema = self._graph.schema.get_node_schema(type)

        errors = schema.validate(data, raw=True)
        if errors:
            raise ValidationError(errors)

        node = Node(schema, id=node_id, properties=data)
        self._updated_nodes[node.id] = node
        self._removed_nodes.discard(node.id)
        for index in chain(self._node_indexes,
                           self._node_indexes_by_type.get(node.type, [])):
            index.add(node)

        for observer in self._observers:
            observer.on_node(self, None, node)

        return node

    def set_node(self, node_id: tt.GraphNode | tt.GraphNodeId, **data: object
                 ) -> tt.GraphNode:
        if is_node(node_id):
            node_id = node_id.id
        if t.TYPE_CHECKING:
            node_id = t.cast(tt.GraphNodeId, node_id)

        old_node: tt.GraphNode | None
        if node_id in self._updated_nodes:
            old_node = self._updated_nodes[node_id]
        else:
            if node_id in self._removed_nodes:
                raise ValueError('Unknown node: %s' % node_id)
            old_node = self._graph.get_node(node_id)
            if old_node is None:
                raise ValueError('Unknown node: %s' % node_id)

        schema = old_node._schema

        # TODO: this code has a problem -- for no-op updates will we still call
        #  on_node observers and only for agent local ones; no-op update will not be
        #  propagated via TACC to other agents; this causes inherent asymmetry
        #  between how unit tests behave (where all observers are local) and how
        #  observers will behave in some real world cases where updates will cross
        #  a boundary of a single agent; it might cause hard to detect issues;

        full_data = dict(old_node.properties, **data)
        errors = schema.validate(full_data, raw=True)
        if errors:
            raise ValidationError(errors)

        new_node = Node(schema, id=old_node.id, properties=full_data)
        self._updated_nodes[new_node.id] = new_node

        for index in chain(self._node_indexes,
                           self._node_indexes_by_type.get(new_node.type, [])):
            index.add(new_node)

        for observer in self._observers:
            observer.on_node(self, old_node, new_node)

        return new_node

    def del_node(self, node_id: tt.GraphNode | tt.GraphNodeId) -> None:
        if is_node(node_id):
            node_id = node_id.id

        if node_id is None:
            return

        if t.TYPE_CHECKING:
            node_id = t.cast(tt.GraphNodeId, node_id)

        for rel in chain(self.get_relationships(source_id=node_id),
                         self.get_relationships(target_id=node_id)):
            self.del_relationship(rel)

        node: tt.GraphNode | None
        if node_id in self._updated_nodes:
            node = self._updated_nodes.pop(node_id)
            if self._graph.get_node(node_id):
                self._removed_nodes.add(node_id)

            for index in chain(self._node_indexes,
                               self._node_indexes_by_type.get(node.type, [])):
                index.remove(node)
        elif node_id in self._removed_nodes:
            return
        else:
            node = self._graph.get_node(node_id)
            if node is None:
                return

            self._removed_nodes.add(node_id)

        for observer in self._observers:
            observer.on_node(self, node, None)

    def add_relationship(
            self,
            type: str,
            source: tt.GraphNode | tt.GraphNodeId,
            target: tt.GraphNode | tt.GraphNodeId,
            id: t.Optional[str] = None,
            **data: object) -> tt.GraphRelationship:
        if id and self.get_relationship(id):
            raise ValueError('Relationship with id %s already exists' % id)

        source_node_id = source.id if is_node(source) else source
        target_node_id = target.id if is_node(target) else target

        relationship_id = id or str(uuid.uuid4())
        source_node = self.get_node(source_node_id)
        target_node = self.get_node(target_node_id)

        if source_node is None:
            raise ValueError('Unknown node: %s' % source_node_id)
        if target_node is None:
            raise ValueError('Unknown node: %s' % target_node_id)

        schema = self._graph.schema.get_relationship_schema(
            type, source_node.type, target_node.type,
        )

        errors = schema.validate(data, raw=True)
        if errors:
            raise ValidationError(errors)

        rel = Relationship(schema, id=relationship_id, source=source_node,
                           target=target_node, properties=data)
        self._updated_relationships[rel.id] = rel
        self._removed_relationships.discard(rel.id)
        for index in self._relationship_indexes:
            index.add(rel)

        for observer in self._observers:
            observer.on_relationship(self, None, rel)

        return rel

    def set_relationship(
            self,
            rel_id: tt.GraphRelationship | tt.GraphRelationshipId,
            **data: object
    ) -> tt.GraphRelationship:
        if is_relationship(rel_id):
            rel_id = rel_id.id
        if t.TYPE_CHECKING:
            rel_id = t.cast(tt.GraphRelationshipId, rel_id)

        old_rel : tt.GraphRelationship | None
        if rel_id in self._updated_relationships:
            old_rel = self._updated_relationships[rel_id]
        else:
            if rel_id in self._removed_relationships:
                raise ValueError('Unknown relationship: %s' % rel_id)
            old_rel = self._graph.get_relationship(rel_id)
            if old_rel is None:
                raise ValueError('Unknown relationship: %s' % rel_id)

        schema = old_rel._schema

        full_data = dict(old_rel.properties, **data)
        errors = schema.validate(full_data, raw=True)
        if errors:
            raise ValidationError(errors)

        new_rel = Relationship(
            schema, id=old_rel.id,
            source=old_rel.source_id,
            target=old_rel.target_id,
            properties=full_data,
        )
        self._updated_relationships[new_rel.id] = new_rel
        for index in self._relationship_indexes:
            index.add(new_rel)

        for observer in self._observers:
            observer.on_relationship(self, old_rel, new_rel)

        return new_rel

    def del_relationship(self, rel_id: tt.GraphRelationship | tt.GraphRelationshipId
                         ) -> None:
        if is_relationship(rel_id):
            rel_id = rel_id.id
        if t.TYPE_CHECKING:
            rel_id = t.cast(tt.GraphRelationshipId, rel_id)

        rel: tt.GraphRelationship | None
        if rel_id in self._updated_relationships:
            rel = self._updated_relationships.pop(rel_id)
            if self._graph.get_relationship(rel_id):
                self._removed_relationships.add(rel_id)

            for index in self._relationship_indexes:
                index.remove(rel)
        elif rel_id in self._removed_relationships:
            return
        else:
            rel = self._graph.get_relationship(rel_id)
            if rel is None:
                return

            self._removed_relationships.add(rel_id)

        for observer in self._observers:
            observer.on_relationship(self, rel, None)

        if rel._schema.sticky:
            self.del_node(rel.target_id)

    def json(self) -> tt.JSON:
        return dump_graph(self, make_compact=False)
