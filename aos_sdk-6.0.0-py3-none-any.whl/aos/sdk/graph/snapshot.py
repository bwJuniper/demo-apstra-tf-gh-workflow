# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=redefined-builtin

from __future__ import annotations

import typing as t
from copy import deepcopy
from itertools import chain

from aos.sdk.graph.batch import UpdateGraphBase


if t.TYPE_CHECKING:
    from aos.sdk import typing as tt
    from .index import CompactRelationshipIndex, GraphIndex


class ImmutableGraphError(Exception):
    pass


class Action(object):
    def __init__(self, name: str) -> None:
        self.name = name

    def __repr__(self) -> str:
        return self.name

ADDED: t.Final[Action] = Action('ADDED')
UPDATED: t.Final[Action] = Action('UPDATED')
REMOVED: t.Final[Action] = Action('REMOVED')

class SnapshotGraph(UpdateGraphBase):
    _old_version: int
    _old_is_committed: bool
    _old_source_versions: tt.SourceVersions

    def __init__(self, graph: tt.Graph, react_on_graph: bool = True
                 ) -> None:
        super(SnapshotGraph, self).__init__(graph)
        if react_on_graph:
            self._graph.add_observer(self)
        self._capture(graph)

    def _capture(self, graph: tt.Graph) -> None:
        # snapshots underlying graph versions/source_versions
        self._old_version = graph.version
        self._old_is_committed = graph.is_committed()
        self._old_source_versions = deepcopy(graph.source_versions)

    def reset(self) -> None:
        super(SnapshotGraph, self)._reset()
        self._capture(self._graph)

    @property
    def version(self) -> int:
        return self._old_version

    @property
    def source_versions(self) -> dict[str, int]:
        return self._old_source_versions

    def add_observer(self, observer: tt.GraphObserver) -> None:
        pass

    def remove_observer(self, observer: tt.GraphObserver) -> None:
        pass

    def is_committed(self) -> bool:
        return self._old_is_committed

    def _immutable(self, *args, **kwargs) -> None:
        raise ImmutableGraphError()

    add_node = set_node = del_node = _immutable
    add_relationship = set_relationship = del_relationship = _immutable
    commit = _immutable

    def _on_object(self,
                   old_obj: t.Optional[tt.GraphNode | tt.GraphRelationship],
                   new_obj: t.Optional[tt.GraphNode | tt.GraphRelationship],
                   old_objs: dict[str, tt.GraphNode | tt. GraphRelationship],
                   new_objs: set[str],
                   indexes: t.Iterable[GraphIndex | CompactRelationshipIndex]
                   ) -> None:
        if not old_obj and not new_obj:
            return

        if not old_obj and new_obj:
            # added
            if new_obj.id not in old_objs:
                new_objs.add(new_obj.id)
        elif old_obj and not new_obj:
            # removed
            if old_obj.id in new_objs:
                new_objs.remove(old_obj.id)
            else:
                old_objs[old_obj.id] = old_obj
                for index in indexes:
                    index.add(old_obj)
        else:
            # updated
            assert(old_obj)
            if old_obj.id in new_objs:
                pass
            elif old_obj.id not in old_objs:
                old_objs[old_obj.id] = old_obj
                for index in indexes:
                    index.add(old_obj)

    @t.overload
    def on_node(self, graph: tt.Graph, old_node: None, new_node: tt.GraphNode
                ) -> None:
        ...

    @t.overload
    def on_node(self, graph: tt.Graph, old_node: tt.GraphNode, new_node: None
                ) -> None:
        ...

    @t.overload
    def on_node(
            self, graph: tt.Graph, old_node: tt.GraphNode, new_node: tt.GraphNode
    ) -> None:
        ...

    def on_node(self, graph, old_node, new_node):
        type = (old_node or new_node).type
        self._on_object(
            old_node, new_node,
            self._updated_nodes,
            self._removed_nodes,
            chain(self._node_indexes, self._node_indexes_by_type.get(type, [])),
        )

    @t.overload
    def on_relationship(
            self, graph: tt.Graph, old_rel: None, new_rel: tt.GraphRelationship
    ) -> None:
        ...

    @t.overload
    def on_relationship(
            self, graph: tt.Graph, old_rel: tt.GraphRelationship, new_rel: None
    ) -> None:
        ...

    @t.overload
    def on_relationship(
            self,
            graph: tt.Graph,
            old_rel: tt.GraphRelationship,
            new_rel: tt.GraphRelationship
    ) -> None:
        ...

    def on_relationship(self, graph, old_rel, new_rel):
        self._on_object(
            old_rel, new_rel,
            self._updated_relationships,
            self._removed_relationships,
            self._relationship_indexes,
        )

    def on_graph(self, graph: tt.Graph) -> None:
        pass

    @property
    def node_updates(self) -> dict[str, Action]:
        return dict(chain(
            ((node_id, ADDED) for node_id in self._removed_nodes),
            ((node_id, UPDATED
              if self._graph.get_node(node_id) else REMOVED)
             for node_id in self._updated_nodes)
        ))

    @property
    def relationship_updates(self) -> dict[str, Action]:
        return dict(chain(
            ((rel_id, ADDED) for rel_id in self._removed_relationships),
            ((rel_id, UPDATED
              if self._graph.get_relationship(rel_id) else REMOVED)
             for rel_id in self._updated_relationships)
        ))
