# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=redefined-builtin,invalid-name,too-many-return-statements

from __future__ import annotations

import logging
import typing as t

from aos.sdk.types import ValidationError
from aos.sdk.generator import compact_dict
from aos.sdk.profiling.instrument import instrument
from .schema import DummySchema
from .matchers import (
    is_matcher, eq, PropertyMatcher, verify_tag_only_matchers_used_only_for_tag,
)
from .index import (
    CompactRelationshipIndex,
    GraphIndex
)

import copy
from itertools import chain
import uuid
import six


if t.TYPE_CHECKING:
    import typing_extensions as te
    from aos.sdk import typing as tt


LOGGER: logging.Logger = logging.getLogger(__name__)

instrument = instrument.nested(source=__name__)

ERROR_EXACTLY_ONE_VALUE: t.Final[str] = (
    'The sequence is expected to have exactly one value'
)
ERROR_AT_MOST_ONE_VALUE: t.Final[str] = (
    'The sequence is expected to have at most one value'
)


class NoElementsError(Exception):
    pass


class MultipleElementsError(Exception):
    pass


class IteratorConvenienceMixin(object):

    def __iter__(self) -> t.Iterator[tt.GraphNode | tt.GraphRelationship]:
        raise NotImplementedError()

    @property
    def first(self) -> t.Optional[tt.GraphNode | tt.GraphRelationship]:
        """Returns first value in sequence or None if sequence is empty."""
        return next(iter(self), None)

    @property
    def one(self) ->  t.Optional[tt.GraphNode | tt.GraphRelationship]:
        """
        Asserts that the sequence has exactly one value.

        :return: the single value from the iterator.
        :raise: NoElementsError when there are no values in the iterator.
        :raise: MultipleElementsError when there is more than one value
                in the iterator.
        """
        it = iter(self)
        ret = next(it, None)
        if ret is None:
            raise NoElementsError(ERROR_EXACTLY_ONE_VALUE)
        if next(it, None) is not None:
            raise MultipleElementsError(ERROR_EXACTLY_ONE_VALUE)
        return ret

    @property
    def one_or_none(self) -> t.Optional[tt.GraphNode | tt.GraphRelationship]:
        """
        Asserts that the sequence has at most one value.

        :return: the single value from the iterator
                 or None if the iterator is empty.
        :raise: MultipleElementsError when there is more than one value
                in the iterator.
        """
        it = iter(self)
        ret = next(it, None)
        if next(it, None) is not None:
            raise MultipleElementsError(ERROR_AT_MOST_ONE_VALUE)
        return ret

    @property
    def count(self) -> int:
        """Returns number of values in sequence."""
        return sum(1 for _ in self)


class NodeIterator(IteratorConvenienceMixin):
    """Wrapper that gives the ability to lazily iterate over nodes and
       their relationships with iterator semantics. This is part of our
       Python-level graph query language.
    """
    _graph: tt.Graph | tt.UpdateGraph
    _node_iter: t.Iterable[tt.GraphNode]
    _depleted: bool

    def __init__(self, graph: tt.Graph | tt.UpdateGraph,
                 node_iter: t.Iterable[tt.GraphNode]):
        super().__init__()
        self._graph = graph
        self._node_iter = node_iter
        self._depleted = False

    def __iter__(self) -> t.Iterator[tt.GraphNode]:
        if self._depleted:
            raise ValueError('Iterator was already used')

        self._depleted = True

        for node in self._node_iter:
            yield node

    def out(self, type: t.Optional[str] = None, **kwargs: te.Unpack[tt.KwargsDict]
            ) -> OutRelationshipIterator:
        """Returns iterator over all relationships that match given criteria
        pointing from nodes in current sequence.

        :param type: (string) If specified, match relationship type
        :param kwargs: (dict) Relationship property values or PropertyMatchers
        :return: a RelationshipIterator
        """
        def relation_iter() -> t.Iterator[tt.GraphRelationship]:
            for node in self:
                for relationship in \
                        self._graph.get_relationships(source_id=node, type=type,
                                                      **kwargs):
                    yield relationship
        return OutRelationshipIterator(self._graph, relation_iter())

    def in_(self, type: t.Optional[str] = None, **kwargs: te.Unpack[tt.KwargsDict]
            ) -> InRelationshipIterator:
        """Returns iterator over all relationships that match given criteria
        pointing to nodes in current sequence.

        :param type: (string) If specified, match relationship type
        :param kwargs: (dict) Relationship property values or PropertyMatchers
        :return: a RelationshipIterator
        """
        def relationship_iter() -> t.Iterator[tt.GraphRelationship]:
            for node in self:
                for relationship in \
                        self._graph.get_relationships(target_id=node, type=type,
                                                      **kwargs):
                    yield relationship
        return InRelationshipIterator(self._graph, relationship_iter())

    def where(self, predicate: t.Callable[[tt.GraphNode], bool]) -> NodeIterator:
        """Filters nodes with given predicate returning a new iterator.

        :param predicate: (callable) Predicate taking a node and returning bool.
            Only nodes for which predicate returns True will end up in resulting
            sequence.
        :return: a NodeIterator over filtered sequence of nodes
        """
        def node_iter():
            for node in self:
                if not predicate(node):
                    continue
                yield node
        return NodeIterator(self._graph, node_iter())


class RelationshipIterator(IteratorConvenienceMixin):
    """Wrapper that gives the ability to lazily iterate over relationships and
       their source nodes / target nodes with iterator semantics. This is part of our
       Python-level graph query language.
    """
    _graph: tt.Graph | tt.UpdateGraph
    _relationship_iter: t.Iterable[tt.GraphRelationship]
    _depleted: bool

    def __init__(self,
                 graph: tt.Graph | tt.UpdateGraph,
                 relationship_iter: t.Iterable[tt.GraphRelationship]
                 ) -> None:
        super(RelationshipIterator, self).__init__()
        self._graph = graph
        self._relationship_iter = relationship_iter
        self._depleted = False

    def __iter__(self) -> t.Iterator[tt.GraphRelationship]:
        if self._depleted:
            raise ValueError('Iterator was already used')

        self._depleted = True

        for relationship in self._relationship_iter:
            yield relationship

    def source(self, type: t.Optional[str] = None, **kwargs: object) -> NodeIterator:
        """Returns iterator over source nodes of given relationships that match
        given criteria.

        :param type: (string) If specified, match node type
        :param kwargs: (dict) Node property values or PropertyMatchers
        :return: a NodeIterator
        """
        def node_iter() -> t.Iterator[tt.GraphNode]:
            for relationship in self:
                source = self._graph\
                    .get_nodes(id=relationship.source_id, type=type, **kwargs).first
                if source is None:
                    continue
                yield source
        return NodeIterator(self._graph, node_iter())

    def target(self, type: t.Optional[str] = None, **kwargs: object) -> NodeIterator:
        """Returns iterator over target nodes of given relationships that match
        given criteria.

        :param type: (string) If specified, match node type
        :param kwargs: (dict) Node property values or PropertyMatchers
        :return: a NodeIterator
        """
        def node_iter() -> t.Iterator[tt.GraphNode]:
            for relationship in self:
                target = self._graph\
                    .get_nodes(id=relationship.target_id, type=type, **kwargs).first
                if target is None:
                    continue
                yield target
        return NodeIterator(self._graph, node_iter())

    def where(self, predicate: t.Callable[[tt.GraphRelationship], bool]
              ) -> RelationshipIterator:
        """Filters relationships with given predicate returning a new iterator.

        :param predicate: (callable) Predicate taking a relationship and returning
            bool. Only nodes for which predicate returns True will end up in
            resulting sequence.
        :return: a RelationshipIterator over filtered sequence of relationships
        """
        def relationship_iter():
            for relationship in self:
                if not predicate(relationship):
                    continue
                yield relationship
        return self.__class__(self._graph, relationship_iter())


class OutRelationshipIterator(RelationshipIterator):
    def node(self, *args: str, **kwargs) -> NodeIterator:
        """Convenience alias for target()."""
        return self.target(*args, **kwargs)


class InRelationshipIterator(RelationshipIterator):
    def node(self, *args: str, **kwargs) -> NodeIterator:
        """Convenience alias for source()."""
        return self.source(*args, **kwargs)


class Node(object):
    obj_type: t.Final[str] = 'node'
    id: str
    properties: t.Dict[str, t.Any]

    __slots__ = ['_schema', 'id', 'properties']

    def __init__(self,
                 schema: tt.NodeSchema,
                 id: str,
                 properties: t.Optional[dict[str, t.Any]] = None
                 ) -> None:
        self._schema = schema
        self.id = id
        self.properties = properties or {}

    @property
    def type(self) -> str:
        return self._schema.type

    def __copy__(self) -> tt.GraphNode:
        return self.__class__(
            schema=self._schema, id=self.id,
            properties=dict(self.properties),
        )

    def __deepcopy__(self, memo: t.Optional[dict]) -> tt.GraphNode:
        return self.__class__(
            schema=self._schema, id=self.id,
            properties=copy.deepcopy(self.properties, memo),
        )

    def __getattr__(self, name: str) -> t.Any:
        if name in self.properties:
            return self.properties[name]
        if name in self._schema:
            return self._schema[name].load(None)
        raise AttributeError('Node %s does not have attribute %s' % (self, name))

    def __eq__(self, other: t.Any) -> bool:
        return getattr(other, 'obj_type', None) == 'node' and self.id == other.id

    def __ne__(self, other: t.Any) -> bool:
        return not self == other

    def __lt__(self, other: t.Any) -> bool:
        if other is None:
            return False
        return self.id < other.id

    def __hash__(self) -> int:
        return hash(('node', self.id))

    def __repr__(self) -> str:
        properties = ' '.join(["%s=%s" % (k, v)
                               for k, v in six.iteritems(self.properties)])
        return '({type}{properties})'.format(
            type=self.type,
            properties=' ' + properties if properties else '',
        )


class Relationship(object):
    obj_type: t.Final[str] = 'relationship'
    id: str
    source_id: str
    target_id: str
    properties: t.Dict[str, t.Any]

    __slots__ = ['_schema', 'id', 'source_id', 'target_id', 'properties']

    def __init__(self,
                 schema: tt.RelationshipSchema,
                 id: str,
                 source: tt.GraphNode | tt.GraphNodeId,
                 target: tt.GraphNode | tt.GraphNodeId,
                 properties: t.Optional[dict[str, t.Any]] = None
                 ) -> None:
        self._schema = schema
        self.id = id
        if is_node(source):
            if t.TYPE_CHECKING:
                source = t.cast(tt.GraphNode, source)
            self.source_id = source.id
        else:
            if t.TYPE_CHECKING:
                source = t.cast(tt.GraphNodeId, source)
            self.source_id = source
        if is_node(target):
            if t.TYPE_CHECKING:
                target = t.cast(tt.GraphNode, target)
            self.target_id = target.id
        else:
            if t.TYPE_CHECKING:
                target = t.cast(tt.GraphNodeId, target)
            self.target_id = target
        self.properties = properties or {}

    @property
    def type(self) -> str:
        return self._schema.type

    def __copy__(self) -> tt.GraphRelationship:
        return self.__class__(
            schema=self._schema, id=self.id,
            source=self.source_id,
            target=self.target_id,
            properties=dict(self.properties),
        )

    def __deepcopy__(self, memo: t.Optional[dict]) -> tt.GraphRelationship:
        return self.__class__(
            schema=self._schema, id=self.id,
            source=self.source_id,
            target=self.target_id,
            properties=copy.deepcopy(self.properties, memo),
        )

    def __getattr__(self, name: str) -> t.Any:
        if name in self.properties:
            return self.properties[name]
        if name in self._schema:
            return self._schema[name].load(None)
        raise AttributeError('Relationship %s does not have attribute %s' % (
            self, name
        ))

    def __eq__(self, other: t.Any) -> bool:
        return getattr(other, 'obj_type', None) == 'relationship' \
            and self.id == other.id

    def __ne__(self, other: t.Any) -> bool:
        return not self == other

    def __lt__(self, other: t.Any) -> bool:
        if other is None:
            return False
        return self.id < other.id

    def __hash__(self) -> int:
        return hash(('relationship', self.id))

    def __repr__(self) -> str:
        properties = ' '.join(["%s=%s" % (k, v)
                               for k, v in six.iteritems(self.properties)])
        return '{source}-[:{type}{properties}]->{target}'.format(
            type=self.type,
            source=self.source_id,
            target=self.target_id,
            properties=' ' + properties if properties else '',
        )


def is_node(obj: t.Any) -> t.TypeGuard[tt.GraphNode]:
    """Checks if given object is a graph node"""
    return getattr(obj, 'obj_type', None) == 'node'


def is_relationship(obj: t.Any) -> t.TypeGuard[tt.GraphRelationship]:
    """Checks if given object is a graph relationship"""
    return getattr(obj, 'obj_type', None) == 'relationship'


def sanitize_traverse_nodes(
        nodes: t.Iterable[tt.GraphNode] | tt.GraphNode,
        listify: bool = True
) -> t.Iterable[tt.GraphNode] | tt.GraphNode:
    if isinstance(nodes, str):
        raise ValueError(
            "Traversing only from nodes allowed. "
            "Got string '{}' instead.".format(nodes)
        )
    elif listify and is_node(nodes):
        nodes = [nodes]

    return nodes


def dump_path(path: dict[str, t.Any]) -> tt.JSON:
    def dump_graph_object(value: t.Any) -> tt.JSON:
        if is_node(value):
            return dump_node(value)
        elif is_relationship(value):
            return dump_relationship(value)
        # for optional() queries that return None
        elif value is None:
            return None
        else:
            raise ValueError('Unknown graph object: %s' % repr(value))

    return {
        name: dump_graph_object(value)
        for name, value in six.iteritems(path)
    }


def dump_node(node: tt.GraphNode) -> tt.JSON:
    return dict(
        id=node.id,
        type=node.type,
        **node._schema.dump(node, ensure_defaults=True)
    )


def dump_relationship(rel: tt.GraphRelationship) -> tt.JSON:
    return dict(
        id=rel.id,
        type=rel.type,
        source_id=rel.source_id,
        target_id=rel.target_id,
        **rel._schema.dump(rel, ensure_defaults=True)
    )


def dump_graph(graph: tt.Graph | tt.UpdateGraph, make_compact: bool = False
               ) -> tt.JSON:
    nodes = {node.id: dump_node(node) for node in graph.get_nodes()}
    relationships = {rel.id: dump_relationship(rel)
                     for rel in graph.get_relationships()}

    if make_compact:
        nodes = {node_id: compact_dict(node)
                 for node_id, node in six.iteritems(nodes)}
        relationships = {rel_id: compact_dict(rel)
                         for rel_id, rel in six.iteritems(relationships)}

    return dict(
        id=graph.id,
        nodes=nodes,
        relationships=relationships
    )


def normalize_id_matcher(
        matcher: tt.PropertyMatcher,
        predicate: t.Callable[
            [str | tt.PropertyMatcher | tt.GraphNode | tt.GraphRelationship | None],
            bool
        ]
) -> tt.PropertyMatcher:
    """Recursively replace each object matching the predicate by its ID."""
    if matcher.type in ('and', 'or', 'not'):
        return PropertyMatcher(
            matcher.type,
            [normalize_id_matcher(v, predicate) if is_matcher(v) else v
             for v in matcher.value]
        )
    if matcher.type in ('in', '!in'):
        return PropertyMatcher(
            matcher.type,
            {v.id if predicate(v) else v for v in matcher.value if v}
        )
    if predicate(matcher.value):
        return PropertyMatcher(matcher.type, matcher.value.id)
    return matcher


def normalize_id(id: str | tt.PropertyMatcher | None |
                     tt.GraphNode | tt.GraphRelationship,
                 predicate: t.Callable[
                     [str | tt.PropertyMatcher | None |
                      tt.GraphNode | tt.GraphRelationship],
                     bool
                 ]
                 ) -> str | tt.PropertyMatcher | None:
    """Recursively replace each object matching the predicate by its ID."""
    if predicate(id):
        assert(id is not None and hasattr(id, 'id'))
        return id.id
    if is_matcher(id):
        if t.TYPE_CHECKING:
            id = t.cast(tt.PropertyMatcher, id)
        return normalize_id_matcher(id, predicate)
    if t.TYPE_CHECKING:
        id = t.cast(str | None, id)
    return id


def extract_candidate_ids(id: str | tt.PropertyMatcher | None) -> t.Optional[list]:
    """Extract a list of IDs that would match."""
    if id is None:
        return None
    if not is_matcher(id):
        return [id]
    if t.TYPE_CHECKING:
        id = t.cast(tt.PropertyMatcher, id)
    if id.type == '==':
        return [id.value]
    if id.type == 'none':
        return []
    if id.type == 'in':
        return id.value
    if id.type == 'and':
        init = True
        for v in id.value:
            vv = extract_candidate_ids(v)
            if vv is None:
                return None
            if init:
                ids = set(vv)
                init = False
            else:
                ids.intersection_update(vv)
        return list(ids)
    if id.type == 'or':
        ids = set()
        for v in id.value:
            vv = extract_candidate_ids(v)
            if vv is None:
                return None
            ids.update(vv)
        return list(ids)
    return None


class GraphObserver(object):
    """Graph notification interface. Useful when you only need particular
    notification and do not want to implement stubs for other ones.

    :param on_graph: (callable) "on_graph" callback taking graph
    :param on_node: (callable) "on_node" callback taking graph, old and new nodes
    :param on_relationship: (callable) "on_relationship" callback taking graph,
        old and new relationships
    """
    def __init__(self,
                 on_graph: t.Optional[tt.OnGraphCallback] = None,
                 on_node: t.Optional[tt.OnNodeCallback] = None,
                 on_relationship: t.Optional[tt.OnRelationshipCallback] = None
                 ) -> None:
        self.on_graph = on_graph or (lambda _: None)
        self.on_node = on_node or (lambda graph, old, new: None)
        self.on_relationship = on_relationship or (lambda graph, old, new: None)


class Graph(object):
    """THE Graph.

    Graph is a datastructure consisting of nodes and relationships between nodes.
    Graph nodes and relationships have types. Nodes and relationships can have
    custom properties determined by their type according to graph schema.

    Notification interface
    ======================

    Graph supports observers that will get notifications wherever any node or
    relationship in the graph changes and when graph is committed. Observers are
    any objects that implement notification callbacks: :func:`on_graph`,
    :func:`on_node` and :func:`on_relationship`.

    on_node/on_relationship take three arguments:
        graph object
        old node/relationship
        new node/relationship

    If old object is None and new one is not, this means that object was added.
    If new object is None and old one is not, this means that object was removed.
    If both old and new objects are present, this means that object was changed from
    old to new.

    Committing a graph
    ==================

    Committing a graph is used to signal end of logicaly grouped updates to the
    graph. Observers can use this signal to finalize graph processing. Committing
    increases graph version by one unless explicit version is given in which case
    graph version will be set to that version.

    Arguments
    =========

    :param schema: (aos.sdk.schema.Schema) Graph schema. If not specified, defaults
        to DummySchema which allows you to use any node/relationship types with
        any attributes.
    :param id: (string) Graph ID. If not specified, a random ID is generated.
    :param enable_indexes: Enable node and relationship indexes. Default is true.
        Only set this to false for testing purposes.
    """
    id: str
    schema: tt.Schema
    _version: int
    _source_versions: t.Optional[tt.SourceVersions]
    _nodes: dict[str, Node]
    _relationships: dict[str, Relationship]
    _node_indexes: list[GraphIndex]
    _node_indexes_by_type: dict[str, list[GraphIndex]]
    _relationship_indexes: list[CompactRelationshipIndex]
    _observers: list[tt.GraphObserver]

    def __init__(self,
                 schema: t.Optional[tt.Schema] = None,
                 id: t.Optional[str] = None,
                 enable_indexes: bool = True) -> None:
        self.id = id or self.__generate_id()
        self.schema = schema or DummySchema()

        self._version = 0
        self._source_versions = None
        self._nodes = {}
        self._relationships = {}

        self._node_indexes = [GraphIndex(['type'])] if enable_indexes else []
        self._node_indexes_by_type = {
            node_schema.type: [
                GraphIndex(columns)
                for columns in node_schema.indexes
            ]
            for node_schema in six.itervalues(self.schema.nodes)
            if node_schema.indexes
        } if enable_indexes else {}

        self._relationship_indexes = [
            CompactRelationshipIndex()
        ] if enable_indexes else []

        self._observers = []

    def __deepcopy__(self, memo: t.Optional[dict]) -> Graph:
        """ Utilized in the upgrade infra. The observers are skipped. schema and id
            are not deep-copied.
        """
        other = self.__class__(schema=self.schema, id=self.id)
        # pylint: disable=attribute-defined-outside-init
        other.__dict__.update({
            k: copy.deepcopy(v, memo)
            for k, v in six.iteritems(self.__dict__)
            # Skip observers. There is no guarantee that observers can be deep
            # copied. schema and id are created as part of other's __init__.
            if k not in {'_observers', 'schema', 'id'}
        })
        other._observers = []
        return other

    def __generate_id(self) -> str:
        return str(uuid.uuid4())

    @property
    def version(self) -> tt.BlueprintVersion:
        """Graph version"""
        return self._version

    @property
    def source_versions(self) -> tt.SourceVersions:
        return copy.deepcopy(self._source_versions)  # type: ignore

    @property
    def node_count(self) -> int:
        return len(self._nodes)

    @property
    def relationship_count(self) -> int:
        return len(self._relationships)

    def is_committed(self) -> bool:
        """Returns True if graph was ever committed; False - otherwise."""
        return self._version > 0

    def commit(self,
               version: t.Optional[int] = None,
               source_versions: t.Optional[tt.SourceVersions] = None
               ) -> None:
        """Commit a graph.

        If version is not specified, graphs current version is incremented by one.
        Otherwise, explicitly passed version is set.

        :param version: (integer) If specified, set graph version to given value
        :param source_versions: (dict) If specified, set graph source versions to
            given value
        """
        self._version = int(version or self._version + 1)
        with instrument.it('SDK graph commit', version=self._version) as activity_id:
            if source_versions is not None:
                self._source_versions = copy.deepcopy(source_versions)
            instrument.checkpoint(activity_id, 'before notifying observers')
            for observer in self._observers:
                observer.on_graph(self)

    def add_node(self,
                 type: tt.GraphNodeType,
                 id: t.Optional[tt.GraphNodeId] = None,
                 **data
                 ) -> tt.GraphNode:
        """Add graph node of given type.

        :param type: (string) Node type
        :param id: (string) Optional node ID. If not specified, will be generated
        :param data: (dict) Node custom property values
        :return: New Node object
        :raises: ValueError - if node ID is given and node with given ID already
            exists
        :raises: aos.sdk.schema.ValidationError - if property values are not valid
            according to schema
        """
        if id and id in self._nodes:
            raise ValueError('Node with id %s already exists' % id)

        schema = self.schema.get_node_schema(type)

        errors = schema.validate(data, raw=True)
        if errors:
            raise ValidationError(errors)

        node_id = id or self.__generate_id()
        node = Node(schema, node_id, properties=data)

        self._nodes[node.id] = node
        for index in chain(self._node_indexes,
                           self._node_indexes_by_type.get(node.type, [])):
            index.add(node)

        self._on_node(None, node)

        return node

    def add_relationship(self,
                         type: tt.GraphRelationshipType,
                         source: tt.GraphNodeId | tt.GraphNode,
                         target: tt.GraphNodeId | tt.GraphNode,
                         id: t.Optional[tt.GraphRelationshipId] = None,
                         **data
                         ) -> tt.GraphRelationship:
        """Add graph relationship of given type from given source node to given
        target node.

        :param type: (string) Relationship type
        :param source: (string or Node) ID of source node
        :param target: (string or Node) ID of target node
        :param id: (string) Optional relationship ID. If not specified, will be
            generated
        :param data: (dict) Relationship custom property values
        :return: New Relationship object
        :raises: ValueError - if relationship ID is given and node with given ID
            already exists
        :raises: ValueError - if source node does not exist
        :raises: ValueError - if target node does not exist
        :raises: aos.sdk.schema.ValidationError - if property values are not valid
            according to schema
        """
        if id and id in self._relationships:
            raise ValueError('Relationship with id %s already exists' % id)

        source_node_id = source.id if is_node(source) else source
        target_node_id = target.id if is_node(target) else target

        if source_node_id not in self._nodes:
            raise ValueError('Unknown node: %s' % source_node_id)
        if target_node_id not in self._nodes:
            raise ValueError('Unknown node: %s' % target_node_id)
        source_node_id = t.cast(str, source_node_id)
        target_node_id = t.cast(str, target_node_id)

        source = self._nodes[source_node_id]
        target = self._nodes[target_node_id]

        schema = self.schema.get_relationship_schema(type, source.type, target.type)

        errors = schema.validate(data, raw=True)
        if errors:
            raise ValidationError(errors)

        relationship_id = id or self.__generate_id()
        relationship = Relationship(schema, relationship_id, source, target,
                                    properties=data)

        self._relationships[relationship.id] = relationship
        for index in self._relationship_indexes:
            index.add(relationship)

        self._on_relationship(None, relationship)

        return relationship

    def set_node(self,
                 node_id: tt.GraphNodeId | tt.GraphNode,
                 **data
                 ) -> tt.GraphNode:
        """Update properties of node with given ID with given values.

        Properties which values are not specified, remain the same.

        :param node_id: (string or Node) ID of node to update
        :param data: (dict) Mapping of node property names to values
        :return: updated Node object
        :raises: ValueError - if node with given ID does not exist
        :raises: aos.sdk.schema.ValidationError - if property values are invalid
            according to schema
        """
        if is_node(node_id):
            node_id = node_id.id

        if node_id not in self._nodes:
            raise ValueError('Unknown node: %s' % node_id)
        node_id = t.cast(str, node_id)

        node = self._nodes[node_id]
        schema = self.schema.get_node_schema(node.type)

        full_data = dict(node.properties, **data)
        errors = schema.validate(full_data, raw=True)
        if errors:
            raise ValidationError(errors)

        new_node = Node(schema, node.id, properties=full_data)

        self._nodes[new_node.id] = new_node
        for index in chain(self._node_indexes,
                           self._node_indexes_by_type.get(node.type, [])):
            index.add(new_node)

        self._on_node(node, new_node)

        return new_node

    def set_relationship(
            self,
            relationship_id: tt.GraphRelationship | tt.GraphRelationshipId,
            **data
    ) -> tt.GraphRelationship:
        """Update properties of relationship with given ID with given values.

        Properties which values are not specified, remain the same.

        :param relationship_id: (string or Relationship) ID of relationship to update
        :param data: (dict) Mapping of relationship property names to values
        :return: updated Relationship object
        :raises: ValueError - if relationship with given ID does not exist
        :raises: aos.sdk.schema.ValidationError - if property values are invalid
            according to schema
        """
        if is_relationship(relationship_id):
            relationship_id = relationship_id.id
        if t.TYPE_CHECKING:
            relationship_id = t.cast(tt.GraphRelationshipId, relationship_id)

        if relationship_id not in self._relationships:
            raise ValueError('Unknown relationship: %s' % relationship_id)

        relationship = self._relationships[relationship_id]
        schema = relationship._schema

        full_data = dict(relationship.properties, **data)
        errors = schema.validate(full_data, raw=True)
        if errors:
            raise ValidationError(errors)

        new_relationship = Relationship(
            schema, relationship.id,
            relationship.source_id,
            relationship.target_id,
            properties=full_data,
        )

        self._relationships[new_relationship.id] = new_relationship
        for index in self._relationship_indexes:
            index.add(new_relationship)

        self._on_relationship(relationship, new_relationship)

        return new_relationship

    def del_node(self, node_id: tt.GraphNodeId | tt.GraphNode) -> None:
        """Delete node by ID.

        Removing a node will automatically remove all relationships to and from
        that node (relationships will be removed before node removal).

        If node does not exist, does nothing.

        :param node_id: (string or Node) ID of node to remove
        """
        if is_node(node_id):
            node_id = node_id.id
        node_id = t.cast(str, node_id)

        node = self._nodes.get(node_id)
        if node is None:
            return

        for rel in list(self.get_relationships(source_id=node_id)):
            self.del_relationship(rel)

        for rel in list(self.get_relationships(target_id=node_id)):
            self.del_relationship(rel)

        # due to presence of sticky relationships, node may have been
        # deleted by one of the above del_relationship calls
        if node_id in self._nodes:
            del self._nodes[node_id]
            for index in chain(self._node_indexes,
                               self._node_indexes_by_type.get(node.type, [])):
                index.remove(node)

            self._on_node(node, None)

    def del_relationship(
            self,
            relationship_id: tt.GraphRelationship | tt.GraphRelationshipId
    ) -> None:
        """Delete relationships by ID.

        If relationship is sticky, it will remove the target node (target node is
        removed after relationship removal).

        If relationship does not exist, does nothing.

        :param relationship_id: (string or Relationship) ID of relationship to remove
        """
        if is_relationship(relationship_id):
            relationship_id = relationship_id.id
        if t.TYPE_CHECKING:
            relationship_id = t.cast(tt.GraphRelationshipId, relationship_id)

        rel = self._relationships.get(relationship_id)
        if rel is None:
            return

        del self._relationships[rel.id]
        for index in self._relationship_indexes:
            index.remove(rel)

        self._on_relationship(rel, None)
        if rel._schema.sticky:
            self.del_node(rel.target_id)

    def _make_matcher(self,
                      type: t.Optional[str | tt.PropertyMatcher] = None,
                      **kwargs) -> t.Callable[[Node | tt.GraphRelationship], bool]:
        type_matcher: t.Optional[tt.PropertyMatcher] = None
        if type is not None:
            if t.TYPE_CHECKING:
                type = t.cast(tt.PropertyMatcher, type)
            type_matcher = type if is_matcher(type) else eq(type)

        verify_tag_only_matchers_used_only_for_tag(dict(kwargs, type=type))
        kwargs = {k: v if is_matcher(v) else eq(v)
                  for k, v in six.iteritems(kwargs)
                  if v is not None}
        tag_matcher = kwargs.pop('tag', None)

        def matcher(obj: tt.GraphNode | tt.GraphRelationship) -> bool:
            # Need to process type first as the rest can refer to type specific
            # attributes
            if type_matcher and not type_matcher(obj.type):
                return False
            if tag_matcher and not tag_matcher(self.get_tags(obj)):
                return False
            return all(v(getattr(obj, k)) for k, v in six.iteritems(kwargs))

        return matcher

    def get_node(self, node_id: tt.GraphNodeId | tt.GraphNode
                 ) -> tt.GraphNode | None:
        """Get node by ID.

        :param node_id: (string or Node) ID of node to get.
            If ID is a Node object, its ID is used (useful for getting updated
            version of node you already have).
        :return: existing Node object or None if node with given ID does not exist
        """
        if is_node(node_id):
            node_id = node_id.id
        node_id = t.cast(str, node_id)
        return self._nodes.get(node_id)

    def get_nodes(self,
                  type: t.Optional[tt.GraphNodeType | tt.PropertyMatcher] = None,
                  id: t.Optional[
                      tt.GraphNodeId | tt.GraphNode | tt.PropertyMatcher
                      ] = None,
                  **kwargs
                  ) -> tt.GraphNodeIterator:
        """Get nodes with given properties. Properties can be specified
        either with values or with PropertyMatcher objects.

        It uses builtin and custom node indexes to speed up search.

        Like get_relationships(), the ID parameter may use a Node object
        directly or within a (possibly nested) PropertyMatcher object.

        :param type: (string or PropertyMatcher) If non-None, return only
            nodes whose type properties match the given value
        :param id: (string, Node, or PropertyMatcher) If non-None, return only
            nodes whose id properties match the given value
        :param kwargs: (dict) Mapping of custom node property names to property
            values or PropertyMatcher objects. Return only nodes whose
            properties match the given values
        :return: a NodeIterator over Node objects
        """
        id = normalize_id(id, predicate=is_node)
        candidate_ids = extract_candidate_ids(id)

        if candidate_ids == []:
            return NodeIterator(self, [])

        matcher = self._make_matcher(
            type=type,
            id=id if candidate_ids is None else None,
            **kwargs
        )

        if candidate_ids is None:
            lookup_results = [
                (len(self._nodes), six.iterkeys(self._nodes))
            ] + [
                index.lookup(type=type, id=id, **kwargs)
                for index in
                self._node_indexes
            ]
            if isinstance(type, str):
                lookup_results += [
                    index.lookup(type=type, id=id, **kwargs)
                    for index in
                   self._node_indexes_by_type.get(type, [])
                ]
            # candidate_ids is None at this point
            # Incompatible types in assignment (expression has type "Iterable[Any]",
            # variable has type "list[Any] | None")
            _, candidate_ids = min(  # type: ignore
                (x for x in lookup_results if x is not None),
                key=lambda x: x[0]
            )

        assert(candidate_ids is not None)

        return NodeIterator(
            self,
            [candidate
             for candidate_id in candidate_ids
             for candidate in [self._nodes.get(candidate_id)]
             if candidate is not None and matcher(candidate)]
        )

    def get_relationship(
            self,
            relationship_id: tt.GraphRelationship | tt.GraphRelationshipId
    ) -> tt.GraphRelationship | None:
        """Get relationship by ID.

        :param relationship_id: (string or Relationship) ID of relationship to get.
            If ID is a Relationship object, its ID is used (useful for getting
            updated version of relationship you already have).
        :return: existing Relationship object or None if relationship with given ID
            does not exist
        """
        if is_relationship(relationship_id):
            relationship_id = relationship_id.id
        if t.TYPE_CHECKING:
            relationship_id = t.cast(tt.GraphRelationshipId, relationship_id)
        return self._relationships.get(relationship_id)

    def get_relationships(
            self,
            type: t.Optional[tt.GraphRelationshipType | tt.PropertyMatcher] = None,
            source_id: t.Optional[
                tt.GraphNodeId | tt.GraphNode | tt.PropertyMatcher
                ] = None,
            target_id: t.Optional[
                tt.GraphNodeId | tt.GraphNode | tt.PropertyMatcher
                ] = None,
            id: t.Optional[
                tt.GraphRelationship | tt.GraphRelationshipId | tt.PropertyMatcher
                ] = None,
            **kwargs: object
        ) -> tt.GraphRelationshipIterator:
        """Get relationships with given properties. Properties can be specified
        either with values or with PropertyMatcher objects.

        It uses builtin indexes to speed up search.

        ID parameters may use Node or Relationship objects directly or within
        (possibly nested) matchers, for example:

            node = graph.add_node(...)
            get_relationships(source_id=eq(node))

        Which is equivalent to:

            get_relationships(source_id=node.id)

        But using a Relationship for a node ID or vice versa does not work.

            get_relationship(id=node) # Result is empty

        :param type: (string or PropertyMatcher) If non-None, return only
            relationships whose type properties match the given value
        :param source_id: (string, Node, or PropertyMatcher) If non-None,
            return only relationships whose source_id properties match the
            given value
        :param target_id: (string, Node, or PropertyMatcher) If non-None,
            return only relationships whose target_id properties match the
            given value
        :param id: (string, Relationship, or PropertyMatcher) If non-None,
            return only relationships whose id properties match the given value
        :param kwargs: (dict) Mapping of custom relationship property names to
            property values or PropertyMatcher objects. Return only relationships
            whose properties match the given values
        :return: a RelationshipIterator over Relationship objects
        """
        normalized_source_id = normalize_id(source_id, predicate=is_node)
        normalized_target_id = normalize_id(target_id, predicate=is_node)
        normalized_id = normalize_id(id, predicate=is_relationship)
        if t.TYPE_CHECKING:
            normalized_source_id = t.cast(
                tt.GraphNodeId | None, normalized_source_id)
            normalized_target_id = t.cast(
                tt.GraphNodeId | None, normalized_target_id)
            normalized_id = t.cast(
                tt.GraphRelationshipId | None, normalized_id)

        candidate_ids = extract_candidate_ids(normalized_id)

        if candidate_ids == []:
            return RelationshipIterator(self, [])

        matcher = self._make_matcher(
            type=type,
            source_id=normalized_source_id,
            target_id=normalized_target_id,
            id=normalized_id if candidate_ids is None else None,
            **kwargs
        )

        if candidate_ids is None:
            lookup_results = [(
                len(self._relationships),
                six.iterkeys(self._relationships)
            )]
            for index in self._relationship_indexes:
                index_result = index.lookup(
                    type=type,
                    source_id=normalized_source_id,
                    target_id=normalized_target_id,
                    id=normalized_id,
                    **kwargs
                )
                if index_result:
                    lookup_results.append(index_result)
            _, candidate_ids = min(  # type: ignore
                (x for x in lookup_results if x is not None),
                key=lambda x: x[0]
            )

        assert(candidate_ids is not None)

        return RelationshipIterator(
            self,
            [candidate
             for candidate_id in candidate_ids
             for candidate in [self._relationships.get(candidate_id)]
             if candidate is not None and matcher(candidate)],
        )

    def get_tags(self, node: tt.GraphNodeId | tt.GraphNode) -> set[str]:
        """ Get tags for a given node.
        """
        graph_node = self.get_node(node)
        return {
            tag_node.lowercased
            for tag_node in self.traverse(graph_node).in_('tag').node('tag')
        }

    def traverse(self,
                 nodes: t.Optional[
                     tt.GraphNode | t.Iterable[tt.GraphNode]] = None,
                 node_type: t.Optional[str | tt.PropertyMatcher] = None
                 ) -> tt.GraphNodeIterator:
        if not nodes and node_type is None:
            return NodeIterator(self, [])

        if nodes is None:
            return self.get_nodes(type=node_type)

        nodes = sanitize_traverse_nodes(nodes)
        if t.TYPE_CHECKING:
            nodes = t.cast(t.Iterable[tt.GraphNode], nodes)

        return NodeIterator(self, nodes)

    def add_observer(self, observer: tt.GraphObserver) -> None:
        """Add graph observer.

        Observer should implement observer callback methods: on_graph(), on_node()
        and on_relationship().
        """
        LOGGER.debug('Add observer %s', observer)
        self._observers.append(observer)

    def remove_observer(self, observer: tt.GraphObserver) -> None:
        """Remove graph observer."""
        if observer in self._observers:
            LOGGER.debug('Remove observer %s', observer)
            self._observers.remove(observer)

    @t.overload
    def _on_node(self, old_node: None, new_node: tt.GraphNode) -> None:
        ...

    @t.overload
    def _on_node(self, old_node: tt.GraphNode, new_node: None) -> None:
        ...

    @t.overload
    def _on_node(self, old_node: tt.GraphNode, new_node: tt.GraphNode) -> None:
        ...

    def _on_node(self, old_node, new_node):
        for observer in self._observers:
            observer.on_node(self, old_node, new_node)

    @t.overload
    def _on_relationship(self, old_rel: None, new_rel: tt.GraphRelationship) -> None:
        ...

    @t.overload
    def _on_relationship(self, old_rel: tt.GraphRelationship, new_rel: None) -> None:
        ...

    @t.overload
    def _on_relationship(
            self, old_rel: tt.GraphRelationship, new_rel: tt.GraphRelationship
    ) -> None:
        ...

    def _on_relationship(self, old_rel, new_rel):
        for observer in self._observers:
            observer.on_relationship(self, old_rel, new_rel)

    def json(self) -> tt.JSON:
        return dump_graph(self, make_compact=False)

    def compact_json(self) -> tt.JSON:
        return dump_graph(self, make_compact=True)
