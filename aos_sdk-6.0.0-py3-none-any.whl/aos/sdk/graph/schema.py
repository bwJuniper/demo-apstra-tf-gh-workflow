# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=redefined-builtin

from __future__ import annotations

import itertools
import typing as t

from aos.sdk import types
from aos.sdk.collection_utils import groupby, type_aware_key
import six


if t.TYPE_CHECKING:
    from aos.sdk import typing as tt


# Node name used in schema representation.
ANY_TARGET_NODE_TYPE: t.Final[object] = object()
# Node name used in storage.
ANY_TARGET_NODE_TYPE_NAME: t.Final[str] = ''

DEFAULT_TAGS = types.SparseOptional(types.List(types.String()))
DEFAULT_PROPERTY_SET = types.SparseOptional(
    types.Dict(types.String(), key_type=types.String()),
 )

class _SchemaBase(object):
    properties: t.Dict[str, t.Any]
    validators: t.Iterable[t.Callable[[dict], None]]

    def __init__(
            self,
            properties: t.Optional[t.Mapping | t.Iterable],
            validate: t.Optional[t.Callable[[dict], None]
                                 | t.Iterable[t.Callable[[dict], None]]] = None
    ) -> None:
        self.properties = {} if properties is None else dict(properties)
        if 'tags' not in self.properties:
            self.properties['tags'] = DEFAULT_TAGS
        if 'property_set' not in self.properties:
            self.properties['property_set'] = DEFAULT_PROPERTY_SET
        if validate is None:
            validate = []
        elif callable(validate):
            validate = [validate]
        self.validators = validate

    def __contains__(self, name: str) -> bool:
        return name in self.properties

    def __getitem__(self, name: str) -> t.Any:
        return self.properties.get(name)

    def load(self, data: dict, partial: bool = False) -> tt.JSONDict:
        '''
        Loads data from raw (serialized) form and validates it.
        If validation fails, raises ValidationError. Returns deserialized data.
        '''
        result = {}

        errors = types.ValidationErrorBuilder()

        for name, loader in six.iteritems(self.properties):
            if name not in data and partial:
                continue

            try:
                result[name] = loader.load(data.get(name))
            except types.ValidationError as ve:
                errors.add_error(name, ve.messages)

        try:
            for validator in self.validators:
                validator(data)
        except types.ValidationError as ve:
            errors.add_errors(ve.messages)

        errors.raise_errors()

        return result

    def dump(self, node: tt.GraphNode, ensure_defaults: bool = False) -> tt.JSON:
        '''
        Dumps data to raw (serialized) form.
        If dump fails, raises ValidationError. Returns serialized data.
        '''
        result = {}

        errors = types.ValidationErrorBuilder()
        for name, schema in six.iteritems(self.properties):
            try:
                val = node.properties.get(name)

                if ensure_defaults:
                    val = schema.load(val)

                result[name] = schema.dump(val)
            except types.ValidationError as ve:
                errors.add_error(name, ve.messages)

        errors.raise_errors()

        return result  # type:ignore

    def validate(self, data: dict[str, t.Any], raw: bool = False
                 ) -> t.Optional[list | dict]:
        '''Validate this data for this graph object. Raises ValidationError if
        there are validation errors.

        :param data: (dict) mapping of property names to property values.
        :param raw: (bool) if True, values in `data` are in serialized form
            (represented with simple types only). If False - values are in
            application format.
        '''
        errors = types.ValidationErrorBuilder()
        for name, validator in six.iteritems(self.properties):
            value = data.get(name)
            if not raw:
                try:
                    value = validator.dump(value)
                except types.ValidationError as ve:
                    errors.add_error(name, ve.messages)
                    continue

            error = validator.validate(value)
            if error:
                errors.add_error(name, error)

        for k in data:
            if k not in self.properties:
                errors.add_error(k, 'Unknown property')

        try:
            for validator in self.validators:
                validator(data)
        except types.ValidationError as ve:
            errors.add_errors(ve.messages)

        if errors.errors:
            return errors.errors

        return None


class NodeSchema(_SchemaBase):
    '''
    Schema for graph node with type `type`.

    :param type: (string) type of nodes
    :param properties: (dict) Mapping of property names to property types
    :param indexes: (list of lists of string) List of column indexes. Each item
        is a list of columns to index on.
    :param validate: a validator (callable getting node object and raising
        ValidationError in case of errors) or list of validators
    '''
    type: str
    indexes: t.Optional[list[list[str]]]

    def __init__(self,
                 type: str,
                 properties: dict[str, t.Any],
                 indexes: t.Optional[list[list[str]]] = None,
                 *args, **kwargs) -> None:
        if 'tag' in properties:
            raise ValueError('Reserved attribute tag found in schema')

        super(NodeSchema, self).__init__(properties, *args, **kwargs)
        self.type = type
        self.indexes = indexes

    def __repr__(self) -> str:
        return '<{klass} {attrs}'.format(
            klass=self.__class__.__name__,
            attrs=' '.join([
                '%s=%s' % (attr, getattr(self, attr))
                for attr in ['type', 'properties', 'indexes']
            ]),
        )


class RelationshipSchema(_SchemaBase):
    '''
    Schema for graph relationship with type `type` from node
    with type `source_type` to node with type `target_type`.

    :param type: (string) type of nodes
    :param source_type: (string) type of source nodes
    :param target_type: (string) type of target nodes
    :param properties: (dict) Mapping of property names to property types
    :param validate: a validator (callable getting relationship object and raising
        ValidationError in case of errors) or list of validators
    '''
    type: str
    source_type: str
    target_type: str
    sticky: bool

    def __init__(self, type: str, source_type: str, target_type: str,
                 properties: t.Optional[dict[str, t.Any]] = None,
                 sticky: bool = False, *args, **kwargs) -> None:
        super(RelationshipSchema, self).__init__(properties, *args, **kwargs)
        self.type = type
        self.source_type = source_type
        self.target_type = target_type
        self.sticky = sticky

    def __repr__(self) -> str:
        return '<{klass} {attrs}>'.format(
            klass=self.__class__.__name__,
            attrs=' '.join([
                '%s=%s' % (attr, getattr(self, attr))
                for attr in ['type', 'source_type', 'target_type',
                             'sticky', 'properties']
            ]),
        )


class _SchemaMeta(type):
    def __new__(mcs, name: str, bases: tuple, attributes: dict[str, t.Any]
                ) -> _SchemaMeta:
        def ensure_unique_relation(type: str,
                                   stype: str,
                                   dtype: str,
                                   relationships: t.Iterable[RelationshipSchema]
                                   ) -> RelationshipSchema:
            relationships = list(relationships)
            if len(relationships) > 1:
                raise ValueError('Duplicate relation %s between %s '
                                 'and %s node types' % (type, stype, dtype))
            return relationships[0]

        def ensure_only_one_ttype_if_any(type: str,
                                         stype: str,
                                         relationships: dict[str, RelationshipSchema]
                                         ) -> dict[str, RelationshipSchema]:
            if ANY_TARGET_NODE_TYPE in relationships and len(relationships) > 1:
                dtypes = ", ".join(
                    "'{}'".format(type_) for type_ in relationships
                    if type_ is not ANY_TARGET_NODE_TYPE
                )
                raise ValueError(
                    "More specific relationship types from source nodes type '%s' "
                    "to target node types '%s' are not allowed because there "
                    "is already the '%s' relationship type "
                    "with ANY_TARGET_NODE_TYPE" % (stype, dtypes, type)
                )
            return relationships

        nodes = attributes.get('nodes', {})
        relationships = attributes.get('relationships', [])

        nodes = [
            node_schema if isinstance(node_schema, NodeSchema) else NodeSchema(
                node_type, properties=node_schema,
            ) for node_type, node_schema in six.iteritems(nodes)
        ]
        nodes = {
            node_schema.type: node_schema
            for node_schema in nodes
        }

        for node_schema in six.itervalues(nodes):
            for property_name in node_schema.properties:
                if property_name in ['id', 'name', 'type', 'properties']:
                    raise ValueError(
                        'Node type "%s" contains reserved property "%s"' % (
                            node_schema.type, property_name,
                        )
                    )

        relationships = [
            rel if isinstance(rel, RelationshipSchema) else RelationshipSchema(
                rel['type'], rel['source'], rel['target'],
                {k: v for k, v in six.iteritems(rel)
                 if k not in ['type', 'source', 'target']},
            ) for rel in relationships
        ]

        for relationship in relationships:
            for property_name in relationship.properties:
                if property_name in ['id', 'name', 'type', 'properties',
                                     'source_id', 'target_id']:
                    raise ValueError(
                        'Relationship type "%s" contains reserved property "%s"' % (
                            relationship.type, property_name,
                        )
                    )

            # TODO - add back checks once multigraph relationship support is there
            # if relationship.source_type not in nodes:
            #     raise ValueError(
            #         'Relationship %s source node type is unknown: %s' % (
            #             relationship.type, relationship.source_type,
            #         )
            #     )
            # if relationship.target_type not in nodes:
            #     raise ValueError(
            #         'Relationship %s target node type is unknown: %s' % (
            #             relationship.type, relationship.target_type,
            #         )
            #     )

        # In dict comprehension below we want to groupby relationships by
        # target_type like we do by source_type:
        #     groupby(lambda r: r.target_type, srels)
        #
        # But we can not do it just like that because target_type can be both
        # a string and the ANY_TARGET_NODE_TYPE object. Hence we need to wrap
        # it into type_aware_key for it to be comparable.
        # Also, we had to expand groupby into itertools.groupby and sorted,
        # because the former requires 'normal' key function.
        target_type_key = type_aware_key(lambda r: r.target_type)

        _relationships = {
            rtype: {
                stype: ensure_only_one_ttype_if_any(rtype, stype, {
                    ttype: ensure_unique_relation(rtype, stype, ttype, trels)
                    for ttype, trels in itertools.groupby(
                        sorted(srels, key=target_type_key), lambda r: r.target_type)
                })
                for stype, srels in groupby(lambda r: r.source_type, rels)
            }
            for rtype, rels in groupby(lambda r: r.type, relationships)
        }

        return super(_SchemaMeta, mcs).__new__(
            mcs, name, bases,
            dict(attributes,
                 nodes=nodes,
                 relationships=relationships,
                 _relationships=_relationships),
        )


class Schema(six.with_metaclass(_SchemaMeta, object)):
    nodes: dict[str, tt.NodeSchema] = {}
    relationships: list[tt.RelationshipSchema] = []
    _relationships: dict[
        str, dict[str, dict[str | object, tt.RelationshipSchema]]] = {}

    def get_node_schema(self, node_type: str) -> tt.NodeSchema:
        'Returns schema for node of given type'
        if node_type not in self.nodes:
            raise ValueError('Unknown node type: %s' % node_type)

        return self.nodes[node_type]

    def get_relationship_schema(self,
                                type: str,
                                source_node_type: str,
                                target_node_type: str
                                ) -> tt.RelationshipSchema:
        'Returns schema for relationship of given type between nodes of given type'
        if type not in self._relationships:
            raise ValueError('Unknown relationship type: %s' % type)

        if source_node_type not in self._relationships[type]:
            raise ValueError('Invalid source node type %s. '
                             'Allowed values are: %s' % (
                                 repr(source_node_type),
                                 list(six.iterkeys(self._relationships[type])),
                             ))

        if ANY_TARGET_NODE_TYPE in self._relationships[type][source_node_type]:
            return self._relationships[type][source_node_type][ANY_TARGET_NODE_TYPE]

        if target_node_type not in self._relationships[type][source_node_type]:
            rel_types = list(six.iterkeys(
                self._relationships[type][source_node_type]))
            raise ValueError('Invalid target node type %s. '
                             'Allowed types are: %s' % (
                                 repr(target_node_type),
                                 rel_types,
                             ))

        return self._relationships[type][source_node_type][target_node_type]

    @classmethod
    def validate(cls) -> None:
        'Validate source and target node types in relationships'
        for relationship in cls.relationships:
            if relationship.source_type not in cls.nodes:
                raise ValueError(
                    "Relationship '%s' source node type is unknown: '%s'" % (
                        relationship.type, relationship.source_type,
                    )
                )
            if (relationship.target_type is not ANY_TARGET_NODE_TYPE
                    and relationship.target_type not in cls.nodes):
                raise ValueError(
                    "Relationship '%s' target node type is unknown: '%s'" % (
                        relationship.type, relationship.target_type,
                    )
                )


class DummyNodeSchema(object):
    '''A node schema that allows any properties of any (simple) type.

    Complex types (like objects) require knowing how to serialize them to string
    thus they cannot be used here (since their real type is unknown). Still,
    this schema is useful in testing.
    '''
    type: str
    indexes: t.Optional[list[list[str]]]
    properties: dict[str, t.Any]
    validators: t.Iterable[t.Callable[[dict], None]]

    def __init__(self,
                 node_type: str,
                 indexes: t.Optional[list[list[str]]] = None,
                 *args, **kwargs) -> None:
        self.type = node_type
        self.indexes = indexes
        self.properties = {}
        self.validators = []

    def __contains__(self, name: str) -> bool:
        return True

    def __getitem__(self, name: str) -> t.Any:
        return types.Any()

    def load(self, data: dict, partial: bool = False) -> tt.JSONDict:
        return {k: types.Any().load(v) for k, v in six.iteritems(data)}

    def dump(self, node: tt.GraphNode, ensure_defaults: bool = False
             ) -> tt.JSON:
        return node.properties  # type:ignore

    def validate(self, data: dict[str, t.Any], raw: bool = False
                 ) -> t.Optional[list | dict]:
        return None

    def __repr__(self) -> str:
        return '<{klass} {attrs}'.format(
            klass=self.__class__.__name__,
            attrs=' '.join([
                '%s=%s' % (attr, getattr(self, attr))
                for attr in ['type', 'properties', 'indexes']
            ]),
        )


class DummyRelationshipSchema(object):
    '''A relationship schema that allows any properties of any (simple) type.

    Complex types (like objects) require knowing how to serialize them to string
    thus they cannot be used here (since their real type is unknown). Still,
    this schema is useful in testing.
    '''
    type: str
    source_type: str
    target_type: str
    properties: dict[str, t.Any]
    sticky: bool
    validators: t.Iterable[t.Callable[[dict], None]]

    def __init__(self,
                 type: str,
                 source_type: str,
                 target_type: str,
                 sticky: bool = False,
                 *args, **kwargs
                 ) -> None:
        self.type = type
        self.source_type = source_type
        self.target_type = target_type
        self.properties = {}
        self.sticky = sticky
        self.validators = []

    def __contains__(self, name: str) -> bool:
        return True

    def __getitem__(self, name: str) -> t.Any:
        return types.Any()

    def load(self, data: dict, partial: bool = False) -> tt.JSONDict:
        return {k: types.Any().load(v) for k, v in six.iteritems(data)}

    def dump(self, node: tt.GraphNode, ensure_defaults: bool = False
             ) -> tt.JSON:
        return node.properties  # type:ignore

    def validate(self, data: dict[str, t.Any], raw: bool = False
                 ) -> t.Optional[list | dict]:
        return None

    def __repr__(self) -> str:
        return '<{klass} {attrs}>'.format(
            klass=self.__class__.__name__,
            attrs=' '.join([
                '%s=%s' % (attr, getattr(self, attr))
                for attr in ['type', 'source_type', 'target_type',
                             'sticky', 'properties']
            ]),
        )


class DummySchema(Schema):
    '''Schema that allows any node types, any relationships and any properties'''
    _node_schema_cache: dict[str, DummyNodeSchema]
    _relationship_schema_cache: dict[tuple[str, str, str], DummyRelationshipSchema]

    def __init__(self, *args, **kwargs) -> None:  # pylint: disable=super-init-not-called
        self._node_schema_cache = {}
        self._relationship_schema_cache = {}

    def get_node_schema(self, node_type: str) -> tt.NodeSchema:
        if node_type not in self._node_schema_cache:
            self._node_schema_cache[node_type] = DummyNodeSchema(node_type)
        return self._node_schema_cache[node_type]

    def get_relationship_schema(self,
                                type: str,
                                source_node_type: str,
                                target_node_type: str
                                ) -> tt.RelationshipSchema:
        key = (type, source_node_type, target_node_type)
        if key not in self._relationship_schema_cache:
            self._relationship_schema_cache[key] = \
                DummyRelationshipSchema(type, source_node_type, target_node_type)
        return self._relationship_schema_cache[key]


def make_full_schema(schema: tt.Schema) -> type[tt.Schema]:
    """Replace relationship with ANY_TARGET_NODE_TYPE with
       a list of relationships with all supported nodes."""

    relationships: list[tt.RelationshipSchema] = []
    for rel in schema.relationships:
        if rel.target_type == ANY_TARGET_NODE_TYPE:
            for node_type in schema.nodes:
                relationships.append(
                    RelationshipSchema(
                        type=rel.type,
                        source_type=rel.source_type,
                        target_type=node_type,
                        properties=rel.properties,
                        sticky=rel.sticky,
                        validate=rel.validators,
                    )
                )
        else:
            relationships.append(rel)

    return type('Schema', (Schema,), dict(
        nodes=schema.nodes,
        relationships=relationships,
    ))
