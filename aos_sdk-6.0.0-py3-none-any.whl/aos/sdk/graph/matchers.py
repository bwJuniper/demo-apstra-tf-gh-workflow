# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula
# pylint: disable=redefined-builtin, redefined-variable-type

from __future__ import annotations

import copy
import re
import types
import typing as t
from fnmatch import fnmatchcase

import six
from six.moves import collections_abc

from aos.sdk.utils import encode_if_unicode, encode_unicode_in_string_list


def encode_if_unicode_py2(value: t.Any) -> t.Any:
    if six.PY2:
        return encode_if_unicode(value)
    return value


def encode_unicode_in_string_list_py2(value: t.Any) -> t.Any:
    if six.PY2:
        return encode_unicode_in_string_list(value)
    return value


def has_keys_matcher(x: t.Iterable, v: t.Any) -> bool:
    return isinstance(v, collections_abc.Mapping) and all(k in v for k in x)


def has_items_matcher(x: t.Dict, v: t.Any) -> bool:
    return (
        isinstance(v, collections_abc.Mapping) and
        all(xv == v.get(xk, None) for xk, xv in six.iteritems(x))
    )


def has_items_merge(v1: t.Dict, v2: t.Dict) -> t.Optional[PropertyMatcher]:
    common_keys = six.viewkeys(v1) & six.viewkeys(v2)
    for k in common_keys:
        if v1[k] != v2[k]:
            return None
    v1.update(v2)
    return has_items(list(six.iteritems(v1)))


def tag_filter(match_fn: t.Callable[[t.Iterable, t.Iterable], bool]
               ) -> t.Callable:
    def matcher(values, inputs):
        if not values:
            return False
        return match_fn([re.compile(v + '$') for v in values],
                        inputs)
    return matcher


@tag_filter
def has_all_matcher(values: t.Iterable, inputs: t.Iterable) -> bool:
    for value in values:
        for _input in inputs:
            if re.match(value, _input):
                break
        else:
            return False

    return True


@tag_filter
def has_any_matcher(values: t.Iterable, inputs: t.Iterable) -> bool:
    for value in values:
        for _input in inputs:
            if re.match(value, _input):
                return True
    return False


@tag_filter
def has_none_matcher(values: t.Iterable, inputs: t.Iterable) -> bool:
    for value in values:
        for _input in inputs:
            if re.match(value, _input):
                return False
    return True


def sanitize_values(values: t.Optional[t.Iterable]) -> tuple[set | list, bool]:
    """
        Sanitize the specified values. Returns a tuple with first element containing
        the container of non-None values and with second element a boolean indicating
        if the set of values had None in it.

        The type of container returned as first element depends on type of values
        provided - if it is set or frozenset, then the returned container is set.
        Otherwise, a list will be returned. This covers two opposite use cases:
         * Set provides fast look up, which is needed in case matcher is used with
           long set of elements like is_in(<very long set of node IDs>)
         * List can contain non-hashable elements, like lists, sets or dicts. That is
           needed to match non-primitive properties, like interface_map.interfaces
           or routing_policy.extra_import_routes (both are lists).

        Raises ValueError in case there are values wth multiple types (except None)
    """
    is_none_present = False
    if isinstance(values, (set, frozenset)):
        non_none_values: set = set()
        add_value = non_none_values.add
    else:
        non_none_values: list = []  # type: ignore
        add_value = non_none_values.append  # type: ignore

    if not values:
        return (non_none_values, is_none_present)

    # We need to support any collection type for values
    first_type = None
    for value in values:
        if value is None:
            is_none_present = True
            continue

        if not first_type:
            first_type = type(value)

        if not isinstance(value, first_type):
            # The implementation of Node and Relationship types in Cpp Graph
            # is based on creating a type dynamically based on a base class.
            # In order to accept nodes/relationships of different types,
            # allow values in case the base classes are the same.
            if first_type.__bases__ != value.__class__.__bases__ \
                    or first_type.__bases__ == (object,):
                raise ValueError(
                    ('Values({value}) with different '
                     'types({type1}, {type2}) provided').format(
                         value=value,
                         type1=first_type,
                         type2=type(value),
                     )
                )

        value = encode_if_unicode_py2(value)
        add_value(value)

    return (non_none_values, is_none_present)


def verify_not_none(value: t.Any, operator: str) -> None:
    if value is None:
        raise TypeError('Matcher "%s" does not support None' %operator)


class PropertyMatcher(object):
    """Utility class used to match Node/Relationship property values."""
    types: dict[str, t.Callable] = {
        '==': lambda v, x: x == v,
        '!=': lambda v, x: x != v,
        '>': lambda v, x: x is not None and x > v,
        '>=': lambda v, x: x is not None and x >= v,
        '<': lambda v, x: x is not None and x < v,
        '<=': lambda v, x: x is not None and x <= v,
        'in': lambda v, x: x in v,
        '!in': lambda v, x: x not in v,
        'none': lambda _, x: x is None,
        '!none': lambda _, x: x is not None,
        'and': lambda ms, x: all(m(x) for m in ms),
        'or': lambda ms, x: any(m(x) for m in ms),
        'not': lambda m, x: not m(x),
        'custom': lambda v, x: v(x),
        '~=': lambda v, x: isinstance(x, six.string_types) and fnmatchcase(x, v),
        'has_keys': has_keys_matcher,
        'has_items': has_items_matcher,
        'has_all': has_all_matcher,
        'has_any': has_any_matcher,
        'has_none': has_none_matcher,
    }

    def __init__(self, type: str, value: t.Any = None) -> None:
        if type not in self.types:
            raise ValueError('Unknown matcher type: %s' % type)

        self.type = type
        self.value = value

    def __call__(self, value: t.Any) -> bool:
        return self.types[self.type](self.value, value)

    def __hash__(self) -> int:
        return hash((self.type, repr(self.value)))

    def __eq__(self, other: t.Any) -> bool:
        if not isinstance(other, self.__class__):
            return self.type == '==' and self.value == other
        if self.type == 'custom':
            return False
        return self.type == other.type and self.value == other.value

    def __ne__(self, other: t.Any) -> bool:
        return not self == other

    def __repr__(self) -> str:
        if self.type in ['custom', 'none', '!none']:
            return self.type

        if self.type in ['has_all', 'has_any', 'has_none']:
            # The representation of the Ast query is used to verify equality
            # of ast in precompiled query. value is a list of pattern objects
            # for has_all type. Hence, overriding the repr to get deterministic
            # output.
            return '%s (%s)' % (self.type, ','.join(self.value))

        return '%s %s' % (self.type, self.value)

    def __deepcopy__(self, memo: t.Optional[dict]) -> PropertyMatcher:
        return PropertyMatcher(self.type, copy.deepcopy(self.value, memo))


def eq(value: t.Any) -> PropertyMatcher:
    if value is None:
        return is_none()
    value = encode_if_unicode_py2(value)
    return PropertyMatcher('==', value)


def aeq(value: t.Any) -> PropertyMatcher:
    verify_not_none(value, '~=')
    value = encode_if_unicode_py2(value)
    if not isinstance(value, six.string_types):
        raise TypeError('Matcher "~=" only matches strings')
    return PropertyMatcher('~=', value)


def ne(value: t.Any) -> PropertyMatcher:
    if value is None:
        return not_none()
    value = encode_if_unicode_py2(value)
    return PropertyMatcher('!=', value)


def gt(value: t.Any) -> PropertyMatcher:
    verify_not_none(value, '>')
    value = encode_if_unicode_py2(value)
    return PropertyMatcher('>', value)


def ge(value: t.Any) -> PropertyMatcher:
    verify_not_none(value, '>=')
    value = encode_if_unicode_py2(value)
    return PropertyMatcher('>=', value)


def lt(value: t.Any) -> PropertyMatcher:
    verify_not_none(value, '<')
    value = encode_if_unicode_py2(value)
    return PropertyMatcher('<', value)


def le(value: t.Any) -> PropertyMatcher:
    verify_not_none(value, '<=')
    value = encode_if_unicode_py2(value)
    return PropertyMatcher('<=', value)


def verify_iterable_input_type(values: t.Iterable, _type: str) -> None:
    #TODO: add dict_keys here after python3 transition completed
    if not isinstance(values, (list, set, tuple, frozenset, types.GeneratorType)):
        raise TypeError(
            '"%s" accepts a list/set/tuple/frozenset. Got %s' %(_type, type(values)))


def is_in(values: t.Iterable) -> PropertyMatcher:
    verify_iterable_input_type(values, 'is_in')
    values, is_none_present = sanitize_values(values)

    if not values and is_none_present:
        return is_none()

    matcher = PropertyMatcher('in', values)
    if is_none_present:
        matcher = _or(is_none(), matcher)

    return matcher


def not_in(values: t.Iterable) -> PropertyMatcher:
    verify_iterable_input_type(values, 'not_in')
    values, is_none_present = sanitize_values(values)

    if not values and is_none_present:
        return not_none()

    matcher = PropertyMatcher('!in', values)
    if is_none_present:
        matcher = _and(not_none(), matcher)

    return matcher


def is_none() -> PropertyMatcher:
    return PropertyMatcher('none', None)


def not_none() -> PropertyMatcher:
    return PropertyMatcher('!none', None)


def has_keys(values: t.Iterable) -> PropertyMatcher:
    verify_iterable_input_type(values, 'has_keys')
    values = encode_unicode_in_string_list_py2(values)
    return PropertyMatcher('has_keys', values)


def has_items(values: t.Mapping | t.Iterable) -> PropertyMatcher:
    try:
        values = dict(values)
    except ValueError:
        raise TypeError('Matcher "has_items" accepts only dict compatible types')

    for key, value in list(six.iteritems(values)):
        values[key] = encode_if_unicode_py2(value)
        values[encode_if_unicode_py2(key)] = values.pop(key)

    return PropertyMatcher('has_items', values)


def validate_tag_matcher_values(values: t.Iterable, matcher_type: str) -> None:
    verify_iterable_input_type(values, matcher_type)

    if not values:
        raise ValueError('No values specified for matcher %s' % matcher_type)

    for tag in values:
        if not isinstance(tag, six.string_types):
            raise TypeError('Specified tag is not string: %s' % tag)


def has_all(values: t.Iterable) -> PropertyMatcher:
    validate_tag_matcher_values(values, 'has_all')
    values = encode_unicode_in_string_list_py2(values)
    values = [v.lower() for v in values]
    return PropertyMatcher('has_all', set(values))


def has_any(values: t.Iterable) -> PropertyMatcher:
    validate_tag_matcher_values(values, 'has_any')
    values = encode_unicode_in_string_list_py2(values)
    values = [v.lower() for v in values]
    return PropertyMatcher('has_any', set(values))


def has_none(values: t.Iterable) -> PropertyMatcher:
    validate_tag_matcher_values(values, 'has_none')
    values = encode_unicode_in_string_list_py2(values)
    values = [v.lower() for v in values]
    return PropertyMatcher('has_none', set(values))


def _and(*matchers: PropertyMatcher) -> PropertyMatcher:
    return PropertyMatcher('and', matchers)


def _or(*matchers: PropertyMatcher) -> PropertyMatcher:
    return PropertyMatcher('or', matchers)


def _not(matcher: PropertyMatcher) -> PropertyMatcher:
    """Negates function of given PropertyMatcher. E.g. it converts eq -> ne,
    gt -> le and so on.
    """
    if not isinstance(matcher, PropertyMatcher):
        raise TypeError('PropertyMatcher is expected, got %s' % type(matcher))

    return {
        '==': lambda m: ne(m.value),
        '!=': lambda m: eq(m.value),
        '>': lambda m: le(m.value),
        '>=': lambda m: lt(m.value),
        '<': lambda m: ge(m.value),
        '<=': lambda m: gt(m.value),
        'in': lambda m: not_in(m.value),
        '!in': lambda m: is_in(m.value),
        'none': lambda m: not_none(),
        '!none': lambda m: is_none(),
    }.get(matcher.type, lambda m: PropertyMatcher('not', m))(matcher)


matchers_merge_table: dict[
    str, dict[str, t.Callable[[t.Any, t.Any], t.Optional[PropertyMatcher]]]
] = {
    '==': {
        '==': lambda v1, v2: eq(v1) if v1 == v2 else None,
        '!=': lambda v1, v2: eq(v1) if v1 != v2 else None,
        '>': lambda v1, v2: eq(v1) if v1 > v2 else None,
        '>=': lambda v1, v2: eq(v1) if v1 >= v2 else None,
        '<': lambda v1, v2: eq(v1) if v1 < v2 else None,
        '<=': lambda v1, v2: eq(v1) if v1 <= v2 else None,
        'in': lambda v1, v2: eq(v1) if v1 in v2 else None,
        '!in': lambda v1, v2: eq(v1) if v1 not in v2 else None,
        'none': lambda v1, _: is_none() if v1 is None else None,
        '!none': lambda v1, _: eq(v1) if v1 is not None else None,
    },
    '!=': {
        '!=': lambda v1, v2: ne(v1) if v1 == v2 else not_in([v1, v2]),
        '>': lambda v1, v2: gt(v2) if v1 <= v2 else _and(ne(v1), gt(v2)),
        '>=': lambda v1, v2: ge(v2) if v1 < v2 else _and(ne(v1), ge(v2)),
        '<': lambda v1, v2: lt(v2) if v1 >= v2 else _and(ne(v1), lt(v2)),
        '<=': lambda v1, v2: le(v2) if v1 > v2 else _and(ne(v1), le(v2)),
        'in': lambda v1, v2: is_in([x for x in v2 if x != v1]),
        '!in': lambda v1, v2: not_in(v2 + [v1]),
        'none': lambda v1, _: is_none(),
        '!none': lambda v1, _: _and(not_none(), ne(v1)),
    },
    '>': {
        '>': lambda v1, v2: gt(max([v1, v2])),
        '>=': lambda v1, v2: gt(v1) if v1 >= v2 else ge(v2),
        '<': lambda v1, v2: _and(gt(v1), lt(v2)) if v1 < v2 else None,
        '<=': lambda v1, v2: _and(gt(v1), lt(v2)) if v1 < v2 else None,
        'in': lambda v1, v2: is_in([x for x in v2 if x > v1]),
        '!in': lambda v1, v2: _and(gt(v1), not_in([x for x in v2 if x > v1])),
        'none': lambda v1, _: None,
        '!none': lambda v1, _: gt(v1),
    },
    '>=': {
        '>=': lambda v1, v2: ge(v1) if v1 >= v2 else ge(v2),
        '<': lambda v1, v2: _and(ge(v1), lt(v2)) if v1 < v2 else None,
        '<=': lambda v1, v2: eq(v1) if v1 == v2 else
              (_and(ge(v1), le(v2)) if v1 < v2 else None),
        'in': lambda v1, v2: is_in([x for x in v2 if x >= v1]),
        '!in': lambda v1, v2: _and(ge(v1), not_in([x for x in v2 if x >= v1])),
        'none': lambda v1, _: None,
        '!none': lambda v1, _: ge(v1),
    },
    '<': {
        '<': lambda v1, v2: lt(min([v1, v2])),
        '<=': lambda v1, v2: lt(v1) if v1 <= v2 else le(v2),
        'in': lambda v1, v2: is_in([x for x in v2 if x < v1]),
        '!in': lambda v1, v2: _and(lt(v1), not_in([x for x in v2 if x < v1])),
        'none': lambda v1, _: None,
        '!none': lambda v1, _: lt(v1),
    },
    '<=': {
        '<=': lambda v1, v2: le(min([v1, v2])),
        'in': lambda v1, v2: is_in([x for x in v2 if x <= v1]),
        '!in': lambda v1, v2: _and(le(v1), not_in([x for x in v2 if x <= v1])),
        'none': lambda v1, _: None,
        '!none': lambda v1, _: le(v1),
    },
    'in': {
        'in': lambda v1, v2: is_in([x for x in v1 if x in v2]),
        '!in': lambda v1, v2: is_in([x for x in v1 if x not in v2])
               if any(x not in v2 for x in v1) else None,
        'none': lambda v1, _: None,
        '!none': lambda v1, _: is_in(v1),
    },
    '!in': {
        '!in': lambda v1, v2: not_in(v1 + v2),
        'none': lambda v1, _: is_none(),
        '!none': lambda v1, _: not_in(v1),
    },
    'none': {
        'none': lambda v1, _: is_none(),
        '!none': lambda v1, _: None,
    },
    '!none': {
        '!none': lambda v1, _: not_none(),
    },
    '~=': {
        '==': lambda v1, v2: eq(v2) if fnmatchcase(v2, v1) else None,
        'in': lambda v1, v2: is_in([x for x in v2 if fnmatchcase(x, v1)]),
        '!in': lambda v1, v2: _and(aeq(v1), \
                not_in([x for x in v2 if fnmatchcase(x, v1)])),
        'none': lambda v1, _: None,
        '!none': lambda v1, _: aeq(v1),
    },
    'has_keys': {
        'has_keys': lambda v1, v2: has_keys(list(set(v1) | set(v2))),
        'none': lambda v1, _: None,
        '!none': lambda v1, _: has_keys(v1)
    },
    'has_items': {
        'has_items': has_items_merge,
        'none': lambda v1, _: None,
        '!none': lambda v1, _: has_items(v1),
    },
    'has_all': {
        'and': lambda v1, v2: _and(has_all(v1), *list(v2)),
        'has_all': lambda v1, v2: has_all(list(set(v1) | set(v2))),
        'has_any': lambda v1, v2: _and(has_all(v1), \
                has_any(list(set(v2) - set(v1)))),
        'has_none': lambda v1, v2: _and(has_all(v1), has_none(v2)),
    },
    'has_any': {
        'and': lambda v1, v2: _and(has_any(v1), *list(v2)),
        'has_all': lambda v1, v2: _and(has_any(list(set(v1) - set(v2))), \
                has_all(v2)),
        'has_any': lambda v1, v2: _and(has_any(v1), has_any(v2)),
        'has_none': lambda v1, v2: _and(has_any(v1), has_none(v2)),
    },
    'has_none': {
        'and': lambda v1, v2: _and(has_none(v1), *list(v2)),
        'has_all': lambda v1, v2: _and(has_none(v1), has_all(v2)),
        'has_any': lambda v1, v2: _and(has_none(v1), has_any(v2)),
        'has_none': lambda v1, v2: has_none(list(set(v1) | set(v2))),
    },
    'and': {
        'has_all': lambda v1, v2: _and(has_all(v2), *list(v1)),
        'has_any': lambda v1, v2: _and(has_any(v2), *list(v1)),
        'has_none': lambda v1, v2: _and(has_none(v2), *list(v1)),
    }
}


def merge_matchers(m1: PropertyMatcher, m2: PropertyMatcher
                   ) -> t.Optional[PropertyMatcher | bool]:
    """Merge two PropertyMatcher objects producing new PropertyMatcher that combines
    effects of given two.

    It tries to be smart to build a simple matcher with updated criteria instead
    of just composing matchers so that it is easier to inspect which matcher it is
    so that a more effective matching can be used when it comes to indexes. E.g.
    if index gets an is_in(values) matcher, instead of doing full scan, it knows that
    particular values can be extracted from the matcher and do just a couple of
    lookups instead of full scan. To do that, matcher should be a simple
    PropertyMatcher, not a composition of multiple matchers.
    """
    if not is_matcher(m1):
        m1 = eq(m1)
    if not is_matcher(m2):
        m2 = eq(m2)
    return (
        matchers_merge_table
        .get(m1.type, {})
        .get(m2.type, lambda v1, v2: matchers_merge_table
             .get(m2.type, {}).get(m1.type, lambda _v1, _v2: False)(v2, v1))
    )(m1.value, m2.value)


def is_matcher(obj: t.Any) -> bool:
    """Checks if given object is a property matcher"""
    return isinstance(obj, PropertyMatcher)


TAG_ONLY_MATCHERS: t.Final[list[str]] = ['has_all', 'has_any', 'has_none']


def verify_no_tag_only_matchers(matcher: PropertyMatcher) -> None:
    # If object is not a "matcher" object or if the values are not iterable,
    # skip.
    if not is_matcher(matcher) or not hasattr(matcher.value, '__iter__'):
        return

    if matcher.type in TAG_ONLY_MATCHERS:
        raise TypeError(
            '%s matcher not supported for the specified attribute' % matcher.type
        )

    for value in matcher.value:
        verify_no_tag_only_matchers(value)


def verify_tag_only_matchers_used_only_for_tag(properties: dict) -> None:
    """ Given a dictionary of key and associated matchers, validate that
        tag-only matchers (has_all, has_any, has_none)
        are not utilized for any key other than 'tag'.
    """
    properties = properties or {}
    for k, v in six.iteritems(properties):
        # tag-only matchers can only be used from "tag" property
        if k == 'tag':
            continue

        verify_no_tag_only_matchers(v)
