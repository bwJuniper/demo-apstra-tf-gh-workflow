# Copyright 2021-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import annotations

import typing as t
from abc import ABCMeta, abstractmethod

from aos.sdk.graph.batch import BatchUpdateGraph
from aos.sdk.graph.graph import Graph

if t.TYPE_CHECKING:
    from aos.sdk import typing as tt


class GraphUpserterError(RuntimeError):
    def __init__(self, message: str) -> None:
        super(GraphUpserterError, self).__init__(
            'GraphUpserter error: {}'.format(message))


class GraphUpserterBase(metaclass=ABCMeta):
    SUPPORTED_INPUT_TYPES: tuple = ()
    SUPPORTED_OUTPUT_TYPES: tuple = ()

    def __init__(self, input_graph: tt.Graph, output_graph: tt.Graph) -> None:
        if not isinstance(input_graph, self.SUPPORTED_INPUT_TYPES):
            raise GraphUpserterError(
                'unsupported input graph type {}'.format(
                    type(input_graph).__name__
                )
            )
        if not isinstance(output_graph, self.SUPPORTED_OUTPUT_TYPES):
            raise GraphUpserterError(
                'unsupported output graph type {}'.format(
                    type(output_graph).__name__
                )
            )

        self.input_graph = input_graph
        self.output_graph = output_graph

        # TODO(egor): add verification that
        #  input_graph.schema <= output_graph.schema

    @abstractmethod
    def on_graph(self, _):
        raise NotImplementedError()

    @abstractmethod
    def start(self, full_sync: bool = False, subscribe: bool = True):
        raise NotImplementedError()

    @abstractmethod
    def stop(self):
        raise NotImplementedError()


class GraphUpserter(GraphUpserterBase):
    """GraphUpserter version based on on_node/on_relationship notifications"""
    SUPPORTED_INPUT_TYPES: tuple[t.Type] = (Graph, )
    SUPPORTED_OUTPUT_TYPES: tuple[t.Type, t.Type] = (
        Graph, BatchUpdateGraph)

    def start(self, full_sync: bool = False, subscribe: bool = True) -> None:
        if full_sync:
            # remove stale nodes/relationships from the output graph
            for node in self.output_graph.get_nodes():
                if self.input_graph.get_node(node.id) is None:
                    self.output_graph.del_node(node)

            for relationship in self.output_graph.get_relationships():
                if self.input_graph.get_relationship(relationship.id) is None:
                    self.output_graph.del_relationship(relationship)

        # upsert all nodes from the input graph to the output graph on start
        for node in self.input_graph.get_nodes():
            self.node_upsert(node)

        for relationship in self.input_graph.get_relationships():
            self.relationship_upsert(relationship)

        if subscribe:
            self.input_graph.add_observer(self)

    def stop(self) -> None:
        self.input_graph.remove_observer(self)

    def on_graph(self, graph: Graph) -> None:
        pass

    @t.overload
    def on_node(self, graph: tt.Graph, old_node: None, new_node: tt.GraphNode
                ) -> None:
        ...

    @t.overload
    def on_node(self, graph: tt.Graph ,old_node: tt.GraphNode, new_node: None
                ) -> None:
        ...

    @t.overload
    def on_node(
            self, graph: tt.Graph, old_node: tt.GraphNode, new_node: tt.GraphNode
    ) -> None:
        ...

    def on_node(self, graph, old_node, new_node):
        assert graph == self.input_graph
        if new_node:
            self.node_upsert(new_node)
        else:
            self.output_graph.del_node(old_node)

    @t.overload
    def on_relationship(
            self, graph: tt.Graph, old_rel: None, new_rel: tt.GraphRelationship
    ) -> None:
        ...

    @t.overload
    def on_relationship(
            self, graph: tt.Graph, old_rel: tt.GraphRelationship, new_rel: None
    ) -> None:
        ...

    @t.overload
    def on_relationship(
            self,
            graph: tt.Graph,
            old_rel: tt.GraphRelationship,
            new_rel: tt.GraphRelationship
    ) -> None:
        ...

    def on_relationship(self, graph, old_rel, new_rel):
        assert graph == self.input_graph
        if new_rel:
            self.relationship_upsert(new_rel)
        else:
            self.output_graph.del_relationship(old_rel)

    def node_upsert(self, node: tt.GraphNode) -> None:
        properties = node.properties

        if self.output_graph.get_node(node) is not None:
            self.output_graph.set_node(node.id, **properties)
        else:
            self.output_graph.add_node(node.type, id=node.id, **node.properties)

    def relationship_upsert(self, rel: tt.GraphRelationship) -> None:
        properties = rel.properties

        if self.output_graph.get_relationship(rel) is not None:
            self.output_graph.set_relationship(rel.id, **properties)
        else:
            self.output_graph.add_relationship(
                rel.type, rel.source_id, rel.target_id,
                id=rel.id, **properties)

    def set_output(self, wrapped_output: tt.Graph):
        self.output_graph = wrapped_output
