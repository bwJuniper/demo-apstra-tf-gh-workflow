# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=redefined-builtin,too-many-return-statements,unnecessary-direct-lambda-call

from __future__ import annotations

import sys
import typing as t
from .matchers import PropertyMatcher
from collections import defaultdict
from functools import reduce
import six
from six.moves import range
from six.moves import zip


if t.TYPE_CHECKING:
    from aos.sdk import typing as tt

    RelIndex: t.TypeAlias = (
        tt.GraphRelationship |
        tuple[tt.GraphRelationship,...] |
        dict[str, set[tt.GraphRelationship]]
    )


class GraphIndex(object):
    """
    Multi level object ID index.

    Takes list of attribute names and builds sets of object IDs with particular
    combination of given attribute values. Supports prefix keys: given index
    with attributes 'foo', 'bar' and 'baz', allows querying objects by all three
    attributes, by 'foo' and 'bar' or just 'foo'.
    """
    class IndexNode(object):
        def __init__(self, inner_index):
            self.index = inner_index
            self.count = 0

        def __len__(self):
            return self.count

    _attrs: list[str]
    _index: GraphIndex.IndexNode
    _reverse: dict[str, tuple]

    def __init__(self, attrs: list[str]) -> None:
        # pylint: disable=undefined-variable
        self._attrs = attrs

        def index() -> GraphIndex.IndexNode:
            return GraphIndex.IndexNode(set())

        for _ in range(len(attrs)):
            index = (lambda inner:
                     lambda: GraphIndex.IndexNode(defaultdict(inner)))(index)
        self._index = index()
        self._reverse = {}

    def add(self, obj: tt.GraphNode | tt.GraphRelationship) -> None:
        """Add object to index. Object should have attributes corresponding to
        configured "index" fields (they will be used to determine object's index key)
        and should have "id" attribute (which will be stored in the index; object
        itself is not stored).

        If object is already in the index, it's index key is updated.
        """
        key = tuple(getattr(obj, attr) for attr in self._attrs)
        if obj.id in self._reverse:
            self.remove(obj)

        self._reverse[obj.id] = key
        target = self._index
        for v in key:
            target.count += 1
            target = target.index[v]
        target.count += 1
        target.index.add(obj.id)

    def remove(self, obj: tt.GraphNode | tt.GraphRelationship) -> None:
        """Remove object from index."""
        key = self._reverse.pop(obj.id, None)
        if not key:
            return

        targets = reduce(lambda targets, v: targets + [targets[-1].index[v]],
                         key, [self._index])
        if obj.id in targets[-1].index:
            targets[-1].index.remove(obj.id)
            # compact index
            for target in targets:
                target.count -= 1

            for target, k in reversed(list(zip(targets, key))):
                if target.index[k]:
                    break
                del target.index[k]

    def lookup(
            self, **kwargs: object
    ) -> t.Optional[tuple[int, t.Iterable[tt.GraphNode | tt.GraphRelationship]]]:
        """Lookup object based on given properties.

        If given properties contain properties that are present in indexed columns,
        the longest column prefix is used to lookup values. E.g. if index
        uses columns c1, c2, c3 and c4 and properties contain values for c1, c2 and
        c4, [c1, c2] will be used to narrow down search and the rest will be
        scanned.

        Properties can be specified either with values or with PropertyMatchers.
        If PropertyMatcher is used, all index keys are tried with that matcher
        to find keys that match and search continues for inner keys. However,
        some specific types of matchers (e.g. "==" or "in") are handled more
        efficiently: instead of matching all keys, algorithm extracts particular
        values right from PropertyMatcher and uses those keys to navigate index.

        Lookup returns tuple (cardinality, items) where cardinality is the number of
        objects that will be iterated on and items is the iterator over IDs of those
        objects. Cardinality is needed for choosing which index to use based on
        number of items that will be full-scanned: the less items to scan, the
        better.
        """
        prefix = []
        for attr in self._attrs:
            value = kwargs.get(attr)
            if value is None:
                break
            if isinstance(value, PropertyMatcher) and \
                    value.type not in ['==', 'in']:
                break

            prefix.append(value)

        if not prefix:
            return None

        def target():
            return [self._index]

        # pylint: disable=used-before-assignment
        for pref in prefix:
            if isinstance(pref, PropertyMatcher):
                if pref.type == '==':
                    target = (lambda prev, value:
                              lambda: (index.index[value.value]
                                       for index in prev()
                                       if value.value in index.index))(target, pref)
                elif pref.type == 'in':
                    target = (lambda prev, value:
                              lambda: (index.index[val]
                                       for index in prev()
                                       for val in value.value
                                       if val in index.index))(target, pref)
                elif pref.type == 'none':
                    target = (lambda prev, value:
                              lambda: (index.index[None]
                                       for index in prev()
                                       if None in index.index))(target, pref)
                else:
                    target = (lambda prev, value:
                              lambda: (index.index[key]
                                       for index in prev()
                                       for key in index.index.keys()
                                       if value(key)))(target, pref)
            else:
                target = (lambda prev, value:
                          lambda: (index.index[value]
                                   for index in prev()
                                   if value in index.index))(target, pref)

        count = sum(t.count for t in target())

        indexes = target()
        for _ in range(len(self._attrs) - len(prefix)):
            indexes = (subindex
                       for index in indexes
                       for subindex in six.itervalues(index.index))
        items = (obj for index in indexes for obj in index.index)

        return count, items


def extract_candidates(
        value: t.Optional[
            tt.PropertyMatcher | tt.GraphNode | tt.GraphRelationship | str
            ]
) -> t.Optional[list]:
    """Returns a list of values that could match, or none on failure."""
    if value is None:
        return None
    if not isinstance(value, PropertyMatcher):
        return [value]
    if value.type == '==':
        return [value.value]
    if value.type == 'none':
        return [None]
    if value.type == 'in':
        return list(value.value)
    if value.type == 'and':
        candidates: t.Optional[set] = None
        for v in value.value:
            vv = extract_candidates(v)
            if vv is None:
                return None
            if candidates is None:
                candidates = set(vv)
            else:
                candidates.intersection_update(vv)
        candidates = t.cast(set, candidates)
        return list(candidates)
    if value.type == 'or':
        candidates = set()
        for v in value.value:
            vv = extract_candidates(v)
            if vv is None:
                return None
            candidates.update(vv)
        return list(candidates)
    return None


class CompactRelationshipIndex(object):
    """
    Almost all the nodes is a graph have very low in and out degree. This index
    attempts to use more efficient collections than a set of dicts when the
    number of contained elements is low:

    Degree 0:            None
    Degree 1:            Relationship
    Degree <  threshold: tuple(Relationship)
    Degree >= threshold: dict[set(Relationship)]
    """
    _threshold: int
    _forward: dict[str, RelIndex]
    _reverse: dict[str, RelIndex]

    def __init__(self, threshold: int = 5) -> None:
        assert threshold > 2
        self._threshold = threshold
        self._forward = {}
        self._reverse = {}

    def add(self, obj: tt.GraphRelationship) -> None:
        assert getattr(obj, 'obj_type', None) == 'relationship'
        source_id = obj.source_id
        target_id = obj.target_id
        self._forward[source_id] = self._add(self._forward.get(source_id), obj)
        self._reverse[target_id] = self._add(self._reverse.get(target_id), obj)

    def remove(self, obj: tt.GraphRelationship) -> None:
        assert getattr(obj, 'obj_type', None) == 'relationship'
        source_id = obj.source_id
        target_id = obj.target_id
        forward_removed = self._remove(self._forward.get(source_id), obj)
        reverse_removed = self._remove(self._reverse.get(target_id), obj)
        if forward_removed is None:
            self._forward.pop(source_id, None)
        else:
            self._forward[source_id] = forward_removed
        if reverse_removed is None:
            self._reverse.pop(target_id, None)
        else:
            self._reverse[target_id] = reverse_removed

    def lookup(self,
               type:  t.Optional[
                   tt.PropertyMatcher | tt.GraphNode | tt.GraphRelationship | str
                   ] = None,
               source_id: t.Optional[tt.GraphNode | tt.GraphNodeId] = None,
               target_id: t.Optional[tt.GraphNode | tt.GraphNodeId] = None,
               **kwargs) -> t.Optional[tuple[int, t.Iterator[str]]]:
        types = extract_candidates(type)
        source_ids = extract_candidates(source_id)
        target_ids = extract_candidates(target_id)
        return min(
            self._lookup(self._index(self._forward, source_ids), types),
            self._lookup(self._index(self._reverse, target_ids), types),
            key=lambda x: sys.maxsize if x is None else x[0]
        )

    def _add(self, index: t.Optional[RelIndex], obj: tt.GraphRelationship
             ) -> RelIndex:
        if index is None:
            return obj
        if getattr(index, 'obj_type', None) == 'relationship':
            if t.TYPE_CHECKING:
                index = t.cast(tt.GraphRelationship, index)
            return obj if index.id == obj.id else (index, obj)
        if isinstance(index, tuple):
            for i, rel in enumerate(index):
                if obj.id == rel.id:
                    return index[:i] + (obj,) + index[i + 1:]
            if len(index) + 1 < self._threshold:
                return index + (obj,)
            new_index: dict[str, set[tt.GraphRelationship]] = {}
            for rel in index:
                subindex = new_index.setdefault(rel.type, set())
                subindex.add(rel)
            subindex = new_index.setdefault(obj.type, set())
            subindex.add(obj)
            return new_index
        subindex = index.setdefault(obj.type, set())
        subindex.discard(obj)
        subindex.add(obj)
        return index

    def _remove(self, index: t.Optional[RelIndex], obj: tt.GraphRelationship
                ) -> t.Optional[RelIndex]:
        if index is None:
            return None
        if getattr(index, 'obj_type', None) == 'relationship':
            if t.TYPE_CHECKING:
                index = t.cast(tt.GraphRelationship, index)
            return None if obj.id == index.id else index
        if isinstance(index, tuple):
            for i, rel in enumerate(index):
                if obj.id == rel.id:
                    index = index[:i] + index[i + 1:]
                    return index if len(index) > 1 else index[0]
            return index
        if t.TYPE_CHECKING:
            index = t.cast(dict[str, set[tt.GraphRelationship]], index)
        subindex = index.get(obj.type)
        if subindex is None:
            return index
        subindex.discard(obj)
        if len(subindex) == 0:
            del index[obj.type]
        if len(index) < self._threshold:
            n = 0
            for subindex in six.itervalues(index):
                n += len(subindex)
                if n >= self._threshold:
                    return index
            return tuple(
                rel
                for subindex in six.itervalues(index)
                for rel in subindex
            )
        return index

    def _index(self, index: dict[str, RelIndex], ids: t.Optional[list]
               ) -> t.Optional[list[RelIndex]]:
        if ids is None:
            return None
        indices = []
        for id in ids:
            v = index.get(id)
            if v:
                indices.append(v)
        return indices

    def _count(self, indices: list[RelIndex], types: t.Optional[list]
               ) -> int:
        count = 0
        for index in indices:
            if getattr(index, 'obj_type', None) == 'relationship':
                if t.TYPE_CHECKING:
                    index = t.cast(tt.GraphRelationship, index)
                if types is None or index.type in types:
                    count += 1
                continue
            if isinstance(index, tuple):
                if types is None:
                    count += len(index)
                else:
                    for obj in index:
                        if obj.type in types:
                            count += 1
                continue
            if t.TYPE_CHECKING:
                index = t.cast(dict[str, set[tt.GraphRelationship]], index)
            if types is None:
                for subindex in six.itervalues(index):
                    count += len(subindex)
                continue
            for type in types:
                count += len(index.get(type, []))
        return count

    def _generate(self, indices: list[RelIndex], types: t.Optional[list]
                  ) -> t.Iterator[str]:
        for index in indices:
            if getattr(index, 'obj_type', None) == 'relationship':
                if t.TYPE_CHECKING:
                    index = t.cast(tt.GraphRelationship, index)
                if types is None or index.type in types:
                    yield index.id
                continue
            if isinstance(index, tuple):
                for obj in index:
                    if types is None or obj.type in types:
                        yield obj.id
                continue
            if t.TYPE_CHECKING:
                index = t.cast(dict[str, set[tt.GraphRelationship]], index)
            if types is None:
                for subindex in six.itervalues(index):
                    for obj in subindex:
                        yield obj.id
                continue
            for type in types:
                subindex = index.get(type, set())
                for obj in subindex:
                    yield obj.id

    def _lookup(self, indices: t.Optional[list[RelIndex]], types: t.Optional[list]
                ) -> t.Optional[tuple[int, t.Iterator[str]]]:
        if indices is None:
            return None
        return self._count(indices, types), self._generate(indices, types)
