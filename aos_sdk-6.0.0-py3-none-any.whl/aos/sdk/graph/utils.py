# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import annotations

import typing as t
from itertools import chain

from .graph import Graph
import six


if t.TYPE_CHECKING:
    from aos.sdk import typing as tt


def copy_graph_unoptimised(
        source: tt.Graph,
        target: tt.Graph
) -> None:
    def property_updates(ps1: dict[str, t.Any], ps2: dict[str, t.Any]
                         ) -> dict[str, t.Any]:
        return {
            k: ps1.get(k)
            for k in set(chain(six.iterkeys(ps1), six.iterkeys(ps2)))
            if ps1.get(k) != ps2.get(k)
        }

    for node_id in [node.id
                    for node in target.get_nodes()
                    if not source.get_node(node)]:
        target.del_node(node_id)

    for node in source.get_nodes():
        node1 = target.get_node(node.id)
        if node1 is not None and node1.type != node.type:
            target.del_node(node1)
            node1 = None

        if node1 is None:
            target.add_node(type=node.type, id=node.id, **node.properties)
        else:
            updates = property_updates(node.properties, node1.properties)

            if updates:
                target.set_node(node1, **updates)

    for rel_id in [rel.id
                   for rel in target.get_relationships()
                   if not source.get_relationship(rel)]:
        target.del_relationship(rel_id)

    for rel in source.get_relationships():
        rel1 = target.get_relationship(rel.id)
        if rel1 is not None and (
                rel1.type != rel.type or rel1.source_id != rel.source_id or
                rel1.target_id != rel.target_id
        ):
            target.del_relationship(rel1.id)
            rel1 = None  # type: ignore

        if rel1 is None:
            target.add_relationship(
                id=rel.id, type=rel.type,
                source=rel.source_id, target=rel.target_id,
                **rel.properties
            )
        else:
            updates = property_updates(rel.properties, rel1.properties)

            if updates:
                target.set_relationship(rel1.id, **updates)


def copy_graph(source: tt.Graph,
               target: tt.Graph,
               commit: bool = True,
               source_name: t.Optional[tt.BlueprintType] = None,
               enforce_version: bool = True) -> None:
    """Updates target graph to be exact copy of source graph."""
    if hasattr(target, 'copy_from') and getattr(source, 'is_cpp_graph', False):
        # CppGraph implementation has optimised copy methods
        target.copy_from(source)
    else:
        # Hybrid graph and sdk graph will use this variant
        copy_graph_unoptimised(source, target)

    if commit:
        if source_name:
            source_versions = {source_name: source.version}
        else:
            source_versions = None
        version = source.version if enforce_version else None
        target.commit(version, source_versions=source_versions)


def properties_equal(ps1: dict[str, t.Any], ps2: dict[str, t.Any]) -> bool:
    """ Compares properties of two nodes which are assumed
        to be of the same type."""
    for k in set(chain(six.iterkeys(ps1), six.iterkeys(ps2))):
        if ps1.get(k) != ps2.get(k):
            return False
    return True


def graphs_equal(g1: tt.Graph, g2: tt.Graph) -> bool:
    """ Compares properties of two graphs that are assumed to be of
        the same reference design."""
    g1_nodes = [node for node in g1.get_nodes()]
    g2_nodes = [node for node in g2.get_nodes()]
    g1_rel = [rel for rel in g1.get_relationships()]
    g2_rel = [rel for rel in g2.get_relationships()]
    if len(g1_nodes) != len(g2_nodes) or \
            len(g1_rel) != len(g2_rel):
        return False

    for n1 in g1_nodes:
        n2 = g2.get_node(n1)
        if not n2 or not properties_equal(n1.properties, n2.properties):
            return False

    for r1 in g1_rel:
        r2 = g2.get_relationship(r1)
        if not r2 or not properties_equal(r1.properties, r2.properties):
            return False

    return True


def nodes_equal(n1: tt.GraphNode, n2: tt.GraphNode) -> bool:
    if not n1 and not n2:
        return False
    return n1 == n2 and properties_equal(n1.properties, n2.properties)


def relationships_equal(r1: tt.GraphRelationship, r2: tt.GraphRelationship) -> bool:
    if not r1 and not r2:
        return False
    return r1 == r2 and r1.source_id == r2.source_id and \
        r1.target_id == r2.target_id and \
        properties_equal(r1.properties, r2.properties)


def node_upsert(graph: tt.Graph, node: tt.GraphNode) -> None:
    """Add node to graph or update if it already exists."""
    if graph.get_node(node):
        graph.set_node(node.id, **node.properties)
    else:
        graph.add_node(node.type, id=node.id, **node.properties)


def relationship_upsert(graph: tt.Graph, rel: tt.GraphRelationship) -> None:
    """Add relationship to graph or update if it already exists."""
    if graph.get_relationship(rel):
        graph.set_relationship(rel.id, **rel.properties)
    else:
        graph.add_relationship(rel.type, rel.source_id, rel.target_id,
                               id=rel.id, **rel.properties)


def dict_to_graph(graph_dict: dict[str, t.Any]) -> Graph:
    """Creates Graph from nested dict representation."""

    graph = Graph(id=graph_dict['id'])
    for node in six.itervalues(graph_dict['nodes']):
        graph.add_node(node.pop('type'), id=node.pop('id'), **node)

    for rel in six.itervalues(graph_dict['relationships']):
        graph.add_relationship(
            type=rel.pop('type'),
            source=rel.pop('source_id'),
            target=rel.pop('target_id'),
            id=rel.pop('id'),
            **rel
        )

    if graph_dict.get('version'):
        graph.commit(graph_dict['version'],
                     source_versions=graph_dict.get('source_versions'))

    return graph
