# Copyright 2021-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


"""This module allows to have traverse API calls automatically rewritten into the
iterate API calls; The primary use of this is CPP stack where traverse API
implementation is substantially slower than the iterate API;

However, given that traverse API syntax is almost identical and covers only
a subset of what iterate API can do, it's quite easy to have an adaptor layer
to make automatic conversion based on accumulating the AST and executing the query
when the last iterator is iterated;"""

# pylint: disable=redefined-builtin

import base64
import hashlib

import six

from aos.sdk.graph.graph import IteratorConvenienceMixin
from aos.sdk.graph.query import is_in
from aos.sdk.graph.query.ast import Ast
from aos.sdk.graph.query.dsl import PathQueryBuilder
from aos.sdk.graph.graph import is_node


class NotSupportedIterationError(Exception):
    pass


class AstAccumulatingIteratorBase(IteratorConvenienceMixin):
    def __init__(self, parent):
        super(AstAccumulatingIteratorBase, self).__init__()
        self._parent = parent
        self._next = None
        self._query_builder = None
        self._top = None
        self._ast_element = None  # filled by the child classes
        self._depleted = False

        if parent is not None:
            assert isinstance(parent, AstAccumulatingIteratorBase)
            self._ensure(parent._next is None, 'Forking is not supported')
            self._ensure(not parent._depleted, 'Parent is already depleted')
            parent._next = self
            self._query_builder = parent._query_builder
            self._top = parent._top
        else:  # no parent
            self._top = self

    @property
    def ast(self):
        return self._query_builder.ast if self._query_builder else None

    @staticmethod
    def _sanitize_matchers(matchers):
        return {
            key: matchers[key]
            for key in matchers
            if matchers[key] is not None
        }

    @staticmethod
    def _ensure(cond, message):
        if not cond:
            raise NotSupportedIterationError(message)

    def _allocate_named_element(self):
        str_names = '\x00'.join(sorted(self._query_builder._names))

        if six.PY3:
            str_names = str_names.encode('utf-8')

        name_digest = hashlib.sha1(str_names).digest()
        element_name = base64.standard_b64encode(name_digest)

        if six.PY3:
            # On CPP stack the result of this method is later passed into
            # Tac as Tac::String, which corresponds to str in both python
            # versions. Hence in python 3 we decode the result.
            element_name = element_name.decode('ascii')

        self._query_builder._names.add(element_name)
        return element_name

    def where(self, predicate):
        element_name = self._allocate_named_element()
        self._ast_element.name = element_name
        self._query_builder.where(predicate, names=[element_name])
        return self

    def __iter__(self):
        self._ensure(
            self._next is None,
            '__iter__ must be called on the last iterator of the sequence')

        if self._depleted:
            raise ValueError('Iterator was already used')

        self._depleted = True

        target_element = self._ast_element
        if not target_element.name:
            target_element.name = self._allocate_named_element()

        for path in self._top._iterate_fn(self._top._graph, self._query_builder):
            yield path[target_element.name]


class AstAccumulatingNodeIterator(AstAccumulatingIteratorBase):
    def __init__(self, parent):
        super(AstAccumulatingNodeIterator, self).__init__(parent)

        # for the top node iterator parent is not set, and ast element is filled
        # by that top iterator
        if parent:
            self._ast_element = self._query_builder._elements[-1]
            assert isinstance(self._ast_element, Ast.Node)

    def out(self, type=None, **kwargs):
        kwargs = self._sanitize_matchers(kwargs)
        self._query_builder.out(type, **kwargs)
        return AstAccumulatingRelationshipIterator(self)

    def in_(self, type=None, **kwargs):
        kwargs = self._sanitize_matchers(kwargs)
        self._query_builder.in_(type, **kwargs)
        return AstAccumulatingRelationshipIterator(self)


class TopAstAccumulatingNodeIterator(AstAccumulatingNodeIterator):
    def __init__(self, graph, iterate_fn, nodes=None, node_type=None):
        super(TopAstAccumulatingNodeIterator, self).__init__(parent=None)
        self._query_builder = PathQueryBuilder(node_type)
        self._graph = graph
        self._iterate_fn = iterate_fn
        self._ast_element = self._query_builder._elements[0]
        assert isinstance(self._ast_element, Ast.Node)

        # when nodes are specified extract IDs to be used inside the ID matcher
        if nodes is not None:
            if is_node(nodes):
                self._ast_element.type = nodes.type
                self._ast_element.id = nodes.id
            else:  # multiple nodes
                node_ids = list()
                node_types = set()
                for node in nodes:
                    node_ids.append(node.id)
                    node_types.add(node.type)
                assert not self._ast_element.id
                self._ast_element.id = is_in(node_ids)
                self._ast_element.type = is_in(node_types)


class AstAccumulatingRelationshipIterator(AstAccumulatingIteratorBase):
    def __init__(self, parent):
        super(AstAccumulatingRelationshipIterator, self).__init__(parent)
        self._ast_element = self._query_builder._elements[-2]
        assert isinstance(self._ast_element, Ast.Relationship)

    def node(self, type=None, **kwargs):
        kwargs = self._sanitize_matchers(kwargs)
        self._query_builder.node(type, **kwargs)
        return AstAccumulatingNodeIterator(self)

    def target(self, type=None, **kwargs):
        self._ensure(self._ast_element.direction != 'in',
                     '.in_(...).target(...) pattern is not supported')
        return self.node(type, **kwargs)

    def source(self, type=None, **kwargs):
        self._ensure(self._ast_element.direction != 'out',
                     '.out(...).source(...) pattern is not supported')
        return self.node(type, **kwargs)
