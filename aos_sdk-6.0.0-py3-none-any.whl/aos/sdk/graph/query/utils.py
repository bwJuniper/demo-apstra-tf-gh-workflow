# Copyright 2021-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


def rule(query):
    """
    Defines Query Engine incremental processing rule as part of the "queries"
    attribute in the decorated function.
    """

    def wrapper(f):
        if not hasattr(f, 'queries'):
            f.queries = []
        f.queries.append(query)
        return f

    return wrapper


def register_rules(target, query_engine):
    """
    Inspects a target object looking for defined queries inside "queries" attribute
    and registered them using the specified Query Engine instance.
    """
    query_ids = []
    for k in dir(target):
        v = getattr(target, k)
        if hasattr(v, 'queries'):
            for query in v.queries:
                query_id = query_engine.register_query(query, v)
                query_ids.append(query_id)
    return query_ids
