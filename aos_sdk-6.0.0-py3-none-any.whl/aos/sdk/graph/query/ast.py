# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import abc
import copy
import hashlib
import struct

from aos.sdk.graph.matchers import (
    is_matcher, merge_matchers, eq, verify_tag_only_matchers_used_only_for_tag,
)
from aos.sdk.utils import (
    check_func_equal, encode_if_unicode, encode_unicode_in_string_list,
)
import six

# pylint: disable=invalid-name,redefined-builtin,super-init-not-called


def get_ast_type(element):
    ''' Returns None in case type is not specified. Otherwise, returns a list
        of types specified.
    '''
    assert isinstance(element, (Ast.Node, Ast.Relationship))
    if not element.type:
        return {None}

    if not is_matcher(element.type):
        return {element.type}

    if element.type.type == 'in':
        return element.type.value

    assert element.type.type == '=='
    return {element.type.value}


def verify_type_matcher(_type):
    ''' Add validation that type matcher is either '==' or 'in'.
    '''
    if is_matcher(_type) and _type.type not in ['in', '==']:
        raise ValueError('Type does not support matcher %s' %_type.type)


class Base(six.with_metaclass(abc.ABCMeta, object)):
    """Base class for all AST element subclasses.

    Each subclass must implement __hash_fn__ and set __hash__ to Base.__hash__
    in order to use the mechanism of caching hashes for its instances.
    """
    def get_merkle_tree_hash(self):
        if not hasattr(self, '__calculated_merkle_tree_hash__'):
            hasher = MerkleTreeHasher()
            hasher.visit(self)
            # pylint: disable=attribute-defined-outside-init
            self.__calculated_merkle_tree_hash__ = hasher.result()

        return self.__calculated_merkle_tree_hash__

    def __hash__(self):
        if not hasattr(self, '__calculated_hash__'):
            # pylint: disable=attribute-defined-outside-init
            self.__calculated_hash__ = self.__hash_fn__()
        return self.__calculated_hash__

    def __ne__(self, obj):
        return not self.__eq__(obj)

    @abc.abstractmethod
    def __repr__(self):
        raise NotImplementedError()

    @abc.abstractmethod
    def __eq__(self, obj):
        raise NotImplementedError()

    @abc.abstractmethod
    def __hash_fn__(self):
        raise NotImplementedError()


class Ast(object):

    Base = Base

    class Node(Base):
        '''
        Graph Node matcher

        :param name: (string) Name to assigned to matched Node
        :param type: (string) Match only nodes of this type
        :param id: (string) Match Node with given ID
        :param properties: (dict) Mapping of Node attribute names to either
            values or aos.sdk.graph.PropertyMatcher objects. Match only
            Nodes that matching properties.
        '''
        def __init__(self, name=None, type=None, id=None, properties=None):
            self.name = name
            self.id = id
            self.type = type
            properties = properties or {}
            verify_tag_only_matchers_used_only_for_tag(
                dict(properties, id=id, type=type))
            verify_type_matcher(type)
            self.properties = {k: v if is_matcher(v) else eq(v)
                               for k, v in six.iteritems(properties)}
            # Updated by cpp query engine specific compiler.
            self.seq_number = None

        def __copy__(self):
            return Ast.Node(name=self.name, type=self.type, id=self.id,
                            properties=self.properties)

        def __deepcopy__(self, memo):
            node = self.__class__(name=self.name, type=self.type, id=self.id)
            node.properties = copy.deepcopy(self.properties, memo)
            node.seq_number = self.seq_number
            return node

        def __repr__(self):
            prop_items = list(six.iteritems(self.properties))
            prop_string = ''.join([
                ' %s=%s' % (k, v)
                for k, v in [('name', self.name),
                             ('id', self.id),
                             ('type', self.type)] + prop_items
                if v is not None
            ])
            return '<%s%s>' % (self.__class__.__name__, prop_string)

        __hash__ = Base.__hash__

        def __hash_fn__(self):
            return hash((
                self.__class__,
                self.name,
                self.id,
                self.type,
                tuple(
                    sorted(
                        (k, v if is_matcher(v) else (type(v), repr(v)))
                        for k, v in six.iteritems(self.properties)
                    )
                ),
            ))

        def __eq__(self, obj):
            return self is obj or (
                self.__class__ is obj.__class__
                and self.name == obj.name
                and self.id == obj.id
                and self.type == obj.type
                and self.properties == obj.properties
            )

        def get_type(self):
            return set(get_ast_type(self))

    class Relationship(Base):
        '''
        Graph Relationship matcher

        :param direction: (string) Relationship direction ("in" or "out").
            This meaning only makes sense for Relationship being part of Path
            where this direction shows relation of this Relationship to Node
            matched by previous Node matcher in Path.
        :param name: (string) Name to assigned to matched Node
        :param type: (string) Match only nodes of this type
        :param id: (string) Match Node with given ID
        :param properties: (dict) Mapping of Node attribute names to either
            values or aos.sdk.graph.PropertyMatcher objects. Match only
            Ast.Node's that matching properties.
        '''
        def __init__(self, direction, name=None, id=None, type=None,
                     properties=None):
            self.direction = direction
            self.name = name
            self.id = id
            self.type = type
            properties = properties or {}
            verify_tag_only_matchers_used_only_for_tag(
                dict(properties, id=id, type=type))
            verify_type_matcher(type)
            self.properties = {k: v if is_matcher(v) else eq(v)
                               for k, v in six.iteritems(properties)}
            # Updated by cpp query engine specific compiler.
            self.seq_number = None

        def __copy__(self):
            return Ast.Relationship(direction=self.direction, name=self.name,
                                    type=self.type, id=self.id,
                                    properties=self.properties)

        def __deepcopy__(self, memo):
            relationship = self.__class__(
                direction=self.direction, name=self.name, id=self.id, type=self.type)
            relationship.properties = copy.deepcopy(self.properties, memo)
            relationship.seq_number = self.seq_number
            return relationship

        def __repr__(self):
            prop_items = list(six.iteritems(self.properties))
            prop_string = ''.join([
                ' %s=%s' % (k, v)
                for k, v in [('direction', self.direction),
                             ('name', self.name),
                             ('id', self.id),
                             ('type', self.type)] + prop_items
                if v is not None
            ])
            return '<%s%s>' % (self.__class__.__name__, prop_string)

        __hash__ = Base.__hash__

        def __hash_fn__(self):
            return hash((
                self.__class__,
                self.direction,
                self.name,
                self.id,
                self.type,
                tuple(
                    sorted(
                        (k, v if is_matcher(v) else (type(v), repr(v)))
                        for k, v in six.iteritems(self.properties)
                    )
                ),
            ))

        def __eq__(self, obj):
            return self is obj or (
                self.__class__ is obj.__class__
                and self.direction == obj.direction
                and self.name == obj.name
                and self.id == obj.id
                and self.type == obj.type
                and self.properties == obj.properties
            )

        def get_type(self):
            return set(get_ast_type(self))

    class Path(Base):
        '''
        Defines a "path" in graph (a sequence of nodes connected with relationships)

        :param elements: (list) List of Ast.Node and Ast.Relationship.
            List should start and end with Ast.Node and have Ast.Node and
            Ast.Relationship interchanging
        '''
        def __init__(self, elements):
            self.elements = elements

        def __deepcopy__(self, memo):
            return self.__class__(copy.deepcopy(self.elements, memo))

        def __repr__(self):
            return '<%s elements=%s>' % (self.__class__.__name__, self.elements)

        __hash__ = Base.__hash__

        def __hash_fn__(self):
            return hash((
                self.__class__,
                tuple(self.elements or ()),
            ))

        def __eq__(self, obj):
            return self is obj or (
                self.__class__ is obj.__class__
                and self.elements == obj.elements
            )

    class MultiPath(Base):
        '''
        Defines a group of Ast.Path's

        :param paths: (list) List of Ast.Path
        '''
        def __init__(self, paths):
            self.paths = paths

        def __deepcopy__(self, memo):
            return self.__class__(copy.deepcopy(self.paths, memo))

        def __repr__(self):
            return '<%s paths=%s>' % (self.__class__.__name__, self.paths)

        __hash__ = Base.__hash__

        def __hash_fn__(self):
            return hash((
                self.__class__,
                tuple(self.paths or ()),
            ))

        def __eq__(self, obj):
            return self is obj or (
                self.__class__ is obj.__class__
                and self.paths == obj.paths
            )

    class Select(Base):
        '''
        Node that modifies visibility of inner query names to outside queries.

        :param query: (Ast.Base) Inner query (e.g. Ast.Path or Ast.MultiPath)
        :param names: (list of string) Names that should only be visible from
            inner query to outside queries
        '''
        def __init__(self, query, names):
            self.query = query
            self.names = names

        def __deepcopy__(self, memo):
            return self.__class__(
                copy.deepcopy(self.query, memo),
                copy.deepcopy(self.names, memo),
            )

        def __repr__(self):
            return '<%s query=%s names=%s>' % (self.__class__.__name__,
                                               self.query, self.names)

        __hash__ = Base.__hash__

        def __hash_fn__(self):
            return hash((
                self.__class__,
                self.query,
                tuple(sorted(self.names or ())),
            ))

        def __eq__(self, obj):
            return self is obj or (
                self.__class__ is obj.__class__
                and set(self.names or ()) == set(obj.names or ())
                and self.query == obj.query
            )

    class Distinct(Base):
        # pylint: disable=anomalous-backslash-in-string
        '''
        Node that filters out results so that combination of objects with given
        names is present only once.

        Example:

            You have following graph

                b1
              /    \
            a        c
              \    /
                b2

            and you want to find pairs of A and C connected together through some
            node B, but each pair of A and C should be present only once.

            This can be done by following query:

            Ast.Distinct(
                Ast.Path([
                    Ast.Node(type='a', name='x'),
                    Ast.Relationship(),
                    Ast.Node(type='b', name='y'),
                    Ast.Relationship(),
                    Ast.Node(type='c', name='z'),
                ]),
                ['x', 'z'],
            )

            It will yield only one path with node B being either one of nodes B.
            You probably should not rely or capture node B in that case.

        :param query: (Ast.Base) Inner query (e.g. Ast.Path or Ast.MultiPath)
        :param names: (list of string) Names of objects to use for uniqueness check
        '''
        def __init__(self, query, names):
            self.query = query
            self.names = names

        def __deepcopy__(self, memo):
            return self.__class__(
                copy.deepcopy(self.query, memo),
                copy.deepcopy(self.names, memo),
            )

        def __repr__(self):
            return '<%s query=%s names=%s>' % (self.__class__.__name__,
                                               self.query, self.names)

        __hash__ = Base.__hash__

        def __hash_fn__(self):
            return hash((
                self.__class__,
                self.query,
                tuple(sorted(self.names or ())),
            ))

        def __eq__(self, obj):
            return self is obj or (
                self.__class__ is obj.__class__
                and set(self.names or ()) == set(obj.names or ())
                and self.query == obj.query
            )

    class OptionalPath(Base):
        '''
        Optional path. If query yields results, they all are flat mapped
        into final path. If query yields no results, all it's steps' results are
        Nones. There will be only one None-path yielded.

        :param query: (Ast.Base) Inner query (e.g. Ast.Path or Ast.MultiPath)
        '''
        def __init__(self, query):
            self.query = query

        def __deepcopy__(self, memo):
            return self.__class__(
                copy.deepcopy(self.query, memo),
            )

        def __repr__(self):
            return '<%s query=%s>' % (self.__class__.__name__, self.query)

        __hash__ = Base.__hash__

        def __hash_fn__(self):
            return hash((self.__class__, self.query))

        def __eq__(self, obj):
            return self is obj or (
                self.__class__ is obj.__class__
                and self.query == obj.query
            )

    class FunctionConstraint(Base):
        '''
        Filter paths with a predicate

        Takes objects with given names from matched path and passes them to a
        given function. If function returns False, rejects that path.

        :param predicate: (callable) Function to filter paths with.
            Should have the same arity as length of names parameter.
        :param names: (list of string) Names of path objects to pass to predicate.
        '''
        def __init__(self, predicate, names):
            self.predicate = predicate
            self.names = names

        def __deepcopy__(self, memo):
            return self.__class__(
                self.predicate,
                copy.deepcopy(self.names, memo)
            )

        def __repr__(self):
            return '<%s names=%s>' % (self.__class__.__name__, self.names)

        __hash__ = Base.__hash__

        def __hash_fn__(self):
            return hash((
                self.__class__,
                id(self.predicate),
                tuple(sorted(self.names or ())),
            ))

        def __eq__(self, obj):
            return self is obj or (
                self.__class__ is obj.__class__
                and set(self.names or ()) == set(obj.names or ())
                and check_func_equal(self.predicate, obj.predicate)
            )

    class EnsureDifferentConstraint(Base):
        '''
        Filter paths with unique name

        Takes objects with given names from matched path and checks if the
        the names are different.

        :param names: (list of string) Names of path objects to pass to predicate.
        '''
        def __init__(self, names):
            self.names = names
            if len(self.names) != 2:
                raise ValueError("Internal Error. Constrain expects 2 names")

        def __deepcopy__(self, memo):
            return self.__class__(
                copy.deepcopy(self.names, memo),
            )

        def __repr__(self):
            return '<%s names=%s>' % (self.__class__.__name__, self.names)

        __hash__ = Base.__hash__

        def __hash_fn__(self):
            return hash((
                self.__class__,
                tuple(sorted(self.names or ())),
            ))

        def __eq__(self, obj):
            return self is obj or (
                self.__class__ is obj.__class__
                and set(self.names or ()) == set(obj.names or ())
            )

    class PathConstraint(Base):
        '''
        Filter paths with a subgraph query

        Takes objects with given names from matched path and tries to match a
        number of subgraphs. If number of subgraphs is not within given bounds,
        rejects that path.

        It tries to match minimal amount of subgraphs to determine if their number
        fits bounds (e.g. if at_least=None, at_most=2, will only try to match 2
        subgraphs, will succeed if the 3rd match fails)

        Example:

            find a path A->B->C, where node C has at least one relationship to node D

            Ast.ConstrainedPath(
                # Main query A->B->C
                query=Ast.Path([
                    Ast.Node(type='A'),
                    Ast.Relationship(),
                    Ast.Node(type='B'),
                    Ast.Relationship(),
                    Ast.Node(type='C', name='c'),
                ]),
                constraints=[
                    Ast.PathConstraint(
                        # Subgraph query C->D
                        Ast.Path([
                            Ast.Node(name='c'),
                            Ast.Relationship(),
                            Ast.Node(type='D'),
                        ]),
                        names=['c'],
                        # Match at least one query
                        at_least=1,
                    )
                ],
            )

        :param query: (Ast.Base) Query to check constraints for
        :param names: (list of string) Names of objects that should be same in
            checked query and in outside query
        :params at_least: (int or None) If not None, check that there are at least
            this number of results for query
        :params at_most: (int or None) If not None, check that there are at most
            this number of results for query
        :param inverse: (bool) If True, inverse range (select results that are
            outside given range instead of those that are in range).
            Default is False
        '''
        def __init__(self, query, names, at_least=1, at_most=None, inverse=False):
            self.query = query
            self.names = names
            self.at_least = at_least
            self.at_most = at_most
            self.inverse = inverse

        def __deepcopy__(self, memo):
            return self.__class__(
                copy.deepcopy(self.query, memo),
                copy.deepcopy(self.names),
                self.at_least,
                self.at_most,
                self.inverse,
            )

        def __repr__(self):
            props_string = ''.join([
                ' %s=%s' % (k, v)
                for k in ['query', 'names', 'at_least', 'at_most', 'inverse']
                for v in [getattr(self, k)]
                if v is not None
            ])
            return '<%s%s>' % (self.__class__.__name__, props_string)

        __hash__ = Base.__hash__

        def __hash_fn__(self):
            return hash((
                self.__class__,
                self.query,
                tuple(sorted(self.names or ())),
                self.at_least,
                self.at_most,
                self.inverse,
            ))

        def __eq__(self, obj):
            return self is obj or (
                self.__class__ is obj.__class__
                and self.at_least == obj.at_least
                and self.at_most == obj.at_most
                and self.inverse == obj.inverse
                and set(self.names or ()) == set(obj.names or ())
                and self.query == obj.query
            )

    class ConstrainedPath(Base):
        '''
        A path that should be filtered accodring to constraints

        Constraints can be one of FunctionConstraint, PathConstraint or
        EnsureDifferentConstraint.

        :param query: (Ast.Base) Inner query (e.g. Ast.Path or Ast.MultiPath)
        :param constraints: (list) List of constraints
            (one of Ast.FunctionConstraint, Ast.PathConstraint,
            Ast.EnsureDifferentConstraint)
        '''
        def __init__(self, query, constraints):
            self.query = query
            self.constraints = constraints

        def __deepcopy__(self, memo):
            return self.__class__(
                copy.deepcopy(self.query, memo),
                copy.deepcopy(self.constraints, memo),
            )

        def __repr__(self):
            return '<%s query=%s constraints=%s>' % (self.__class__.__name__,
                                                     self.query, self.constraints)

        __hash__ = Base.__hash__

        def __hash_fn__(self):
            return hash((
                self.__class__,
                self.query,
                tuple(self.constraints or ()),
            ))

        def __eq__(self, obj):
            def cmp_consts(values):
                return sorted(values or (), key=lambda v: v.names)

            return self is obj or (
                self.__class__ is obj.__class__
                and self.query == obj.query
                and cmp_consts(self.constraints) == cmp_consts(obj.constraints)
            )


def merge_Node(node1, node2):
    'Merge contents of two Ast.Node instances. Returns new Ast.Node'
    node_id = node1.id
    if node2.id:
        if node_id and node_id != node2.id:
            raise ValueError('Two node matchers with same name %s '
                             'match nodes with different IDs: '
                             '%s and %s' % (node1.name, node1.id, node2.id))
        node_id = node2.id

    node_type = node1.type
    if node2.type:
        if node_type and node_type != node2.type:
            raise ValueError('Two node matchers with same name %s '
                             'match nodes with different types: '
                             '%s and %s' % (node1.name, node1.type, node2.type))
        node_type = node2.type

    node_properties = dict(node1.properties)
    for k, v in six.iteritems(node2.properties):
        if k in node_properties:
            v2 = merge_matchers(v, node_properties[k])
            if v2 is None:
                raise ValueError('Two node matchers with same name %s '
                                 'match nodes with different values '
                                 'for property %s: %s and %s' % (
                                     node1.name, k, node1.properties[k], v
                                 ))
            v = v2

        node_properties[k] = v

    return Ast.Node(name=node1.name, id=node_id, type=node_type,
                    properties=node_properties)


def merge_Relationship(rel1, rel2):
    'Merge contents of two Ast.Relationship instances. Returns new Ast.Relationship'
    rel_id = rel1.id
    if rel2.id:
        if rel_id and rel_id != rel2.id:
            raise ValueError(
                'Two relationship matchers with same name %s '
                'match relationships with different IDs: '
                '%s and %s' % (rel1.name, rel1.id, rel2.id)
            )
        rel_id = rel2.id

    rel_type = rel1.type
    if rel2.type:
        if rel_type and rel_type != rel2.type:
            raise ValueError(
                'Two relationship matchers with same name %s '
                'match relationships with different types: '
                '%s and %s' % (rel1.name, rel1.type, rel2.type)
            )
        rel_type = rel2.type

    rel_properties = dict(rel1.properties)
    for k, v in six.iteritems(rel2.properties):
        if k in rel_properties:
            v2 = merge_matchers(v, rel_properties[k])
            if v2 is None:
                raise ValueError(
                    'Two relationship matchers with same name %s '
                    'match relationships with different values '
                    'for property %s: %s and %s' % (
                        rel1.name, k, rel1.properties[k], v
                    )
                )
            v = v2

        rel_properties[k] = v

    return Ast.Relationship(direction=rel1.direction, name=rel1.name,
                            id=rel_id, type=rel_type, properties=rel_properties)


class AstError(Exception):
    '''
    Exception for AST related errors (probably sign of incorrect implementation)
    '''


class AstTraversal(object):
    '''
    Traverse query AST tree

    Calls visit_<AST_type>(ast) methods, e.g. visit_Node(node).
    '''
    def visit(self, ast):
        method_name = 'visit_%s' % ast.__class__.__name__
        method = getattr(self, method_name)
        if not method:
            raise ValueError('Unsupported AST node: %s' % ast)
        method(ast)

    def visit_Node(self, ast):
        pass

    def visit_Relationship(self, ast):
        pass

    def visit_Path(self, ast):
        for item_ast in ast.elements:
            self.visit(item_ast)

    def visit_MultiPath(self, ast):
        for item_ast in ast.paths:
            self.visit(item_ast)

    def visit_Select(self, ast):
        self.visit(ast.query)

    def visit_Distinct(self, ast):
        self.visit(ast.query)

    def visit_OptionalPath(self, ast):
        self.visit(ast.query)

    def visit_FunctionConstraint(self, ast):
        pass

    def visit_EnsureDifferentConstraint(self, ast):
        pass

    def visit_PathConstraint(self, ast):
        self.visit(ast.query)

    def visit_ConstrainedPath(self, ast):
        self.visit(ast.query)
        for constraint in ast.constraints:
            self.visit(constraint)


class AstTransform(object):
    '''
    Transform query AST tree

    For every AST node calls visit_<AST_type>(ast) methods, e.g. visit_Node(node).
    Each method can return None, an AST node or list of AST nodes (where appropriate)
    If result is None, the original AST node will be removed.
    If result is AST node or list of AST nodes, original node will be replaced.
    '''
    def visit(self, ast):
        method_name = 'visit_%s' % ast.__class__.__name__
        method = getattr(self, method_name)
        if not method:
            raise ValueError('Unsupported AST node: %s' % ast)
        return method(ast)

    def visit_Node(self, ast):
        return ast

    def visit_Relationship(self, ast):
        return ast

    def visit_Path(self, ast):
        new_elements = []
        for item_ast in ast.elements:
            result = self.visit(item_ast)
            if result is None:
                continue
            if isinstance(result, Ast.Base):
                result = [result]
            new_elements.extend(result)
        if not new_elements:
            return None
        return Ast.Path(new_elements)

    def visit_MultiPath(self, ast):
        new_paths = []
        for item_ast in ast.paths:
            result = self.visit(item_ast)
            if result is None:
                continue
            if isinstance(result, Ast.Base):
                result = [result]
            new_paths.extend(result)
        if not new_paths:
            return None
        return Ast.MultiPath(new_paths)

    def visit_Select(self, ast):
        result = self.visit(ast.query)
        if result is None:
            return None
        if not isinstance(result, Ast.Base):
            raise AstError('Invalid transformation result: %s' % result)
        return Ast.Select(result, ast.names)

    def visit_Distinct(self, ast):
        result = self.visit(ast.query)
        if result is None:
            return None
        if not isinstance(result, Ast.Base):
            raise AstError('Invalid transformation result: %s' % result)
        return Ast.Distinct(result, ast.names)

    def visit_OptionalPath(self, ast):
        result = self.visit(ast.query)
        if result is None:
            return None
        if not isinstance(result, Ast.Base):
            raise AstError('Invalid transformation result: %s' % result)
        return Ast.OptionalPath(result)

    def visit_FunctionConstraint(self, ast):
        return ast

    def visit_EnsureDifferentConstraint(self, ast):
        return ast

    def visit_PathConstraint(self, ast):
        result = self.visit(ast.query)
        if result is None:
            return None
        if not isinstance(result, Ast.Base):
            raise AstError('Invalid transformation result: %s' % result)
        return Ast.PathConstraint(result, ast.names,
                                  at_least=ast.at_least,
                                  at_most=ast.at_most,
                                  inverse=ast.inverse)

    def visit_ConstrainedPath(self, ast):
        new_query = self.visit(ast.query)
        if new_query is None:
            return None
        if not isinstance(new_query, Ast.Base):
            raise AstError('Invalid transformation result: %s' % new_query)

        new_constraints = []
        for constraint in ast.constraints:
            new_constraint = self.visit(constraint)
            if new_constraint is None:
                continue
            if isinstance(new_constraint, Ast.Base):
                new_constraint = [new_constraint]
            new_constraints.extend(new_constraint)

        if not new_constraints:
            return new_query

        return Ast.ConstrainedPath(new_query, new_constraints)


class NamesCollector(AstTraversal):
    def __init__(self, skip_path_constraints=True):
        super(NamesCollector, self).__init__()
        self.node_names = set()
        self.relationship_names = set()
        self.skip_path_constraints = skip_path_constraints

    def visit_Node(self, ast):
        if ast.name:
            self.node_names.add(ast.name)

    def visit_Relationship(self, ast):
        if ast.name:
            self.relationship_names.add(ast.name)

    def visit_PathConstraint(self, ast):
        if not self.skip_path_constraints:
            super(NamesCollector, self).visit_PathConstraint(ast)


def get_path_names(path):

    c = NamesCollector()
    c.visit(path)

    return c.node_names.union(c.relationship_names)


class AstTagFinder(AstTraversal):
    def __init__(self, *args, **kwargs):
        super(AstTagFinder, self).__init__(*args, **kwargs)
        # Node elements with tag filters.
        self.__tagged_elements = []
        self.seen_names = set()

    @property
    def tagged_elements(self):
        return self.__tagged_elements

    def visit_Node(self, ast):
        if 'tag' not in ast.properties:
            return

        if ast.name:
            if ast.name in self.seen_names:
                return
            self.seen_names.add(ast.name)

        self.__tagged_elements.append(ast)


class MerkleTreeHasher(AstTraversal):
    '''
    MerkleTreeHasher is an AST traversal that generates a hash for the
    whole AST tree.

    https://en.wikipedia.org/wiki/Merkle_tree

    The whole idea is that we traverse a tree and calculate some hash
    for each leaf. After that, having these hashes, we calculate a
    combination of them for a parent of some leaves. Going to the root,
    we repeatedly calculate these hashes so a root hash is a Merkle tree
    hash we are searching for.

    If some leaf is changed or some subtree is rebuilt, this all results
    in a final hash. So, if 2 trees have equal caches, we can consider
    them as equal.
    '''
    # Let's assume we traverse a node. Node has id, type, properties and
    # so on. We also have a tree hasher which is a mixer.
    #
    # If we put values into a mixer one by one, we may face a
    # concatenation issue:
    # id(hell), type(oworld) = id(hello), type(world)
    #
    # but if some delimiter, that is not printable (e.g \x00) is
    # put between, we do not have such an issue.
    DELIMITER = b'\x00'

    # This is an identifier of the AST node type. This is a byte
    # mostly because of the hashing speed. In synthetic benchmark such
    # optimization cuts an execution time twice. In real world we can
    # expect slightly smaller, boost. But still noticeable.
    NODE_TYPE = b'\x01'
    RELATIONSHIP_TYPE = b'\x02'
    PATH_TYPE = b'\x03'
    MULTIPATH_TYPE = b'\x04'
    SELECT_TYPE = b'\x05'
    DISTINCT_TYPE = b'\x06'
    OPTIONAL_TYPE = b'\x07'
    FUNCTION_CONSTRAINT_TYPE = b'\x08'
    ENSURE_DIFFERENT_CONSTRAINT_TYPE = b'\x09'
    PATH_CONSTRAINT_TYPE = b'\x0a'
    CONSTRAINED_TYPE = b'\x0b'

    NONE_AS_INT = struct.pack('=cq', b'\x10', 0)

    class Result(object):
        def __init__(self, hasher):
            self.digest = hasher._hasher.digest()
            self.cacheable = hasher._cacheable

        @property
        def hexdigest(self):
            if six.PY3:
                return self.digest.hex()
            else:
                return self.digest.encode('hex')

    def __init__(self, hashfunc=hashlib.sha1):
        self._hasher = hashfunc()
        self._cacheable = True

    def _hash_str(self, value):
        # concatenation is faster than calling hasher update twice.
        if value is None:
            value = b'\x13'
        else:
            value = b'\x12' + encode_if_unicode(value)
        self._hasher.update(value + self.DELIMITER)

    def _hash_strcollection(self, value):
        value = value or ()
        # we have to put a length of the collection first to avoid
        # a problem of having an empty collection and not having a
        # collection at all.
        self._hash_int(len(value))
        encoded_value = self.DELIMITER.join(
            encode_unicode_in_string_list(sorted(value)))
        self._hasher.update(encoded_value)

    def _hash_int(self, value):
        if value is None:
            value = self.NONE_AS_INT
        else:
            value = struct.pack('=cq', b'\x11', value or 0)
        self._hash_str(value)

    def _hash_leaf_id(self, value):
        self._hash_str('' if value is None else '+')

    def _hash_leaf_type(self, value):
        if is_matcher(value):
            if value.type == 'in':
                encoded_value = encode_unicode_in_string_list(value.value)
                self._hash_str(b'in\xaa' + b'\x00'.join(sorted(encoded_value)))
            else:
                self._hash_str(encode_if_unicode(value.type) + b'\xaa' +
                               encode_if_unicode(value.value))
        elif isinstance(value, six.string_types):
            self._hash_str(b'==\xaa' + encode_if_unicode(value))
        else:
            self._hash_str(b'\xaa')

    def result(self):
        return self.Result(self)

    def visit_Node(self, ast):
        super(MerkleTreeHasher, self).visit_Node(ast)
        self._hash_str(self.NODE_TYPE)

        # id can be a matcher
        self._hash_leaf_id(ast.id)
        self._hash_str(ast.name)
        self._hash_leaf_type(ast.type)
        self._hash_strcollection(ast.properties)

    def visit_Relationship(self, ast):
        super(MerkleTreeHasher, self).visit_Relationship(ast)
        self._hash_str(self.RELATIONSHIP_TYPE)

        self._hash_str(ast.direction)
        self._hash_str(ast.name)
        # id can be a matcher
        self._hash_leaf_id(ast.id)
        self._hash_leaf_type(ast.type)
        self._hash_strcollection(ast.properties)

    def visit_Path(self, ast):
        super(MerkleTreeHasher, self).visit_Path(ast)
        self._hash_str(self.PATH_TYPE)

        self._hash_int(len(ast.elements))

    def visit_MultiPath(self, ast):
        super(MerkleTreeHasher, self).visit_MultiPath(ast)
        self._hash_str(self.MULTIPATH_TYPE)

        self._hash_int(len(ast.paths))

    def visit_Select(self, ast):
        super(MerkleTreeHasher, self).visit_Select(ast)
        self._hash_str(self.SELECT_TYPE)

        self._hash_strcollection(ast.names)

    def visit_Distinct(self, ast):
        super(MerkleTreeHasher, self).visit_Distinct(ast)
        self._hash_str(self.DISTINCT_TYPE)

        self._hash_strcollection(ast.names)

    def visit_OptionalPath(self, ast):
        super(MerkleTreeHasher, self).visit_OptionalPath(ast)
        self._hash_str(self.OPTIONAL_TYPE)

    def visit_FunctionConstraint(self, ast):
        super(MerkleTreeHasher, self).visit_FunctionConstraint(ast)
        self._hash_str(self.FUNCTION_CONSTRAINT_TYPE)

        # we have to mix an ID of the function here because of closures:
        # even the same function with the same code may have a different
        # set of objects in its closure and naive reuse of them can lead
        # to really hard-to-debug effects.
        #
        # each time you recreate a lambda, a new object is created so
        # hashes should be different.
        self._hash_int(id(ast.predicate))
        self._hash_strcollection(ast.names)

        # by the comment above, it would be better to skip caching of such
        # queries completely because of unpredictable effects of closures.
        self._cacheable = False

    def visit_EnsureDifferentConstraint(self, ast):
        super(MerkleTreeHasher, self).visit_FunctionConstraint(ast)
        self._hash_str(self.ENSURE_DIFFERENT_CONSTRAINT_TYPE)

        self._hash_strcollection(ast.names)

    def visit_PathConstraint(self, ast):
        super(MerkleTreeHasher, self).visit_PathConstraint(ast)
        self._hash_str(self.PATH_CONSTRAINT_TYPE)

        self._hash_strcollection(ast.names)
        self._hash_int(ast.at_least)
        self._hash_int(ast.at_most)
        self._hash_int(int(ast.inverse))

    def visit_ConstrainedPath(self, ast):
        super(MerkleTreeHasher, self).visit_ConstrainedPath(ast)
        self._hash_str(self.CONSTRAINED_TYPE)

        self._hash_int(len(ast.constraints))
