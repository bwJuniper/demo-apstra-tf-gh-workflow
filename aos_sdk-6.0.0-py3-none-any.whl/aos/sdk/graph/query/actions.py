# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula
'''
Query engine actions

To search subgraphs in a graph based on a query, query is decomposed into a
series of actions by query compiler.

Actions operate on a concept of "path" - list of graph objects (nodes/relationships)
that were collected while performing a search. Actions chain together by iterating
over all paths found on previous step and then looking up data in paths,
performing some checks or searches on a graph and producing new, updated paths.

E.g. when performing a search for

   (node a) --> (node b) --> (node c)

it will first search for any node a (step 1) and produce a sequence of paths with
a single node a (with index 0). The next action will take every path found on
step 1, take a node at index 0 in path and will search for any outgoing relationship
from that node. For every relationship it will generate a new sequence of paths
with node a at index 0 and relationship at index 1. The next action will take
relationship at index 1 in each path and yield new path with relationship's target
node at index 2. And so on.

But there is more. Each action produces not just a sequence of paths, but actually
a sequence of path tuples (old_path, new_path). Action's main method - iterator() -
takes sequence of paths from previous action (a generator) and two graphs: old and
new each of which can be None. The idea is that if both graphs are present,
actions build paths on both graphs: each path in one graph is accompanied with
the same path in other graph (if any). Thus, there can be situations:

    old_path  |  new_path  |  meaning
    --------------------------------------------
      None    |  not None  |  a path was added
    not None  |    None    |  a path was removed
    not None  |  not None  |  a path was updated
      None    |    None    |  ignore

So, actions operate on paths which are just lists of graph objects. There is one
action - ResultAction - which is an exclusion. It can only come as last action and
it converts paths from lists to dictionaries mapping query object names to object
found during search. Let's say in previous example user assigned name "foo" to
node a and name "bar" to node c. The resulting paths yielded by ResultAction will
be dictionary with "foo" and "bar" keys and values being objects at indexes 0 and 5
in path.

'''

from __future__ import print_function

import operator

from aos.sdk.graph.graph import is_node, is_relationship
from aos.sdk.graph.matchers import is_matcher, eq
from functools import reduce  # pylint: disable=redefined-builtin
import six

# pylint: disable=invalid-name,redefined-builtin,abstract-method


def _make_matcher(value):
    return value if is_matcher(value) else eq(value)


class Action(object):
    '''
    Base action

    Every action should implement `iterator()` method.
    '''
    def iterator(self, old_graph, new_graph, paths):
        '''
        Gets paths and should yield new paths.

        Gets paths - iterable of tuples of old and new path pairs - and based on
        semantics of particular subclass should yield updated path pairs.

        :param old_graph: (aos.sdk.graph.Graph or None) Old graph
        :param new_graph: (aos.sdk.graph.Graph or None) New graph
        :param paths: (iterable) An iterable of 2-item tuples - (old_path, new_path)
            Either one can be None.
        '''
        raise NotImplementedError()


class FilterAction(Action):
    '''
    A base action that does not modify paths (e.g. add new elements) but rather
    filters them. Subclasses need to implement `_matches()` method which is applied
    to both old and new path (if path is not None).
    '''
    def iterator(self, old_graph, new_graph, paths):
        for old_path, new_path in paths:
            if old_path is not None and not self._matches(old_graph, old_path):
                old_path = None
            if new_path is not None and not self._matches(new_graph, new_path):
                new_path = None

            if old_path is not None or new_path is not None:
                yield old_path, new_path

    def _matches(self, graph, path):
        '''
        Checks if given path for given graph matches filtering condition.
        Returns True or False

        :param graph: (Graph) Graph to check condition on
        :param path: (list of objects) Path objects traversed so far
        :return: (bool) True if this step matches this path; False otherwise
        '''
        raise NotImplementedError()


class StepAction(Action):
    '''
    A base action that adds new element to the end of a path. Subclasses need to
    implement `_steps()` method which returns list of next elements
    (nodes/relationships) to add to given path. If that method returns multiple
    elements, it will cause action to yield multiple new paths (for each step
    element).

    E.g. if original path is [A, B, C] and _steps() return [D, E, F], the result
    will be new paths [A, B, C, D], [A, B, C, E] and [A, B, C, F].
    '''
    def iterator(self, old_graph, new_graph, paths):
        for old_path, new_path in paths:
            if old_path is not None and new_path is None:
                if not old_graph:
                    continue

                for step in self._steps(old_graph, old_path):
                    yield old_path + step, None
            elif old_path is None and new_path is not None:
                if not new_graph:
                    continue

                for step in self._steps(new_graph, new_path):
                    yield None, new_path + step
            elif old_path is not None and new_path is not None:
                if not old_graph or not new_graph:
                    continue

                old_steps = sorted(self._steps(old_graph, old_path))
                new_steps = sorted(self._steps(new_graph, new_path))

                while old_steps and new_steps:
                    if old_steps[0] == new_steps[0]:
                        yield (
                            old_path + old_steps.pop(0),
                            new_path + new_steps.pop(0),
                        )
                    elif old_steps[0] < new_steps[0]:
                        yield old_path + old_steps.pop(0), None
                    else:
                        yield None, new_path + new_steps.pop(0)

                while old_steps:
                    yield old_path + old_steps.pop(0), None

                while new_steps:
                    yield None, new_path + new_steps.pop(0)

    def _steps(self, graph, path):
        '''
        Returns list of "next steps" for a given path in a given graph.

        :param graph: (Graph) Graph to search next steps in
        :param path: (list of objects) Path objects traversed so far
        :return: (list of objects) Next path step objects
        '''
        raise NotImplementedError()


class NodeActionMixin(object):
    '''
    A base action for actions that match Nodes based on Node properties.

    :param id: (string or None) Value of Node.id to compare (if not None)
    :param type: (string or None) Value of Node.type to compare (if not None)
    :param properties: (dict) Mapping of node properties to values or
        PropertyMatcher's
    '''
    def __init__(self, id=None, type=None, properties=None, **kwargs):
        super(NodeActionMixin, self).__init__(**kwargs)
        self.id = _make_matcher(id) if id is not None else None
        self.type = _make_matcher(type) if type is not None else None
        self.properties = {
            k: _make_matcher(v)
            for k, v in six.iteritems(properties or {})
        }
        self.tag = self.properties.pop('tag', None)

    def _node_matches(self, graph, node):
        '''Check that given node matches values of stored ID/type/properties.'''
        if not is_node(node):
            return False
        if self.id is not None and not self.id(node.id):
            return False
        if self.type is not None and not self.type(node.type):
            return False
        if self.tag is not None and not self.tag(graph.get_tags(node)):
            return False
        for k, v in six.iteritems(self.properties):
            if not hasattr(node, k) or not v(getattr(node, k)):
                return False
        return True

    def __repr__(self):
        prop_string = ''.join([
            ' %s=%s' % (k, v)
            for k, v in [('id', self.id),
                         ('type', self.type)] + list(six.iteritems(self.properties))
            if v is not None
        ])
        return '<%s%s>' % (self.__class__.__name__, prop_string)


class IndexedNodeActionMixin(NodeActionMixin):
    '''
    A base action that validates Node with given index in path.

    :param index: (int) Index of Node object in path. Negative indexes
        refer to items counting from the end (e.g. -1 means last element).
    '''
    def __init__(self, index=-1, **kwargs):
        super(IndexedNodeActionMixin, self).__init__(**kwargs)
        self.index = index

    def __repr__(self):
        prop_string = ''.join([
            ' %s=%s' % (k, v)
            for k, v in [('index', self.index),
                         ('id', self.id),
                         ('type', self.type)] + list(six.iteritems(self.properties))
            if v is not None
        ])
        return '<%s%s>' % (self.__class__.__name__, prop_string)


class RelationshipActionMixin(object):
    '''
    A base action for actions that match Relationship based on
    Relationship properties.

    :param id: (string, PropertyMatcher or None) Value of Relationship.id to compare
        (if not None)
    :param type: (string, PropertyMatcher or None) Value of Relationship.type to
        compare (if not None)
    :param properties: (dict) Mapping of node properties to values
        or PropertyMatcher's
    '''
    def __init__(self, id=None, type=None, properties=None, **kwargs):
        super(RelationshipActionMixin, self).__init__(**kwargs)
        self.id = _make_matcher(id) if id is not None else None
        self.type = _make_matcher(type) if type is not None else None
        self.properties = {
            k: _make_matcher(v)
            for k, v in six.iteritems(properties or {})
        }

    def _relationship_matches(self, relationship):
        '''
        Check that given relationship matches values of stored ID/type/properties.

        :param relationship: (Relationship) Relationship to check
        :return: (bool) True if relationship matches; False otherwise
        '''
        if not is_relationship(relationship):
            return False
        if self.id is not None and not self.id(relationship.id):
            return False
        if self.type is not None and not self.type(relationship.type):
            return False
        for k, v in six.iteritems(self.properties):
            if not hasattr(relationship, k) or not v(getattr(relationship, k)):
                return False
        return True

    def __repr__(self):
        prop_string = ''.join([
            ' %s=%s' % (k, v)
            for k, v in [('id', self.id),
                         ('type', self.type)] + list(six.iteritems(self.properties))
            if v is not None
        ])
        return '<%s%s>' % (self.__class__.__name__, prop_string)


class IndexedRelationshipActionMixin(RelationshipActionMixin):
    '''
    A base action that validates Relationship with given index in path.

    :param index: (int) Index of Relationship object in path. Negative indexes
        refer to items counting from the end (e.g. -1 means last element).
    '''
    def __init__(self, index=-1, **kwargs):
        super(IndexedRelationshipActionMixin, self).__init__(**kwargs)
        self.index = index

    def __repr__(self):
        prop_string = ''.join([
            ' %s=%s' % (k, v)
            for k, v in [('index', self.index),
                         ('id', self.id),
                         ('type', self.type)] + list(six.iteritems(self.properties))
            if v is not None
        ])
        return '<%s%s>' % (self.__class__.__name__, prop_string)


class FindNodeAction(NodeActionMixin, StepAction):
    '''
    Action that searches nodes in graph that match criterias and adds them to path.
    '''
    def _steps(self, graph, path):
        return ([node] for node in
                graph.get_nodes(id=self.id, type=self.type, tag=self.tag,
                                **self.properties))


class FindRelationshipAction(RelationshipActionMixin, StepAction):
    '''
    Action that searches relationships in graph that match criterias
    and adds them to path.
    '''
    def _steps(self, graph, path):
        return (
            [rel] for rel in
            graph.get_relationships(id=self.id, type=self.type, **self.properties)
        )


class CheckNodeMatchesAction(IndexedNodeActionMixin, FilterAction):
    '''
    Action that checks that existing Node in path matches criterias.
    '''
    def _matches(self, graph, path):
        return self._node_matches(graph, path[self.index])


class CheckRelationshipMatchesAction(IndexedRelationshipActionMixin, FilterAction):
    '''
    Action that checks that existing Relationship in path matches criterias.
    '''
    def _matches(self, graph, path):
        return self._relationship_matches(path[self.index])


class NodeOutRelationshipAction(IndexedRelationshipActionMixin, StepAction):
    '''
    Action that finds out relationships from node with given index
    that match criterias and adds it to path.
    '''
    def _steps(self, graph, path):
        node = path[self.index]
        return (
            [rel] for rel in
            graph.get_relationships(source_id=node, id=self.id, type=self.type,
                                    **self.properties)
        )


class NodeInRelationshipAction(IndexedRelationshipActionMixin, StepAction):
    '''
    Action that finds in relationships to node with given index
    that match criterias and adds it to path.
    '''
    def _steps(self, graph, path):
        node = path[self.index]
        return (
            [rel] for rel in
            graph.get_relationships(target_id=node, id=self.id, type=self.type,
                                    **self.properties)
        )


class RelationshipSourceAction(IndexedNodeActionMixin, StepAction):
    '''
    Action that adds source Node of relationship with given index to path
    if node matches criterias.
    '''
    def _steps(self, graph, path):
        rel = path[self.index]
        source = graph.get_node(rel.source_id)
        if not self._node_matches(graph, source):
            return []

        return [[source]]


class RelationshipTargetAction(IndexedNodeActionMixin, StepAction):
    '''
    Action that adds target Node of relationship with given index to path
    if node matches criterias.
    '''
    def _steps(self, graph, path):
        rel = path[self.index]
        target = graph.get_node(rel.target_id)
        if not self._node_matches(graph, target):
            return []

        return [[target]]


class ReseedAction(Action):
    '''
    Takes already found path, picks only particular objects (with given indexes)
    and tries to "seed" it.

    For each old/new path pair it:

    * repacks path with only objects with given indexes
    * if either old or new path is not present, it tries to find objects from
        the accompanying path. If all objects exist, it yields path pair as "update"
        (where both paths are present)

    This action is used in update scenario when updated object is inside
    PathPredicate. In that case we build path inside predicate, then it takes only
    common objects between subpath and outer path and pretends that theses are new
    seed objects.

    :param indexes: (list of int) Indexes of objects in path to use as new seeds
    '''
    def __init__(self, indexes):
        super(ReseedAction, self).__init__()
        self.indexes = indexes

    def _get(self, graph, obj):
        if is_node(obj):
            return graph.get_node(obj)
        elif is_relationship(obj):
            return graph.get_relationship(obj)
        return None

    def iterator(self, old_graph, new_graph, paths):
        for old_path, new_path in paths:
            if old_path is None and new_path is not None:
                p = [self._get(old_graph, new_path[idx]) for idx in self.indexes]
                if all(obj is not None for obj in p):
                    old_path = p
                new_path = [new_path[idx] for idx in self.indexes]
            elif old_path is not None and new_path is None:
                p = [self._get(new_graph, old_path[idx]) for idx in self.indexes]
                if all(obj is not None for obj in p):
                    new_path = p
                old_path = [old_path[idx] for idx in self.indexes]
            elif old_path is not None and new_path is not None:
                old_path = [old_path[idx] for idx in self.indexes]
                new_path = [new_path[idx] for idx in self.indexes]

            if old_path is not None or new_path is not None:
                yield old_path, new_path

    def __repr__(self):
        return '<%s indexes=%s>' % (self.__class__.__name__, self.indexes)


class FunctionConstrainerAction(FilterAction):
    '''
    Action that takes objects with given indexes and passes them to given function.
    Filters out paths for which function returns False.

    :param func: (callable) Filter predicate
    :param indexes: (list of int) Indexes of objects in path to pass
        to filter function
    '''
    def __init__(self, func, indexes):
        super(FunctionConstrainerAction, self).__init__()
        self.func = func
        self.indexes = indexes

    def _matches(self, graph, path):
        return self.func(*[path[idx] for idx in self.indexes])

    def __repr__(self):
        return '<%s indexes=%s>' % (self.__class__.__name__, self.indexes)


class PathConstrainerAction(FilterAction):
    '''
    Action that takes objects with given indexes and runs a subsearch with
    given actions with objects forming a new seed path. Then counts results.
    If number of results is within given limits (both inclusive) then path
    passes.

    :param actions: (list of Action) Compiled inner path
    :param indexes: (list of int) Indexes of objects in path to build subsearch on
    :param at_least: (int or None) Minimum limit of subgraph search results
        (inclusive)
    :param at_most: (int or None) Maximum limit of subgraph search results
        (inclusive)
    :param inverse: (bool) If True, inverse range (select results that are
        outside given range instead of those that are in range).
        Default is False
    '''
    def __init__(self, actions, indexes, at_least=None, at_most=None, inverse=False):
        super(PathConstrainerAction, self).__init__()
        self.actions = actions
        self.indexes = indexes
        self.at_least = at_least
        self.at_most = at_most
        if self.at_least is None and self.at_most is None:
            self.at_least = 1
        self.inverse = inverse

    def _matches(self, graph, path):
        inner_paths = reduce(
            lambda ps, action: action.iterator(None, graph, ps),
            self.actions,
            [(None, [path[idx] for idx in self.indexes])]
        )

        count = 0
        if self.at_least is not None:
            while count < self.at_least:
                p = next(inner_paths, None)
                if p is None:
                    return self.inverse
                count += 1

        if self.at_most is not None:
            while count < self.at_most:
                p = next(inner_paths, None)
                if p is None:
                    return not self.inverse
                count += 1

            p = next(inner_paths, None)
            if p is not None:
                return self.inverse

        return not self.inverse

    def __repr__(self):
        props = [
            (k, v)
            for k in ['actions', 'indexes', 'inverse']
            for v in [getattr(self, k)]
            if v
        ]
        if self.at_least is not None:
            props.append(('at_least', self.at_least))
        if self.at_most is not None:
            props.append(('at_most', self.at_most))

        props_string = ''.join([' %s=%s' % (k, v) for k, v in props])
        return '<%s%s>' % (self.__class__.__name__, props_string)


class DistinctAction(Action):
    '''
    Action that takes objects with given indexes from path and ensures that
    each combination of those objects is seen only in one path. Filters subsequent
    paths with already seen combination of objects.

    :param indexes: (list of int) Indexes of objects to check for uniquness
    '''
    def __init__(self, indexes):
        super(DistinctAction, self).__init__()
        self.indexes = indexes
        self.key = operator.itemgetter(*indexes) if indexes else lambda x: ()

    def iterator(self, old_graph, new_graph, paths):
        removed = set()
        added = set()
        updated = set()
        for old_path, new_path in paths:
            if old_path is None:
                # added
                key = self.key(new_path)
                if key in added:
                    continue
                added.add(key)
            elif new_path is None:
                # removed
                key = self.key(old_path)
                if key in removed:
                    continue
                removed.add(key)
            else:
                # updated
                key = self.key(new_path)
                if key in updated:
                    continue
                updated.add(key)
            yield old_path, new_path

    def __repr__(self):
        return '<%s indexes=%s>' % (self.__class__.__name__, self.indexes)


class OptionalPathAction(StepAction):
    '''
    Action that runs a subquery search and adds all named objects back to
    main path. If subquery search yields no results, this action will yield a
    single path with None for each named object.

    :param actions: (list of Action) Subquery actions
    :param step_count: (int) number of steps produced by inner query. In case
        inner query produces no results, it needs to know how many None
        steps to add
    '''
    def __init__(self, actions, step_count):
        super(OptionalPathAction, self).__init__()
        self.actions = actions
        self.step_count = step_count

    def _steps(self, graph, path):
        opt_paths = list(reduce(
            lambda ps, action: action.iterator(None, graph, ps),
            self.actions,
            [(None, path)]
        ))
        if opt_paths:
            return (list(opt_path)[len(path):] for _, opt_path in opt_paths)

        return [[None] * self.step_count]

    def __repr__(self):
        return '<%s%s>' % (self.__class__.__name__, ''.join([
            ' %s=%s' % (k, v)
            for k in ['actions', 'step_count']
            for v in [getattr(self, k)]
            if v
        ]))


class CheckEqualAction(FilterAction):
    '''
    Action that compares two objects in path given by their indexes to be equal.
    Rejects paths that have those objects not equal to each other.

    :param index1: (int) Index of first object
    :param index2: (int) Index of second object
    '''
    def __init__(self, index1, index2):
        super(CheckEqualAction, self).__init__()
        self.index1 = index1
        self.index2 = index2

    def _matches(self, graph, path):
        return path[self.index1] == path[self.index2]

    def __repr__(self):
        return '<%s index1=%d index2=%d>' % (self.__class__.__name__,
                                             self.index1, self.index2)


class ResultAction(Action):
    '''
    A special action that is added automatically at the end of actions list to
    convert path from list to dictionary, leaving only named objects.

    :param name_indexes: (dict) Mapping of object names to indexes in path
    '''
    def __init__(self, name_indexes, should_filter_updates=False):
        super(ResultAction, self).__init__()
        self.name_indexes = name_indexes
        self.should_filter_updates = should_filter_updates

    def iterator(self, old_graph, new_graph, paths):
        for old_path, new_path in paths:
            if old_path and new_path and self.should_filter_updates:
                continue
            if old_path:
                old_path = {k: old_path[v]
                            for k, v in six.iteritems(self.name_indexes)}
            if new_path:
                new_path = {k: new_path[v]
                            for k, v in six.iteritems(self.name_indexes)}

            yield old_path, new_path

    def __repr__(self):
        return '<%s name_indexes=%s, filter update=%r>' % (
            self.__class__.__name__, self.name_indexes, self.should_filter_updates)


class TraceAction(Action):
    '''
    A special action that just prints label and value of each old/new path pair.
    Usefull for debugging intermediate action results.

    :param label: (string) Label prefix for messages
    '''
    def __init__(self, label):
        super(TraceAction, self).__init__()
        self.label = label

    def iterator(self, old_graph, new_graph, paths):
        for old_path, new_path in paths:
            # TODO: convert it to logging
            print('%s: old = %s, new = %s' % (self.label, old_path, new_path))
            yield old_path, new_path

    def __repr__(self):
        return '<%s label=%r>' % (self.__class__.__name__, self.label)
