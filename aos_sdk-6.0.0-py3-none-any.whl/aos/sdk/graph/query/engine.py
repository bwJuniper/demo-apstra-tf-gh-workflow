# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from .ast import Ast
from . import compiler
from .actions import CheckNodeMatchesAction
from aos.sdk.graph.snapshot import SnapshotGraph
from aos.sdk.profiling.stats_manager import NoopStatsManager
from itertools import chain
import time
import uuid
import logging
from collections import defaultdict
import six

LOGGER = logging.getLogger(__name__)

def iterate(graph, query, trace=False):
    '''Run given query on given graph and yield results'''
    for path in QueryEngine(trace=trace).iterate(graph, query):
        yield path


class QueryInfo(object):
    def __init__(self, query, trace=False):
        if not isinstance(query, Ast.Base):
            query = query.ast

        self.trace = trace
        self.query = compiler.optimize_query(query, expand_tag_filters=True)
        self.actions = compiler.compile_query(self.query, trace=self.trace)
        self.callback = None
        self.node_seed_actions = {}
        self.rel_seed_actions = {}

    def init_seed_actions(self, callback):
        self.callback = callback
        for seed_actions in compiler.compile_seed_query(self.query,
                                                        trace=self.trace):

            node_action_first = isinstance(seed_actions[0],
                                           CheckNodeMatchesAction)

            for applicable_type in compiler.extract_types(seed_actions[0].type):
                if node_action_first:
                    if applicable_type not in self.node_seed_actions:
                        self.node_seed_actions[applicable_type] = []
                    self.node_seed_actions[applicable_type].append(seed_actions)
                else:
                    if applicable_type not in self.rel_seed_actions:
                        self.rel_seed_actions[applicable_type] = []
                    self.rel_seed_actions[applicable_type].append(seed_actions)


def dict_update(d1, d2):
    return dict(d2, **{
        key: None
        for key in d1
        if key not in d2
    })


class GraphInfo(object):
    def __init__(self, graph, commit_callback):
        self.graph = graph
        self.callback = commit_callback

        self.old_graph = SnapshotGraph(self.graph, react_on_graph=False)

    @property
    def node_updates(self):
        return self.old_graph.node_updates

    @property
    def relationship_updates(self):
        return self.old_graph.relationship_updates

    def reset(self):
        self.old_graph.reset()

    def on_graph(self, graph):
        if self.node_updates or self.relationship_updates:
            self.callback(self)
            self.reset()

    def on_node(self, graph, old_node, new_node):
        self.old_graph.on_node(graph, old_node, new_node)

    def on_relationship(self, graph, old_rel, new_rel):
        self.old_graph.on_relationship(graph, old_rel, new_rel)


class Callback(object):
    def __init__(self, query):
        self.removed_paths = []
        self.added_paths = []
        self.updated_paths = []
        self._callback = query.callback
        self.seen_paths = set()

    def callback(self, path, action):
        path1 = (frozenset(six.iteritems(path)), action)
        if path1 in self.seen_paths:
            return
        self.seen_paths.add(path1)
        self._callback(path, action)

    def execute_removed(self):
        for path in self.removed_paths:
            self.callback(path, 'removed')
        self.removed_paths = []
    def execute_added(self):
        for path in self.added_paths:
            self.callback(path, 'added')
        self.added_paths = []
    def execute_updated(self):
        for path in self.updated_paths:
            self.callback(path, 'updated')
        self.updated_paths = []


class QueryEngine(object):
    '''Engine that executes/monitors queries on graphs'''
    def __init__(self, trace=False, stats_manager=None):
        self._queries = {}
        self._watched_graphs = []
        self._trace = trace
        self._stats_manager = stats_manager or NoopStatsManager()
        self._commit_stats = self._stats_manager.create_namespace('commit')

    def make_graph_info(self, graph, callback):
        return GraphInfo(graph, callback)

    def register_query(self, query, callback):
        '''
        Register query for monitoring. Whenever new graph is watched or
        watched graph updated, it will run the query and call provided callback
        if new query match appeared, existing match updated or removed.

        :param query: (Ast, PathQueryBuilder or MultiPathQueryBuilder) Query to
            monitor
        :param callback: (callable) Callback to call when query matches change.
            Should accept two arguments:
                + path - (dict) Mapping of names in the path to matched objects
                + action - (string) Either "added", "updated" or "removed"
        :return: (string) Unique ID that identifies this query
        '''
        qid = str(uuid.uuid4())
        while qid in self._queries:
            qid = str(uuid.uuid4())

        query_info = QueryInfo(query, trace=self._trace)
        query_info.init_seed_actions(callback)
        self._queries[qid] = query_info

        for info in self._watched_graphs:
            for _, path in compiler.run_actions(query_info.actions, info.graph):
                callback(path, 'added')

        return qid

    def remove_query(self, qid):
        '''
        Unregister query from monitoring.

        :param qid: (string) Query ID obtained from `register_query()`
        '''
        if qid in self._queries:
            del self._queries[qid]

    def execute_all(self, graph, action='added'):
        '''
        Run all registered queries on given graph (triggering callbacks with
        given action).

        :param graph: (aos.sdk.graph.Graph) Graph to run queries on
        :param action: (string) Action to run callbacks with (defaults to "added")
        '''
        for query in six.itervalues(self._queries):
            for _, path in compiler.run_actions(query.actions, graph):
                query.callback(path, 'added')

    def iterate(self, graph, query):
        '''
        Run given query on given graph, yielding every match.

        :param graph: (aos.sdk.graph.Graph) Graph to run query on
        :param query: (Ast, PathQueryBuilder or MultiPathQueryBuilder) query to run
        :yield: (dict) Mapping of path names to matched graph objects
        '''
        query_info = QueryInfo(query, trace=self._trace)
        for _, path in compiler.run_actions(query_info.actions, graph):
            yield path

    def watch(self, graph):
        '''
        Add graph to watched graphs: on any updated to graph it will check if
        any registered query matches have added/updated/removed.

        :param graph: (aos.sdk.graph.Graph) Graph to watch
        '''
        assert not getattr(graph, 'is_cpp_graph', False)

        info = self._find_watched_graph(graph)
        if info:
            return

        info = self.make_graph_info(graph, self._process_graph_updates)
        self._watched_graphs.append(info)
        graph.add_observer(info)
        self.execute_all(graph)
        self._process_graph_updates(info)

    def unwatch(self, graph):
        '''
        Removed graph from watched graphs.

        :param graph: (aos.sdk.graph.Graph) Graph to watch
        '''
        info = self._find_watched_graph(graph)
        if not info:
            return

        graph.remove_observer(info)
        self._watched_graphs = [
            info
            for info in self._watched_graphs
            if info.graph != graph
        ]

    def _process_graph_updates(self, info):
        '''Graph API listener implementation'''
        def run_seed_actions(seed_actions, seeds, callback):
            for actions in seed_actions:
                for old_path, new_path in compiler.run_actions(
                        actions,
                        old_graph=info.old_graph,
                        new_graph=info.graph,
                        seeds=seeds):

                    if old_path is None:
                        callback.added_paths.append(new_path)
                    elif new_path is None:
                        callback.removed_paths.append(old_path)
                    else:
                        callback.updated_paths.append(new_path)

        def get_seeds_to_actions_mapping(seeds_by_type, actions_by_type):
            result = []
            should_handle_none_type_actions = None in actions_by_type
            for seed_type, seeds in six.iteritems(seeds_by_type):
                if seed_type in actions_by_type:
                    if should_handle_none_type_actions:
                        actions_to_run = chain(
                            actions_by_type[seed_type], actions_by_type[None])
                    else:
                        actions_to_run = actions_by_type[seed_type]
                    result.append((seeds, actions_to_run))
                elif should_handle_none_type_actions:
                    result.append((seeds, actions_by_type[None]))

            return result

        exec_times = []
        graph_version = info.graph.version

        old_node_ids = set()
        old_rel_ids = set()

        while True:
            ts_begin = time.time()

            # Accumuluate a list of Callback objects to process at the same time
            callbacks = []

            node_changes = info.node_updates
            node_ids = set(node_changes) - old_node_ids

            rel_changes = info.relationship_updates
            rel_ids = set(rel_changes) - old_rel_ids
            if not node_ids and not rel_ids:
                break

            node_seeds = defaultdict(list)
            rel_seeds = defaultdict(list)
            for node_id in node_ids:
                old_node = info.old_graph.get_node(node_id)
                new_node = info.graph.get_node(node_id)
                seed = ([old_node] if old_node else None,
                        [new_node] if new_node else None)

                if old_node:
                    node_seeds[old_node.type].append(seed)
                    if new_node and old_node.type != new_node.type:
                        node_seeds[new_node.type].append(seed)
                elif new_node:
                    node_seeds[new_node.type].append(seed)

            for rel_id in rel_ids:
                old_rel = info.old_graph.get_relationship(rel_id)
                new_rel = info.graph.get_relationship(rel_id)
                seed = ([old_rel] if old_rel else None,
                        [new_rel] if new_rel else None)

                if old_rel:
                    rel_seeds[old_rel.type].append(seed)
                    if new_rel and old_rel.type != new_rel.type:
                        rel_seeds[new_rel.type].append(seed)
                elif new_rel:
                    rel_seeds[new_rel.type].append(seed)

            for query in six.itervalues(self._queries):
                node_seeds_to_actions = get_seeds_to_actions_mapping(
                    node_seeds, query.node_seed_actions)
                rel_seeds_to_actions = get_seeds_to_actions_mapping(
                    rel_seeds, query.rel_seed_actions)

                if node_seeds_to_actions or rel_seeds_to_actions:
                    callback = Callback(query)
                    for seeds, seed_actions in chain(node_seeds_to_actions,
                                                     rel_seeds_to_actions):
                        run_seed_actions(seed_actions, seeds, callback)
                    callbacks.append(callback)

            ts_callback = time.time()

            for callback in callbacks:
                callback.execute_removed()
            for callback in callbacks:
                callback.execute_added()
            for callback in callbacks:
                callback.execute_updated()

            old_node_ids = old_node_ids.union(node_ids)
            old_rel_ids = old_rel_ids.union(rel_ids)

            ts_end = time.time()

            exec_times.append((
                ts_callback - ts_begin,
                ts_end - ts_callback,
            ))

        stats = {
            'tags': {
                'graph_id':  info.graph.id,
                'graph_version': graph_version
            }
        }
        for idx, (query_time, callback_time) in enumerate(exec_times):
            stats['query_%d' % idx] = query_time
            stats['callback_%d' % idx] = callback_time
        self._commit_stats.add_entry(stats)

    def _find_watched_graph(self, graph):
        for info in self._watched_graphs:
            if info.graph == graph:
                return info
        return None

    def on_graph(self, graph):
        info = self._find_watched_graph(graph)
        if not info:
            info = self.make_graph_info(graph, self._process_graph_updates)
            self._watched_graphs.append(info)

        info.on_graph(graph)

    def reset(self, graph):
        """Discard all changes accumulated for a watched graph.

        This resets the state of an underlying SnapshotGraph used for keeping
        track of updated/removed nodes and relationships of a watched graph.
        This method should be invoked with caution, since it can potentially
        break the internal state of the caller, and must be accompanied with
        a reset of an agent's internal state.
        """
        info = self._find_watched_graph(graph)
        if info:
            info.reset()

    def on_node(self, graph, old_node, new_node):
        info = self._find_watched_graph(graph)
        if not info:
            info = self.make_graph_info(graph, self._process_graph_updates)
            self._watched_graphs.append(info)

        info.on_node(graph, old_node, new_node)

    def on_relationship(self, graph, old_rel, new_rel):
        info = self._find_watched_graph(graph)
        if not info:
            info = self.make_graph_info(graph, self._process_graph_updates)
            self._watched_graphs.append(info)

        info.on_relationship(graph, old_rel, new_rel)
