# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import print_function

from collections import defaultdict
from copy import copy
import uuid
import re
from functools import partial
from .ast import (
    Ast,
    AstTagFinder,
    AstTransform,
    AstTraversal,
    NamesCollector,
    get_path_names,
    merge_Node,
    merge_Relationship,
)
from . import actions as a
from . import dsl
from aos.sdk.graph.graph import is_node, is_relationship
from itertools import chain
from aos.sdk.graph.matchers import (
    _or,
    PropertyMatcher,
    is_in,
    is_matcher,
)
import six
from six.moves import range

# pylint: disable=invalid-name


def extract_types(matcher):
    if is_matcher(matcher):
        if matcher.type == '==':
            return [matcher.value]
        elif matcher.type == 'in':
            if None in matcher.value:
                return [None]
            else:
                return matcher.value
        return [None]
    elif matcher:
        return [matcher]
    return [None]


class FindFirstNamedObject(AstTraversal):
    '''Finds first object which name is present in given given list
    of names so query search can start from that point. Captures AST path
    to found named object.

    :param names: List of graph object names to search for
    '''
    def __init__(self, names):
        super(FindFirstNamedObject, self).__init__()
        self._names = names
        self._stack = []
        self.path = None

    def visit(self, ast):
        if self.path is not None:
            return

        self._stack.append(ast)
        super(FindFirstNamedObject, self).visit(ast)
        self._stack.pop()

    def visit_Node(self, ast):
        if ast.name and ast.name in self._names:
            self.path = list(self._stack)

    def _visit_Relationship(self, ast):
        if ast.name and ast.name in self._names:
            self.path = list(self._stack)


class NamedElementCollector(AstTraversal):
    def __init__(self):
        self.nodes = {}
        self.relationships = {}

    def visit_Node(self, ast):
        if not ast.name:
            return

        if ast.name not in self.nodes:
            self.nodes[ast.name] = ast
        else:
            self.nodes[ast.name] = merge_Node(self.nodes[ast.name], ast)

    def visit_Relationship(self, ast):
        if not ast.name:
            return

        if ast.name not in self.relationships:
            self.relationships[ast.name] = ast
        else:
            self.relationships[ast.name] = merge_Relationship(
                self.relationships[ast.name], ast
            )


class NamedElementUpdater(AstTransform):
    def __init__(self, nodes, relationships):
        self.nodes = nodes
        self.relationships = relationships

    def visit_Node(self, ast):
        if ast.name not in self.nodes:
            return ast

        return copy(self.nodes[ast.name])

    def visit_Relationship(self, ast):
        if ast.name not in self.relationships:
            return ast

        ast1 = copy(self.relationships[ast.name])
        ast1.direction = ast.direction
        return ast1


class NamesCounter(AstTraversal):
    def __init__(self):
        super(NamesCounter, self).__init__()
        self.names = defaultdict(int)

    def visit_Node(self, ast):
        if ast.name:
            self.names[ast.name] += 1

    def visit_Relationship(self, ast):
        if ast.name:
            self.names[ast.name] += 1

    def visit_OptionalPath(self, ast):
        pass

    def visit_PathConstraint(self, ast):
        pass


class SingleNodePathRemover(AstTransform):
    def __init__(self, name_counts):
        super(SingleNodePathRemover, self).__init__()
        self._counts = name_counts
        self._constraints = []

    def visit_Path(self, ast):
        if len(ast.elements) == 1 and \
                self._counts.get(ast.elements[0].name, 0) > 1:
            # If this is the single element path and element with that name
            # was seen in other paths, it is safe to remove it, but
            # keep track how many more references to that name is left
            self._counts[ast.elements[0].name] -= 1
            return None
        return ast

    def visit_MultiPath(self, ast):
        result = super(SingleNodePathRemover, self).visit_MultiPath(ast)
        if result is None:
            return result

        if not isinstance(result, Ast.MultiPath):
            return result

        if len(result.paths) == 1:
            result = result.paths[0]

        if self._constraints:
            counter = NamesCounter()
            counter.visit(result)

            matched_constraints = []
            unmatched_constraints = []
            for constraint in self._constraints:
                if all(name in counter.names for name in constraint.names):
                    matched_constraints.append(constraint)
                else:
                    unmatched_constraints.append(constraint)
                self._constraints = unmatched_constraints
                if matched_constraints:
                    # pylint: disable=redefined-variable-type
                    if isinstance(result, Ast.ConstrainedPath):
                        result = Ast.ConstrainedPath(
                            query=result.query,
                            constraints=result.constraints + matched_constraints,
                        )
                    else:
                        result = Ast.ConstrainedPath(
                            query=result,
                            constraints=matched_constraints,
                        )

        return result

    def visit_ConstrainedPath(self, ast):
        result = super(SingleNodePathRemover, self).visit_ConstrainedPath(ast)
        if result is None:
            self._constraints.extend(ast.constraints)
        elif isinstance(result, Ast.ConstrainedPath) \
                and isinstance(result.query, Ast.ConstrainedPath):
            return Ast.ConstrainedPath(
                query=result.query.query,
                constraints=ast.constraints+result.query.constraints,
            )
        return result

    def visit_PathConstraint(self, ast):
        # Path constraints are searches inside search, so their
        # names should not affect outer path names. They are
        # optimized separately
        new_query = remove_single_element_paths(ast.query)
        if new_query is None:
            return None
        return Ast.PathConstraint(new_query, names=ast.names,
                                  at_least=ast.at_least,
                                  at_most=ast.at_most,
                                  inverse=ast.inverse)


def sync_same_name_elements(query):
    '''
    Given a query AST, finds all same-name elements and syncs their configuraitons.

    E.g. given a query

        match(
            node('a', name='my_a', foo='hello').out().node('b'),
            node('a', name='my_a', bar=123).out().node('c'),
        )

    which has node with name 'my_a' mentioned more than once, having different
    match criterias, this method will synchronize their match criterias.
    The result will be equivalent to this:

        match(
            node('a', name='my_a', foo='hello', bar=123).out().node('b'),
            node('a', name='my_a', foo='hello', bar=123).out().node('c'),
        )

    If it ends up with multiple constraints for the same property, the algorithm
    will merge those constraints resulting in (hopefully simple) combined property
    matcher. See `aos.sdk.graph.merge_matchers()` for more details.

    :param query: (Ast) Query AST to optimize
    :return: (Ast) Optimized query AST
    '''

    collector = NamedElementCollector()
    collector.visit(query)

    node_names = set(collector.nodes.keys())
    relationship_names = set(collector.relationships.keys())

    common_names = node_names.intersection(relationship_names)
    if common_names:
        raise ValueError('Node and relationship with same name: %s' %
                         list(common_names)[0])

    updater = NamedElementUpdater(nodes=collector.nodes,
                                  relationships=collector.relationships)
    return updater.visit(query)


def remove_single_element_paths(query):
    '''
    Given a query AST, finds all single named node paths and removes them unless
    it is the only mention of that name in entire query.

    The rationale for this optimization is: to encourage path reuse the common
    practice is to separate paths that describe relationships between nodes from
    describing properties of objects in those paths. E.g.

        match(
            node('a').out().node('b', name='my_b').out().node('c', name='my_c'),
            node(name='my_b', foo='hello', bar=123),
            node(name='my_c', baz=True),
        )

    Notice that first path defines a query of three connected nodes, but it does
    not mention properties of those nodes. Properties of particular nodes are
    defined separately. When executing query, there is no point of searching those
    single element paths because those objects were either already found or do
    not define enough context (and constraints) and will result in too broad
    results.

    Given properties of nodes are synched together with `sync_same_name_elements()`
    single element paths can be removed, resulting in equivalent query:

        match(
            node('a')
            .out()
            .node('b', name='my_b', foo='hello', bar=123),
            .out()
            .node('c', name='my_c', baz=True),
        )

    Although, if named element can only be seen in a single element path, it should
    not be optimized away:

        match(
            node('a', name='a', foo='hello'),
            node('a', name='a', bar=123),
        )

    results in

        match(node('a', name='a', foo='hello', bar=123))

    And the following query is not modified in any way

        match(
            node('a', name='a', foo='hello'),
            node('b').out().node('c')
        )

    :param query: (Ast) Query AST to optimize
    :return: (Ast) Optimized query AST
    '''
    counter = NamesCounter()
    counter.visit(query)

    remover = SingleNodePathRemover(dict(counter.names))
    return remover.visit(query)


def is_not_regex_pattern(pattern):
    special_characters = '.^$*+?{}[]\\|()'
    return all(c not in pattern for c in special_characters)


class TagFilterExpander(AstTransform):
    def __init__(self, reserved_names):
        self.reserved_names = reserved_names
        self.generated_names = set()

    def generate_name(self):
        while True:
            name = str(uuid.uuid4())
            if name not in self.reserved_names and \
                    name not in self.generated_names:
                self.generated_names.add(name)
                return name

    @staticmethod
    def make_regex_matcher(pattern):
        return PropertyMatcher(
            'custom', partial(re.match, re.compile(pattern)))

    def transform_path_element(self, element):
        matcher_type = element.properties['tag'].type
        if not element.name:
            name = self.generate_name()
        else:
            name = element.name

        new_element = copy(element)
        new_element.name = name
        tag_matcher = new_element.properties.pop('tag')

        paths = []
        path_constraints = []

        if matcher_type == 'has_all':
            for pattern in tag_matcher.value:
                # If pattern does not contains any regex special characters,
                # utilize "==" matcher, to make use of "lowercased" index
                if is_not_regex_pattern(pattern):
                    matcher = pattern
                else:
                    matcher = self.make_regex_matcher(pattern)

                paths.append(dsl.node('tag', lowercased=matcher)
                             .out('tag')
                             .node(name=name).ast)
        else:
            raw_string_patterns = []
            regex_matchers = []

            for pattern in tag_matcher.value:
                if is_not_regex_pattern(pattern):
                    raw_string_patterns.append(pattern)
                else:
                    regex_matchers.append(self.make_regex_matcher(pattern))

            if raw_string_patterns:
                if regex_matchers:
                    matcher = _or(is_in(raw_string_patterns), *regex_matchers)
                else:
                    matcher = is_in(raw_string_patterns)
            else:
                matcher = _or(*regex_matchers)

            q = (dsl.node('tag', lowercased=matcher)
                 .out('tag')
                 .node(name=name)).ast

            if matcher_type == 'has_any':
                constraint = Ast.PathConstraint(
                    q, [name], at_least=1)
            else:
                constraint = Ast.PathConstraint(
                    q, [name], at_most=0, at_least=None)
            path_constraints.append(constraint)

        return new_element, paths, path_constraints

    def expand_tag_filters(self, path):
        paths = []
        path_constraints = []
        new_elements = []
        for element in path.elements:
            if 'tag' in element.properties:
                (new_element,
                 new_paths,
                 new_constraints) = self.transform_path_element(element)

                new_elements.append(new_element)
                paths.extend(new_paths)
                path_constraints.extend(new_constraints)
            else:
                new_elements.append(copy(element))

        return [Ast.Path(new_elements)] + paths, path_constraints

    def construct_constrained_path(self, paths, constraints):
        query = Ast.MultiPath(paths)
        if constraints:
            return Ast.ConstrainedPath(query, constraints=constraints)
        else:
            return query

    def visit_Path(self, ast):
        return self.construct_constrained_path(
            *self.expand_tag_filters(ast))


class FindSeedPaths(AstTraversal):
    def __init__(self, seeds):
        super(FindSeedPaths, self).__init__()
        self._seeds = seeds
        self._stack = []
        self._seen_names = set()
        self.paths = []
        if is_node(seeds[0]):
            self.visit_Node = self._visit_Node
        elif is_relationship(seeds[0]):
            self.visit_Relationship = self._visit_Relationship
        else:
            raise ValueError('Unknown seed object: %s' % seeds[0])

    def _node_matches(self, node, ast):
        if not is_node(node):
            return False
        if ast.id is not None and node.id != ast.id:
            return False
        if ast.type is not None and node.type != ast.type:
            return False
        for k, v in six.iteritems(ast.properties):
            if not hasattr(node, k) or not v(getattr(node, k)):
                return False
        return True

    def _relationship_matches(self, rel, ast):
        if not is_relationship(rel):
            return False
        if ast.id is not None and rel.id != ast.id:
            return False
        if ast.type is not None and rel.type != ast.type:
            return False
        for k, v in six.iteritems(ast.properties):
            if not hasattr(rel, k) or not v(getattr(rel, k)):
                return False
        return True

    def visit(self, ast):
        self._stack.append(ast)
        super(FindSeedPaths, self).visit(ast)
        self._stack.pop()

    def _visit_Node(self, ast):
        if ast.name and ast.name in self._seen_names:
            return
        if ast.name:
            self._seen_names.add(ast.name)
        if any(self._node_matches(seed, ast) for seed in self._seeds):
            self.paths.append(list(self._stack))

    def _visit_Relationship(self, ast):
        if ast.name and ast.name in self._seen_names:
            return
        if ast.name:
            self._seen_names.add(ast.name)
        if any(self._relationship_matches(seed, ast) for seed in self._seeds):
            self.paths.append(list(self._stack))


# FIXME(Rajeev): Move to ast.py
class FindAllSeedPaths(AstTraversal):
    def __init__(self):
        super(FindAllSeedPaths, self).__init__()
        self._stack = []
        self._seen_names = set()
        self.paths = []

    def visit(self, ast):
        self._stack.append(ast)
        super(FindAllSeedPaths, self).visit(ast)
        self._stack.pop()

    def visit_Node(self, ast):
        if ast.name and ast.name in self._seen_names:
            return
        if ast.name:
            self._seen_names.add(ast.name)
        self.paths.append(list(self._stack))

    def visit_Relationship(self, ast):
        if ast.name and ast.name in self._seen_names:
            return
        if ast.name:
            self._seen_names.add(ast.name)
        self.paths.append(list(self._stack))


class ActionCompiler(AstTraversal):
    '''
    THE Compiler - transforms query AST into list of actions to perform
    '''
    def __init__(self, path=None, path_index=None, name_indexes=None, base_index=0):
        super(ActionCompiler, self).__init__()
        self.actions = []
        self.name_indexes = name_indexes if name_indexes is not None else {}
        self._next_index = base_index
        self._constraints = []

        self._path = list(path or [])
        self._seed_name = getattr(path[-1], 'name', None) if path else None
        self._path_index = path_index
        if self._path and self._path_index is None:
            raise ValueError('No index for a path')

    def visit(self, ast):
        if self._path:
            if self._path[0] == ast:
                self._path.pop(0)

        super(ActionCompiler, self).visit(ast)

    def visit_Path(self, ast):
        start_reverse = False

        start_element_index = self._next_index

        if self._path and self._path[0] in ast.elements:
            element = self._path.pop(0)
            for start_index, elem in enumerate(ast.elements):
                if elem is element:
                    break

            start_element_index = self._path_index

            if isinstance(element, Ast.Node):
                self.actions.append(
                    a.CheckNodeMatchesAction(
                        index=start_element_index,
                        id=element.id, type=element.type,
                        properties=element.properties,
                    )
                )
            elif isinstance(element, Ast.Relationship):
                self.actions.append(
                    a.CheckRelationshipMatchesAction(
                        index=start_element_index,
                        id=element.id, type=element.type,
                        properties=element.properties,
                    )
                )
                start_reverse = element.direction == 'in'
            else:
                raise ValueError('Unknown element: %s' % element)
        else:
            start_index = 0
            start_score = self._matcher_start_score(ast.elements[start_index])
            for idx, element in enumerate(ast.elements):
                score = self._matcher_start_score(element)
                if score > start_score:
                    start_score, start_index = score, idx

            element = ast.elements[start_index]
            if element.name and element.name in self.name_indexes:
                start_element_index = self.name_indexes[element.name]
            else:
                if isinstance(element, Ast.Node):
                    self.actions.append(
                        a.FindNodeAction(
                            id=element.id, type=element.type,
                            properties=element.properties,
                        )
                    )
                elif isinstance(element, Ast.Relationship):
                    self.actions.append(
                        a.FindRelationshipAction(
                            id=element.id, type=element.type,
                            properties=element.properties,
                        )
                    )
                    start_reverse = element.direction == 'in'
                else:
                    raise ValueError('Unknown element: %s' % element)

                self._next_index += 1

        if element.name and element.name not in self.name_indexes:
            self.name_indexes[element.name] = start_element_index

        self._apply_constraints()

        if start_index > 0:
            last_element_index = start_element_index
            reverse = start_reverse
            for idx in range(start_index-1, -1, -1):
                cur_element_index = last_element_index
                last_element_index = self._next_index
                reverse = self._build_element_iterator(
                    cur_element_index, ast.elements[idx],
                    reverse=reverse ^ True,
                )

        last_element_index = start_element_index
        reverse = start_reverse
        for idx in range(start_index+1, len(ast.elements)):
            cur_element_index = last_element_index
            last_element_index = self._next_index
            reverse = self._build_element_iterator(
                cur_element_index, ast.elements[idx], reverse=reverse,
            )

    def visit_MultiPath(self, ast):
        def matching_name_count(path):
            return len(set(self.name_indexes.keys())
                       .intersection(get_path_names(path)))

        paths = ast.paths[:]

        if self._path:
            for idx, elem in enumerate(paths):
                if elem is self._path[0]:
                    self.visit(paths.pop(idx))
                    break

        while paths:
            best_index = 0
            best_name_count = matching_name_count(paths[0])
            for idx, path in enumerate(paths):
                name_count = matching_name_count(path)
                if name_count > best_name_count:
                    best_index = idx
                    best_name_count = name_count

            self.visit(paths.pop(best_index))

    def visit_FunctionConstraint(self, ast):
        self._constraints.append(ast)

    def visit_EnsureDifferentConstraint(self, ast):
        self._constraints.append(ast)

    def visit_PathConstraint(self, ast):
        if self._path:
            if ast.query != self._path[0]:
                self._constraints.append(ast)
                return
            self._path.pop(0)

            self.visit(ast.query)
            self.actions.append(
                a.ReseedAction([self.name_indexes[name] for name in ast.names])
            )
            self.actions.append(
                a.DistinctAction(list(range(len(ast.names))))
            )
            self._next_index = len(ast.names)
            self.name_indexes = {name: idx for idx, name in enumerate(ast.names)}
            self._apply_PathConstraint(ast)
        else:
            self._constraints.append(ast)

    def visit_ConstrainedPath(self, ast):
        if self._path:
            start_idx = -1
            for idx, constraint in enumerate(ast.constraints):
                if constraint == self._path[0]:
                    self.visit(constraint)
                    start_idx = idx
                    break

            for idx, constraint in enumerate(ast.constraints):
                if idx == start_idx:
                    continue
                self.visit(constraint)

            self.visit(ast.query)
        else:
            for constraint in ast.constraints:
                self.visit(constraint)

            self.visit(ast.query)

    def visit_OptionalPath(self, ast):
        class ObjectsCounter(AstTraversal):
            def __init__(self):
                super(ObjectsCounter, self).__init__()
                self.count = 0

            def visit_Node(self, ast):
                self.count += 1

            def visit_Relationship(self, ast):
                self.count += 1

            def visit_PathConstraint(self, ast):
                pass

        def get_objects_count(path):
            c = ObjectsCounter()
            c.visit(path)
            return c.count

        if self._path:
            if ast.query != self._path[0]:
                return
            self._path.pop(0)

            self.visit(ast.query)

        start_location_finder = FindFirstNamedObject(
            list(six.iterkeys(self.name_indexes)))
        start_location_finder.visit(ast.query)

        start_path = start_location_finder.path
        start_path_index = None
        if start_path:
            start_path_index = self.name_indexes[start_path[-1].name]

        compiler = self.__class__(
            path=start_path,
            path_index=start_path_index,
            name_indexes=self.name_indexes,
            base_index=self._next_index,
        )
        compiler.visit(ast.query)

        count = get_objects_count(ast.query)
        # -1 here because first object is reused from outer path and is only
        # checked for matching instead of producing a step
        if start_path:
            count -= 1
        self.actions.append(a.OptionalPathAction(compiler.actions, count))
        self._apply_constraints()

        self._next_index += count

    def visit_Select(self, ast):
        super(ActionCompiler, self).visit_Select(ast)
        self.name_indexes = {name: idx
                             for name, idx in six.iteritems(self.name_indexes)
                             if name in ast.names}

    def visit_Distinct(self, ast):
        super(ActionCompiler, self).visit_Distinct(ast)
        indexes = {self.name_indexes[name] for name in ast.names} \
            if ast.names else list(six.itervalues(self.name_indexes))
        self.actions.append(a.DistinctAction(indexes))

    def _apply_constraints(self):
        i = 0
        while i < len(self._constraints):
            constraint = self._constraints[i]
            if all(name in self.name_indexes for name in constraint.names):
                constraint = self._constraints.pop(i)

                method = getattr(self, '_apply_%s' % constraint.__class__.__name__)
                if method is None:
                    raise ValueError('Unknown constraint type: %s' % constraint)
                method(constraint)
            else:
                i += 1

    def _apply_FunctionConstraint(self, constraint):
        self.actions.append(
            a.FunctionConstrainerAction(
                constraint.predicate,
                [self.name_indexes[name] for name in constraint.names],
            )
        )

    def _apply_EnsureDifferentConstraint(self, constraint):
        assert len(constraint.names) == 2
        # TODO(Rajeev): This is a stop gap solution for the old query stack.
        self.actions.append(
            a.FunctionConstrainerAction(
                lambda a, b: a != b,
                [self.name_indexes[name] for name in constraint.names],
            )
        )

    def _apply_PathConstraint(self, constraint):
        names = list(constraint.names)
        start_location_finder = FindFirstNamedObject(names)
        start_location_finder.visit(constraint.query)

        start_path = start_location_finder.path
        start_path_index = None
        if start_path:
            start_path_index = names.index(start_path[-1].name)

        compiler = self.__class__(
            path=start_path,
            path_index=start_path_index,
            name_indexes={k: i for i, k in enumerate(names)},
            base_index=len(names),
        )
        compiler.visit(constraint.query)

        inner_actions = compiler.actions
        self.actions.append(
            a.PathConstrainerAction(
                inner_actions,
                [self.name_indexes[k] for k in names],
                at_least=constraint.at_least,
                at_most=constraint.at_most,
                inverse=constraint.inverse,
            )
        )

    def _build_element_iterator(self, index, element, reverse=False):
        reverse1 = False
        if isinstance(element, Ast.Node):
            action = a.RelationshipSourceAction \
                if reverse else a.RelationshipTargetAction
            self.actions.append(
                action(index=index, id=element.id, type=element.type,
                       properties=element.properties)
            )
        elif isinstance(element, Ast.Relationship):
            out = ((element.direction == 'out' and not reverse) or
                   (element.direction == 'in' and reverse))
            action = a.NodeOutRelationshipAction \
                if out else a.NodeInRelationshipAction
            self.actions.append(
                action(index=index, id=element.id, type=element.type,
                       properties=element.properties)
            )
            reverse1 = (not out) ^ reverse
        else:
            raise ValueError('Unknown element: %s' % element)

        if element.name:
            if element.name in self.name_indexes:
                self.actions.append(
                    a.CheckEqualAction(self.name_indexes[element.name],
                                       self._next_index)
                )
            else:
                self.name_indexes[element.name] = self._next_index

            self._apply_constraints()

        self._next_index += 1

        return reverse1

    def _matcher_start_score(self, element):
        if not isinstance(element, (Ast.Node, Ast.Relationship)):
            return -1

        if element.id is not None:
            return 100
        if element.name is not None and element.name in self.name_indexes:
            return 100

        if isinstance(element, Ast.Relationship):
            return -1

        score = 0
        if element.type is not None:
            score += 10
        if element.properties:
            score += 5
        return score

    def make_result_action(self):
        return a.ResultAction(
            name_indexes=self.name_indexes,
            # This condition checks if first action is unnamed or if its
            # name was filtered by select action. If so, updated paths
            # should be filtered out.
            should_filter_updates=self._seed_name not in self.name_indexes)


def trace(actions, prefix=''):
    '''
    Transforms compiled query to trace results after each step.

    :param actions: (list of Action) Compiled query actions
    :return: (list of Action) Modified query actions
    '''
    new_actions = []
    for idx, action in enumerate(actions):
        if isinstance(action, (a.PathConstrainerAction, a.OptionalPathAction)):
            action.actions = trace(
                action.actions,
                prefix='%s%d: %s -> ' % (prefix, idx, action.__class__.__name__)
            )

        new_actions.append(action)
        new_actions.append(
            a.TraceAction('%s%d: %s' % (prefix, idx, action.__class__.__name__))
        )

    return new_actions


trace_actions = trace


def optimize_query(query, expand_tag_filters=False):
    '''
    Normalizes and optimizes graph Query (AST).

    :param query: (Ast) Query to optimize
    :return: (Ast) Optimized query
    '''
    if expand_tag_filters:
        name_collector = NamesCollector(skip_path_constraints=False)
        name_collector.visit(query)
        original_query_names = (
            name_collector.node_names | name_collector.relationship_names)

        tag_expander = TagFilterExpander(reserved_names=original_query_names)
        query = tag_expander.visit(query)

        if tag_expander.generated_names:
            query = Ast.Select(query, original_query_names)

    query = sync_same_name_elements(query)
    query = remove_single_element_paths(query)
    return query


def compile_query(query, trace=False):
    '''
    Compiles graph query (Ast) into list of Actions.

    :param query: (Ast) Query to compile
    :return: (list of Action) Low level sequential actions
    '''
    # pylint: disable=redefined-outer-name
    compiler = ActionCompiler()
    compiler.visit(query)

    actions = compiler.actions + [compiler.make_result_action()]

    if trace:
        print(actions)
        actions = trace_actions(actions)

    return actions


class FilterOutUpdatesAction(a.Action):
    '''
    Action that filters out paths that are present in both old and new graph.
    Used in seeded queries to filter out unimportant node update search results.
    '''
    def iterator(self, old_graph, new_graph, paths):
        for old_path, new_path in paths:
            if old_path and new_path:
                continue
            yield old_path, new_path


# pylint: disable=redefined-variable-type
def make_seed_query(query):
    ''' Query elements could potentially have tag based filters. In such a case,
        the query should be expanded such that the tag based elements are
        directly called out in the graph query.
    '''
    tag_finder = AstTagFinder()
    tag_finder.visit(query)

    if not tag_finder.tagged_elements:
        return query

    tagged_query_ast = dsl.match(
        *[
            (
                # TODO(Rajeev): Update the filter to be more tighter.
                # We need a query DSL parser such that every "has_all" is transformed
                # to is_in for filter in "element.properties['tag']".
                dsl.node('tag')
                .out('tag')
                .node(name=element.name,
                      type=element.type,
                      id=element.id,
                      **element.properties)
            )
            for element in tag_finder.tagged_elements
        ]
    ).ast
    if len(tag_finder.tagged_elements) == 1:
        tagged_query_ast = Ast.MultiPath([tagged_query_ast])

    result_query = None
    if isinstance(query, Ast.ConstrainedPath):
        if isinstance(query.query, Ast.Path):
            # Constrained path on path.
            tagged_query_ast.paths.append(query.query)
            query.query = tagged_query_ast
        else:
            # Constrained path on multi path.
            query.query.paths.extend(tagged_query_ast.paths)
        result_query = query
    elif isinstance(query, Ast.MultiPath):
        query.paths.extend(tagged_query_ast.paths)
        result_query = query
    elif isinstance(query, Ast.Path):
        tagged_query_ast.paths.append(query)
        result_query = tagged_query_ast
    else:
        assert False, 'Unhandled query type {}'.format(query.__class__)

    return optimize_query(result_query)


def compile_seed_query(query, trace=False):
    '''
    Generates series of actions to match query from any of given seed objects.

    :param query: (Ast) Query to run
    :param old_graph: (Graph) Graph before change
    :param new_graph: (Graph) Graph after change
    :param seeds: (list of Node, Relationship or None) Seed objects
    :yield: (list of Action objects) Actions to match query starting from position
        matching given seed.
    '''
    # pylint: disable=redefined-outer-name
    def compile_actions(query, path):
        compiler = ActionCompiler(path=list(path), path_index=0, base_index=1)
        compiler.visit(query)

        return compiler.actions + [compiler.make_result_action()]

    seed_locations_finder = FindAllSeedPaths()
    seed_locations_finder.visit(query)

    for seed_path in seed_locations_finder.paths:
        actions = compile_actions(query, seed_path)

        if trace:
            print(actions)
            actions = trace_actions(actions)

        yield actions


def run_actions(actions, new_graph, old_graph=None, seeds=None):
    seeds = seeds or [([] if old_graph else None,
                       [] if new_graph else None)]

    actions = iter(actions)

    # This optimization reduces number of involved generator chains produced
    # by each action: if the first action doesn't match anything, then
    # there is no need to execute other actions and we can return earlier.
    for action in actions:
        seeds = action.iterator(old_graph, new_graph, seeds)

        first_matched_path = next(seeds, None)
        if first_matched_path is None:
            return []

        seeds = chain((first_matched_path,), seeds)
        break

    for action in actions:
        seeds = action.iterator(old_graph, new_graph, seeds)

    return seeds
