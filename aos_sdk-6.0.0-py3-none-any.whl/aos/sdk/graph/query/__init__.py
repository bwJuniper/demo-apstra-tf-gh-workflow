# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

'''
Query engine implements subgraph search in a graph with ability to subscribe to
graph updates: you can register queries and get notifications when subgraphs
matched by those queries are added/removed/updated.

Path patterns
=============

First you need to specify a query using provided internal DSL. Query always starts
with some node:

    node('system')

which means "match node of type 'system'". Then you can use methods `out()` and
`in_()` to specify a relationships to traverse from that node:

    node('system').out('has_interface')

or

    node('system').in_('hosted_on')

Then you can continue alternating nodes and relationship methods to specify a
path pattern in a graph that you want to match:

    node('system').out('has_interface').node('interface').out('part_of').node('link')

Matching properties
-------------------

`node()`, `out()` and `in_()` methods can have additional arguments that declare
constraints on node/relationship properties:

    # match a node with property "role" having value "spine"
    node('system', role='spine')

Those property constraints can be specified with either values verbatim or using
special "property matcher" objects. Property matchers allow to express constraints
other than "equal":

    from aos.sdk.graph import is_in

    # match "system" node that has "role" property equal to either "spine" or "leaf"
    node('system', role=is_in(['spine', 'leaf'])

Naming objects
--------------

There is one special argument to `node()`/`out()`/`in_()` methods - "name" - which
defines a name for that matched object so that you can reference it later. Also,
when you get final matching graph, only named objects are returned:

    # Search result will be a dictionary with "device1" and "device2" keys with
    # values being matched nodes. "link" node won't be returned since it is
    # unnamed in query
    node('system', name='device1')\
        .out().node('link')\
        .out().node('system', name='device2')

Multi-object constraints
------------------------

Sometimes you need to add constraints on multiple matched objects. For that you
should use `where()` method:

    node('a', name='x').out().node('b').out().node('a', name='y')\
        .where(lambda x, y: x != y)

`where()` method accepts a function which argument names should be names assigned
to found objects you want to constraint (notice "x" and "y" names on nodes).
Matched objects with those names will be passed to function. If function returns
False (or any "false" value), that subgraph will be rejected.
If you want to use different names in function, you need to pass object names as
second argument:

    node('a', name='foo').out().node('b').out().node('a', name='bar')\
        .where(lambda x, y: x.attr1 == y.attr2, ['foo', 'bar'])

Making sure that nodes in subgraph are different is a common requirement, so for
that there is a `ensure_different()` method that takes a list of match names and
creates a series of constraints that will ensure that all objects with given names
are different:

    node(name='a').out().node(name='b').out().node(name='c')\
        .ensure_different('a', 'b', 'c')

Multi-path queries
------------------

A single path query can match a chain of nodes. If you need to match a subgraph
that is not a chain, you need to use multiple path queries binding them together
with use of named objects and tieing path queries with `match()` method:

    # This should match subgraphs like this:
    #
    #            c
    #          /
    #   a -> b
    #          \
    #            d
    #
    match(
        node('a').out().node('b', name='x').out().node('c'),
        node(name='b').out().node('d'),
    )

You can have arbitrarily nested `match()` statements. Also, you can keep adding
constraints on resulting query:

    match(
        # ...
    ).where(lambda a, b: a.attr1 == b.attr2).ensure_different('a', 'b', 'c')


Searching queries
=================

There are two ways to use QueryEngine to search graph:
1. Subscribe to queries and get callbacks
2. Just iterate graph to find all matching subgraphs

Subscribing to updates
----------------------

To subscribe to query updates, register queries in QueryEngine and then tell
QueryEngine to start watching some graph:

    query = match(node('a', name='a').out().node('b').out().node('c', name='c'))
    def callback(path, action):
        # do something

    engine = QueryEngine()
    engine.register_query(query, callback)

    engine.watch(graph)
    # will trigger callbacks if subgraphs found

Path will be a dictionary mapping query names to found graph objects. Action is
either "added", "updated" or "removed".

Searching graph
---------------

To just search graph, use `QueryEngine.iterate()` method:

    query = match(node('a', name='a').out().node('b').out().node('c', name='c'))

    engine = QueryEngine()
    for path in engine.iterate(graph, query):
        # do something

There is a shortcut for instantiating `QueryEngine` and running iterate:

    from aos.sdk.graph.query import iterate

    for path in iterate(graph, query):
        # do something
'''

from .engine import QueryEngine, iterate
from .dsl import match, node, optional
from aos.sdk.graph.matchers import eq, aeq, ne, gt, ge, lt, le, is_in, not_in, \
    is_none, not_none, has_items, has_keys, _and, _or, _not, has_all, has_any, \
    has_none


__all__ = [
    'QueryEngine',
    # convenience function
    'iterate',

    # Query DSL
    'match',
    'node',
    'optional',

    # property matchers
    'eq',
    'aeq',
    'ne',
    'gt',
    'ge',
    'lt',
    'le',
    'is_in',
    'not_in',
    'is_none',
    'not_none',
    '_and',
    '_or',
    '_not',
    'has_items',
    'has_keys',
    'has_all',
    'has_any',
    'has_none',
]
