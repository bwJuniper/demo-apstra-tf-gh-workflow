# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import inspect
from aos.sdk.graph.matchers import is_matcher, eq
from .ast import Ast, get_path_names
import six
from six.moves import range

# pylint: disable=invalid-name,redefined-builtin,redefined-variable-type


def match(*path_queries):
    '''Shortcut for grouping several paths queries together'''
    return MultiPathQueryBuilder(path_queries)


def node(*args, **kwargs):
    '''Shortcut for starting a path query definition'''
    return PathQueryBuilder(*args, **kwargs)


def optional(query):
    '''Shortcut for making an optional path'''
    return Ast.OptionalPath(query.ast)


class PathQueryBuilder(object):
    '''
    DSL implementation for path query builder

    On creation defines a query of a single node with criterias specified in
    constructor. Sets current node to that node.

    :param name: (optional string) Name in a query to assign to node
    :param type: (optional string) Type of node
    :param id: (optional string) Id of node
    :param properties: (optional dict) Mapping of node property names
        to either values or PropertyMatcher's
    '''

    def __init__(self, type=None, name=None, id=None, **properties):
        self._elements = [
            Ast.Node(type=type, name=name, id=id, properties=properties),
        ]
        self._constraints = []
        self._names = set()
        # Specific to Cpp graph. This attribute is not used anywhere. This is added
        # to be consistent with multipath query builder interface.
        self._template = None
        self._seed_templates = None
        if name is not None:
            self._names.add(name)

    @property
    def ast(self):
        '''Get query AST'''
        ast = Ast.Path(self._elements)
        if self._constraints:
            ast = Ast.ConstrainedPath(ast, self._constraints)

        return ast

    def node(self, type=None, name=None, id=None, **properties):
        '''
        Update criterias for current node

        :param name: (optional string) Name in a query to assign to node
        :param type: (optional string) Type of node
        :param id: (optional string) Id of node
        :param properties: (optional dict) Mapping of node property names
            to either values or PropertyMatcher's
        '''
        if not self._elements:
            raise ValueError('Can\'t match target of empty query')

        if not isinstance(self._elements[-1], Ast.Node):
            raise ValueError('Misplaced target node matcher')

        element = self._elements[-1]
        if name is not None:
            element.name = name
            self._names.add(name)
        if id is not None:
            element.id = id
        if type is not None:
            element.type = type
        for k, v in six.iteritems(properties):
            element.properties[k] = v if is_matcher(v) else eq(v)

        return self

    def out(self, type=None, id=None, name=None, **properties):
        '''
        Navigate through out relationships with given criterias from current node.
        Sets current node to relationship target node.

        :param name: (optional string) Name in a query to assign to relationship
        :param type: (optional string) Type of relationship
        :param id: (optional string) Id of relationship
        :param properties: (optional dict) Mapping of relationship property names
            to either values or PropertyMatcher's
        '''
        self._elements.append(
            Ast.Relationship(direction='out', name=name, type=type, id=id,
                             properties=properties)
        )
        self._elements.append(
            Ast.Node()
        )
        if name is not None:
            self._names.add(name)
        return self

    def in_(self, type=None, id=None, name=None, **properties):
        '''
        Navigate through in relationships with given criterias to current node.
        Sets current node to relationship source node.

        :param name: (optional string) Name in a query to assign to relationship
        :param type: (optional string) Type of relationship
        :param id: (optional string) Id of relationship
        :param properties: (optional dict) Mapping of relationship property names
            to either values or PropertyMatcher's
        '''
        self._elements.append(
            Ast.Relationship(direction='in', name=name, type=type, id=id,
                             properties=properties)
        )
        self._elements.append(
            Ast.Node()
        )
        if name is not None:
            self._names.add(name)
        return self

    def where(self, predicate, names=None):
        '''
        Filter path by evaluating given predicate function for path objects
        with given names. If names are not given, it infers names from names
        of function arguments.

        :param predicate: (callable) Function to filter paths with
        :param names: (list of string or None) Names of path objects
            to pass to predicate. If None, it defaults to predicate function
            argument names
        '''
        names = names or inspect.getargspec(predicate).args
        if not all((name in self._names for name in names)):
            raise ValueError('Not all names in where clause are valid')
        self._constraints.append(Ast.FunctionConstraint(predicate, names))
        return self

    def having(self, query, names=None, at_least=None, at_most=None, inverse=False):
        '''
        Filter path by executing subquery with given objects with given names
        being same as in current path. If number of results does not fit into given
        limits, reject the path.

        :param query: (query) Subquery to evaluate
        :param names: (list of string or None) List of objects that should be
            same between path an subquery paths. If None, it assumes all named
            objects in subquery should be the same as objects with same names in
            current path
        :param at_least: (int or None) Minimum required number of subquery matches.
            If None - unbounded
        :param at_most: (int or None) Maximum required number of subquery matches.
            If None - unbounded
        :param inverse: (bool) If True, inverse range (select results that are
            outside given range instead of those that are in range).
            Default is False
        '''
        if not isinstance(query, Ast.Base):
            query = query.ast

        if at_least is None and at_most is None:
            at_least = 1

        if names is None:
            names = get_path_names(query)

        if not all((name in self._names for name in names)):
            raise ValueError('Not all names in where clause are valid')

        self._constraints.append(
            Ast.PathConstraint(query, names,
                               at_least=at_least, at_most=at_most,
                               inverse=inverse)
        )
        return self

    def ensure_different(self, *names):
        '''
        Add filters that ensures that objects with given names are unique among
        each other.

        :param names: (list of string) Names of path objects to check for
            uniqueness. Names should already be present in query.
        '''
        if not all((name in self._names for name in names)):
            raise ValueError('Not all names in ensure_different clause are valid')

        for i in range(len(names)-1):
            for j in range(i+1, len(names)):
                self._constraints.append(
                    Ast.EnsureDifferentConstraint([names[i], names[j]])
                )
        return self


class MultiPathQueryBuilder(object):
    '''DSL implementation for multi path query'''
    def __init__(self, queries, names=None):
        asts = [
            query if isinstance(query, Ast.Base) else query.ast
            for query in queries
        ]
        if len(asts) == 1:
            self._ast = asts[0]
        else:
            self._ast = Ast.MultiPath(asts)
        self._constraints = []
        self._names = names or get_path_names(self.ast)
        self._template = None
        self._seed_templates = None

    @property
    def ast(self):
        if self._constraints:
            return Ast.ConstrainedPath(self._ast, self._constraints)
        return self._ast

    def where(self, predicate, names=None):
        '''
        Filter path by evaluating given predicate function for path objects
        with given names. If names are not given, it infers names from names
        of function arguments.

        :param predicate: (callable) Function to filter paths with
        :param names: (list of string or None) Names of path objects
            to pass to predicate. If None, it defaults to predicate function
            argument names
        '''
        names = names or inspect.getargspec(predicate).args
        if not all((name in self._names for name in names)):
            raise ValueError('Not all names in where clause are valid')
        self._constraints.append(Ast.FunctionConstraint(predicate, names))
        return self

    def having(self, query, names=None, at_least=None, at_most=None, inverse=False):
        '''
        Filter path by executing subquery with given objects with given names
        being same as in current path. If number of results does not fit into given
        limits, reject the path.

        :param query: (query) Subquery to evaluate
        :param names: (list of string or None) List of objects that should be
            same between path an subquery paths. If None, it assumes all named
            objects in subquery should be the same as objects with same names in
            current path.
        :param at_least: (int or None) Minimum required number of subquery matches.
            If None - unbounded
        :param at_most: (int or None) Maximum required number of subquery matches.
            If None - unbounded
        :param inverse: (bool) If True, inverse range (select results that are
            outside given range instead of those that are in range).
            Default is False
        '''
        if not isinstance(query, Ast.Base):
            query = query.ast

        if at_least is None and at_most is None:
            at_least = 1

        if names is None:
            names = get_path_names(query)

        if not all((name in self._names for name in names)):
            raise ValueError('Not all names in where clause are valid')

        self._constraints.append(
            Ast.PathConstraint(query, names,
                               at_least=at_least, at_most=at_most,
                               inverse=inverse)
        )
        return self

    def ensure_different(self, *names):
        '''
        Add filters that ensures that objects with given names are unique among
        each other.

        :param names: (list of string) Names of path objects to check for
            uniqueness. Names should already be present in query.
        '''
        if not all((name in self._names for name in names)):
            raise ValueError('Not all names in ensure_different clause are valid')

        for i in range(len(names)-1):
            for j in range(i+1, len(names)):
                self._constraints.append(
                    Ast.EnsureDifferentConstraint([names[i], names[j]])
                )
        return self

    def select(self, *names):
        '''
        (Deprecated) Hide all names in query so far except for given names.

        :param names: (list of string) Names of objects in query that should
            remain visible. Other object names will be hidden.
        '''
        self._ast = Ast.Select(self._ast, names)
        return self

    def distinct(self, names=None):
        '''
        Ensure that all paths contain different combinations of objects with given
        names. If names are not specified, all path names to this point is assumed.

        :param names: (list of string) Names of objects which combinations
            should be unique. If not specified, all path names up to this point is
            assumed
        '''
        self._ast = Ast.Distinct(self._ast, names)
        return self
