# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import annotations

import typing as t

if t.TYPE_CHECKING:
    from aos.sdk import typing as tt

class FrozenGraphError(Exception):
    def __init__(self) -> None:
        super(FrozenGraphError, self).__init__('Trying to modify frozen graph')


class FrozenGraph(object):
    def __init__(self, graph: tt.Graph) -> None:
        self.__dict__.update({'_graph': graph})

    def _frozen(self, *args: object, **kwargs: object) -> None:
        raise FrozenGraphError()

    add_node = set_node = del_node = _frozen
    add_relationship = set_relationship = del_relationship = _frozen
    commit = _frozen

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._graph, name)
