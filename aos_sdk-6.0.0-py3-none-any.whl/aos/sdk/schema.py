# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

__all__ = [
    # schemas
    'Schema',
    'NodeSchema',
    'RelationshipSchema',

    'DummySchema',

    # types
    'Any', 'String', 'Number', 'Integer', 'Float', 'Boolean', 'List',
    'Collection', 'Dict', 'Object', 'DateTime', 'DateTimeISO8601', 'Optional',
    'OptionalAsMissing', 'SparseOptional', 'ErrorContext', 'Tuple',
    'DumpOnly', 'LoadOnly', 'OneOf', 'SingleItemDict', 'Transform', 'Type',
    'TimeDelta', 'Constant', 'MISSING', 'validated_type',
    # fields
    'Field', 'AttributeField', 'IndexField', 'FunctionField', 'MethodField',
    # validation error
    'ValidationError', 'ValidationErrorBuilder',
    # validators
    'Validator', 'Predicate', 'Range', 'Length', 'Regexp', 'AnyOf', 'NoneOf',
    'Unique', 'FirstFailing', 'Preprocess', 'DependentKeys',

    'OpenStruct',

    # common types registry
    'TYPES',

    'MIN_ASN', 'MAX_ASN',
    'MIN_LOOPBACK_ID', 'MAX_LOOPBACK_ID',
    'MIN_VLAN_ID', 'MAX_VLAN_ID',
    'MIN_SUBINTF_ID', 'MAX_SUBINTF_ID',
    'MIN_VXLAN_ID', 'MAX_VXLAN_ID',
    'MAX_VN_LABEL_SIZE',
    'MIN_PORT', 'MAX_PORT',
    'MIN_SYSTEM_INDEX', 'MAX_SYSTEM_INDEX',
    'MIN_VRF_ID', 'MAX_VRF_ID',
    'PROTOCOL_IP', 'PROTOCOL_ICMP', 'PROTOCOL_TCP', 'PROTOCOL_UDP', 'PORT_ANY',
    'DEFAULT_ESI_MAC_MSB',
    # custom types
    'NodeId', 'Asn', 'LoopbackId', 'VlanId', 'SubintfId', 'VxlanId',
    'VirtualNetworkLabel', 'VirtualNetworkDescription',
    'Description', 'VirtualNetworkId',
    'ProbeLabel', 'DashboardLabel', 'WidgetLabel', 'ProcessorName',
    'SingleItemDict', 'IpAddress', 'IpAddressOrEmpty', 'IpNetworkAddress',
    'Ipv6orIpv4NetworkAddress', 'InterfaceDescription',
    'Ipv6NetworkAddress', 'Ipv6Address', 'Ipv6AddressOrEmpty', 'Ipv4OrIpv6Address',
    'IpNetworkAddressOrPrefix', 'Ipv6NetworkAddressOrPrefix',
    'StrictIpNetworkAddressOrPrefix', 'StrictIpv6NetworkAddressOrPrefix',
    'StrictIpNetworkAddress', 'StrictIpv6NetworkAddress',
    'MacAddress', 'Hostname', 'Rackname', 'GenericName', 'Enum', 'AnomalySeverity',
    'AnomalyType', 'AnomalyRange', 'TacMappingField', 'TacEnumField', 'Expression',
    'ExpressionValue', 'Speed', 'TacEnum', 'RouteDistinguisher', 'RouteTarget',
    'IndexString', 'SecurityZoneName',
    'Port', 'PortRange', 'PortRangeOrAny', 'PortSet', 'PortSetOrAny', 'PortSpeed',
    'TcpConnectionState',
    'SecurityRuleProtocol', 'SecurityRuleAction', 'PrefixListEntry',
    'SystemId', 'VirtualInfraType', 'VnetRemediationPolicyVnetType',
    'Label', 'LagModes', 'OperationState',
    'SafeNetworkString', 'OspfDomainId', 'ManagementLevel',
    'OptionalProperty', 'RackTypeDesign', 'TagLabel', 'TenantLabel',
    'SviIpv4AllocationMode', 'SviIpv6AllocationMode', 'SviIpRequirement',
    'ValidationSeverityEnum', 'DisplayName', 'Mtu', 'EvpnInterconnectESIMac',
    'UniqueNodeIds', 'TagList', 'RailIndex', 'FlowsetTableSize',

    'ERRORS', 'ERROR_MESSAGES',

    'StringNumber', 'StringInteger', 'StringFloat', 'StringBoolean',
    'NonEmptyString', 'InterfaceCounterField', 'OpticalInterfaceLane',
    'ObjectWithIndexField',

    # custom modifiers
    'Deprecated',

    # Lollipop based graph schema
    'GRAPH_SCHEMA',

    # hints
    'dict_value_hint',
]

from aos.sdk.telemetry.schemas import OpticalInterfaceLane
from aos.sdk.types import Any, String, Number, Integer, Float, Boolean, List, \
    Collection, Dict, Object, DateTime, DateTimeISO8601, Optional, Tuple, \
    OptionalAsMissing, SparseOptional, \
    DumpOnly, LoadOnly, OneOf, Transform, Type, Constant, ErrorContext, \
    MISSING, validated_type, \
    Field, AttributeField, IndexField, FunctionField, MethodField, \
    ValidationError, ValidationErrorBuilder, \
    Validator, Predicate, Range, TimeDelta, Length, Regexp, AnyOf, NoneOf, Unique, \
    FirstFailing, Preprocess, DependentKeys, \
    OpenStruct, \
    TYPES, \
    MIN_ASN, MAX_ASN, \
    MIN_LOOPBACK_ID, MAX_LOOPBACK_ID, MIN_SUBINTF_ID, MAX_SUBINTF_ID, \
    MIN_VLAN_ID, MAX_VLAN_ID, MIN_VXLAN_ID, MAX_VXLAN_ID, MAX_VN_LABEL_SIZE, \
    MIN_PORT, MAX_PORT, PROTOCOL_IP, PROTOCOL_ICMP, PROTOCOL_TCP, PROTOCOL_UDP, \
    PORT_ANY, DEFAULT_ESI_MAC_MSB, \
    MIN_SYSTEM_INDEX, MAX_SYSTEM_INDEX, MIN_VRF_ID, MAX_VRF_ID, \
    NodeId, Asn, LoopbackId, VlanId, VxlanId, SubintfId, Description, \
    VirtualNetworkId, VirtualNetworkDescription, VirtualNetworkLabel, \
    ProbeLabel, DashboardLabel, WidgetLabel, ProcessorName, \
    RouteDistinguisher, RouteTarget, SingleItemDict, InterfaceDescription,\
    IpAddress, IpAddressOrEmpty, IpNetworkAddress, MacAddress, Hostname, Rackname, \
    GenericName, Label, LagModes, OperationState, ManagementLevel, \
    OptionalProperty, RackTypeDesign, SviIpv4AllocationMode, SviIpv6AllocationMode, \
    SviIpRequirement, Ipv6NetworkAddress, Ipv6Address, Ipv6AddressOrEmpty, \
    Ipv4OrIpv6Address, Enum, TacEnum, AnomalySeverity, AnomalyType, AnomalyRange, \
    Ipv6orIpv4NetworkAddress, IpNetworkAddressOrPrefix, Ipv6NetworkAddressOrPrefix, \
    StrictIpNetworkAddressOrPrefix, StrictIpv6NetworkAddressOrPrefix, \
    StrictIpNetworkAddress, StrictIpv6NetworkAddress, \
    TacMappingField, TacEnumField, Expression, ExpressionValue, Speed, \
    StringNumber, StringInteger, StringFloat, StringBoolean, \
    InterfaceCounterField, IndexString, NonEmptyString, \
    ERRORS, ERROR_MESSAGES, SecurityZoneName, \
    Port, PortRange, PortRangeOrAny, PortSet, PortSetOrAny, PortSpeed, \
    TcpConnectionState, \
    SecurityRuleProtocol, SecurityRuleAction, PrefixListEntry, \
    SystemId, VirtualInfraType, VnetRemediationPolicyVnetType, \
    SafeNetworkString, OspfDomainId, TagLabel, TenantLabel, ValidationSeverityEnum, \
    DisplayName, Mtu, EvpnInterconnectESIMac, UniqueNodeIds, \
    Deprecated, ObjectWithIndexField, TagList, RailIndex, \
    FlowsetTableSize, \
    dict_value_hint
from collections import OrderedDict
from aos.sdk.graph.schema import Schema, NodeSchema, RelationshipSchema, DummySchema
import lollipop_jsonschema


class ExpressionEncoder(lollipop_jsonschema.TypeEncoder):
    schema_type = Expression

    def json_schema(self, encoder, schema):
        js = super().json_schema(encoder, schema)
        js['type'] = 'string'
        return js


class DateTimeISO8601Encoder(lollipop_jsonschema.DateTimeEncoder):
    schema_type = DateTimeISO8601


class TimeDeltaEncoder(lollipop_jsonschema.TypeEncoder):
    schema_type = TimeDelta

    def json_schema(self, encoder, schema):
        js = super().json_schema(encoder, schema)
        js['type'] = 'string'
        js['format'] = 'time-delta'

        # ECMA-262 compatible regex for time delta
        js['pattern'] = (
            '^'
            '([-+])'
            # 0-99999999
            '([0-9]'
            '|[1-9][0-9]{1,7})'
            # 0-86399
            '(:([0-9]'
            '|[1-9][0-9]{1,3}'
            '|[1-7][0-9]{4}'
            '|8[0-5][0-9]{3}'
            '|86[0-3][0-9]{2}'
            '))?'
            '$'
        )

        return js


class DeprecatedEncoder(lollipop_jsonschema.ModifierEncoder):
    schema_type = Deprecated

    def json_schema(self, encoder, schema):
        if schema.is_inner_type_missing:
            return None

        js = super().json_schema(encoder, schema)
        if js is None:
            return

        description = schema._error_messages['message']
        if 'description' in js and js['description']:
            description += ": {}".format(js['description'])

        js['description'] = description

        return js


class OrderedDictEncoder(lollipop_jsonschema.DictEncoder):
    schema_type = OrderedDict

class AnyEncoder(lollipop_jsonschema.TypeEncoder):
    schema_type = Any

    def json_schema(self, encoder, schema):
        js = super().json_schema(encoder, schema)
        js['type'] = 'any'
        return js

class JsonSchemaEncoder(lollipop_jsonschema.Encoder):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.add_encoder(ExpressionEncoder())
        self.add_encoder(DateTimeISO8601Encoder())
        self.add_encoder(TimeDeltaEncoder())
        self.add_encoder(DeprecatedEncoder())
        self.add_encoder(OrderedDictEncoder())
        self.add_encoder(AnyEncoder())


_ENCODER = JsonSchemaEncoder()
json_schema = _ENCODER.json_schema


NODE_SCHEMA = Transform(
    Any(),
    pre_dump=lambda ns: json_schema(Object(dict(
        ns.properties, type=String(ns.type)
    ))))

RELATIONSHIP_SCHEMA = Transform(
    Any(),
    pre_dump=lambda rel: json_schema(Object(dict(
        rel.properties, type=String(rel.type), source_type=String(rel.source_type),
        target_type=String(rel.target_type)
    ))))

GRAPH_SCHEMA = Object({
    'nodes': FunctionField(List(NODE_SCHEMA),
                           lambda schema: list(schema.nodes.values())),
    'relationships': List(RELATIONSHIP_SCHEMA)
})
