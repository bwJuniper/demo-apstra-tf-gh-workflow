# Copyright 2022-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


def get_port_channel_interface_name(
        os_family: str, port_channel_id: int) -> str:
    os_family = os_family.lower()

    if os_family == 'cumulus':
        po_name = 'bond' + str(port_channel_id)
    elif os_family == 'junos':
        po_name = 'ae' + str(port_channel_id)
    elif os_family == 'sonic':
        # Sonic used to expect po names in the order described below.
        # "PortChannelxxxx", where "xxxx" is number of 1 to 4 digits.
        # Ex: "PortChannel0002".
        po_name = 'PortChannel' + str(port_channel_id)
    else:
        po_name = 'port-channel' + str(port_channel_id)

    return po_name
