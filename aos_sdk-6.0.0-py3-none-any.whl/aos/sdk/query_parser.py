# Copyright 2022-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import absolute_import

import ast
import itertools

import six
import lollipop.errors

from aos.sdk.graph import query


ALLOWED_QUERY_FUNCTIONS = {
    'match': query.match,
    'node': query.node,
    'optional': query.optional,
    'eq': query.eq,
    'ne': query.ne,
    'gt': query.gt,
    'ge': query.ge,
    'lt': query.lt,
    'le': query.le,
    'is_in': query.is_in,
    'not_in': query.not_in,
    'is_none': query.is_none,
    'not_none': query.not_none,
    'has_items': query.has_items,
    'has_keys': query.has_keys,
    'has_all': query.has_all,
    'has_any': query.has_any,
    'has_none': query.has_none,
    '_and': query._and,
    '_not': query._not,
    '_or': query._or,
    'aeq': query.aeq,
}
ALLOWED_QUERY_BUILTINS = {
    'float': float,
    'int': int,
    'str': str,
    'bool': bool,
    'True': True,
    'False': False,
    'None': None,
}
ALLOWED_QUERY_PROPERTIES = [
    # dsl.PathQueryBuilder
    'out',
    'in_',
    # dsl.MultiPathQueryBuilder
    'ensure_different',
    'where',
    'having',
    'distinct',
    'select',
]
ALLOWED_ASYNC_MODES = [
    'full',
    'partial',
]
ALLOWED_TASK_LIST_MODES = [
    'full',
    'digest',
]


@six.python_2_unicode_compatible
class QueryParsingError(lollipop.errors.ValidationError, ValueError):

    def __init__(self, query_string, message):
        super(QueryParsingError, self).__init__(message)
        self.query_string = query_string
        self.message = message

    def __str__(self):
        return six.ensure_text(u"{}: {}".format(self.message, self.query_string))


def encode_unicode_strings(ast_root):
    """ Encodes Unicode strings into binary strings in the AST in-place """
    class Encoder(ast.NodeTransformer):
        # pylint:disable=invalid-name
        def visit_Str(self, node):
            # change the Str AST nodes in-place
            node.s = six.ensure_str(node.s)
            return node

    Encoder().visit(ast_root)


def parse_graph_query(query_string):
    query_string = six.ensure_text(query_string)

    try:
        expr_ast = ast.parse(query_string, mode='eval')

        # encode unicode because it's what most of the code base expects
        encode_unicode_strings(expr_ast)

        code_obj = compile(expr_ast, 'validate', mode='eval')
    except SyntaxError as exc:
        six.raise_from(QueryParsingError(query_string, 'Invalid Syntax'), exc)

    invalid_functions = (set(code_obj.co_names)
                         - set(itertools.chain(
                             ALLOWED_QUERY_FUNCTIONS,
                             ALLOWED_QUERY_BUILTINS,
                             ALLOWED_QUERY_PROPERTIES,
                         )))
    if invalid_functions:
        raise QueryParsingError(query_string, 'Invalid graph query functions')

    try:
        retval = eval( # pylint: disable=eval-used
            code_obj,
            {
                '__builtins__': ALLOWED_QUERY_BUILTINS,
            },
            ALLOWED_QUERY_FUNCTIONS,
        )
    except Exception as exc:  # pylint: disable=broad-except
        err = QueryParsingError(
            query_string,
            'Incorrect graph query: {}'.format(exc))
        six.raise_from(err, exc)

    if hasattr(retval, 'ast'):
        return retval.ast

    raise QueryParsingError(query_string, 'Invalid graph query')
