#!/usr/bin/env python3
# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""
Module to interact with the AOS Rest API in a pythonic way.
"""

from json import dumps
import logging
import re
import requests
from six.moves.urllib.parse import urlencode
from six.moves.urllib.parse import urlparse
from six.moves import range

def disable_insecure_request_warning():
    """Disable warning for self-signed certificate"""
    requests.packages.urllib3.disable_warnings(
        requests.packages.urllib3.exceptions.InsecureRequestWarning)


def safe_dumps(obj, dump_default=None, **kwargs):
    try:
        return dumps(obj, **kwargs)
    except ValueError:
        return dump_default if dump_default else obj


HTTP_2xx = set(range(200, 300))
HTTP_2xx_AS_LIST = list(range(200, 300))


class AosRestBase(object):
    """
    Make AOS REST-ful API calls and process the result

    Args:
        url (str): url of the current rest object
        scheme (str): 'http' or 'https' (unsupported for now)
        host (str): IP address or hostname of the server
        port (int): HTTP server port
    """
    logger = logging.getLogger(__name__)
    MAX_LOG_SIZE = 5000
    def __init__(self, scheme='https', host='aos-server',
                 port=443, verify_certificate=False,
                 session_token=None, logger=None):
        self._scheme = scheme
        self._host = host
        self._port = port
        self._base_url = '%s://%s:%d' % (scheme, host, port)
        self._verify_certificate = verify_certificate
        if not verify_certificate:
            disable_insecure_request_warning()
        self.logger = logger or AosRestBase.logger
        self._session_token = session_token
        self._user_id = None
        self.headers = {"content-type":"application/json"}

    def __str__(self):
        return self._expand_path(self._base_url)

    @staticmethod
    def _normalize_url(url):
        """
        needed when chaining URL, to make sure we
        strip double slashes when they occur
        """
        purl = urlparse(url)
        path = purl.path
        path = re.sub('/{2,}', '/', path)
        return path

    def _expand_path(self, path=None):
        """
        returns the absolute path of the URL including query params
        Args:
            url (str): path to expand into a complete URL
        Returns:
            full RFC 1808 URL
        """
        if path is None:
            path = ''
        path = self._normalize_url(path)
        return '%s%s' % (self._base_url, path)

    def set_session_token(self, session_token):
        """
        Set session token returned by AOS server after authentication
        """
        self._session_token = session_token

    def set_user_id(self, user_id):
        """
        Set user_id returned by AOS server after authentication
        """
        self._user_id = user_id

    def _do_http_request(self, method, url=None, params=None, body=None,
                         expect_status_codes=None):
        """
        Performs the requested HTTP method on the specified resource.
        Note: if url is none, the method is run on the object URL, otherwise
        we will do it on a path suffix appended to the current URL.

        Internally we use python requests to handle the complexity of
        interacting with the HTTP server specifying the proper headers
        and parsing the response.

        Also, we assert on the exit code of the response we get, but we can
        override this behavior through the parameter 'expected_status_codes'
        very useful for negative testing or to handle more
        gracefully specific error condition (e.g.: first authentication)

        Args:
            method (str): GET, POST, PUT, PATCH, PDELETE
            url (str): url or path suffix of the resource on which the method
                       is run
            params (dict): query params that will be urlencoded in the actual
                           request (from dict to "?key1=value&key2=value")
            body (dict): body of the request
            expected_status_code (list): raise an exception if the response
                                         code is not in the list

        Returns:
            _AOSResponse object

        Raises
            UnexpectedExitCode, if the response code different than expected"""

        params = params or {}
        body = body or {}
        exp = expect_status_codes

        if url is not None:
            if '://' not in url:
                url = self._expand_path(self._base_url + '/' + url)
        else:
            url = self._expand_path(self._base_url)

        if self._session_token is not None:
            self.headers['AuthToken'] = self._session_token

        out_str = '>> %s %s' % (method, url)
        if params != {}:
            out_str += '?%s' % urlencode(params)
        if body != {}:
            out_str += '\n%s' % safe_dumps(
                body, sort_keys=True, indent=4, dump_default='<NON-JSONABLE DATA>')
        self.logger.info(out_str)

        if method == 'GET':
            status_codes = exp or HTTP_2xx
            res = requests.get(
                url,
                headers=self.headers,
                params=params,
                verify=self._verify_certificate
            )
        elif method == 'POST':
            status_codes = exp or HTTP_2xx
            res = requests.post(
                url,
                headers=self.headers,
                params=params,
                data=safe_dumps(body),
                verify=self._verify_certificate
            )
        elif method == 'PUT':
            status_codes = exp or HTTP_2xx
            res = requests.put(
                url,
                headers=self.headers,
                params=params,
                data=safe_dumps(body),
                verify=self._verify_certificate
            )
        elif method == 'PATCH':
            status_codes = exp or HTTP_2xx
            res = requests.patch(
                url,
                headers=self.headers,
                params=params,
                data=safe_dumps(body),
                verify=self._verify_certificate
            )
        elif method == 'DELETE':
            status_codes = exp or HTTP_2xx
            res = requests.delete(
                url,
                headers=self.headers,
                params=params,
                data=safe_dumps(body) if body else None,
                verify=self._verify_certificate
            )
        else:
            raise AssertionError('"Method %s unsupported' % method)

        self.logger.debug('<< Status code: %d, Elapsed time: %s',
                          res.status_code, str(res.elapsed.total_seconds()))

        if res.status_code not in status_codes:
            if status_codes is HTTP_2xx:
                # TODO(dmitryme): fix any ptest which fails if this 'if' is removed
                # and delete the 'if' and HTTP_2xx_AS_LIST afterwards
                # Or rewrite the code to use function, which accepts or declines
                # status code. A separate function should return string
                # representation of expected range.
                status_codes = HTTP_2xx_AS_LIST

            message = 'expected exit code in %s, got %s. response: %s' \
                % (str(status_codes), res.status_code, res.text)
            raise RuntimeError(message, res)

        # verify body if GET specified a body
        # if body is not None and method == 'GET':
        #    dict_is_subset_of(req.body, res.body, )

        return res

        # creating a request object so we can store it with the response
        # req = _AosRequest(method, url, body, params, self._session_token)
        # res = _AosResponse(res, session_token=self._session_token, request=req)

    def request(self, url, method=None, headers=None, data=None, **kwargs):
        if method is None:
            method = 'GET' if data is None else 'POST'

        url = self._base_url + url

        self._log_request(method, url, data)
        # headers not supported
        response = self._do_http_request(
            method=method, url=url, body=data, **kwargs)
        self._log_response(response)
        return response.json() if len(
            response.text) > 0 and response.status_code != 404 else None

    def _log_request(self, method, url, data):
        """Log HTTP request"""
        s = '%s request to %s' % (method, url)
        if data:
            s += ' body=%s' % safe_dumps(data, dump_default='<NON-JSONABLE DATA>')

        self.logger.info('Sending %s', s)

    def _log_response(self, response):
        """Log HTTP response"""
        s = 'code=%d' % response.status_code
        if response.headers:
            s += ' headers=%s' % repr(response.headers)
        if response.text:
            s += ' body=%s' % response.text[:self.MAX_LOG_SIZE]
            if len(response.content) > self.MAX_LOG_SIZE:
                s += '\n<Truncated %d bytes because body exceeds the limit of %d ' \
                    'bytes>' % \
                    (len(response.content) - self.MAX_LOG_SIZE, self.MAX_LOG_SIZE)
        self.logger.info('Got response %s', s)


class AosAPISession(AosRestBase):
    def login(self, username='admin', password='admin'):
        """
        Establish an authenticated session with   storing the session token
        to be used for every future REST methods
        """
        res = self.request('/api/aaa/login',
                           method='POST',
                           data={
                               'username':username,
                               'password':password
                           })
        self.set_session_token(res.get('token'))
        self.set_user_id(res.get('id'))

    def change_password(self, old_password='admin',
                        new_password='admin'):
        """ performs a password change on the server """
        return self.request(
            '/api/aaa/users/{}/change-password'.format(self.user_id),
            method='PUT',
            data={"new_password": old_password,
                  "current_password": new_password})

    def logout(self):
        return self.do_post('/api/aaa/logout', expect_status_codes=[200])
