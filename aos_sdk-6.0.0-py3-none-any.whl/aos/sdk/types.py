# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


__all__ = [
    # types
    'Any', 'String', 'Number', 'Integer', 'Float', 'Boolean', 'List', 'Tuple',
    'Collection', 'Dict', 'Object', 'DateTime', 'DateTimeISO8601', 'Optional',
    'OptionalAsMissing', 'SparseOptional',
    'DumpOnly', 'LoadOnly', 'OneOf', 'SingleItemDict', 'Transform', 'Type',
    'TimeDelta', 'Constant', 'Modifier', 'MISSING', 'validated_type',
    # fields
    'Field', 'AttributeField', 'IndexField', 'FunctionField', 'MethodField',
    # validation error
    'ValidationError', 'ValidationErrorBuilder',
    # validators
    'Validator', 'Predicate', 'Range', 'Length', 'Regexp', 'AnyOf', 'NoneOf',
    'Unique', 'FirstFailing', 'Preprocess',

    'OpenStruct',

    # common types registry
    'TYPES',

    'MIN_ASN', 'MAX_ASN',
    'MIN_LOOPBACK_ID', 'MAX_LOOPBACK_ID',
    'MIN_VLAN_ID', 'MAX_VLAN_ID',
    'MIN_SUBINTF_ID', 'MAX_SUBINTF_ID',
    'MIN_VXLAN_ID', 'MAX_VXLAN_ID',
    'MAX_VN_LABEL_SIZE', 'MAX_VN_DESC_SIZE', 'MAX_INTF_DESC_LEN',
    'MIN_PORT', 'MAX_PORT',
    'MIN_VRF_ID', 'MAX_VRF_ID',
    'PROTOCOL_IP', 'PROTOCOL_ICMP', 'PROTOCOL_TCP', 'PROTOCOL_UDP', 'PORT_ANY',
    'DEFAULT_ESI_MAC_MSB', 'FRR_RD_VLAN_OFFSET', 'DEFAULT_FABRIC_EVI_RT',
    'MAX_PORT_CHANNEL_NUMBER', 'LAG_MODES',
    'MIN_L3_MTU', 'MAX_L3_MTU', 'DEFAULT_SVI_L3_MTU', 'BP_DEFAULT_L3_MTU',
    'DEFAULT_DUP_MAC_RECOVERY_TIME',
    'FabricConnectivityDesigns',
    # custom types
    'NodeId', 'Asn', 'LoopbackId', 'VlanId', 'SubintfId', 'VxlanId',
    'VirtualNetworkLabel', 'VirtualNetworkDescription',
    'Description', 'VirtualNetworkId',
    'ProbeLabel', 'DashboardLabel', 'WidgetLabel', 'ProcessorName',
    'SingleItemDict', 'IpAddress', 'IpAddressOrEmpty', 'IpNetworkAddress',
    'Ipv6NetworkAddress', 'Ipv6Address', 'Ipv6AddressOrEmpty', 'Ipv4OrIpv6Address',
    'Ipv6orIpv4NetworkAddress', 'Ipv6NetworkAddress', 'IpNetworkAddressOrPrefix',
    'Ipv6NetworkAddressOrPrefix', 'StrictIpNetworkAddressOrPrefix',
    'StrictIpv6NetworkAddressOrPrefix', 'StrictIpNetworkAddress',
    'StrictIpv6NetworkAddress',
    'MacAddress', 'MacAddressOrEmpty',
    'Hostname', 'Rackname', 'GenericName', 'Enum', 'TacEnum',
    'AnomalySeverity', 'AnomalyType', 'AnomalyRange',
    'TacMappingField', 'Expression',
    'ExpressionValue', 'Speed', 'IPv4PrefixLen', 'RouteDistinguisher',
    'InterfaceCounterField', 'IndexString', 'SecurityZoneName',
    'Port', 'PortRange', 'PortRangeOrAny', 'PortSet', 'PortSetOrAny', 'PortSpeed',
    'TcpConnectionState',
    'SecurityRuleProtocol', 'SecurityRuleAction', 'PrefixListEntry',
    'SystemId', 'VirtualInfraType', 'VnetRemediationPolicyVnetType',
    'Label', 'LagModes', 'OperationState', 'OspfDomainId', 'StringBoolean',
    'StringNumber', 'StringInteger', 'StringFloat', 'SviIpv4AllocationMode',
    'SviIpv6AllocationMode', 'SviIpRequirement', 'ValidationSeverityEnum',
    'DisplayName', 'NaturalNumber', 'PositiveNumber', 'PortChannelNumber',
    'Mtu', 'EvpnInterconnectESIMac', 'ObjectWithIndexField', 'TagList',

    # custom modifiers
    'Deprecated',

    # hints
    'dict_value_hint',
]

import ast
import collections.abc
import copy
import datetime
import functools
import json
import re
import socket

import iso8601
import netaddr
import six

# Import types for re-export
# A relative import is done here by design. This file is utilized by multiple sdk
# packages like aos-sdk-telemetry and these packages contain this source file at
# different location. The only invariant we have here is that the basic_types.py and
# types.py will be in the same location.
from .basic_types import Any, String, Number, Integer, Float, Boolean, List, Tuple, \
    Dict, Object, DateTime, Optional, DumpOnly, LoadOnly, OneOf, Transform, Type, \
    Constant, Modifier, MISSING, validated_type, Enum, Field, AttributeField, \
    IndexField, FunctionField, MethodField, ValidationError, ValidationErrorBuilder,\
    Validator, Predicate, Range, Length, Regexp, AnyOf, NoneOf, Unique, \
    TypeRegistry, OpenStruct, to_snake_case, to_camel_case, \
    Speed, StringBoolean, StringNumber, \
    StringInteger, StringFloat, SparseOptional, \
    dict_value_hint

# pylint: disable=redefined-builtin,eval-used

MIN_ASN = 1
MAX_ASN = 2**32-1
MIN_LOOPBACK_ID = 0
MAX_LOOPBACK_ID = 20000
MIN_VLAN_ID = 1
MAX_VLAN_ID = 4094
MIN_SUBINTF_ID = 1
MAX_SUBINTF_ID = 511
MIN_VXLAN_ID = 4096
MAX_VXLAN_ID = 16777214
MAX_VN_LABEL_SIZE = 30
MAX_VN_DESC_SIZE = 222
# 222 is 255-30-3 because description is rendered as '{vn_name}---{vn_desc}'
# on Junos we need to take into account OS limitation (255 chars) and
# maximum vn_name (30 chars)
MIN_PORT = 1
MAX_PORT = 65535
MAX_INTF_DESC_LEN = 240
MIN_SYSTEM_INDEX = 1
MAX_SYSTEM_INDEX = 19999
MIN_VRF_ID = 1
MAX_VRF_ID = 4999
MAX_PORT_CHANNEL_NUMBER = 4096
MIN_L3_MTU = 1280
MAX_L3_MTU = 9216
DEFAULT_SVI_L3_MTU = 9000
BP_DEFAULT_L3_MTU = 9170

PROTOCOL_IP = 'IP'
PROTOCOL_ICMP = 'ICMP'
PROTOCOL_TCP = 'TCP'
PROTOCOL_UDP = 'UDP'
PORT_ANY = 'any'

# Do not ever change this default value - changing will cause complete fabric
# disruption on any deployed customer blueprint.

DEFAULT_ESI_MAC_MSB = 2
MIN_RAIL_INDEX = 0
MAX_RAIL_INDEX = 1024


class OptionalAsMissing(Optional):
    '''Works like an Optional, but does not produce a None value if the data
       load()-ed does not contain the key. This allows differentiating between
       2 different intents - (a) not wanting to supply a value, and (b) supplying
       the value None explicitly. These 2 cases are commonly supported by
       PATCH APIs.
    '''
    def __init__(self, *args, **kwargs):
        if 'load_default' in kwargs:
            kwargs.pop('load_default')

        super().__init__(*args, load_default=MISSING, **kwargs)

    def load(self, data, context=None, *args, **kwargs):
        if data is MISSING:
            return self.load_default(context)
        elif data is None:
            return data
        return super().load(
            data, context=context, *args, **kwargs
        )


def override_attributes(obj, name=MISSING, description=MISSING):
    """
    Override 'name' and/or 'description' attributes of `lollipop.Type`
    instance.

    Example:
        COLOUR = s.Enum(
            [
                'green',
                'blue',
            ],
            description='Colour'
        )

        TEXT_STYLE = s.Dict(
            {
                'foreground_colour': override_attributes(COLOUR,
                    description='Foreground colour'
                ),
                'background_colour': override_attributes(COLOUR,
                    description='Background colour'
                ),
            }
        )
    """
    if name is MISSING and description is MISSING:
        raise ValueError("At least name or description must be specified")
    copy_obj = copy.copy(obj)
    if name is not MISSING:
        copy_obj.name = name
    if description is not MISSING:
        copy_obj.description = description
    return copy_obj


class Deprecated(Modifier):
    """A modifier which makes a value deprecated. The inner type is optional
    and if omitted, then the type is not even rendered in the schema.

    Example:

        Dict({
            'name': String(),
            'label': Deprecated(error_messages={
                'message': 'Not supported since 1.0, use name instead',
            }),
        })


    Error message keys:
        * message - a deprecation message.
    """

    default_error_messages = {
        'message': 'Deprecated',
    }

    def __init__(self, inner_type=None, **kwargs):
        if inner_type is None:
            is_inner_type_missing = True
            inner_type = Type()
        else:
            is_inner_type_missing = False
        super().__init__(inner_type, **kwargs)
        self.is_inner_type_missing = is_inner_type_missing

    def load(self, data, *args, **kwargs):
        if data is MISSING:
            return MISSING
        self._fail('message')

    def dump(self, value, *args, **kwargs):
        if value is MISSING:
            return MISSING
        self._fail('message')


class FirstFailing(Validator):
    '''Takes validators and stops on first failing'''
    def __init__(self, *args, **kwargs):
        super().__init__(**kwargs)
        self.validators = args

    def __call__(self, value, context=None):
        for validator in self.validators:
            validator(value, context=context)


class Preprocess(Validator):
    '''Applies transformation function to value and then
    calls other validators on it.'''
    def __init__(self, func, validate, **kwargs):
        super().__init__(**kwargs)
        self.func = func
        if not isinstance(validate, collections.abc.Sequence):
            validate = [validate]

        self.validators = validate

    def __call__(self, value, context=None):
        value = self.func(value)

        errors_builder = ValidationErrorBuilder()
        for validator in self.validators:
            try:
                validator(value, context)
            except ValidationError as ve:
                errors_builder.add_errors(ve.messages)
        errors_builder.raise_errors()


NodeId = validated_type(String, 'NodeId', Length(min=1))

Asn = validated_type(Integer, 'Asn', Range(MIN_ASN, MAX_ASN))

LoopbackId = validated_type(Integer, 'LoopbackId',
                            Range(MIN_LOOPBACK_ID, MAX_LOOPBACK_ID))

VlanId = validated_type(Integer, 'VlanId', Range(MIN_VLAN_ID, MAX_VLAN_ID))

SubintfId = validated_type(Integer, 'SubintfId',
                           Range(MIN_SUBINTF_ID, MAX_SUBINTF_ID))

VxlanId = validated_type(Integer, 'VxlanId', Range(MIN_VXLAN_ID, MAX_VXLAN_ID))

Description = validated_type(String, 'Description', Length(max=4094))

VirtualNetworkId = validated_type(String, 'VirtualNetworkId', Length(max=128))

VirtualNetworkLabel = validated_type(
    String, 'VirtualNetworkLabel', validate=[
        Length(min=1, max=MAX_VN_LABEL_SIZE),
        Regexp('^[a-zA-Z0-9_-]*$',
               error='Invalid label. '\
                     'Only ASCII alphanumeric characters, '
                     'underscore and dash are allowed'),
    ],
)

VirtualNetworkDescription = validated_type(
    String, 'VirtualNetworkDescription', validate=[
        Length(max=MAX_VN_DESC_SIZE),
        Regexp('^[^"<>\\\\?]*$',
               error='Invalid description. The following characters are not '
                     'allowed in the device configuration: ", <, >, \\, ?')])


def validate_is_ascii(value):
    err = ValidationError('Non-ASCII characters not allowed')

    try:
        six.ensure_str(value, encoding='ascii')
    except (UnicodeDecodeError, UnicodeEncodeError) as exc:
        raise err from exc

    # this is not enough to ensure text in case of Python3 because
    # it is perfectly fine for it to have a unicode string with
    # non-ascii characters. Also, having str as alias to unicode
    # makes it more tricky.
    #
    # The most efficient and cheap solution is to iterate over all
    # codepoints and see if they belong to ASCII interval:
    #
    # https://www.ascii-code.com (see ASCII printable)
    if not all(31 < ord(codepoint) < 127 for codepoint in value):
        raise err


def validate_leading_trailing_whitespace(value):
    if value.strip() != value:
        raise ValidationError('Invalid leading or trailing whitespace')

ProbeLabel = validated_type(String, 'ProbeLabel', validate=[
    Length(min=1, max=120), validate_leading_trailing_whitespace])
DashboardLabel = validated_type(String, 'DashboardLabel', validate=[
    Length(min=1, max=120), validate_leading_trailing_whitespace])
WidgetLabel = validated_type(String, 'WidgetLabel', validate=[
    Length(min=1, max=120), validate_leading_trailing_whitespace])
ProcessorName = validated_type(String, 'ProcessorName', validate=[
    Length(min=1, max=120), validate_leading_trailing_whitespace])

# AOS-10660 - Security zone VRF name should be limited at 15 characters
# due to linux constraint
SecurityZoneName = validated_type(
    String, 'SecurityZoneName', validate=[
        Length(min=1, max=15),
        Regexp('^[a-zA-Z0-9_-]*$',
               error='Invalid routing zone name. '\
                     'Only ASCII alphanumeric characters, '
                     'underscore and dash are allowed. '
                     'Maximum length 15 characters'),
    ],
)

InterfaceDescription = validated_type(
    # Since '?' (code 63) is forbidden, listing allowed characters
    # as two ranges: [<space> - >] (codes 32 - 62) and
    # [@ - ~] (codes 64 - 126).
    String, 'InterfaceDescription', validate=[
        Length(max=MAX_INTF_DESC_LEN),
        Regexp(r'\A([!#-;=@-[\]-~]([ !#-;=@-[\]-~]*[!#-;=@-[\]-~])?)?\Z',
               error=('Invalid interface description. ' \
                      'Only ASCII characters with codes 32 - 126, '
                      'except "?", "<", ">", \'"\' and "\" are allowed.'
                      ' The description should not start or end with a space.'))
    ]
)

SingleItemDict = validated_type(Dict, 'SingleItemDict', Length(exact=1))


NonEmptyString = validated_type(
    String,
    'NonEmptyString',
    Length(min=1)
)


NaturalNumber = validated_type(Integer, 'NaturalNumber', validate=Range(min=0))

PositiveNumber = validated_type(Integer, 'PositiveNumber', validate=Range(min=1))


class RailIndex(Integer):
    def __init__(self, *args, **kwargs):
        super().__init__(
            name='RailIndex',
            validate=[Range(MIN_RAIL_INDEX, MAX_RAIL_INDEX)],
            description='Specifies rail index for the link to indicate Rail '
                        'membership; only applicable on Leaf-Generic links for '
                        'rail-optimized network design',
            *args, **kwargs
        )


class Port(Integer):
    def __init__(self, *args, **kwargs):
        super().__init__(
            name='Port',
            validate=Range(MIN_PORT, MAX_PORT),
            description='A single integer port number '
                        'in range %d-%d' % (MIN_PORT, MAX_PORT),
            *args, **kwargs
        )


def validate_port_range(port_range):
    valid = False
    port_range_pattern = r"^([1-9]\d{0,4})(-([1-9]\d{0,4}))?$"
    result = re.match(port_range_pattern, port_range)
    if result:
        valid = True
        groups = result.groups()
        s_min = groups[0]
        i_min = Port().load(int(s_min))
        s_max = groups[2]
        if s_max:
            i_max = Port().load(int(s_max))
            if i_max < i_min:
                valid = False
    if not valid:
        raise ValidationError('Invalid port range expression %s' % port_range)


def validate_port_range_or_any(port_range):
    if port_range != PORT_ANY:
        validate_port_range(port_range)


def validate_port_set(port_set):
    # Expect expression in the form 80,443-445,8080-8090
    # where port numbers are strictly increased
    last_port_number = -1
    for port_range_token in port_set.split(','):
        port_range = PortRange().load(port_range_token)
        port_range_splitted = port_range.split('-')
        min_range_number = int(port_range_splitted[0])
        max_range_number = int(port_range_splitted[-1])
        if min_range_number <= last_port_number:
            raise ValidationError('Invalid port set expression %s' % port_set)
        last_port_number = max_range_number


def validate_port_set_or_any(port_set):
    if port_set != PORT_ANY:
        validate_port_set(port_set)


class PortRange(String):
    def __init__(self, *args, **kwargs):
        super().__init__(
            name='PortRange',
            validate=validate_port_range,
            description='A single valid port number or range '
                        'in the form of {min}-{max}',
            *args, **kwargs
        )


class PortRangeOrAny(String):
    def __init__(self, *args, **kwargs):
        super().__init__(
            name='PortRangeOrAny',
            validate=validate_port_range_or_any,
            description='A single valid port number '
                        'or range in the form of {min}-{max} '
                        'or "%s"' % PORT_ANY,
            *args, **kwargs
        )


class PortSet(String):
    def __init__(self, *args, **kwargs):
        super().__init__(
            name='PortSet',
            validate=validate_port_set,
            description='Multiple port ranges separated by comma',
            *args, **kwargs
        )


class PortSetOrAny(String):
    def __init__(self, *args, **kwargs):
        super().__init__(
            name='PortSetOrAny',
            validate=validate_port_set_or_any,
            description='Multiple port ranges separated by comma '
                        'or "%s"' % PORT_ANY,
            *args, **kwargs
        )


def validate_tcp_connection_state(tcp_state_qualifier):
    if tcp_state_qualifier != 'established':
        raise ValidationError("Option is supported only for TCP protocol. "
                              "Allowed value is 'established'.")


class TcpConnectionState(String):
    # We may want to extend this class to TCP flags in the future.
    # This is the reason why we use a String and not an Enum.
    def __init__(self, *args, **kwargs):
        super().__init__(
            name='TcpConnectionState',
            validate=validate_tcp_connection_state,
            description='State of the TCP connection',
            *args, **kwargs
        )


IPv4PrefixLen = validated_type(Integer, 'IPv4PrefixLen', Range(0, 32))

def validate_ipv4_address(address):
    try:
        socket.inet_pton(socket.AF_INET, address)
    except OSError as err:
        raise ValidationError('Invalid IP address %s' % address) from err

def is_ipv4_address(address_string):
    try:
        validate_ipv4_address(str(address_string))
    except ValidationError:
        return False
    return True

def validate_ipv6_address(address):
    try:
        socket.inet_pton(socket.AF_INET6, address)
    except OSError as exc:
        raise ValidationError('Invalid IPv6 address %s' % address) from exc

def is_ipv6_address(address_string):
    try:
        validate_ipv6_address(str(address_string))
    except ValidationError:
        return False
    return True


def validate_ipv4_address_or_empty(address):
    if address:
        validate_ipv4_address(address)

def validate_ipv6_address_or_empty(address):
    if address:
        validate_ipv6_address(address)


def validate_ipv6_network_address(network_address,
                                  error_type='ipv6_only',
                                  must_be_network_address=False):
    """
    :param network_address: IPV6 Network CIDR (fc01::1/64)
    :param error_type: 'dual' or 'ipv6_only' (default)
    :param must_be_network_address: enable strict validation for hosts zero bits
                                    in specified network_address
    """
    format_error = '%s is not a valid IPv4 or IPv6 network address, ' \
                   'expected format is network/prefixlen or IP address ' \
                   '(interpreted as /32 network address)'
    network_error = '%s does not identify a network subnet, ' \
                    'since host bits must be all zeroes. Did you mean %s?'
    try:
        address = netaddr.IPNetwork(network_address)
    except (netaddr.core.AddrFormatError, ValueError) as exc:
        if error_type == 'dual':
            raise ValidationError(format_error % network_address) from exc
        else:
            raise ValidationError(
                'Invalid IPv6 network address %s' % network_address) from exc
    if must_be_network_address:
        if str(address) != str(address.cidr):
            raise ValidationError(network_error % (network_address, address.cidr))
    if address.version != 6 and error_type == 'ipv6_only':
        raise ValidationError('Not an IPv6 address %s' % network_address)

    if address.version == 6:
        tokens = network_address.split('/')
        if len(tokens) != 2:
            raise ValidationError(
                'Invalid IPv6 network address {addr} Did you mean {addr}/128?'
                .format(addr=network_address))


def validate_ipv4_or_ipv6_address(address):
    try:
        validate_ipv4_address(address)
    except (ValidationError, netaddr.core.AddrFormatError):
        pass
    else:
        return
    try:
        validate_ipv6_address(address)
    except (ValidationError, netaddr.core.AddrFormatError) as exc:
        raise ValidationError(
            '%s is neither valid IPv4 nor IPv6 address' % address) from exc

def validate_ipv4_or_ipv6_network_address(address):
    try:
        validate_ipv4_network_address(address, must_be_network_address=True)
    except (ValidationError, netaddr.core.AddrFormatError, ValueError):
        validate_ipv6_network_address(address, error_type='dual',
                                      must_be_network_address=True)


IpAddress = validated_type(
    String, 'IpAddress',
    validate=validate_ipv4_address
)
Ipv6Address = validated_type(
    String, 'Ipv6Address',
    validate=validate_ipv6_address
)

# For BGP Session modelling
Ipv4OrIpv6Address = validated_type(
    String, 'Ipv4OrIpv6Address',
    validate=validate_ipv4_or_ipv6_address
)

Ipv6AddressOrEmpty = validated_type(
    String, 'Ipv6AddressOrEmpty',
    validate=validate_ipv6_address_or_empty
)

IpAddressOrEmpty = validated_type(
    String, 'IpAddressOrEmpty',
    validate=validate_ipv4_address_or_empty
)


def validate_ipv4_network_address(network_address,
                                  must_be_network_address=False):
    """
    :param network_address: IPV4 Network CIDR (192.0.0.1/24)
    :param must_be_network_address: enable strict validation for hosts zero bits
                                    in specified network_address
    """
    network_address_format = re.compile(
        r'^\d+\.\d+\.\d+\.\d+/([0-9]|1[0-9]|2[0-9]|3[0-2])$')

    if network_address_format.match(network_address) is None:
        raise ValidationError('Invalid IP network address %s' % network_address)

    try:
        address = netaddr.IPNetwork(network_address)
    except (netaddr.core.AddrFormatError, ValueError) as exc:
        raise ValidationError(
            'Invalid IP network address %s' % network_address) from exc

    network_error = '%s does not identify a network subnet, ' \
                    'since host bits must be all zeroes. Did you mean %s?'
    if must_be_network_address:
        if str(address) != str(address.cidr):
            raise ValidationError(network_error % (network_address, address.cidr))


def validate_ipv4_network_address_or_prefix(network_address,
                                            must_be_network_address=False):
    """Checks for valid ipv4 network address or just prefix.

    Prefix is specified as '/29' (note the leading slash).
    """
    prefix_format = re.compile(
        r'^/([0-9]|1[0-9]|2[0-9]|3[0-2])$')

    if prefix_format.match(network_address) is None:
        validate_ipv4_network_address(
            network_address, must_be_network_address=must_be_network_address)


def validate_ipv6_network_address_or_prefix(network_address,
                                            must_be_network_address=False):
    """Checks for valid ipv6 network address or just prefix.

    Prefix is specified as '/128' (note the leading slash).
    """
    # NOTE: use optimized expression, which checks:
    # 0-9, 10-20-30..-90, 11-19-21-29...-91-99, 100-110, 120-128
    # also it exclude 0* values
    prefix_format = re.compile(
        r'^/([0-9]|[1-9]0|[1-9]{2}|1[01][0-9]|12[0-8])$')

    if prefix_format.match(network_address) is None:
        validate_ipv6_network_address(
            network_address,
            error_type='ipv6_only',
            must_be_network_address=must_be_network_address)

# NOTE(skraynev): here and below 'partial' is used for correct processing
# validation functions with more then 1 parameter. It's necessary because:
# - 'validated_type' returns ValidatedSubtype, which uses ValidatorCollection
#   for storing validators.
# - ValidatorCollection during creating or updating list of self._validators
#   calls 'make_context_aware' function, which wrap passed validators in the way
#   to use or ignore 'context' parameter.
#   It's necessary, because all classes inherited from Type pass second argument
#   'context' in 'load method' for each call of validator, see:
#   https://github.com/maximkulkin/lollipop/blob/master/lollipop/types.py#L139
# - Current implementation for ValidatorCollection expects, that validator have
#   at most 1 argument. If it's not True like in methods below, passed method
#   will not be normalized inside 'make_context_aware' function.
#   It means, that context will not be ignored and passed as a second parameter.
#   For example: "validate_ipv6_network_address" will be called with:
#      (network_address, error_type=context, must_be_network_address=False)
#   Note, that previously it worked, because in logic for methods:
#     validate_ipv4_network_address, validate_ipv6_network_address,
#     validate_ipv4_network_address_or_prefix,
#     validate_ipv6_network_address_or_prefix
#   was the same, when parameter equals to default value or None.
#   However, it did not work correct for
#    StrictIpNetworkAddressOrPrefix and StrictIpv6NetworkAddressOrPrefix,
#   because we want to pass True value instead of default False or None.
#
#   'partial' function solves current issue, because it raises TypeError in
#   'make_context_aware' and normalize wrapped method always.

IpNetworkAddress = validated_type(
    String, 'IpNetworkAddress',
    validate=functools.partial(validate_ipv4_network_address)
)

Ipv6NetworkAddress = validated_type(
    String, 'Ipv6NetworkAddress',
    validate=functools.partial(validate_ipv6_network_address)
)

class Ipv6orIpv4NetworkAddress(String):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.validators.insert(0, validate_ipv4_or_ipv6_network_address)

    def load(self, data, *args, **kwargs):
        if isinstance(data, str):
            transformed_data = data.replace(' ', '')
        else:
            transformed_data = data
        return super().load(
            transformed_data, *args, **kwargs
        )

IpNetworkAddressOrPrefix = validated_type(
    String, 'IpNetworkAddressOrPrefix',
    validate=functools.partial(validate_ipv4_network_address_or_prefix)
)

Ipv6NetworkAddressOrPrefix = validated_type(
    String, 'Ipv6NetworkAddressOrPrefix',
    validate=functools.partial(validate_ipv6_network_address_or_prefix)
)

SafeNetworkString = validated_type(
    String, 'SafeNetworkString',
    validate=[
        Length(max=240, min=1),
        # All typable characters on US keyboard except ' ' and '?'
        # Ideally prevents config rendering errors on devices.
        # `~!@#$%^&*()_+-={}[]:";'<>,./
        # Couldn't include {} in error response due to forced format-string
        # parsing downstream, but they are also valid.
        Regexp(r'(?i)^[a-z0-9@#$!%^&+=\\\<\>\(\)\.\*\[\]\-_{}:;\'"\.,/~`]*$', \
               error=r'Invalid string. Only ASCII characters a-Z, 0-9, and '
                     'special typable characters "`~!@#$%^&*()_+-=[]:";\'<>,./" '
                     'are allowed (not including " " and "?")')]
    )


def validate_mac_address(address):
    mac_address_format = re.compile(r'^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$')

    if mac_address_format.match(address) is None:
        raise ValidationError('Invalid Mac address')


def validate_mac_address_or_empty(address):
    if address:
        validate_mac_address(address)
    elif address is None:
        raise ValidationError('Invalid Mac address')


StrictIpNetworkAddressOrPrefix = validated_type(
    String, 'StrictIpNetworkAddressOrPrefix',
    validate=functools.partial(validate_ipv4_network_address_or_prefix,
                               must_be_network_address=True)
)

StrictIpv6NetworkAddressOrPrefix = validated_type(
    String, 'StrictIpv6NetworkAddressOrPrefix',
    validate=functools.partial(validate_ipv6_network_address_or_prefix,
                               must_be_network_address=True)
)

StrictIpNetworkAddress = validated_type(
    String, 'IpNetworkAddress',
    validate=functools.partial(validate_ipv4_network_address,
                               must_be_network_address=True)
)

StrictIpv6NetworkAddress = validated_type(
    String, 'Ipv6NetworkAddress',
    validate=functools.partial(validate_ipv6_network_address,
                               must_be_network_address=True)
)


MacAddress = validated_type(
    String, 'MacAddress',
    validate=validate_mac_address
)

MacAddressOrEmpty = validated_type(
    String, 'MacAddressOrEmpty',
    validate=validate_mac_address_or_empty
)


Hostname = validated_type(
    String, 'Hostname',
    [Length(min=1, max=32),
     Regexp(r'^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*'
            r'([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])$',
            error='Invalid hostname. It may contain only [a-zA-Z0-9] '
                  'groups separated by "." or "-"')]
)

Rackname = validated_type(
    String, 'Rackname',
    [Length(min=1, max=24)]
)


GenericName = validated_type(
    String, 'Name',
    [Length(min=1, max=32)]
)

Label = validated_type(
    String, 'Label',
    Regexp(r'^.*[a-zA-Z]+.*$',
           error='Invalid label')
)


LAG_MODES = ['lacp_active', 'lacp_passive', 'static_lag']
LagModes = Enum(LAG_MODES,
                description='For port-channel interfaces, specifies the LAG '
                            'mode the interface is operating in. LACP Active '
                            'and LACP Passive are used for LACP LAGs. Mode '
                            'static is used for LAGs that do not run LACP at '
                            'all. This option is None for interfaces that '
                            'do not operate as a LAG (Link Aggregation Group)')

OperationState = Enum(['admin_down', 'deduced_down', 'up'],
                      description='Indicates interface state.')

ManagementLevel = Enum(['unmanaged', 'telemetry_only', 'full_control'],
                       description='Indicates the management level of systems. '
                                   'It is mandatory for generic systems, for other '
                                   'systems the management level is derived '
                                   'from system properties.')

OptionalProperty = Enum(['disabled', 'enabled'],
                        description='Indicates whether the property '
                                    'is disabled or enabled')

RackTypeDesign = Enum(['l3clos', 'l3collapsed', 'rail_collapsed'],
                      description='Identifies which template type the rack type can '
                                  'be used for. Possible values "l3clos", '
                                  '"l3collapsed" and "rail_collapsed", default to '
                                  '"l3clos". Design "l3clos" is the traditional '
                                  'design with spines and spine-leaf links. Design '
                                  '"l3collapsed" is used for spineless blueprints '
                                  'with full-mesh connectivity between leafs. '
                                  'Design "rail_collapsed" is used for '
                                  'rail-optimized spineless blueprints.')

SviIpv4AllocationMode = Enum(
    ['disabled', 'enabled', 'forced'],
    description="Identifies an approach to IP address "
                "allocation on a per-SVI basis. 'disabled' "
                "is used when no IP allocation required. IP "
                "overrides are also rejected. 'enabled' "
                "sets the default behavior. Allocates the "
                "SVI address unless it is not necessary for "
                "a current system's DP. 'forced' is used to "
                "unconditionally allocate an IP address for "
                "the SVI.")

SviIpv6AllocationMode = Enum(
    ['disabled', 'link_local', 'enabled', 'forced'],
    description="Identifies an approach to IP address "
                "allocation on a per-SVI basis. 'disabled' "
                "is used when no IP allocation required. IP "
                "overrides are also rejected. 'link_local' "
                "is used when only IPv6 link-local address "
                "is required on SVI. 'enabled' "
                "sets the default behavior. Allocates the "
                "SVI address unless it is not necessary for "
                "a current system's DP. 'forced' is used to "
                "unconditionally allocate an IP address for "
                "the SVI.")

SviIpRequirement = Enum(
    ['forbidden', 'optional', 'mandatory', 'intention_conflict'],
    description="Possible values for svi ip requirement; full description could be "
                "found in sdk/vn_helpers.py")

CELL_TYPE_TO_GENERIC_TYPE = {
    'boolType': 'Boolean',
    'stringType': 'String',
    'u8Type': 'Numeric',
    'u16Type': 'Numeric',
    'u32Type': 'Numeric',
    'u64Type': 'Numeric',
    's8Type': 'Numeric',
    's16Type': 'Numeric',
    's32Type': 'Numeric',
    's64Type': 'Numeric',
    'f32Type': 'Numeric',
    'f64Type': 'Numeric',
}

def validate_route_distinguisher(string):
    # prefix(integer):suffix(integer) or ip(dotted-quad):suffix(integer)
    pattern = r'^((?P<prefix>\d+)|' \
              r'(?P<ip>[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})):' \
              r'(?P<value>\d+)$'

    matches = re.match(pattern, string)
    if not matches:
        raise ValidationError('Invalid RD format, must be in format X:Y where X=IP '
                              'or 2-4 byte value and Y=2-4 byte value. '
                              'Provided value: "%s"' % string)

    prefix = matches.group('prefix')
    suffix = matches.group('value')
    ip = matches.group('ip')

    # Validation for '0' are validated uniquely within their integer range
    # constraints. Check for leading zeroes, eg '0555:555' or '555:0555'.
    # The device would likely accept this configuration, but the route-map policy
    # matching would fail to match on this RT/RD pattern. Telemetry may also become
    # confused for EVPN analytics.
    if prefix and prefix != '0' and (len(prefix) != len(prefix.lstrip('0'))):
        raise ValidationError(
            'RD Type cannot contain leading zeroes in format TYPE:VALUE')
    if suffix and suffix != '0' and (len(suffix) != len(suffix.lstrip('0'))):
        raise ValidationError(
            'RD Value field cannot contain leading zeroes in format TYPE:VALUE')

    if prefix and suffix:
        # Type 0 2-byte ASN:4-byte value
        if 1 <= int(prefix) <= 2**16 -1:
            if 1 <= int(suffix) <= 2 ** 32 -1:
                return True
            else:
                raise ValidationError('Type 0 RD X:Y must be in format '
                                      '2-byte ASN:4-byte value. '
                                      'Provided value: "%s"' % string)

        # Type 2: 4-byte ASN:2-byte value
        if 1 <= int(prefix) <= 2**32 -1:
            if 1 <= int(suffix) <= 2 ** 16 -1:
                return True
            else:
                raise ValidationError('Type 2 RD X:Y must be in format '
                                      '4-byte ASN:2-byte value. '
                                      'Provided value: "%s"' % string)

    # Type 1: 4-byte IP:2-byte ASN
    if ip and suffix:
        validate_ipv4_address(ip)
        if 1 <= int(suffix) <= 2 ** 16 -1:
            return True
        else:
            raise ValidationError('Type 1 RD X:Y must be in format '
                                  '4-byte IP:2-byte value. '
                                  'Provided value: "%s"' % string)

    raise ValidationError('Invalid RD format, must be in format X:Y '
                          'where X=IP or 2-4 byte value and Y=2-4 byte '
                          'value. Provided value: "%s"' % string)

RouteDistinguisher = validated_type(
    String, 'RouteDistinguisher',
    validate=validate_route_distinguisher
)


# RD value and RT value have same format. See RFC8294
RouteTarget = validated_type(
    String, 'RouteTarget',
    validate=validate_route_distinguisher
)


# String for indexer use should not container leading or trailing whitespace,
# and it also cannot be empty string.
IndexString = validated_type(
    String, 'IndexString',
    validate=[Length(min=1), validate_leading_trailing_whitespace]
)


DisplayName = validated_type(
    String, 'DisplayName',
    validate=[Length(min=1, max=64)],
)


class TacEnum(String):
    """Enum schema type for Tac::Enumeration

    TacEnum can transform camel case, TACC backend naming convention, to
    snake case, front-end naming convention automatically.


    Init data should be back-end TACC::Enumeration values which are in camel
    case. It will be transformed to snake case. Load data should be front-end
    snake case data. It will be transformed to camel case.

    Raises:
        TypeError:  If init data is not a list of str
    """
    def __init__(self, choices, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if isinstance(choices, str):
            raise TypeError(f'Invalid type {choices}')
        for choice in choices:
            if not isinstance(choice, str):
                raise TypeError(f'Invalid type {choice}')
        choices = [to_snake_case(choice) for choice in choices]
        self.validators.append(AnyOf(choices, error='Invalid choice {data}'))

    def load(self, data, *args, **kwargs):
        return to_camel_case(
            super().load(to_snake_case(data), *args, **kwargs)
        )

    def dump(self, value, *args, **kwargs):
        return to_snake_case(
            super().dump(value, *args, **kwargs)
        )

class AnomalySeverity(Enum):
    def __init__(self, *args, **kwargs):
        super().__init__(
            ['low', 'medium', 'high', 'critical'],
            *args, **kwargs)


class AnomalyType(Enum):
    def __init__(self, *args, **kwargs):
        super().__init__(
            ['value', 'sum', 'avg', 'sample_count', 'std_dev'],
            *args, **kwargs)


def validate_anomaly_range(anomaly_range):
    range_min = anomaly_range['min']
    range_max = anomaly_range['max']

    # either min or max is optional, min must be less or equal max
    if ((range_min is None and range_max is None)
            or (isinstance(range_min, (int, float))
                and isinstance(range_max, (int, float))
                and range_min > range_max)):
        raise ValidationError('Invalid range')


def anomaly_type_hint(value):
    if isinstance(value, int):
        return 'int'
    elif isinstance(value, float):
        return 'float'
    elif isinstance(value, ((str,), ExpressionValue)):
        return 'expression'
    return 'unknown'


def anomaly_expr_type_hint(value):
    if isinstance(value, int):
        return 'int'
    elif isinstance(value, float):
        return 'float'
    return 'unknown'


class AnomalyRange(Object):
    def __init__(self, default_field_type=IndexField, **kwargs):
        field = OneOf(
            {
                'int': Integer(),
                'float': Float(),
                'expression': Expression(OneOf(
                    {
                        'int': Integer(),
                        'float': Float(),
                    },
                    error_messages={
                        'unknown_type_id': 'Value should be integer or float',
                    },
                    load_hint=anomaly_expr_type_hint,
                    dump_hint=anomaly_expr_type_hint,
                ), validate=Length(min=1)),
            },
            error_messages={
                'unknown_type_id': 'Value should be integer, float or expression',
            },
            load_hint=anomaly_type_hint,
            dump_hint=anomaly_type_hint,
        )

        super().__init__(
            {
                'min': Optional(field, dump_default=MISSING),
                'max': Optional(field, dump_default=MISSING),
            },
            allow_extra_fields=False,
            default_field_type=default_field_type,
            **kwargs)

        self.validators.insert(0, validate_anomaly_range)


POSSIBLE_PROTOCOLS = (PROTOCOL_TCP, PROTOCOL_UDP, PROTOCOL_ICMP, PROTOCOL_IP)


class SecurityRuleProtocolName(Enum):
    def __init__(self, *args, **kwargs):
        super().__init__(
            POSSIBLE_PROTOCOLS,
            description='Protocol name for a security rule.',
            *args, **kwargs)


SecurityRuleProtocolNumber = validated_type(Integer, 'SecurityRuleProtocolNumber',
                                            Range(min=0, max=255))


def validate_security_rule_protocol(protocol):
    try:
        SecurityRuleProtocolNumber().load(int(protocol))
    except ValueError:
        SecurityRuleProtocolName().load(protocol)


class SecurityRuleProtocol(String):
    def __init__(self, *args, **kwargs):
        super().__init__(
            name='SecurityRuleProtocol',
            validate=validate_security_rule_protocol,
            description='Protocol name or number for a security rule.',
            *args, **kwargs)


class SecurityRuleAction(Enum):
    def __init__(self, *args, **kwargs):
        super().__init__(
            ['deny', 'deny_log', 'permit', 'permit_log'],
            description='Action performed by a rule.',
            *args, **kwargs)


class Collection(List):
    def dump(self, items, *args, **kwargs):
        return super().dump(
            list(items.values()), *args, **kwargs)


class TacMappingField(Field):
    def get_value(self, name, obj, context=None):
        return dict(getattr(obj, name))

    def set_value(self, name, obj, value, context=None):
        mapping = getattr(obj, name)
        for k in mapping.keys():
            if k not in value:
                del mapping[k]

        for k, v in value.items():
            mapping[k] = v


class TacEnumField(AttributeField):
    def get_value(self, name, obj, *args, **kwargs):
        value = super().get_value(
            name, obj, *args, **kwargs)
        if not (value is MISSING or value is None):
            return value.value
        return value


class Dot1xPolicyFields:
    # From a model perspective,
    # multi_auth and single_auth are options too, but not supported on EOS or NXOS
    # so are not defined in schema.
    auth_mode = Optional(
        Enum(['multi_host', 'single_host'],
             description="single_host permits traffic only from one endpoint which "
                         "authenticated on the 802.1x port.  All other endpoints "
                         "will not be permitted to communicate on the interface. "
                         "multiple_host mode will move the entire port and all "
                         "endpoints to an authorized state following successful "
                         "authentication from any device on the interface."),
        load_default='multi_host')

    mac_auth_bypass = Optional(
        Boolean(
            description="MAC Authentication Bypass allows a dot1x-enabled port to "
                        "pass a MAC address to the RADIUS server for authentication "
                        "instead of a full EAPOL exchange.  This feature is not "
                        "compatible on trunk interfaces (i.e. interfaces facing "
                        "servers which carry tagged vn_endpoints).  The default "
                        "is to not use MAB.",
        ), load_default=False)
    port_control = Optional(
        Enum(['auto', 'force_authorized', 'force_unauthorized'],
             description='Determines authorization behavior on a port.  "auto" '
                         'enables 802.1x authentication on the port, which will '
                         'by default be unauthorized.  "force_unauthorized" will '
                         'ignore 802.1x on the port, and disallow endpoints to '
                         'communicate on the interface. "force_authorized" will '
                         'skip 802.1x on the port and authorize it immediately. '
                         'This is the default port mode.  If the port is in '
                         'force_authorized mode, it effectively means it is not '
                         'dot1x enabled, so no dot1x commands will be rendered.'),
        load_default='force_authorized')
    reauthentication_timeout = Optional(
        Integer(
            description='If a reauthentication timeout is configured on a port, '
                        'the switch periodically, based on this interval, request '
                        'the client to reauth to the RADIUS server.  If this '
                        'option is not specified, the 802.1x port will remain '
                        'permanently in authorized state until the link goes '
                        'down and no reauthentication will be permitted.',
            validate=[Range(min=1, max=65534)]))
    ##### FACADE FIELDS #####
    # The below properties are not directly used by dot1x policy nodes but are
    # used by facade APIs and config rendering device model, so accumulate their
    # descriptions in one place to reduce ambiguity and duplication during re-use
    # and enhance consistency.
    fallback_virtual_network_id = Optional(
        VirtualNetworkId(
            description='If specified, and supported by the OS platform, specify '
                        'the Virtual network used for the dot1x fallback vlan.  The '
                        'fallback vlan is the virtual network that the client will '
                        'fall back to if dot1x authentication explicitly fails. '
                        'This is otherwise known as a "guest" vlan.  Support of '
                        'fallback vlan is OS Vendor dependent.',
            validate=[Length(min=1)]))


class ValidationSeverityEnum(Enum):
    def __init__(self, *args, **kwargs):
        super().__init__(
            ['error', 'warning', 'no_warning'], *args, **kwargs)


class AAAServerFields:
    # Eg, add TACACS here later.
    server_type = Enum(
        ['radius_dot1x', 'radius_coa'],
        description='Indicates server type of AAA server.  radius_dot1x is for '
                    '802.1x RADIUS servers. radius_coa is for RADIUS Dynamic '
                    'authorization servers that switches accept RADIUS Change of '
                    'authorization packets')
    hostname = Hostname(
        description='Indicates the server IP address or DNS name '
                    'corresponding to the AAA server.')
    key = SafeNetworkString(description="Encryption key used by AAA Server")
    auth_port = Optional(
        Port(),
        description="Authentication port used by AAA server. When the "
                    "server type is radius_coa, the port can only "
                    "be 3799.  If not specified, back-end will choose a default "
                    "port 1812 for radius_dot1x and port 3799 for radius_coa")
    acct_port = Optional(
        Port(),
        description="Accounting port used by AAA server. When the "
                    "server type is radius_coa, the port can not be specified. "
                    "If radius_dot1x, and auth_port is not specified, this will "
                    "default to 1813.  acct_port may also be None, which implies "
                    "not to do AAA Accounting with this RADIUS server.")


class DateTimeISO8601(Type):
    FORMAT = '%Y-%m-%dT%H:%M:%S.%f%z'

    default_error_messages = {
        'invalid': 'Invalid date value',
        'invalid_type': 'Value should be string',
        'invalid_format': 'Value should match date format',
        'no_timezone': 'Timezone info is not present',
    }

    def is_timezone_aware_datetime(self, date):
        """"
        Checks if a given datetime object is timezone aware.
        Returns True if the datetime object is timezone aware, False otherwise.
        """
        return date.tzinfo is not None and date.tzinfo.utcoffset(
            date) is not None

    def load(self, data, *args, **kwargs):
        if data is MISSING or data is None:
            self._fail('required')

        if not isinstance(data, str):
            self._fail('invalid_type', data=data)

        try:
            date = iso8601.parse_date(data, default_timezone=None)
            # Validate timezone aware datetime
            if not self.is_timezone_aware_datetime(date):
                self._fail('no_timezone', data=date, format=self.FORMAT)

            return super().load(date, *args, **kwargs)
        except iso8601.iso8601.ParseError:
            self._fail('invalid_format', data=data, format=self.FORMAT)

    def dump(self, value, *args, **kwargs):
        if value is MISSING or value is None:
            self._fail('required')

        try:
            # Validate timezone aware datetime
            if not self.is_timezone_aware_datetime(value):
                self._fail('no_timezone', data=value, format=self.FORMAT)

            date_str = value.strftime(self.FORMAT)
            if value.utcoffset().total_seconds() == 0:
                date_str = date_str.replace('+0000', 'Z')

            return super()\
                .dump(date_str, *args, **kwargs)
        except (AttributeError, ValueError):
            self._fail('invalid', data=value)


class TimeDelta(Type):
    """Time delta in format <sign><days>[:<seconds>]"""

    ZERO_TIMEDELTA = datetime.timedelta()

    timedelta_re = re.compile(
        '^'
        '(?P<sign>[-+])'
        # days: 0-99999999
        '(?P<days>'
        '[0-9]'
        '|[1-9][0-9]{1,7}'
        ')'
        # seconds: 0-86399
        '(?::(?P<seconds>'
        '[0-9]'
        '|[1-9][0-9]{1,3}'
        '|[1-7][0-9]{4}'
        '|8[0-5][0-9]{3}'
        '|86[0-3][0-9]{2}'
        '))?'
        '$'
    )

    default_error_messages = {
        'invalid': 'Invalid timedelta value',
        'invalid_load_type': 'Value should be string',
        'invalid_dump_type': 'Value should be datetime.timedelta',
        'invalid_format': (
            'Value should match format: '
            '<sign><days>[:<seconds>]. '
            'Where '
            '<sign>: + or -, '
            '<days>: 0-99999999, '
            '<seconds>: 0-86399.'
        ),
        'invalid_timedelta': (
            'Normalized days count should be less than 99999999'
        ),
    }

    def load(self, data, *args, **kwargs):
        if data is MISSING or data is None:
            self._fail('required')

        if not isinstance(data, str):
            self._fail('invalid_load_type', data=data)

        match = self.timedelta_re.match(data)

        if not match:
            self._fail('invalid_format')

        sign = match.group('sign')
        days = int(match.group('days'))
        seconds = int(match.group('seconds') or 0)

        mul = -1 if sign == '-' else 1

        timedelta = mul * datetime.timedelta(days, seconds)

        return super().load(timedelta, *args, **kwargs)

    def dump(self, value, *args, **kwargs):
        if value is MISSING or value is None:
            self._fail('required')

        if not isinstance(value, datetime.timedelta):
            self._fail('invalid_dump_type', data=value)

        sign = '+' if value >= self.ZERO_TIMEDELTA else '-'

        diff = abs(value)

        # Note: datetime.timedelta limits are not symmetric:
        #    min: timedelta(days=-999999999)
        #    max: timedelta(days=999999999, seconds=86399, microseconds=999999)
        # To simplify data format validation TimeDelta schema supports symmetric
        # value range (8 digits for days instead of 9 digits):
        #    min: -99999999:86399
        #    max: +99999999:86399
        # For this reason the provided timedelta is additionally validated here.
        if diff.days > 99999999:
            self._fail('invalid_timedelta')

        if diff.seconds != 0:
            return '{sign}{days}:{seconds}'.format(
                sign=sign, days=diff.days, seconds=diff.seconds
            )

        timedelta = f'{sign}{diff.days}'

        return super().dump(timedelta, *args, **kwargs)


class Expression(Type):
    default_error_messages = {
        'invalid': 'Invalid expression',
        'invalid_load_type': 'Value should be string',
        'invalid_dump_type': 'Value should be an expression',
    }

    def __init__(self, result_type=None, types=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.result_type = result_type

    def load(self, data, *args, **kwargs):
        if data is MISSING or data is None:
            self._fail('required')

        if not isinstance(data, str):
            self._fail('invalid_load_type', data=data)

        try:
            value = ExpressionValue(data, result_type=self.result_type)
        except ValueError:
            self._fail('invalid', data=data)

        return super().load(value, *args, **kwargs)

    def dump(self, value, *args, **kwargs):
        if value is MISSING or value is None:
            self._fail('required')

        if not isinstance(value, ExpressionValue):
            self._fail('invalid_dump_type', data=value)

        return super().dump(value.source, *args, **kwargs)


class _AstNodeAttributeVisitor(ast.NodeVisitor):
    def visit_Attribute(self, node):  # pylint: disable=invalid-name
        if node.attr.startswith('_'):
            raise ValidationError(
                "Access to attribute with name started from underscore is "
                f"not allowed: {node.attr}"
            )
        self.generic_visit(node)


class ExpressionValue:
    __slots__ = (
        'source',
        'code',
        'ast',
        'result_type',
        'constant',
        'constant_value',
        'types',
    )

    default_types = {
        'bool': Boolean(),
        'float': Float(),
        'int': Integer(),
        'str': String(),
    }

    # This is done mostly to exclude the following built-ins:
    # compile, eval and exec, locals, globals and __import__, and some other ones
    # which are irrelevant, such as dir, help, etc.
    allowed_builtins = {
        name: __builtins__[name]
        for name in (
            'abs',
            'all',
            'any',
            'ascii',
            'bin',
            'bool',
            'bytearray',
            'bytes',
            'chr',
            'complex',
            'dict',
            'divmod',
            'enumerate',
            'filter',
            'float',
            'format',
            'frozenset',
            'hash',
            'hex',
            'id',
            'int',
            'iter',
            'len',
            'list',
            'map',
            'max',
            'min',
            'next',
            'oct',
            'ord',
            'pow',
            'range',
            'repr',
            'reversed',
            'round',
            'set',
            'slice',
            'sorted',
            'str',
            'sum',
            'tuple',
            'zip',
        )
    }

    def __init__(self, source, result_type=None, types=None):
        self.source = source
        self.result_type = result_type
        self.types = types or self.default_types

        self.code = None
        self.ast = None
        self.constant = not self.source
        self.constant_value = None

        if self.source:
            try:
                self.ast = compile(self.source, 'ExpressionValue', 'eval',
                                   ast.PyCF_ONLY_AST, dont_inherit=True)
            except SyntaxError as err:
                raise ValueError(f"Could not parse expression: {err}") from err

            self._check_underscore_attributes()

            value_type = None

            if (isinstance(self.ast.body, ast.Call)
                    and isinstance(self.ast.body.func, ast.Name)
                    and self.ast.body.func.id in self.types):
                value_type = self.types[self.ast.body.func.id]
            elif (isinstance(self.ast.body, ast.Call)
                    and isinstance(self.ast.body.func, ast.Attribute)
                    and self.ast.body.func.attr == 'format'
                    and isinstance(self.ast.body.func.value, ast.Constant)
                    and isinstance(self.ast.body.func.value.value, str)):
                # A str.format() method call, e.g. `'{}'.format(123)`
                if 'str' in self.types:
                    value_type = self.types['str']
            elif (isinstance(self.ast.body, ast.BinOp)
                    and isinstance(self.ast.body.op, ast.Mod)
                    and isinstance(self.ast.body.left, ast.Constant)
                    and isinstance(self.ast.body.left.value, str)):
                # An old string formatting `format % value`, e.g. `'%s' % 123`
                if 'str' in self.types:
                    value_type = self.types['str']
            elif isinstance(self.ast.body, ast.JoinedStr):
                # A formatted string literal or f-string, e.g. `f{val}`
                if 'str' in self.types:
                    value_type = self.types['str']
            elif isinstance(self.ast.body, (ast.Num, ast.UnaryOp)):
                if isinstance(self.ast.body, ast.UnaryOp):
                    # Negative numeric literal in python 3
                    assert isinstance(self.ast.body.operand, ast.Num)
                    self.constant_value = self.ast.body.operand.n
                    if isinstance(self.ast.body.op, ast.USub):
                        self.constant_value = -self.constant_value  # pylint: disable=invalid-unary-operand-type
                else:
                    # Positive numeric literal in python 3 or any
                    # numeric literal in python 2
                    self.constant_value = self.ast.body.n

                if (isinstance(self.constant_value, int)
                        and 'int' in self.types):
                    value_type = self.types['int']
                elif (isinstance(self.constant_value, float)
                      and 'float' in self.types):
                    value_type = self.types['float']
                self.constant = True
            elif isinstance(self.ast.body, ast.Str):
                self.constant_value = self.ast.body.s
                if 'str' in self.types:
                    value_type = self.types['str']
                self.constant = True
            elif (isinstance(self.ast.body, ast.Name)
                  and self.ast.body.id in ('True', 'False')):
                # Boolean literal in python 2
                self.constant_value = self.ast.body.id == 'True'
                if 'bool' in self.types:
                    value_type = self.types['bool']
                self.constant = True
            elif (six.PY3 and isinstance(self.ast.body, ast.NameConstant)
                  and self.ast.body.value in (True, False)):
                # Boolean literal in python 3. six.PY3 check is needed because
                # ast.NameConstant is defined only in python 3.
                self.constant_value = self.ast.body.value
                if 'bool' in self.types:
                    value_type = self.types['bool']
                self.constant = True

            if not self.constant_value:
                self.code = compile(self.source, 'ExpressionValue', 'eval',
                                    dont_inherit=True)

            if not self.result_type:
                self.result_type = value_type

        if self.constant and self.result_type:
            self.constant_value = self.result_type.load(self.constant_value)

    def __call__(self, **globals):
        if self.constant:
            return self.constant_value

        # Explicit pass dict of allowed __builtins__ to avoid executing unsafe code
        if '__builtins__' in globals:
            raise ValueError('"__builtins__" is not allowed in globals')
        result = eval(self.code, {'__builtins__': self.allowed_builtins} | globals)

        if self.result_type:
            return self.result_type.load(result)

        return result

    def __str__(self):
        return six.ensure_text(self.source)

    def __hash__(self):
        return hash(('exp', self.source, self.result_type))

    def __eq__(self, other):
        if isinstance(other, self.__class__):
            return (
                self.source == other.source
                and self.result_type == other.result_type
            )
        return NotImplemented

    def __len__(self):
        return len(self.source)

    def __repr__(self):
        return '<ExpressionValue({source!r}, result_type={type})>'.format(
            source=self.source,
            type=self.result_type,
        )

    def _check_underscore_attributes(self):
        _AstNodeAttributeVisitor().visit(self.ast)


TYPES = TypeRegistry()
ERRORS = TYPES.add(
    'ERRORS', OneOf([String(), List(String()), Dict(TYPES['ERRORS'])]),
)
ERROR_MESSAGES = Dict({'errors': ERRORS}, name='ErrorMessages')


class ErrorContext(Modifier):
    def __init__(self, path, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.path = path

    def _wrapped_path(self, path, message):
        parts = path.split('.', 1)
        if len(parts) == 1:
            return {parts[0]: message}

        return {parts[0]: self._wrapped_path(parts[1], message)}

    def load(self, data, context=None):
        try:
            return self.inner_type.load(data, context=context)
        except ValidationError as ve:
            raise ValidationError(self._wrapped_path(self.path, ve.messages))

    def dump(self, value, context=None):
        try:
            return self.inner_type.dump(value, context=context)
        except ValidationError as ve:
            raise ValidationError(self._wrapped_path(self.path, ve.messages))


class InterfaceCounterField(OneOf):
    """Field for interface counter type.

    Based on OneOf with a list of string constants. Unlike enum,
    allows to expose human-readable labels for counter types
    in json schema.
    """

    def __init__(self, counters, *args, **kwargs):
        super().__init__(
            [Constant(counter_code, field_type=String(),
                      name=counter_info.label)
             for counter_code, counter_info in counters],
            error_messages={
                'no_type_matched': 'Invalid counter value'},
            *args, **kwargs
        )

    def dump(self, data, *args, **kwargs):
        return String().dump(data)


class ObjectWithIndexField(Object):
    """Object with field type IndexField."""

    def __init__(self, *args, **kwargs):
        super().__init__(default_field_type=IndexField, *args, **kwargs)


def validate_prefix_list_entry(prefix_list_entry):
    """ Validates semantics of individual prefix-list entries.  Perform validation
        as early as possible to prevent impossible data in the graph/API layer.

        Violation of these policies is a violation of intent and will cause deploy
        errors when rendering configurations that fail these validations.

        The IP Prefix itself is already validated by Ipv6orIpv4NetworkAddress
     """

    prefix = prefix_list_entry['prefix']
    le_mask = prefix_list_entry.get('le_mask')
    ge_mask = prefix_list_entry.get('ge_mask')

    network = netaddr.IPNetwork(prefix)

    errors = ValidationErrorBuilder()

    def validate_masklen(field):

        # Field is optional, so None and missing are valid values
        if prefix_list_entry.get(field) is None:
            return

        # ipv4 le_mask and ge_mask must be between 0-32
        if network.version == 4 and not 0 <= prefix_list_entry[field] <= 32:
            errors.add_error(field, '{} {} - ipv4 {} must be between 0-32'.format(
                field, prefix_list_entry[field], network))

        # ipv6 le_mask and ge_mask must be between 0-128
        # This will also be validated in PrefixListEntry field validation.
        if network.version == 6 and not 0 <= prefix_list_entry[field] <= 128:
            errors.add_error(field, '{} {} - ipv6 {} must be between 0-128'.format(
                field, prefix_list_entry[field], network))

        # Supplied field must be longer than the subnet prefix length
        # ensure le_mask > prefixlen and ge_mask > prefixlen
        if not prefix_list_entry[field] > network.prefixlen:
            errors.add_error(
                field,
                '{}: {} {} must be greater than subnet prefix length {}'.format(
                    network, field, prefix_list_entry[field],
                    network.prefixlen))

    validate_masklen('le_mask')
    validate_masklen('ge_mask')

    # if ge_mask and le_mask are both present, then le_mask must be greater than
    # ge_mask
    if le_mask is not None and ge_mask is not None:
        if not le_mask > ge_mask:
            errors.add_error(
                'ge_mask',
                '%s: le_mask %s must be greater than ge_mask %s'
                % (network, le_mask, ge_mask))
    errors.raise_errors()


PrefixListPrefix = Ipv6orIpv4NetworkAddress(
    name='Prefix',
    description='IPv4 or IPV6 network address, specified in the form of '
                'network/prefixlen.',
)
PrefixListLeMask = Integer(
    validate=[Range(0, 128)],
    name="More-specific prefixes mask",
    description="Match more-specific prefixes from a parent prefix, "
                "up until le_mask prefix len. Range is 0-32 for "
                "IPv4, 0-128 for IPv6. If not specified, implies "
                "the prefix-list entry should be an exact match. "
                "This option can be optionally be used in "
                "combination with ge_mask.  le_mask must be "
                "longer than the subnetprefix length.  If le_mask "
                "and ge_mask are both specified, then le_mask must "
                "be greater than ge_mask.",
)
PrefixListGeMask = Integer(
    validate=[Range(0, 128)],
    name="Less-specific prefixes mask",
    description="Match less-specific prefixes from a parent prefix, "
                "up from ge_mask to the prefix length of the route. "
                "Range is 0-32 for IPv4, 0-128 for IPv6. If not "
                "specified, implies the prefix-list entry should "
                "be an exact match. This option can be optionally "
                "be used in combination with le_mask. ge_mask must "
                "be longer than the subnet prefix length. If "
                "le_mask and  ge_mask are both specified, then "
                "le_mask must be greater than ge_mask.",
)
PrefixListEntry = Dict(
    {
        'prefix': PrefixListPrefix,
        'le_mask': Optional(PrefixListLeMask),
        'ge_mask': Optional(PrefixListGeMask),
        'action': Optional(
            Enum(['permit', 'deny'],
                 description="If the action is permit, match the route. If the "
                             "action is deny, do not match the route. For composing "
                             "complex policies, all prefix-list items will be "
                             "processed in the order specified, top-down.  This "
                             "allows the user to deny a subset of a route that may "
                             "otherwise be permitted."),
            load_default='permit'),
        'description': SparseOptional(
            Description(),
            description="Optional description for the specific entry of a custom "
                        "prefix list. This description will not be included in "
                        "rendered configuration, it is only for visual annotation "
                        "of the policy in the UI."
        ),
    },
    description="IPv4 or IPV6 prefix-list entries are used with extra_import_routes "
                "or extra_export_routes, to compose RoutesFromExt and RoutesToExt "
                "prefix-list items.  Prefix-lists are composed top-to-bottom, "
                "permitting complex import and export policy filtering. The "
                "fully rendered prefix-list will contain items from user-specified "
                "prefix-list items, followed by merged reference design "
                "prefix-list items.  The default behavior for a prefix-list item is "
                "to permit only the exact-match, unless the le_mask and ge_mask are "
                "specified.",
    validate=validate_prefix_list_entry,
)


SystemId = validated_type(
    String, 'SystemId', Length(min=1, max=120))


class VirtualInfraType(Enum):
    def __init__(self, *args, **kwargs):
        super().__init__(
            ['vcenter', 'nsx', 'nutanix'],
            description='Indicates the type of virtual infrastructure',
            *args, **kwargs)


# The value defined in the Enum field is and needs to be in sync with
# leblon/sdk/reference_design/two_stage_l3clos/schema.py#virtual_network.vn_type
# And they are a subset of virtual_network.vn_type
class VnetRemediationPolicyVnetType(Enum):
    def __init__(self, *args, **kwargs):
        super().__init__(
            ['vlan', 'vxlan'],
            description='Indicates the type of virtual network to create as part of '
                        'remediating VLAN mismatch anomalies. \"security_zone\" '
                        'must be selected as well indicating the routing zone in '
                        'which such virtual networks are created. When \"vlan\" is '
                        'selected, routing zone must be default routing zone',
            *args, **kwargs)

def to_upper_case(string):
    return string.upper()

PortSpeed = Transform(Enum([
    '10M', '10m',
    '100M', '100m',
    '1G', '1g',
    '2500M', '2500m',
    '5G', '5g',
    '10G', '10g',
    '25G', '25g',
    '40G', '40g',
    '50G', '50g',
    '100G', '100g',
    '150G', '150g',
    '200G', '200g',
    '400G', '400g',
    '800G', '800g'
    # New options must be added at the end
]), post_load=to_upper_case)


def validate_ospf_domain_id(domain_id):
    valid = is_ipv4_address(domain_id)
    if valid:
        return
    try:
        id = int(domain_id)
    except:
        raise ValidationError('Invalid ospf domain id %s' % domain_id)
    if id >= 0 and id <= 2**32-1:  # pylint: disable=chained-comparison
        valid = True
    if not valid:
        raise ValidationError('Invalid ospf domain id %s' % domain_id)


OspfDomainId = validated_type(
    String, 'OspfDomainId',
    validate=validate_ospf_domain_id
)


TagLabel = validated_type(
    String, 'TagLabel',
    validate=[
        Length(min=1, max=64),
        Regexp(
            r'^(\S+(\s+\S+)*)*$',
            error='Label cannot start or end with space-characters',
        ),
    ],
)


TenantLabel = validated_type(
    String, 'TenantLabel',
    validate=[
        Length(min=1, max=64),
        Regexp(
            r'^[a-zA-Z0-9_-]*$',
            error='Tenant label should be alphanumeric with \'-\' and \'_\' '
                  'characters allowed',
        ),
    ],
)


PortChannelNumber = validated_type(
    Integer, validate=Range(min=0, max=MAX_PORT_CHANNEL_NUMBER))

Mtu = validated_type(
    Integer, validate=[
        Range(min=MIN_L3_MTU, max=MAX_L3_MTU),
        Predicate(
            lambda value: value % 2 == 0,
            error='L3 MTU value must be even')])


# EVPN: parse_esi failed: The first octet of a user-defined ESI must be 0 in instance
EvpnInterconnectESIMac = validated_type(
    String, 'EvpnInterconnectESIMac',
    validate=[
        Length(exact=17),
        Regexp(r'([0-9a-f]{2}:){5}([0-9a-f]{2})',
               error='Invalid interconnect ESI MAC. Must be a 6-octet MAC address '
                     'in the format xx:xx:xx:xx:xx:xx where xx is '
                     '0-9a-f, lower-cased')]
    )

# Used with virtual_network_policy.frr_rd_vlan_offset
# if frr_rd_vlan_offset is enabled, route distinguisher's VLAN ID component
# has 10000 added to it to avoid kernel race conditions between FRR Auto-RD and
# rendered RD on the device: changes '192.168.0.1:100' -> '192.168.0.1:10100'
# to avoid any possible overlap with automatically instantiated EVPN VNI RDs.
FRR_RD_VLAN_OFFSET = 10000

# Juniper Qfx series only supports vlan-aware models for EPVN, where 1 switching
# instance is mapped to multiple VLANs, this route target is per EVI RT,
# which must be common across the fabric for all switches participating in one
# EVI. And it also must not overlap with any existing EVI (L2VNI) RTs
DEFAULT_FABRIC_EVI_RT = '100:100'

# Juniper default value for duplicate mac auto recovery time. This is the recovery
# time the device waits before the duplicate MAC address is unsuppressed. The
# duplicate mac detection time by default is 180 secs. Recovery time is set to
# 9 minutes which is 3x the duplicate mac detection time.
DEFAULT_DUP_MAC_RECOVERY_TIME = 9


class UniqueNodeIds(List):
    def __init__(self, **kwargs):
        kwargs['validate'] = [Unique(), Length(min=1)]
        super().__init__(NodeId(), **kwargs)


ANY_PROPERTY = object()


def validate_json_string(value):
    try:
        json.loads(value)
    except Exception as exc:  # pylint: disable=broad-except
        six.raise_from(ValidationError(str(exc)), exc)


JSONString = validated_type(
    String,
    'JSONString',
    validate_json_string)


JSONKVMap = JSONString(
    description='JSON representation of a key-value map')


def validate_tags_uniqueness(data):
    tag_labels = {tag.lower() for tag in data}

    if len(data) != len(tag_labels):
        raise ValidationError('All tag labels have to be unique.')


class TagList(List):
    def __init__(self, **kwargs):
        super().__init__(
            TagLabel(),
            validate=validate_tags_uniqueness,
            **kwargs
        )

VALID_FLOWSET_TABLE_SIZE = (256, 512, 1024, 2048, 4096, 8192, 16384, 32768)

def validate_flowset_table_size(flowset_table_size):
    if flowset_table_size not in VALID_FLOWSET_TABLE_SIZE:
        raise ValidationError(
            f'flowset_table_size must be one '
            f'of {VALID_FLOWSET_TABLE_SIZE}')

FlowsetTableSize = validated_type(
    Integer, 'FlowsetTableSize',
    validate=validate_flowset_table_size
)


# TODO: Replace with enum.StrEnum after upgrade to python 3.11
class MetaEnum(type):
    def __new__(mcs, cls, bases, attrs):
        attrs[f'_{mcs.__name__}__options'] = tuple(
            value for key, value in attrs.items() if not key.startswith('_')
        )
        return super().__new__(mcs, cls, bases, attrs)

    def __contains__(cls, x):
        return x in cls.__options

    def __iter__(cls):
        return iter(cls.__options)

class FabricConnectivityDesigns(metaclass=MetaEnum):
    L3CLOS = 'l3clos'
    L3COLLAPSED = 'l3collapsed'
    RAIL_COLLAPSED = 'rail_collapsed'

class DependentKeys(Validator):
    """Validator that raises an error if more than one dictionary key is required
    to be non-empty in a dictionary collection.
    Validator that succeeds if items in collection are unqiue.
    By default items themselves should be unique, but you can specify a custom
    function to get uniqueness key from items.

    :param key_groups: Lists of key groups that have dependencies between each
        other
    :param str error: Error message raised when a key value is specified and a
        dependent key is not also specified.
        Can be interpolated with ``data`` (the key-values that are provided)
        and ``keys`` (The list of dependent keys that must all be provided).
    """

    default_error_messages = {
        'dependent_keys': 'When dependent key values are provided, '
                          'all dependent key groups {key_groups} must be '
                          'provided: {data}',
    }

    def __init__(self, *key_groups: list[str], error=None, **kwargs):
        super(DependentKeys, self).__init__(**kwargs)
        self.key_groups = key_groups
        if error is not None:
            self._error_messages['dependent_keys'] = error

    def __call__(self, value, context=None):
        error_keys = []
        error_values = []
        for key_group in self.key_groups:
            values = {key: value.get(key, None) for key in key_group}
            if not len(set(bool(i) for i in values.values())) == 1:
                error_keys.append(key_group)
                error_values.append(values)
        if error_keys:
            self._fail('dependent_keys',
                       data=error_values, key_groups=error_keys)

    def __repr__(self):
        return '<{klass}>'.format(klass=self.__class__.__name__)
