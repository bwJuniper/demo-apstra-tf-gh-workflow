# Copyright 2024-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import annotations

import collections
import statistics
import typing as t


if t.TYPE_CHECKING:
    class StatsSpec(t.TypedDict):
        total: int
        min: int
        max: int
        mean: float
        median: float
        mode: float | None
        variance: float | None
        std_dev: float | None


def get_dataset_for_dict(mapping: dict[t.Any, t.Any],
                         get_elem: t.Callable[[t.Any], t.Any] = lambda x: x
                         ) -> list:
    """ Convert dict to format acceptable for statistics generation. """
    return sorted([get_elem(v) for v in mapping.values()])


def get_histogram(mapping: dict[t.Any, t.Any],
                  get_elem: t.Callable[[t.Any], t.Any] = lambda x: x
                  ) -> collections.Counter:
    """ Get histogram from dict. """
    return collections.Counter(get_dataset_for_dict(mapping, get_elem))


def get_stats(dataset: list) -> StatsSpec:
    """ Get basic statistic from the dataset. """
    stats = {
        'total': sum(dataset),
        'min': 0,
        'max': 0,
        'mean': 0,
        'median': 0,
        'mode': None,
        'variance': None,
        'std_dev': None,
    }

    def _(_stats):
        if t.TYPE_CHECKING:
            return t.cast(StatsSpec, _stats)
        return _stats

    if not stats['total']:
        return _(stats)

    stats['min'] = min(dataset)
    stats['max'] = max(dataset)
    stats['mean'] = statistics.mean(dataset)
    stats['median'] = statistics.median(dataset)
    stats['mode'] = statistics.mode(dataset)

    if len(dataset) < 2:
        return _(stats)

    stats['variance'] = statistics.variance(dataset)
    stats['std_dev'] = statistics.stdev(dataset)
    return _(stats)
