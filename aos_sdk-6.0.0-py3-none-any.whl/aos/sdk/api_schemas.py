# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""Schema definitions for AOS API payloads"""

__all__ = [
    'PortSpeedSchema',
]


import aos.sdk.schema as s


PortSpeedSchema = s.Object({
    'value': s.Integer(validate=s.Range(min=1)),
    'unit': s.String(validate=s.AnyOf(['M', 'G'])),
}, name='PortSpeed')
