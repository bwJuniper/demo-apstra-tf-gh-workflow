#!/usr/bin/env python3
# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula
# pylint: disable=invalid-name
# pylint: disable=line-too-long
"""
Module to translate structured data to AOS Rest API calls
"""

from __future__ import annotations

import json
import functools
import inspect
import logging
import re
import time
import textwrap
import typing as t
import urllib.parse

import flask

from aos.sdk import schema as s
from aos.sdk import http_test_client
from aos.sdk.graph import dict_to_graph, Node, Relationship, DummyNodeSchema
from aos.sdk.http_test_client import ClientError, api
from aos.sdk.utils import with_async_state

if t.TYPE_CHECKING:
    import collections.abc

    import google.protobuf.message
    import lollipop.types
    import requests
    import typing_extensions as te
    import werkzeug.test

    from aos.sdk import typing as tt


    T = t.TypeVar('T')
    P = t.ParamSpec('P')

    _MAGIC: t.Any
    aos: t.Any


HTTP_2xx: t.Final[set[tt.HTTPStatusCode]] = set(range(200, 300))
HTTP_2xx_AS_LIST: t.Final[list[tt.HTTPStatusCode]] = list(range(200, 300))
PARAM_RE: t.Final[re.Pattern] = re.compile(r'^/(?:[^{]+/)*?\{(.+)\}$')


def _klass_attrs(klass: type) -> dict[str, t.Any]:
    return {
        name: getattr(klass, name)
        for name in dir(klass)
        if name == '__doc__' or not name.startswith('__')
    }


def _merge_attrs(
    attrs1: dict[str, t.Any],
    attrs2: dict[str, t.Any]
) -> dict[str, t.Any]:
    merged = {}
    for attr, value1 in attrs1.items():
        if attr not in attrs2 or attrs2[attr] == value1:
            merged[attr] = value1
            continue

        value2 = attrs2[attr]

        if isinstance(value1, http_test_client.ApiNamespace) and \
                isinstance(value2, http_test_client.ApiNamespace):
            if not value1.param and value1.path != value2.path:
                raise ValueError('Incompatible APIs: %s points to both %s and %s' % (
                    attr, value1.path, value2.path,
                ))

            api_attrs = _merge_attrs(_klass_attrs(value1.klass),
                                     _klass_attrs(value2.klass))
            merged[attr] = api(value1.path)(type(
                value1.klass.__name__,
                (Api,),
                api_attrs
            ))
            continue

        merged[attr] = value2

    for attr, value2 in attrs2.items():
        if attr in merged:
            continue

        merged[attr] = value2

    return merged


def wrap_qe_response(response: tt.JSON) -> list[dict[str, Node | None]]:

    def build_object(obj_dict: dict[str, t.Any]) -> Node | None:
        # this can happen with optional named matchers in the query
        if obj_dict is None:
            return None

        # TODO (Rags): AOS does not support returning matched relations today
        node_type = obj_dict.pop('type')
        return Node(
            DummyNodeSchema(node_type), obj_dict.pop('id'),
            properties=obj_dict,
        )

    return [
        {
            matcher_name: build_object(matched_object)
            for matcher_name, matched_object in t.cast(
                dict[str, dict[str, t.Any]], matched_path
            ).items()
        }
        for matched_path in response['items']  # type: ignore
    ]


class ApiMeta(http_test_client.ApiMeta):
    def __new__(
        mcs,
        name: str,
        bases: tuple[type],
        attrs: dict[str, t.Any],
        **kwargs,
    ) -> type:
        merged_attrs: dict[str, t.Any] = {}
        for base in bases:
            merged_attrs = _merge_attrs(merged_attrs, _klass_attrs(base))

        merged_attrs = _merge_attrs(merged_attrs, attrs)

        param_apis = {
            attr_name: attr_value
            for attr_name, attr_value in merged_attrs.items()
            if isinstance(attr_value, http_test_client.ApiNamespace)
            and attr_value.param
        }
        if len(param_apis) > 1:
            raise ValueError(
                f'Multiple index APIs are not supported: {param_apis}')
        elif len(param_apis) == 1:
            param_api = next(iter(param_apis.values()))

            def getitem(self, param_value: str) -> Api:
                quoted_param_value = urllib.parse.quote(param_value)
                return param_api.klass(
                    self._client, f'{self._url}/{quoted_param_value}',
                )

            merged_attrs['__getitem__'] = getitem

        annotations: dict[str, dict[str, str]] = {}
        docstrings: dict[str, str] = {}

        def annotate(
            func: t.Callable[P, T],
            anns: dict[str, str]
        ) -> t.Callable[P, T]:
            def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
                return func(*args, **kwargs)

            wrapper = functools.update_wrapper(wrapper, func)

            sig = inspect.signature(func)
            replace_args: dict[str, t.Any] = {
                'parameters': []
            }
            if 'return' in anns:
                replace_args['return_annotation'] = anns['return']

            for param in sig.parameters.values():
                if param.name in anns:
                    param = param.replace(annotation=anns[param.name])
                replace_args['parameters'].append(param)

            setattr(wrapper, '__signature__', sig.replace(**replace_args))

            return wrapper

        for defn, value in kwargs.items():
            value = str(value)

            match defn.split('__', maxsplit=1):
                case '', arg if arg not in merged_attrs:
                    raise ValueError(f'Parameter {arg} is absent')
                case '', arg:
                    docstrings[arg] = value
                case name_, _ if name_ not in merged_attrs:
                    raise ValueError(f'Parameter {name_} is absent')
                case name_, arg:
                    key = arg or 'return'
                    annotations.setdefault(name_, {})[key] = value

        for _name, anns in annotations.items():
            merged_attrs[_name] = annotate(merged_attrs[_name], anns)

        def wrap_func(old_func: t.Callable[P, T], doc: str) -> t.Callable[P, T]:
            @functools.wraps(old_func)
            def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
                return old_func(*args, **kwargs)

            setattr(wrapper, '__doc__', doc.strip())

            return wrapper

        for _name, doc in docstrings.items():
            merged_attrs[_name] = wrap_func(merged_attrs[_name], doc)

        # pylint: disable=too-many-function-args
        return super().__new__(mcs, name, bases, merged_attrs)


# pylint: disable=invalid-metaclass
class Api(http_test_client.Api, metaclass=ApiMeta):
    '''Base class that represents a segment of URL path of AOS API.

    AOS API is based upon REST concept: each method has corresponding
    endpoint that is bound to a specific URL path. For example:

    ::

        /api/blueprints/xxx/1

    can be represented as

    .. code-block:: python

        api = Client(...)
        api.blueprints.xxx['1'].get()

    Api present a segment like ``blueprints`` or ``xxx`` in the example: it
    has a mapping to URL path and provides some set of methods to access
    this endpoint.
    '''

    def raw_request(
        self,
        url: tt.Url,
        method: t.Optional[tt.HTTPMethod] = None,
        headers: t.Optional[tt.HTTPHeaders] = None,
        data: t.Optional[tt.JSON] = None,
        **kwargs: te.Unpack[tt.RequestsRequestKwargs],
    ) -> tt.HTTPResponse:
        '''Perform a low-level HTTP request to the endpoint.

        :param url: a segment that is concatenated with a currently bound prefix.
        :param method: :rfc:`HTTP request method <7231#section-4>`.
        :param headers: :rfc:`HTTP headers <7231#section-5>` to pass with
            a request.
        :param data: HTTP request body to pass. AOS API works with JSON,
            so this data, if provided, should be jsonable (i.e, correctly treated
            by :py:func:`json.encode`)
        '''
        return self._client._raw_request(
            url=self._url + (url or ''),
            method=method,
            headers=headers,
            data=data,
            **kwargs
        )

    def request(
        self,
        url: tt.Url,
        method: t.Optional[tt.HTTPMethod] = None,
        headers: t.Optional[tt.HTTPHeaders] = None,
        data: t.Optional[tt.JSON] = None,
        **kwargs: te.Unpack[tt.RequestsRequestKwargs],
    ) -> tt.JSON:
        '''Perform a simple HTTP request to endpoint and take
        parsed JSON body only.

        :param url: a segment that is concatenated with a currently bound prefix.
        :param method: :rfc:`HTTP request method <7231#section-4>`.
        :param headers: :rfc:`HTTP headers <7231#section-5>` to pass with
            a request.
        :param data: HTTP request body to pass. AOS API works with JSON,
            so this data, if provided, should be jsonable (i.e, correctly treated
            by :py:func:`json.encode`)
        '''
        return self._client._request(
            url=self._url + (url or ''),
            method=method,
            headers=headers,
            data=data,
            **kwargs
        )


class RestResource(Api):
    '''Basic class for API segments that represent singular resource.

    In terms of CRUD operations, we expect that resource can be
    Created, Retrieved, Updated, Deleted.
    '''

    if t.TYPE_CHECKING:
        class TReadKwargs(tt.RequestsRequestKwargs, total=False):
            headers: tt.HTTPHeaders
            data: tt.JSON

        class TWriteKwargs(tt.RequestsRequestKwargs, total=False):
            headers: tt.HTTPHeaders

    def get(self, **kwargs: te.Unpack[RestResource.TReadKwargs]) -> tt.JSON:
        '''Retrieve a resource content from an endpoint.'''
        return self._request(method='GET', **kwargs)

    def update(
        self,
        data: tt.JSON,
        **kwargs: te.Unpack[RestResource.TWriteKwargs],
    ) -> tt.JSON:
        '''Update resource with a given data.

        :param data: Data to update resource with.
        '''
        return self._request(method='PUT', data=data, **kwargs)

    def patch(
        self,
        cmds: tt.JSON,
        **kwargs: te.Unpack[RestResource.TWriteKwargs],
    ) -> tt.JSON:
        '''Partially update resource with a given data. The difference to
        :py:meth:`update` is that it updates only given fields, not replacing
        the whole object.

        :param cmds: Data to update resource with.
        '''
        return self._request(method='PATCH', data=cmds, **kwargs)

    def delete(self, **kwargs: te.Unpack[RestResource.TReadKwargs]) -> tt.JSON:
        '''Deletes resource.'''
        response = self._request(method='DELETE', **kwargs)
        self._client.remove_cleanup(self._url)
        return response


class RestResources(Api):
    '''Basic class that represent a collection of resources.'''
    resource = api('/{resource_id}')(RestResource)

    def list(self, **kwargs: te.Unpack[RestResource.TReadKwargs]) -> tt.JSON:
        '''Retrieve a list of resources from endpoint.'''
        response = self._request(method='GET', **kwargs)
        if response:
            return t.cast(dict, response).get('items', None)
        return None

    def options(
        self,
        **kwargs: te.Unpack[RestResource.TReadKwargs],
    ) -> tt.JSON:
        '''Get a list of options for a collection of resources.'''
        response = self._request(method='OPTIONS', **kwargs)
        if response:
            return t.cast(dict, response).get('items', None)
        return None

    def create(
        self,
        data: tt.JSON,
        **kwargs: te.Unpack[RestResource.TWriteKwargs],
    ) -> tt.JSON:
        '''Create a new resource within collection.

        :param data: A data to create resource with.
        '''
        result = self._request(method='POST', data=data, **kwargs)
        if isinstance(result, dict) and 'id' in result:
            self._client.add_cleanup(
                f'{self._url}/{urllib.parse.quote(str(result["id"]))}',
                # pylint: disable=unsubscriptable-object
                self[result['id']].delete,  # type: ignore[index]
            )
        return result


def resources(
    url_path: tt.UrlPath,
    *,
    get_schema: str = '',
    collection_schema: str = '',
    post_schema: str = '',
    put_schema: str = '',
    patch_schema: str = '',
    with_options: bool = False,
    resource_doc: t.Optional[str] = None,
    resource_name: str = 'resource',
    resource_names: str = '',
    resource_method_doc_templates: t.Optional[dict[str, str]] = None,
    collection_doc: t.Optional[str] = None,
    collection_method_doc_templates: t.Optional[dict[str, str]] = None
):
    '''A shortcut function to create a standardized combination of
    resource collection and corresponding resource class.

    :param url_path: Path that is bound to a collection of resources.
    :param get_schema: A :py:mod:`typing` definition for a schema to
        retrieve a single resource.
    :param post_schema: A :py:mod:`typing` definition for a schema to
        create a resource.
    :param put_schema: A :py:mod:`typing` definition for a schema to
        update resource as a whole.
    :param patch_schema: A :py:mod:`typing` definition for a schema to
        partially update a resource.
    :param with_options: Generate OPTION endpoint if required.
    :param resource_doc: Docstring for a class of a single resource.
    :param resource_name: A name of the resource to use in autogenerated
        docstrings
    :param resource_names: A name of the resources (plural form) to use in
        autogenerated docstrings
    :param resource_method_doc_templates: A dictionary that has keys
        as method names of :py:class:`RestResource`, values -
        Python `string templates
        <https://docs.python.org/3/library/string.html#formatstrings>`_ in
        where 0 element is `resource_name`, and 1 - `resource_names`. If
        value is empty, docstring is not generated. If key is absent, default
        value is used.
    :param collection_doc: Docstring for a class of a resource collection.
    :param collection_method_doc_templates: Same meaning as for
        `resource_method_doc_templates` but for :py:class:`RestResources`.
    '''
    assert resource_name

    if not resource_names:
        resource_names = f'{resource_name}s'
    if resource_doc is None:
        resource_doc = f'Manage collection of {resource_names}'
    if collection_doc is None:
        collection_doc = f'Manage {resource_name}'

    obj_docs = {
        'get': 'Get a single {0}.',
        'delete': 'Delete a {0}.',
        'update': textwrap.dedent('''
            Update {0} with a given data.

            :param data: Data to update {0}.
        '''.strip()),
        'patch': textwrap.dedent('''
            Partially update {0} with a given data. The difference to
            :py:meth:`update` is that it updates only given fields, not replacing
            the whole object.

            :param data: Data to update {0}.
        '''.strip()),
        **(resource_method_doc_templates or {})
    }
    resource_docs = {
        'list': 'Get a list of {1}.',
        'options': 'Get a list of options for a collection of {1}.',
        'create': 'Create a new {0} in collection of {1}.',
        **(collection_method_doc_templates or {})
    }

    obj_docs = {
        f'__{k}': v.format(resource_name, resource_names)
        for k, v in obj_docs.items()
    }
    resource_docs = {
        f'__{k}': v.format(resource_name, resource_names)
        for k, v in resource_docs.items()
    }

    resources_kwargs = {
        'create__data': post_schema,
        'list__': collection_schema,
        'options__': lp_schema('schema', 'OptionsSchema') if with_options else '',
        **resource_docs,
    }
    resources_kwargs = {k: v for k, v in resources_kwargs.items() if v}
    if 'create__data' in resources_kwargs:
        resources_kwargs['create__'] = lp_schema('schema', 'IdSchema')

    obj_kwargs = {
        'get__': get_schema,
        'update__data': put_schema,
        'patch__data': patch_schema,
        **obj_docs,
    }
    obj_kwargs = {k: v for k, v in obj_kwargs.items() if v}
    @api(url_path)
    class result(RestResources, **resources_kwargs):
        @api('/{resource_id}')
        class resource(RestResource, **obj_kwargs):
            pass

    if collection_doc:
        result.klass.__doc__ = textwrap.dedent(collection_doc.strip())

    if resource_doc:
        result.klass.resource.klass.__doc__ = textwrap.dedent(
            resource_doc.strip()
        )

    return result


class HttpTransport(http_test_client.HttpTransport):
    '''Base HTTP transport for a client.

    :param base_url: :rfc:`Base URL <3986#section-5.1>` of AOS API endpoint.
    :param verify_certificates: Check whether certificate verification is
        required or not.
    '''

    def __init__(
        self,
        base_url: tt.Url,
        verify_certificates: bool = True
    ) -> None:
        super(HttpTransport, self).__init__(base_url)
        self._session.verify = verify_certificates


class FlaskTestTransport:
    '''Base transport for testing.

    :param test_client: Base Werkzeug test client.
    :param prefix: URL prefix of each endpoint.
    '''

    _client: werkzeug.test.Client
    _prefix: tt.UrlPath

    Response = http_test_client.Response
    """Base response class."""

    def __init__(
        self,
        test_client: werkzeug.test.Client,
        prefix: tt.UrlPath = '',
    ) -> None:
        self._client = test_client
        self._prefix = prefix

    def request(
        self,
        url: tt.Url,
        method: t.Optional[tt.HTTPMethod] = None,
        headers: t.Optional[tt.HTTPHeaders] = None,
        data: t.Optional[tt.JSON] = None,
        **kwargs: te.Unpack[tt.RequestsRequestKwargs],
    ) -> tt.HTTPResponse:
        '''Perform a simple HTTP request to endpoint and take
        parsed JSON body only. See :py:meth:`Api.request`.

        :param url: a segment that is concatenated with a currently bound prefix.
        :param method: :rfc:`HTTP request method <7231#section-4>`.
        :param headers: :rfc:`HTTP headers <7231#section-5>` to pass with
            a request.
        :param data: HTTP request body to pass. AOS API works with JSON,
            so this data, if provided, should be jsonable (i.e. correctly treated
            by :py:func:`json.encode`)
        '''
        response = self._client.open(
            path=self._prefix + url,
            method=method or 'GET',
            headers=headers,
            data=data,
            query_string=t.cast(dict[str, str] | None, kwargs.get('params')),
        )

        return self.Response(
            status_code=response.status_code,
            headers=response.headers,
            text=response.get_data(as_text=True),
        )


class ClientMeta(type):
    def __new__(
        mcs,
        name: str,
        bases: tuple[type],
        attrs: dict[str, t.Any],
    ) -> type:
        merged_attrs: dict[str, t.Any] = {}
        for base in bases:
            merged_attrs = _merge_attrs(merged_attrs, _klass_attrs(base))

        merged_attrs = _merge_attrs(merged_attrs, attrs)

        return super().__new__(mcs, name, bases, merged_attrs)


def lp_schema(klass: str, obj: str) -> str:
    if '.' not in klass:
        klass = f'scotch.schemas.{klass}'

    return f'_MAGIC.lollipop_type[aos.{klass}.{obj}]'


class Client(http_test_client.Client, metaclass=ClientMeta):
    '''Base SDK client. This class has no specific reference design methods
    but common ones only.

    :param url: :rfc:`Base URL <3986#section-5.1>` of AOS API endpoint.
    :param verify_certificates: Activate (default) or deactivate certificate
        validation.
    :param url_prefix: Prefix of each URL path endpoint.
    '''

    _auth_token: str | None
    _user_id: str | None

    logger: logging.Logger = logging.getLogger(f'{__module__}.Client')
    """A logger instance that is used with this client."""

    def __init__(
        self,
        url: str | flask.Flask | tt.HTTPTransportProto,
        verify_certificates: bool = True,
        url_prefix: tt.UrlPath = '/api',
    ) -> None:
        transport: tt.HTTPTransportProto

        if isinstance(url, flask.Flask):
            transport = FlaskTestTransport(url.test_client(), prefix=url_prefix)
        elif not hasattr(url, 'request'):
            transport = HttpTransport(
                url, verify_certificates=verify_certificates)
        else:
            transport = url

        super().__init__(transport)
        self._auth_token = None
        self._user_id = None

    def raw_request(
        self,
        url: tt.Url,
        method: t.Optional[tt.HTTPMethod] = None,
        headers: t.Optional[tt.HTTPHeaders] = None,
        data: t.Optional[tt.JSON] = None,
        encode_data: tt.JSONEncode = json.dumps,
        content_type: tt.HTTPMimeType = 'application/json',
        **kwargs: te.Unpack[tt.RequestsRequestKwargs],
    ) -> tt.HTTPResponse:
        '''Perform a low-level HTTP request to the endpoint.

        :param url: a segment that is concatenated with a currently bound prefix.
        :param method: :rfc:`HTTP request method <7231#section-4>`.
        :param headers: :rfc:`HTTP headers <7231#section-5>` to pass with
            a request.
        :param data: HTTP request body to pass. AOS API works with JSON,
            so this data, if provided, should be jsonable (i.e, correctly treated
            by :py:func:`json.encode`)
        :param encode_data: A function that encodes a data into
            :rfc:`JSON <8259>`.
        :param content_type: A content type of the request. Supports
            :rfc:`MIME types<2045>`.
        '''
        if self._auth_token:
            headers = t.cast(dict[str, str], headers or {})
            headers['AuthToken'] = self._auth_token

        return super().raw_request(
            url=url,
            method=method,
            headers=headers,
            data=data,
            encode_data=encode_data,
            content_type=content_type,
            **kwargs
        )

    def request(
        self,
        url: tt.Url,
        method: t.Optional[tt.HTTPMethod] = None,
        headers: t.Optional[tt.HTTPHeaders] = None,
        data: t.Optional[tt.JSON] = None,
        **kwargs: te.Unpack[tt.RequestsRequestKwargs],
    ) -> tt.JSON:
        '''Perform a simple HTTP request to endpoint and take
        parsed JSON body only. See :py:meth:`Api.request`.

        :param url: a segment that is concatenated with a currently bound prefix.
        :param method: :rfc:`HTTP request method <7231#section-4>`.
        :param headers: :rfc:`HTTP headers <7231#section-5>` to pass with
            a request.
        :param data: HTTP request body to pass. AOS API works with JSON,
            so this data, if provided, should be jsonable (i.e, correctly treated
            by :py:func:`json.encode`)
        '''
        def is_get_or_delete_request() -> bool:
            """ Return True in case request is for GET/DELETE method. This is
                identified using either 'method' field or 'data' field.
            """
            if not method:
                return data is None
            return method in ['GET', 'DELETE']

        try:
            return super().request(
                url=url,
                method=method,
                headers=headers,
                data=data,
                **kwargs
            )
        except ClientError as ce:
            # Masking 404 response for GET and DELETE APIs to make client library
            # pythonic and to maintain backward compatibility. Ideally, we should
            # not mask the error for any status codes.
            if ce.status_code == 404 and is_get_or_delete_request():
                return None
            raise ce

    _request = request
    _raw_request = raw_request

    def cleanup(self) -> None:
        '''Performs cleanup and removes a list of created resources
        in this session.'''
        # pylint: disable=broad-except,access-member-before-definition
        tries = 0
        while self._cleanup:
            new_cleanup = []
            for url, func in self._cleanup:
                # pylint: disable=bare-except
                try:
                    func()
                except Exception as exc:
                    self.logger.info('CL: %s', self._cleanup)
                    self.logger.info('TRY: %s, url: %s', tries, url)
                    if tries >= 7:
                        # If resource pool is busy, move it to the end of cleanup
                        if getattr(exc, 'status_code', 0) == 423:
                            self.logger.info(
                                'Pool cleanup: %s, url: %s', tries, url)
                            self.logger.info('CLEANUP_DATA: %s', self._cleanup)
                            self.logger.info('Current: %s, %s', url, func)
                            res = self._raw_request(url, method='GET').json()
                            self.logger.info('RES: %s', res)
                        # Enough trying, propagate error
                        raise

                    new_cleanup.append((url, func))

            if len(self._cleanup) == len(new_cleanup):
                tries += 1
                time.sleep(2 ** tries / 10)
            else:
                tries = 0

            # pylint: disable=attribute-defined-outside-init
            self._cleanup = new_cleanup

    def new_session(self) -> Client:
        '''Creates a new session with the same set of parameters as
        original client.'''
        return self.__class__(self._transport)

    def try_login(
        self,
        username: str = 'admin',
        password: str = 'admin',
        expect_status_codes: t.Optional[collections.abc.Container[int]] = None,
        **kwargs: te.Unpack[tt.RequestsRequestKwargs],
    ) -> tt.HTTPResponse:
        '''Login into system.

        :param username: Name of the use.
        :param password: Password of the user.
        :param expect_status_codes: A list of
            :rfc:`HTTP status codes <7231#section-6>` that are expected during
            correct login procedure.
        '''
        status_codes = expect_status_codes or HTTP_2xx
        response = self.raw_request(self._url + '/aaa/login', data={
            'username': username,
            'password': password,
        }, **kwargs)
        if response is None:
            # http_test_client returns None on 404, which is
            # abnormal and should be propagated
            raise ClientError(404, 'AOS Auth API is missing on the server')
        if response.status_code not in status_codes:
            if status_codes is HTTP_2xx:
                # TODO(dmitryme): fix any ptest which fails if this 'if' is removed
                # and delete the 'if' and HTTP_2xx_AS_LIST afterwards
                # Or rewrite the code to use function, which accepts or declines
                # status code. A separate function should return string
                # representation of expected range.
                status_codes = HTTP_2xx_AS_LIST

            message = "expected exit code in %s, got %s" \
                      % (str(status_codes), response.status_code)
            raise ClientError(response.status_code, message)
        return response

    def login(
        self,
        username: str = 'admin',
        password: str = 'admin'
    ) -> tuple[str, str]:
        '''Login into system and store given authentication token.

        :param username: Name of the use.
        :param password: Password of the user.
        '''
        response = self.try_login(username, password)
        resp = json.loads(response.text)

        self._auth_token = resp['token']
        self._user_id = resp['id']

        assert self._auth_token
        assert self._user_id

        return self._auth_token, self._user_id

    def set_auth_token(self, new_token: str) -> None:
        '''Set authentication token in a session.

        :param new_token: A token to set.
        '''
        self._auth_token = new_token

    def logout(self) -> None:
        '''Performs logout from a system and erases stores auth token.'''
        if not self._auth_token:
            return

        self.request(self._url + '/aaa/logout', method='POST')
        self._auth_token = None
        self._user_id = None

    @api('/aaa/users')
    class users(
        RestResources,
        create__data=lp_schema('user_schema', 'USER_POST_SCHEMA'),
        create__=lp_schema('schema', 'IdSchema'),
        __create='''
            Create a new user.

            :param data: Data to create user with.
        ''',
        list__=lp_schema('user_schema', 'USER_LIST_GET_RESPONSE_SCHEMA'),
        __list='Retrive a list of users.',
    ):
        @api('/{user_id}')
        class resource(
            RestResource,
            get__=lp_schema('user_schema', 'USER_PROFILE_GET_RESPONSE_SCHEMA'),
            __get='Get user details.',
            update__data=lp_schema('user_schema', 'USER_PUT_PROFILE_SCHEMA'),
            __update='''
                Update user details.

                :param data: Data to replace user data with.
            ''',
            patch__data=lp_schema('user_schema', 'USER_PATCH_PROFILE_SCHEMA'),
            __patch='''
                Partially update user details.

                :param data: Data to update user data with.
            '''
        ):
            def change_password(
                self,
                old_password: str,
                new_password: str,
                **kwargs: te.Unpack[tt.RequestsRequestKwargs]
            ) -> tt.JSON:
                '''Change user password.

                :param old_password: Old (current) password in use.
                :param new_password: New password to set.
                '''
                return self._request('/change-password', method='PUT', data={
                    "current_password": old_password,
                    "new_password": new_password,
                }, headers={}, **kwargs)

            @api('/roles')
            class roles(Api):
                '''Manage user roles.'''

                def get(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> lp_schema('user_schema', 'USER_ROLES_GET_RESPONSE_SCHEMA'):
                    '''Get a list of user roles.'''
                    return self._request(method='GET', **kwargs)

                def update(
                    self,
                    data: lp_schema('user_schema', 'USER_ROLES_SCHEMA'),
                    **kwargs: te.Unpack[RestResource.TWriteKwargs]
                ) -> tt.JSON:
                    '''Update user roles.

                    :param data: Data to update user roles with.
                    '''
                    return self._request(method='PUT', data=data, **kwargs)

            @api('/preferences')
            class preferences(
                RestResources,
                create__data=lp_schema(
                    'user_schema',
                    'PREFERENCES_ITEM_POST_SCHEMA'
                ),
                create__=lp_schema('schema', 'IdSchema'),
                __create='''
                    Create new user preference.

                    :param data: Preference data.
                ''',
            ):
                '''Manage user preferences.'''

                @api('/{preference_id}')
                class resource(RestResource):
                    '''Manage user preference.'''

            @api('/favorites')
            class favorites(
                RestResources,
                create__data=lp_schema(
                    'user_schema',
                    'FAVORITES_ITEM_POST_SCHEMA'
                ),
                create__=lp_schema('schema', 'IdSchema'),
                __create='''
                    Create new favorite page.

                    :param data: Page data.
                '''
            ):
                '''Manage user favorite pages.'''

                @api('/{favorite_id}')
                class resource(
                    RestResource,
                    patch__data=lp_schema(
                        'user_schema',
                        'FAVORITES_ITEM_PATCH_SCHEMA'
                    ),
                    __patch='''
                        Partially update user favorite page.

                        :param data: Data to update user favorite page with.
                    '''
                ):
                    '''Manage user favorite page.'''

    @api('/aaa/ratelimit')
    class ratelimit(
        RestResource,
        get__=lp_schema('security_schema', 'RATELIMIT_GET_RESPONSE_SCHEMA'),
        __get='Get a ratelimiter config.',
        patch__data=lp_schema('security_schema', 'RATELIMIT_PATCH_SCHEMA'),
        __patch='''
            Partially update ratelimiter config.

            :param data: Ratelimiter config.
        '''
    ):
        '''Manage ratelimit configs.'''

        @api('/denylist')
        class denylist(
            RestResources,
            list__=lp_schema('security_schema', 'DENYLIST_GET_SCHEMA'),
            __list='Get a list of denylist entries.',
        ):
            '''Manage ratelimit denylist configs.'''

            def delete_single(
                self,
                *items: _MAGIC.lollipop_type[
                'aos.scotch.schemas.security_schema.DENYLIST_KEY_SCHEMA'],
                **kwargs: te.Unpack[tt.RequestsRequestKwargs]
            ) -> tt.JSON:
                '''Delete ratelimit denylist entries.

                :param items: Entries to delete.
                '''
                return self._request('-batch-delete', method='POST', data={
                    "items": t.cast(list, items),
                }, headers={}, **kwargs)

        @api('/allowlist')
        class allowlist(
            RestResources,
            list__=lp_schema('security_schema', 'ALLOWLIST_GET_SCHEMA'),
            __list='Get a list of allowlist entries.',
            create__data=lp_schema('security_schema', 'ALLOWLIST_POST_SCHEMA'),
            create__=lp_schema(
                'security_schema',
                'ALLOWLIST_POST_RESPONSE_SCHEMA'
            ),
            __create='''
                Create new allowlist entry.

                :param data: Entry properties.
            '''
        ):
            '''Manage ratelimit allowlist configs.'''

            def update(
                self,
                data: _MAGIC.lollipop_type[
                'aos.scotch.schemas.security_schema.ALLOWLIST_PATCH_SCHEMA'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs]
            ) -> _MAGIC.lollipop_type[
                # pylint: disable=line-too-long
                'aos.scotch.schemas.security_schema.ALLOWLIST_PATCH_RESPONSE_SCHEMA']:
                '''Update allowlist entries.

                :param data: Data to update allowlist with.
                '''
                return self._request(
                    method='PATCH',
                    data=data,
                    **kwargs
                )

            def delete_single(
                self,
                *items: _MAGIC.lollipop_type[
                'aos.scotch.schemas.security_schema.ALLOWLIST_KEY_SCHEMA'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs]
            ):
                '''Delete allowlist entries.

                :param items: Entries to delete.
                '''
                return self._request('-batch-delete', method='POST', data={
                    "items": t.cast(list, items),
                }, **kwargs)

    @api('/aaa/password_complexity')
    class password_complexity(Api):
        '''Manage password complexity policies.'''

        def get(
            self,
            **kwargs: te.Unpack[RestResource.TReadKwargs]
        ) -> _MAGIC.lollipop_type[
            'aos.scotch.schemas.security_schema.PASSWORD_COMPLEXITY_SCHEMA']:
            '''Get a single password complexity policy.'''
            return self._request(method='GET', **kwargs)

        def update(
            self,
            data: _MAGIC.lollipop_type[
            'aos.scotch.schemas.security_schema.PASSWORD_COMPLEXITY_UPDATE_SCHEMA'],
            **kwargs: te.Unpack[RestResource.TWriteKwargs]
        ) -> tt.JSON:
            '''Update password complexity policy.

            :param data: Data to update password complexity policy.
            '''
            return self._request(method='PUT', data=data, **kwargs)

    @api('/aaa/acl')
    class acl(Api):
        '''Manage access control lists.'''

        def get(
            self,
            **kwargs: te.Unpack[RestResource.TReadKwargs],
        ) -> _MAGIC.lollipop_type[
            'aos.scotch.schemas.security_schema.ACL_SCHEMA']:
            '''Get access control list data.'''
            return self._request(method='GET', **kwargs)

        def update(
            self,
            data: _MAGIC.lollipop_type[
                'aos.scotch.schemas.security_schema.ACL_SCHEMA'],
            **kwargs: te.Unpack[RestResource.TWriteKwargs]
        ) -> tt.JSON:
            '''Update access control list.

            :param data: Data to update access control list with.
            '''
            return self._request(method='PUT', data=data, **kwargs)

    aaa_providers = resources(
        '/aaa/providers',
        get_schema=lp_schema(
            'auth_provider_schema',
            'PROVIDER_GET_RESPONSE_SCHEMA'
        ),
        collection_schema=lp_schema(
            'auth_provider_schema',
            'PROVIDER_LIST_GET_RESPONSE_SCHEMA'
        ),
        put_schema=lp_schema('auth_provider_schema', 'PROVIDER_PUT_SCHEMA'),
        post_schema=lp_schema('auth_provider_schema', 'PROVIDER_POST_SCHEMA'),
        resource_name='provider',
        collection_doc='''
            A collection of AAA (Authentication, authorization, and accounting)
            providers.
        ''',
        resource_doc='''
            AAA (Authentication, authorization, and accounting) provider.
        '''
    )

    @api('/aaa/saml-providers')
    class saml_providers(
        RestResources,
        create__data=lp_schema(
            'auth_provider_schema',
            'SAML_POST_SCHEMA'
        ),
        create__=lp_schema(
            'auth_provider_schema',
            'SAML_POST_RESULT_SCHEMA'
        ),
        list__=lp_schema(
            'auth_provider_schema',
            'SAML_GET_LIST_SCHEMA'
        ),
    ):
        '''Manage SAML providers.

        This class provides methods to interact with SAML providers, including
        downloading metadata for a single provider.
        '''

        @api('/{provider_id}')
        class resource(
            RestResource,
            patch__data=lp_schema(
                'auth_provider_schema',
                'SAML_PATCH_SCHEMA'
            ),
            patch__=lp_schema(
                'auth_provider_schema',
                'SAML_PATCH_RESULT_SCHEMA'
            ),
            delete__=lp_schema(
                'auth_provider_schema',
                'SAML_DELETE_RESULT_SCHEMA'
            ),
            get__=lp_schema(
                'auth_provider_schema',
                'SAML_GET_SCHEMA'
            ),
        ):
            '''Manage a single SAML provider.

            This class provides methods to interact with a specific SAML provider
            identified by `provider_id`.
            '''

        def download_batch(
                self,
                *items: lp_schema('schema', 'IdSchema'),
                **kwargs: te.Unpack[tt.RequestsRequestKwargs]
        ) -> tt.JSON:
            '''Reload metadata by saved metadata URL.

            This method allows reloading metadata for the specified SAML
            providers using their saved metadata URLs.
            '''
            return self._request('/batch-metadata-download', method='POST', data={
                'items': t.cast(list, items),
            }, headers={}, **kwargs)

    @api('/aaa/group-role-mappings')
    class group_role_mappings(RestResource):
        '''Manage mapping of provider group to AOS roles.'''

        def list(
            self,
            **kwargs: te.Unpack[RestResource.TReadKwargs],
        ) -> _MAGIC.lollipop_type[
            # pylint: disable=line-too-long
            'aos.scotch.schemas.auth_provider_schema.GROUP_ROLE_MAPPING_ELEMENT_SCHEMA']:
            '''List provider group to AOS role mappings.'''
            return t.cast(dict, self._request(method='GET', **kwargs))['items']

    roles = resources(
        '/aaa/roles',
        get_schema=lp_schema('user_schema', 'ROLE_SCHEMA'),
        collection_schema=lp_schema('user_schema', 'ROLE_ITEMS_SCHEMA'),
        put_schema=lp_schema('user_schema', 'ROLE_PUT_SCHEMA'),
        post_schema=lp_schema('user_schema', 'ROLE_POST_SCHEMA'),
    )

    @api('/aaa/permissions')
    class permissions(Api):
        '''Manage permissions.'''

        def get(
            self,
            **kwargs: te.Unpack[RestResource.TReadKwargs]
        ) -> _MAGIC.lollipop_type[
            'aos.scotch.schemas.user_schema.PERMISSION_LIST_SCHEMA']:
            '''Get permission.'''
            return self._request(method='GET', **kwargs)

    @api('/version')
    class version(
        RestResource,
        get__=lp_schema('version_schema', 'VERSION_API_SCHEMA'),
        __get='Get a version of the product.',
    ):
        '''Manage AOS versions.'''

    @api('/versions')
    class versions(Api):
        '''Manage AOS versions.'''

        def controller_id(
            self,
            **kwargs: te.Unpack[RestResource.TReadKwargs],
        ) -> _MAGIC.lollipop_type[
            'aos.scotch.blueprints.versions.CONTROLLER_ID_SCHEMA']:
            '''Get AOS Controller ID.'''
            return self._request('/controller-id', method='GET', **kwargs)

        def build(
            self,
            **kwargs: te.Unpack[RestResource.TReadKwargs],
        ) -> _MAGIC.lollipop_type[
            'aos.scotch.schemas.version_schema.VERSION_SERVER_SCHEMA']:
            '''Get server build version.'''
            return self._request('/build', method='GET', **kwargs)

    @api('/supported-speeds')
    class supported_speeds(Api):
        '''Manage supported speeds.'''

        def get(
            self,
            **kwargs: te.Unpack[RestResource.TReadKwargs],
        ) -> _MAGIC.lollipop_type[
            'aos.scotch.blueprints.supported_speeds.SUPPORTED_SPEEDS_SCHEMA']:
            '''Enumerate supported speeds.'''
            return self._request(method='GET', **kwargs)

    @api('/config')
    class config(Api):
        '''Manage configurations.'''

        @api('/audit')
        class audit(Api):
            '''Manage audit configurations.'''

            def get(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs],
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.blueprints.audit.AUDIT_CONFIG']:
                '''Get current audit configuration.'''
                return self._request(method='GET', **kwargs)

            def update(
                self,
                data: _MAGIC.lollipop_type[
                    'aos.scotch.blueprints.audit.AUDIT_CONFIG'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> tt.JSON:
                '''Update current audit configuration.

                :param data: Audit configuration data.
                '''
                return self._request(method='PUT', data=data, **kwargs)

        @api('/timezones')
        class timezones(Api):
            '''Manage timezones.'''

            def list(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs],
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.blueprints.syslog.TIMEZONES_CONFIG']:
                '''List timezone configurations.'''
                return self._request(method='GET', **kwargs)

        syslogs = resources(
            '/syslogs',
            with_options=True,
            get_schema=lp_schema('scotch.blueprints.syslog', 'SYSLOG_CONFIG'),
            collection_schema=lp_schema(
                'scotch.blueprints.syslog',
                'LIST_SYSLOG_CONFIGS'
            ),
            post_schema=lp_schema('scotch.blueprints.syslog', 'SYSLOG_CONFIG'),
            put_schema=lp_schema('scotch.blueprints.syslog', 'SYSLOG_CONFIG'),
        )

    @api('/audit')
    class audit(Api):
        '''Manage audit.'''

        @api('/events')
        class events(Api):
            '''Manage audit events.'''

            def list_raw(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.schemas.audit_events.AUDIT_EVENTS_ITEMS_SCHEMA']:
                '''Get API response of audit events.'''
                return self._request(method='GET', **kwargs)

            def list(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs],
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.schemas.audit_events.AUDIT_EVENTS_LIST_SCHEMA']:
                '''List audit events.'''
                result = self.list_raw(**kwargs)
                return result['items']

            @api('/query')
            class query(Api):
                '''Query audit events.'''
                def run_raw(
                    self,
                    data: _MAGIC.lollipop_type[
                    'aos.scotch.schemas.audit_events.AUDIT_QUERY_REQUEST'],
                    params: t.Optional[tt.RequestsRequestQueryParams] = None,
                ) -> _MAGIC.lollipop_type[
                    'aos.scotch.schemas.audit_events.AUDIT_QUERY_RESPONSE']:
                    '''Return raw response of audit events query.'''
                    return self._request(
                        method='POST',
                        data=data,
                        params=params or {},
                        headers={}
                    )

                def run(
                    self,
                    begin_time: _MAGIC.lollipop_type[
                        'aos.scotch.schemas.audit_events.TIMESTAMP_FIELD'],
                    end_time: _MAGIC.lollipop_type[
                        'aos.scotch.schemas.audit_events.TIMESTAMP_FIELD'],
                    query_filter: _MAGIC.lollipop_type[
                    'aos.scotch.schemas.audit_events.METRIC_FILTER_FIELD'] = '',
                    orderby: t.Optional[str] = None,
                    per_page: t.Optional[int] = None
                ) -> _MAGIC.lollipop_type[
                    'aos.scotch.schemas.audit_events.AUDIT_QUERY_RESPONSE']:
                    '''Convenience wrapper for :py:meth:`.run_raw`.

                    :param begin_time:
                        `ISO8601 <https://en.wikipedia.org/wiki/ISO_8601>`_
                        timestamp of a time range start.
                    :param end_time:
                        `ISO8601 <https://en.wikipedia.org/wiki/ISO_8601>`_
                        timestamp of a time range end.
                    :param query_filter: Events filter expression.
                    :param orderby: Field name to order events by.
                    :param per_page: How many elements per page should be
                        returned.
                    '''
                    if query_filter is None:
                        query_filter = ''
                    data = {
                        'begin_time': begin_time,
                        'end_time': end_time,
                        'filter': query_filter,
                    }

                    params = {}
                    if orderby:
                        params['orderby'] = orderby
                    if per_page:
                        params['per_page'] = str(per_page)
                    if len(params) == 0:
                        params = {}

                    return self.run_raw(data, params)

            @api('/device-config')
            class device_config(Api):
                '''Manage audit events for device configs.'''

                def get(
                    self,
                    data: _MAGIC.lollipop_type[
                    'aos.scotch.schemas.audit_events.DEVICE_CONFIG_REQUEST'],
                ) -> _MAGIC.lollipop_type[
                    'aos.scotch.schemas.audit_events.DEVICE_CONFIG_RESPONSE']:
                    '''Get device config audit events.

                    :param data: Specification of device configs and
                        audit events.
                    '''
                    return self._request(method='POST', headers={}, data=data)

            @api('/retention')
            class retention(Api):
                '''Manage audit events retention policy.'''
                def get(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type[
                    # pylint: disable=line-too-long
                    'aos.scotch.schemas.audit_events.AUDIT_RETENTION_CONFIG_GET_RESPONSE']:
                    '''Get current audit events retention policy.'''
                    return self._request(method='GET', **kwargs)

                def update(
                    self,
                    data: _MAGIC.lollipop_type[
                    # pylint: disable=line-too-long
                    'aos.scotch.schemas.audit_events.AUDIT_RETENTION_CONFIG_PATCH_REQUEST'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs]
                ) -> tt.JSON:
                    '''Update current audit events retention policy.

                    :param data: Configuration of retention policy.
                    '''
                    return self._request(method='PATCH', data=data, **kwargs)

            @api('/types')
            class types(Api):
                '''Manage audit event types.'''
                def get(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type[
                    # pylint: disable=line-too-long
                    'aos.scotch.schemas.audit_events.AUDIT_EVENT_TYPES_RESPONSE']:
                    '''List the audit events types defined by backend.'''
                    results = self._request(method='GET', **kwargs)
                    return results['items']

    device_profiles = resources(
        '/device-profiles',
        with_options=True,
        get_schema=lp_schema('device_profile', 'DeviceProfileStatusSchema'),
        collection_schema=lp_schema(
            'device_profile',
            'DeviceProfileStatusCollectionSchema'
        ),
        post_schema=lp_schema('device_profile', 'DeviceProfileConfigSchema'),
        put_schema=lp_schema('device_profile', 'DeviceProfileConfigSchema'),
        resource_name='device profile',
    )
    device_profile_clone = resources(
        '/device-profile-clone',
        post_schema=lp_schema(
            'device_profile_clone',
            'DeviceProfileCloneSchema',
        ),
        collection_doc='Clone device profiles',
    )
    device_profile_digests = resources(
        '/device-profile-digests',
        with_options=True,
        get_schema=lp_schema('device_profile', 'DeviceProfileDigestSchema'),
        collection_schema=lp_schema(
            'device_profile',
            'DeviceProfileDigestCollectionSchema'
        ),
        resource_name='device profile digest',
    )
    linecard_profiles = resources(
        '/linecard-profiles',
        with_options=True,
        get_schema=lp_schema('device_profile', 'LinecardProfileStatusSchema'),
        collection_schema=lp_schema(
            'device_profile',
            'LinecardProfileStatusCollectionSchema'
        ),
        post_schema=lp_schema('device_profile', 'LinecardProfileConfigSchema'),
        put_schema=lp_schema('device_profile', 'LinecardProfileConfigSchema'),
        resource_name='linecard profile',
    )
    chassis_profiles = resources(
        '/chassis-profiles',
        with_options=True,
        get_schema=lp_schema('device_profile', 'ChassisProfileStatusSchema'),
        collection_schema=lp_schema(
            'device_profile',
            'ChassisProfileStatusCollectionSchema'
        ),
        post_schema=lp_schema('device_profile', 'ChassisProfileConfigSchema'),
        put_schema=lp_schema('device_profile', 'ChassisProfileConfigSchema'),
        resource_name='chassis profile',
    )
    interface_maps = resources(
        '/design/interface-maps',
        with_options=True,
        get_schema=lp_schema('interface_map', 'InterfaceMapStatusSchema'),
        collection_schema=lp_schema(
            'interface_map',
            'InterfaceMapStatusCollectionSchema'
        ),
        post_schema=lp_schema('interface_map', 'InterfaceMapConfigSchema'),
        put_schema=lp_schema('interface_map', 'InterfaceMapConfigSchema'),
        resource_name='interface map',
    )
    interface_map_digests = resources(
        '/design/interface-map-digests',
        with_options=True,
        get_schema=lp_schema('interface_map', 'InterfaceMapDigestSchema'),
        collection_schema=lp_schema(
            'interface_map',
            'InterfaceMapDigestCollectionSchema'
        ),
        resource_name='interface map digest',
    )
    logical_devices = resources(
        '/design/logical-devices',
        with_options=True,
        get_schema=lp_schema('logical_device', 'LOGICAL_DEVICE_STATUS_SCHEMA'),
        collection_schema=lp_schema(
            'logical_device',
            'LOGICAL_DEVICE_STATUS_COLLECTION_SCHEMA'
        ),
        post_schema=lp_schema(
            'logical_device',
            'LOGICAL_DEVICE_CONFIG_SCHEMA'
        ),
        put_schema=lp_schema('logical_device', 'LOGICAL_DEVICE_CONFIG_SCHEMA'),
        resource_name='logical device',
    )
    tags = resources(
        '/design/tags',
        with_options=True,
        get_schema=lp_schema('tag', 'GET_TAG_SCHEMA'),
        collection_schema=lp_schema('tag', 'LIST_TAG_SCHEMA'),
        post_schema=lp_schema('tag', 'POST_TAG_SCHEMA'),
        put_schema=lp_schema('tag', 'TAG_SCHEMA'),
        resource_name='tag',
    )
    config_templates = resources(
        '/design/config-templates',
        with_options=True,
        get_schema=lp_schema('config_templates', 'GET_CONFIG_TEMPLATE_SCHEMA'),
        collection_schema=lp_schema(
            'config_templates',
            'LIST_CONFIG_TEMPLATE_SCHEMA'
        ),
        post_schema=lp_schema(
            'config_templates',
            'POST_CONFIG_TEMPLATE_SCHEMA'
        ),
        put_schema=lp_schema('config_templates', 'PUT_CONFIG_TEMPLATE_SCHEMA'),
        resource_name='config template',
    )
    graph_queries = resources(
        '/design/graph-queries',
        with_options=True,
        get_schema=lp_schema('graph_queries', 'GET_GRAPH_QUERY_SCHEMA'),
        collection_schema=lp_schema('graph_queries', 'LIST_GRAPH_QUERY_SCHEMA'),
        post_schema=lp_schema('graph_queries', 'PUT_GRAPH_QUERY_SCHEMA'),
        put_schema=lp_schema('graph_queries', 'PUT_GRAPH_QUERY_SCHEMA'),
        resource_name='graph query',
        resource_names='graph queries',
    )
    streaming_config = resources(
        '/streaming-config',
        with_options=True,
        get_schema=lp_schema('streaming', 'STREAMING_STATUS_SCHEMA'),
        collection_schema=lp_schema('streaming', 'STREAMING_STATUS_LIST_SCHEMA'),
        post_schema=lp_schema('streaming', 'STREAMING_CONFIG_SCHEMA'),
        patch_schema=lp_schema('streaming', 'STREAMING_PATCH_SCHEMA'),
        resource_name='streaming config',
    )
    streaming_endpoints = streaming_config
    streaming_certificates = resources(
        '/streaming-certificates',
        with_options=True,
        get_schema=lp_schema(
            'streaming_certificate', 'CERTIFICATE_GET_RESPONSE_SCHEMA'),
        collection_schema=lp_schema(
            'streaming_certificate', 'CERTIFICATE_COLLECTION_SCHEMA'),
        post_schema=lp_schema(
            'streaming_certificate', 'CERTIFICATE_POST_REQUEST_SCHEMA'),
        patch_schema=lp_schema(
            'streaming_certificate', 'CERTIFICATE_PATCH_REQUEST_SCHEMA'),
        resource_name='streaming certificate',
    )
    templates = resources(
        '/design/templates',
        with_options=True,
        get_schema=lp_schema('design_template', 'DESIGN_TEMPLATE_SCHEMA'),
        collection_schema=lp_schema(
            'design_template',
            'LIST_DESIGN_TEMPLATE_SCHEMA'
        ),
        post_schema=lp_schema('design_template', 'DESIGN_TEMPLATE_SCHEMA'),
        put_schema=lp_schema('design_template', 'DESIGN_TEMPLATE_SCHEMA'),
        resource_name='template',
    )
    rack_types = resources(
        '/design/rack-types',
        with_options=True,
        get_schema=lp_schema('rack_type', 'RACK_TYPE_SCHEMA'),
        collection_schema=lp_schema('rack_type', 'RACK_TYPE_SCHEMA_ITEMS'),
        put_schema=lp_schema('rack_type', 'RACK_TYPE_SCHEMA'),
        resource_name='rack type',
    )
    endpoint_policies = resources(
        '/design/endpoint-policies',
        get_schema=lp_schema('endpoint_policies', 'ENDPOINT_POLICY_SCHEMA'),
        collection_schema=lp_schema(
            'endpoint_policies',
            'ENDPOINT_POLICY_SCHEMA_ITEMS'
        ),
        resource_name='endpoint policy',
        resource_names='endpoint policies',
    )
    configlets = resources(
        '/design/configlets',
        with_options=True,
        get_schema=lp_schema('configlet_schema', 'CONFIGLET_SCHEMA'),
        collection_schema=lp_schema(
            'configlet_schema',
            'LIST_CONFIGLET_SCHEMA'
        ),
        put_schema=lp_schema('configlet_schema', 'CONFIGLET_SCHEMA'),
        post_schema=lp_schema('configlet_schema', 'CONFIGLET_SCHEMA'),
        resource_name='configlet',
    )
    property_sets = resources(
        '/property-sets',
        with_options=True,
        get_schema=lp_schema(
            'scotch.blueprints.property_sets',
            'DETAILED_PROPERTY_SET'
        ),
        collection_schema=lp_schema('property_set', 'LIST_PROPERTY_SET'),
        post_schema=lp_schema('property_set', 'CREATE_PROPERTY_SET'),
        put_schema=lp_schema(
            'scotch.blueprints.property_sets',
            'UPDATE_PROPERTY_SET'
        ),
        patch_schema=lp_schema(
            'scotch.blueprints.property_sets',
            'PATCH_PROPERTY_SET'
        ),
        resource_name='property set',
    )
    port_aliases = resources(
        '/port-aliases',
        with_options=True,
        collection_schema=lp_schema('port_aliases', 'LIST_PORT_ALIASES'),
        get_schema=lp_schema('port_aliases', 'PORT_ALIAS'),
        put_schema=lp_schema('port_aliases', 'PORT_ALIAS'),
        post_schema=lp_schema('port_aliases', 'PORT_ALIAS'),
        resource_name='port alias'
    )

    @api('/design/ai-ml-template-calculator')
    class ai_ml_template_calculator(Api):
        def calculate_l3_clos(
                self,
                data: _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.ai_template_calculator.L3_CLOS_REQUEST_SCHEMA'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs]
        ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.ai_template_calculator.L3_CLOS_RESPONSE_SCHEMA']:
            """
            Calculates possible options for AI/ML template for L3 clos design
            given user input parameters.
            """
            return self._request(
                '/calculate-l3-clos',
                method='POST',
                data=data,
                **kwargs
            )

        def calculate_rail_collapsed(
                self,
                data: _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.ai_template_calculator.RAIL_COLLAPSED_REQUEST_SCHEMA'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs]
        ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.ai_template_calculator.RAIL_COLLAPSED_RESPONSE_SCHEMA']:
            """
            Calculates possible options for AI/ML template for rail-collapsed
            (aka spineless) design given user input parameters.
            """
            return self._request(
                '/calculate-rail-collapsed',
                method='POST',
                data=data,
                **kwargs
            )

        def get_juniper_recommended_devices(
                self,
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
        ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.ai_template_calculator.JUNIPER_RECOMMENDED_DEVICES_RESPONSE_SCHEMA']:
            """
            Returns the list of Juniper recommended Device Profiles for AI/ML fabrics.
            """
            return self._request(
                '/juniper-recommended',
                method='GET',
                data=None,
                **kwargs
            )

    @api('/systems')
    class devices(
        RestResources,
        options__=lp_schema('schema', 'OptionsSchema'),
        create__data=lp_schema(
            'scotch.blueprints.device_manager',
            'DEVICE_POST_SCHEMA'
        ),
        create__=lp_schema('schema', 'IdSchema'),
        __create='''
            Create a new system.

            :param data: Properties of a system.
        ''',
        list__=lp_schema(
            'scotch.blueprints.device_manager',
            'LIST_DEVICE_GET_SCHEMA'
        ),
        __list='List known systems.',
    ):
        '''Manage systems.'''

        @api('/{system_id}')
        class resource(
            RestResource,
            get__=lp_schema(
                'scotch.blueprints.device_manager',
                'DEVICE_GET_SCHEMA'
            ),
            __get='Get system information.',
            update__data=lp_schema(
                'scotch.blueprints.device_manager',
                'DEVICE_PUT_SCHEMA'
            ),
            __update='''
                Update system information.

                :param data: Properties that replaces existing data.
            '''
        ):
            '''Manage system.'''

            def get_device_deployment_status(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> tt.JSON:
                '''Return device deployment status.'''
                return self._request('/configuration', **kwargs)

            def apply_full_config(
                self,
                **kwargs: te.Unpack[RestResource.TWriteKwargs]
            ) -> tt.JSON:
                '''Apply full configuration to the system.'''
                return self._request(
                    '/apply-full-config', method='POST', data={}, **kwargs)

            def accept_running_config_as_golden(
                self,
                **kwargs: te.Unpack[RestResource.TWriteKwargs]
            ) -> tt.JSON:
                '''Save current config as golden.'''
                return self._request('/accept-running-config-as-golden',
                                     method='POST', data={}, **kwargs)

            def revert_to_pristine(
                self
            ) -> _MAGIC.lollipop_type['aos.scotch.schemas.schema.IdSchema']:
                '''Revert configuration of the system to the pristine state.'''
                return self._request(
                    '/revert-to-pristine',
                    method='POST',
                    headers={},
                    data={}
                )

            def collect_pristine(
                self
            ) -> _MAGIC.lollipop_type['aos.scotch.schemas.schema.IdSchema']:
                '''Collect pristine config for this device.'''
                return self._request(
                    '/collect-pristine',
                    method='POST',
                    headers={},
                    data={}
                )

            def update_pristine(
                self,
                data: _MAGIC.lollipop_type[
                'aos.scotch.blueprints.deployment.pristine.PRISTINE_POST_SCHEMA']
            ) -> _MAGIC.lollipop_type['aos.scotch.schemas.schema.IdSchema']:
                '''Update device pristine config.

                :param data: Data to update config with.
                '''
                return self._request(
                    '/pristine-config',
                    method='POST',
                    headers={},
                    data=data
                )

            def get_pristine(
                self
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.blueprints.deployment.pristine.PRISTINE_GET_SCHEMA'
            ]:
                '''Get device pristine config.'''
                return self._request(
                    '/pristine-config',
                    method='GET',
                    headers={},
                    data=None,
                )

            @api('/pristine-config')
            class pristine_config(RestResource):
                '''Manage pristine configs.'''

                def get(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type[
                    'aos.scotch.blueprints.deployment.pristine.PRISTINE_GET_SCHEMA'
                ]:
                    '''Get device pristine config.'''
                    return self._request('', method='GET', **kwargs)

                # pylint: disable=arguments-renamed
                def update(   # type: ignore[override]
                    self,
                    config: t.Optional[_MAGIC.lollipop_type[
                    'aos.scotch.blueprints.deployment.pristine.PRISTINE_CONFIG'
                    ]] = None
                ) -> _MAGIC.lollipop_type['aos.scotch.schemas.schema.IdSchema']:
                    '''Update device pristine config.

                    :param data: Data to update config with.
                    '''
                    return self._request('', method='POST', headers={},
                                         data=dict(pristine_data=config or []))

            @api('/services')
            class services(
                RestResources,
                create__data=lp_schema(
                    'scotch.libs.telemetry_service',
                    'CREATE_SYSTEM_SERVICE_SCHEMA',
                ),
                create__=lp_schema(
                    'scotch.blueprints.telemetry_service',
                    'CREATE_RESPONSE_SCHEMA',
                ),
            ):
                '''Manage system services.'''

                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type[
                    # pylint: disable=line-too-long
                    'aos.scotch.blueprints.telemetry_service.DICT_SINGLE_SERVICE_SCHEMA']:
                    '''List system services.'''
                    return t.cast(dict, self._request(
                        method='GET',
                        **kwargs
                    ))['services']

                @api('/{service_name}')
                class resource(
                    RestResource,
                    get__=lp_schema(
                        'scotch.blueprints.telemetry_service',
                        'LIST_SYSTEM_SERVICE_SCHEMA',
                    ),
                    __get='Get the system service.',
                    update__data=lp_schema(
                        'scotch.libs.telemetry_service',
                        'CREATE_SYSTEM_SERVICE_SCHEMA',
                    ),
                    update__=lp_schema(
                        'scotch.blueprints.telemetry_service',
                        'CREATE_RESPONSE_SCHEMA',
                    ),
                    __update='''
                        Update a system service.

                        :param data: Data to update service with.
                    '''
                ):
                    '''Manage system service.'''

                    def get_data(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> _MAGIC.lollipop_type[
                        'aos.scotch.schemas.telemetry_schema.SERVICE_ONE_OF_SCHEMA']:
                        '''Get system service.'''
                        # mlag service does not have 'items'
                        resp = t.cast(
                            dict,
                            self._request('/data', method='GET', **kwargs)
                        )
                        if resp and 'items' in resp:
                            return resp['items']
                        return resp

                    def refresh(
                        self,
                        **kwargs: te.Unpack[RestResource.TWriteKwargs]
                    ) -> tt.JSON:
                        '''Refresh system service.'''
                        return self._request('/refresh', method='POST',
                                             data={}, **kwargs)

            @api('/counters')
            class counters(
                RestResources,
                list__=lp_schema(
                    'telemetry_schema',
                    'TELEMETRY_DEVICE_INTERFACE_COUNTER_SCHEMA'
                ),
                __list='List all counters.',
            ):
                '''Manage system counters.'''

                def get_data(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type[
                    # pylint: disable=line-too-long
                    'aos.scotch.schemas.telemetry_schema.TELEMETRY_INTERFACE_COUNTER_SCHEMA']:
                    '''Get system counters.'''
                    return t.cast(
                        dict,
                        self._request(method='GET', **kwargs)
                    )['items']

        def create_batch(
            self,
            data: _MAGIC.lollipop_type[
            'aos.scotch.blueprints.device_manager.BATCH_DEVICE_CREATE_REQUEST_SCHEMA'
            ],
            **kwargs: te.Unpack[RestResource.TWriteKwargs],
        ) -> _MAGIC.lollipop_type[
            'aos.scotch.blueprints.device_manager.BATCH_DEVICE_CREATE_RESP_SCHEMA'
        ]:
            '''Create a batch of systems.

            :param data: Specification of devices to create.
            '''
            return self._request(
                '-batch-create', method='POST', data=data, **kwargs
            )

        def update_batch(
            self,
            data: _MAGIC.lollipop_type[
            'aos.scotch.blueprints.device_manager.BATCH_DEVICE_UPDATE_SCHEMA'
            ],
            **kwargs: te.Unpack[RestResource.TWriteKwargs],
        ) -> tt.JSON:
            '''Update batch of systems.

            :param data: Specification of systems and parameters to update.
            '''
            return self._request('-batch-update', method='POST', data=data,
                                 **kwargs)

        def delete_batch(
            self,
            data: _MAGIC.lollipop_type[
            'aos.scotch.blueprints.device_manager.BATCH_DEVICE_DELETE_SCHEMA'
            ],
            **kwargs: te.Unpack[RestResource.TWriteKwargs],
        ) -> tt.JSON:
            '''Delete batch of systems.

            :param data: Specification of systems.
            '''
            return self._request('-batch-delete', method='POST', data=data,
                                 **kwargs)

    @api('/rci')
    class rci(Api):
        '''Manage RCI (root cause identifications).'''

        @api('/instances')
        class instances(
            RestResources,
            list__=lp_schema(
                'scotch.blueprints.rci',
                'GET_RCI_INSTANCE_LIST_SCHEMA'
            ),
            __list='Get all RCI instances.',
            create__data=lp_schema(
                'scotch.blueprints.rci',
                'POST_RCI_INSTANCE'
            ),
            __create='''
                Create new RCI instance.

                :param data: RCI configuration.
            '''
        ):
            '''Manage RCI instances.'''

            @api('/{rci_id}')
            class resource(
                RestResource,
                get__=lp_schema(
                    'scotch.blueprints.rci',
                    'GET_RCI_INSTANCE'
                ),
                __get='Get an RCI instance.',
                patch__data=lp_schema(
                    'scotch.blueprints.rci',
                    'PATCH_RCI_INSTANCE'
                ),
                __patch='''
                    Partially update RCI instance.

                    :param data: Updated properties.
                '''
            ):
                '''Manage RCI instance.'''

                def show_rcf(
                    self,
                    rcf: str,
                    timestamp: t.Optional[str] = None
                ) -> _MAGIC.lollipop_type[
                    'aos.scotch.blueprints.rci.GET_IMPACTS_FOR_RCF_RESPONSE']:
                    '''Show RCFs (root cause faults) for RCI.

                    :param rcf: RCF identifier.
                    '''
                    params = {'rcf': rcf}
                    if timestamp:
                        params['timestamp'] = timestamp
                    return self._request(
                        url='/rcf',
                        method='POST',
                        data=params,   # type: ignore
                        headers={},
                    )

                def explain_impact(
                    self,
                    impact: str,
                    timestamp: t.Optional[str] = None
                ) -> _MAGIC.lollipop_type[
                    'aos.scotch.blueprints.rci.EXPLAIN_IMPACT_RESPONSE']:
                    '''Explain a given impact of RCI.

                    :param impact: Impact of RCI.
                    :param timestamp: Timestamp of the event.
                    '''
                    params = {'impact': impact}
                    if timestamp:
                        params['timestamp'] = timestamp
                    return self._request(
                        url='/impact',
                        method='POST',
                        data=params,   # type: ignore
                        headers={},
                    )

        processors = resources(
            '/processors',
            collection_schema=lp_schema(
                'scotch.blueprints.rci',
                'GET_RCI_PROCESSORS_LIST_SCHEMA'
            ),
            resource_name='processor'
        )

    ip_pools = resources(
        '/resources/ip-pools',
        with_options=True,
        get_schema=lp_schema(
            'scotch.blueprints.resources',
            'IP_POOL_STATUS_SCHEMA'
        ),
        collection_schema=lp_schema(
            'scotch.blueprints.resources',
            'IP_POOL_COLLECTION_SCHEMA'
        ),
        post_schema=lp_schema(
            'scotch.blueprints.resources',
            'IP_POOL_CONFIG_SCHEMA'
        ),
        put_schema=lp_schema(
            'scotch.blueprints.resources',
            'IP_POOL_MODIFY_SCHEMA'
        ),
        resource_name='IPv4 pool',
    )
    ipv6_pools = resources(
        '/resources/ipv6-pools',
        with_options=True,
        get_schema=lp_schema(
            'scotch.blueprints.resources',
            'IPV6_POOL_STATUS_SCHEMA'
        ),
        collection_schema=lp_schema(
            'scotch.blueprints.resources',
            'IPV6_POOL_COLLECTION_SCHEMA'
        ),
        post_schema=lp_schema(
            'scotch.blueprints.resources',
            'IPV6_POOL_CONFIG_SCHEMA'
        ),
        put_schema=lp_schema(
            'scotch.blueprints.resources',
            'IPV6_POOL_MODIFY_SCHEMA'
        ),
        resource_name='IPv6 pool',
    )
    vlan_pools = resources(
        '/resources/vlan-pools',
        with_options=True,
        get_schema=lp_schema(
            'scotch.blueprints.resources',
            'VLAN_POOL_STATUS_SCHEMA'
        ),
        collection_schema=lp_schema(
            'scotch.blueprints.resources',
            'VLAN_POOL_COLLECTION_SCHEMA'
        ),
        post_schema=lp_schema(
            'scotch.blueprints.resources',
            'VLAN_POOL_CONFIG_SCHEMA'
        ),
        put_schema=lp_schema(
            'scotch.blueprints.resources',
            'VLAN_POOL_MODIFY_SCHEMA'
        ),
        resource_name='VLAN pool',
    )
    asn_pools = resources(
        '/resources/asn-pools',
        with_options=True,
        get_schema=lp_schema(
            'scotch.blueprints.resources',
            'ASN_POOL_STATUS_SCHEMA'
        ),
        collection_schema=lp_schema(
            'scotch.blueprints.resources',
            'ASN_POOL_COLLECTION_SCHEMA'
        ),
        post_schema=lp_schema(
            'scotch.blueprints.resources',
            'ASN_POOL_CONFIG_SCHEMA'
        ),
        put_schema=lp_schema(
            'scotch.blueprints.resources',
            'ASN_POOL_MODIFY_SCHEMA'
        ),
        resource_name='ASN pool',
    )
    vni_pools = resources(
        '/resources/vni-pools',
        with_options=True,
        get_schema=lp_schema(
            'scotch.blueprints.resources',
            'VNI_POOL_STATUS_SCHEMA'
        ),
        collection_schema=lp_schema(
            'scotch.blueprints.resources',
            'VNI_POOL_COLLECTION_SCHEMA'
        ),
        post_schema=lp_schema(
            'scotch.blueprints.resources',
            'VNI_POOL_CONFIG_SCHEMA'
        ),
        put_schema=lp_schema(
            'scotch.blueprints.resources',
            'VNI_POOL_MODIFY_SCHEMA'
        ),
        resource_name='VNI pool',
    )
    integer_pools = resources(
        '/resources/integer-pools',
        with_options=True,
        get_schema=lp_schema(
            'scotch.blueprints.resources',
            'INTEGER_POOL_STATUS_SCHEMA'
        ),
        collection_schema=lp_schema(
            'scotch.blueprints.resources',
            'INTEGER_POOL_COLLECTION_SCHEMA'
        ),
        post_schema=lp_schema(
            'scotch.blueprints.resources',
            'INTEGER_POOL_CONFIG_SCHEMA'
        ),
        put_schema=lp_schema(
            'scotch.blueprints.resources',
            'INTEGER_POOL_MODIFY_SCHEMA'
        ),
        resource_name='integer pool',
    )
    device_pools = resources(
        '/resources/device-pools',
        with_options=True,
        get_schema=lp_schema(
            'scotch.blueprints.resources',
            'DEVICE_POOL_STATUS_SCHEMA'
        ),
        collection_schema=lp_schema(
            'scotch.blueprints.resources',
            'DEVICE_POOL_COLLECTION_SCHEMA'
        ),
        post_schema=lp_schema(
            'scotch.blueprints.resources',
            'DEVICE_POOL_CONFIG_SCHEMA'
        ),
        put_schema=lp_schema(
            'scotch.blueprints.resources',
            'DEVICE_POOL_MODIFY_SCHEMA'
        ),
        resource_name='device pool',
    )

    @api('/anomalies')
    class anomalies(
        RestResources,
        list__=lp_schema('alerts', 'ANOMALY_ONE_OF_SCHEMA'),
        __list='Get all anomalies.',
    ):
        '''Manage anomalies.'''

        def search(
            self,
            anomaly_type: t.Optional[_MAGIC.lollipop_type[
            'aos.scotch.schemas.alerts.ANOMALY_TYPES']] = None,
        ) -> _MAGIC.lollipop_type[
            'aos.scotch.schemas.alerts.ANOMALY_ONE_OF_SCHEMA']:
            '''Search anomalies.

            :param anomaly_type: Anomaly type to search for.
            '''
            if anomaly_type is not None:
                params = {'anomaly_type': anomaly_type}
            else:
                params = {}
            return self._request(method='GET', headers={}, data=None, params=params)

    @api('/blueprints')
    class blueprints(
        RestResources,
        options__=lp_schema('schema', 'OptionsSchema'),
        __options='List all blueprint IDs',
        list__=lp_schema(
            'scotch.blueprints.blueprint',
            'LIST_RESPONSE_SCHEMA'
        ),
        __list='Get all blueprints.',
    ):
        '''A set of endpoints specific to a blueprint.'''

        # Use special create method for blueprint creation to register a special
        # clean up method. The client has to wait until all task for the blueprint
        # will be done
        def create(
            self,
            data: _MAGIC.lollipop_type[
            'aos.scotch.blueprints.blueprint.CREATE_REQUEST_SCHEMA'],
            **kwargs: te.Unpack[RestResource.TWriteKwargs]
        ) -> _MAGIC.lollipop_type[
            'aos.scotch.blueprints.blueprint.CREATE_RESPONSE_SCHEMA']:
            '''Create a new blueprint.

            :param data: Datastructure of a blueprint.
            '''
            result = self._request(data=data, **kwargs)
            if isinstance(result, dict) and 'id' in result:
                _id = result['id']

                def cleanup() -> None:
                    # pylint: disable=unsubscriptable-object
                    def tasks_are_finished() -> None:
                        tasks_list = self[_id].tasks.list()  # type: ignore[index]
                        # after blueprint deletion task list response will be 404 and
                        # tasks_list will be None. Check for this case.
                        if tasks_list:
                            assert all(task['status'] not in ['in_progress', 'init']
                                       for task in tasks_list)

                    with_async_state(tasks_are_finished)
                    self[_id].delete()  # type: ignore[index]

                self._client.add_cleanup(
                    f'{self._url}/{urllib.parse.quote(t.cast(str, _id))}',
                    cleanup
                )
            return result

        @api('/{blueprint_id}')
        class resource(
            RestResource,
            get__=lp_schema('scotch.blueprints.blueprint', 'BLUEPRINT_SCHEMA'),
            __get='Get blueprint.',
            patch__data=lp_schema(
                'scotch.blueprints.blueprint',
                'BLUEPRINT_UPDATE_SCHEMA'
            ),
            patch__=lp_schema(
                'scotch.blueprints.blueprint',
                'BLUEPRINT_UPDATE_RESPONSE_SCHEMA'
            ),
            __patch='''
                Partially update the blueprint.

                :param data: Updated properties.
            '''
        ):
            '''API endpoints specific to a blueprint.'''

            @api('/commit-check')
            class commit_check(Api):
                '''Verify that commit is possible.'''

                def post(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> tt.JSON:
                    '''Perform commit check.'''
                    return self._request(method='POST', **kwargs)

            @api('/commit-check-result')
            class commit_check_result(Api):
                '''Manage results of commit check.'''
                def get(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> _MAGIC.lollipop_type[
                    # pylint: disable=line-too-long
                    'aos.scotch.schemas.config_rendering.BlueprintCommitCheckResultSchema']:
                    '''Get a commit check result.'''
                    return self._request(method='GET', **kwargs)

            @api('/nodes')
            class nodes(RestResources):
                '''Manage nodes.'''

                def create(
                    self,
                    data: _MAGIC.lollipop_type[
                    'aos.scotch.blueprints.blueprint.POST_NODE_REQUEST_SCHEMA'],
                    allow_unsafe: bool = False,
                    **kwargs: te.Unpack[RestResource.TWriteKwargs]
                ) -> _MAGIC.lollipop_type[
                    'aos.scotch.blueprints.blueprint.POST_NODE_RESPONSE_SCHEMA']:
                    '''Create new node in a blueprint.

                    :param data: Node properties.
                    :param allow_unsafe: Direct node operations are usually
                        very dangerous. This flag ensures user consent.
                    '''
                    params = kwargs.pop('params', None) or {}
                    result = self._request(  # type: ignore[misc]
                        method='POST',
                        data=data,
                        params=dict({'allow_unsafe': 'true'
                                     if allow_unsafe else 'false'}, **params),
                        **kwargs
                    )
                    if isinstance(result, dict) and 'id' in result:
                        self._client.add_cleanup(
                            f'{self._url}/{urllib.parse.quote(str(result["id"]))}',
                            # pylint: disable=unsubscriptable-object
                            self[result['id']].delete,  # type: ignore[index]
                        )
                    return result

                def update(
                    self,
                    cmds: _MAGIC.lollipop_type[
                    'aos.scotch.blueprints.blueprint.NODES_UPDATE_SCHEMA'],
                    allow_unsafe: bool = False,
                    **kwargs: te.Unpack[RestResource.TWriteKwargs]
                ) -> _MAGIC.lollipop_type[
                    # pylint: disable=line-too-long
                    'aos.scotch.blueprints.blueprint.GET_NODES_LIST_RESPONSE_SCHEMA']:
                    '''Update blueprint node.

                    :param cmds: Node properties.
                    :param allow_unsafe: Direct node operations are usually
                        very dangerous. This flag ensures user consent.
                    '''
                    params = kwargs.pop('params', None) or {}
                    return self._request(  # type: ignore[misc]
                        method='PATCH',
                        data=cmds,
                        params=dict({'allow_unsafe': 'true'
                                     if allow_unsafe else 'false'}, **params),
                        **kwargs
                    )

                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type[
                    # pylint: disable=line-too-long
                    'aos.scotch.blueprints.blueprint.GET_NODES_RESPONSE_SCHEMA_DICT']:
                    '''List blueprint nodes.'''
                    return t.cast(
                        dict,
                        self._request(method='GET', **kwargs)
                    )['nodes']

                @api('/{node_id}')
                class resource(RestResource):
                    '''Manage node.'''

                    def update(
                        self,
                        data: _MAGIC.lollipop_type[
                        'aos.scotch.blueprints.blueprint.NODES_UPDATE_SCHEMA'],
                        allow_unsafe: bool = False,
                        **kwargs: te.Unpack[RestResource.TWriteKwargs],
                    ) -> _MAGIC.lollipop_type[
                        # pylint: disable=line-too-long
                        'aos.scotch.blueprints.blueprint.GET_NODES_LIST_RESPONSE_SCHEMA']:
                        '''Update the node in a blueprint.

                        :param data: Node properties.
                        :param allow_unsafe: Direct node operations are usually
                            very dangerous. This flag ensures user consent.
                        '''
                        params = kwargs.pop('params', None) or {}
                        return self._request(  # type: ignore[misc]
                            method='PATCH', data=data,
                            params=dict({'allow_unsafe': 'true'
                                         if allow_unsafe else 'false'}, **params),
                            **kwargs
                        )

                    def delete(
                        self,
                        allow_unsafe: bool = False,  # type: ignore[override]
                        # pylint: disable=line-too-long
                        **kwargs: te.Unpack[RestResource.TReadKwargs],  # type: ignore[override]
                    ) -> tt.JSON:
                        '''Delete a node from the blueprint.

                        :param allow_unsafe: Direct node operations are usually
                            very dangerous. This flag ensures user consent.
                        '''
                        params = kwargs.pop('params', None) or {}
                        response = self._request(  # type: ignore[misc]
                            method='DELETE',
                            params=dict({'allow_unsafe': 'true'
                                         if allow_unsafe else 'false'}, **params),
                            **kwargs
                        )
                        self._client.remove_cleanup(self._url)
                        return response

                    def get_config_rendering(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs],
                    ) -> _MAGIC.lollipop_type[
                        'aos.scotch.schemas.config_rendering.DEVICE_CONFIG_SCHEMA']:
                        '''Get a result of configuration rendering.'''
                        return self._request(
                            '/config-rendering',
                            method='GET',
                            **kwargs
                        )

                    def get_config_context(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs],
                    ) -> _MAGIC.lollipop_type[
                        # pylint: disable=line-too-long
                        'aos.scotch.schemas.config_rendering.CONFIG_RENDERING_CONTEXT_SCHEMA']:
                        '''Get a context for configuration rendering of a node.'''
                        return self._request(
                            '/config-context',
                            method='GET',
                            **kwargs
                        )

                    def get_config_incremental(
                        self,
                        context: t.Optional[str] = None,
                        **kwargs: te.Unpack[RestResource.TReadKwargs],
                    ) -> _MAGIC.lollipop_type[
                        # pylint: disable=line-too-long
                        'aos.scotch.schemas.config_rendering.CONFIG_RENDERING_INCREMENTAL_SCHEMA']:
                        """ Renders incremental configuration for a given node
                        in the blueprint.

                        :param context: If context is specified, use this for
                            incremental config. If context is not specified,
                            derive from diff between deployed->staging
                            blueprints.
                        """
                        data: tt.JSON
                        if context:
                            data = {'context': context}
                        else:
                            data = {}
                        return self._request('/config-incremental', method='POST',
                                             headers={}, data=data)

            @api('/config-templates')
            class config_templates(Api):
                '''Manage global collection of config templates.'''

                @api('/{config_template_id}')
                class resource(RestResource):
                    '''Manage a config template.'''

                    def preview(
                        self,
                        system_id: str,
                        text: str,
                        config_apply_mode: t.Literal['complete', 'incremental'],
                    ) -> str:
                        '''Get a configuration rendering preview.

                        :param system_id: Render configuration related
                            to a given system
                        :param text: Configuration template.
                        :param config_apply_mode: How to apply config.
                        '''
                        return t.cast(
                            dict,
                            self._request(
                                '/preview',
                                method='POST',
                                headers={},
                                data={
                                    'system_id': system_id,
                                    'config_apply_mode': config_apply_mode,
                                    'text': text,
                                }),
                        )['text']

            @api('/relationships')
            class relationships(
                RestResources,
                options__=lp_schema('schema', 'OptionsSchema'),
            ):
                '''Manage blueprint relationships.'''

                def create(
                    self,
                    data: _MAGIC.lollipop_type[
                    # pylint: disable=line-too-long
                    'aos.scotch.blueprints.blueprint.POST_RELATIONSHIP_RESPONSE_SCHEMA'],
                    allow_unsafe: bool = False,
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> _MAGIC.lollipop_type[
                    # pylint: disable=line-too-long
                    'aos.scotch.blueprints.blueprint.POST_RELATIONSHIP_REQUEST_SCHEMA']:
                    '''Create new relationship in a blueprint.

                    :param data: Relationship properties.
                    :param allow_unsafe: Direct node operations are usually
                        very dangerous. This flag ensures user consent.
                    '''
                    params = kwargs.pop('params', None) or {}
                    result = self._request(  # type: ignore[misc]
                        method='POST',
                        data=data,
                        params=dict({'allow_unsafe': 'true'
                                     if allow_unsafe else 'false'}, **params),
                        **kwargs
                    )
                    if isinstance(result, dict) and 'id' in result:
                        self._client.add_cleanup(
                            f'{self._url}/{urllib.parse.quote(str(result["id"]))}',
                            # pylint: disable=unsubscriptable-object
                            self[result['id']].delete,  # type: ignore[index]
                        )
                    return result

                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type[
                    # pylint: disable=line-too-long
                    'aos.scotch.blueprints.blueprint.GET_RELATIONSHIPS_RESPONSE_SCHEMA_DICT']:
                    '''List blueprint relationships.'''
                    return t.cast(
                        dict,
                        self._request(method='GET', **kwargs)
                    )['relationships']

                @api('/{relationship_id}')
                class resource(
                    RestResource,
                    get__=lp_schema(
                        'scotch.blueprints.blueprint',
                        'DUMP_RELATIONSHIP_SCHEMA'
                    ),
                    __get='Get relationship.'
                ):
                    def patch(
                        self,
                        cmds: _MAGIC.lollipop_type[
                        'aos.scotch.blueprints.blueprint.GENERIC_DICT_SCHEMA'],
                        allow_unsafe: bool = False,
                        **kwargs: te.Unpack[RestResource.TWriteKwargs]
                    ) -> _MAGIC.lollipop_type[
                        'aos.scotch.blueprints.blueprint.DUMP_RELATIONSHIP_SCHEMA']:
                        '''Partially update the relationship in a blueprint.

                        :param data: Updated relationship properties.
                        :param allow_unsafe: Direct node operations are usually
                            very dangerous. This flag ensures user consent.
                        '''
                        params = kwargs.pop('params', None) or {}
                        return self._request(  # type: ignore[misc]
                            method='PATCH', data=cmds,
                            params=dict({'allow_unsafe': 'true'
                                         if allow_unsafe else 'false'}, **params),
                            **kwargs
                        )

                    def delete(
                        self,
                        allow_unsafe: bool = False,  # type: ignore[override]
                        **kwargs: te.Unpack[
                            RestResource.TReadKwargs]  # type: ignore[override]
                    ) -> tt.JSON:
                        '''Delete relationship from blueprint.

                        :param allow_unsafe: Direct node operations are usually
                            very dangerous. This flag ensures user consent.
                        '''
                        params = kwargs.pop('params', None) or {}
                        response = self._request(  # type: ignore[misc]
                            method='DELETE',
                            params=dict({'allow_unsafe': 'true'
                                         if allow_unsafe else 'false'}, **params),
                            **kwargs
                        )
                        self._client.remove_cleanup(self._url)
                        return response

            @api('/errors')
            class errors(Api):
                '''Manage blueprint errors.'''

                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type[
                    'aos.scotch.blueprints.blueprint.DUMP_ERROR_SCHEMA']:
                    '''List all blueprint errors.'''
                    return self._request(method='GET', **kwargs)

            @api('/meta')
            class meta(Api):
                '''Manage blueprint metadata.'''

                @api('/errors')
                class errors(Api):
                    '''Manage blueprint errors metadata.'''

                    def get(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs],
                    ) -> _MAGIC.lollipop_type[
                        'aos.scotch.blueprints.blueprint.META_ERRORS_SCHEMA']:
                        '''Get blueprint errors metadata.'''
                        return self._request(method='GET', **kwargs)

            def get(  # type: ignore[override]
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs],
            ) -> tt.Graph[Node, Relationship] | None:
                '''Get a blueprint wrapped in a
                :py:class:`aos.sdk.graph.Graph` instance.
                '''
                graph_dict = self._request(method='GET', **kwargs)
                if not graph_dict:
                    return None

                return dict_to_graph(graph_dict)

            def query(
                self,
                python_query: str,
                **kwargs: te.Unpack[RestResource.TWriteKwargs]
            ) -> list[dict[str, Node | None]]:
                '''Execute a graph query.

                :param python_query: QueryEngine DSL query to execute.
                '''
                result = self._request(
                    '/qe', data=dict(query=python_query), **kwargs)
                return wrap_qe_response(result)

            def cypher(
                self,
                query_string: str,
                **kwargs: te.Unpack[RestResource.TWriteKwargs]
            ) -> tt.JSON:
                '''Execute a
                `Cypher <https://en.wikipedia.org/wiki/Cypher_(query_language)>`_
                graph query.

                :param query_string: Query to execute.
                '''
                return self._request(
                    '/cypher',
                    data={'query': query_string},
                    **kwargs
                )

            def graphql(
                self,
                query_string: str,
                **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> tt.JSON:
                '''Execute a `GraphQL <https://en.wikipedia.org/wiki/GraphQL>`_
                query.

                :param query_string: Query to execute.
                '''
                return self._request(  # type: ignore[misc]
                    '/ql-readonly',
                    data=dict(query=query_string),
                    **kwargs
                )

            def get_version(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> int:
                '''Get a current graph version.'''
                request = t.cast(dict, self.graphql('{version}', **kwargs))
                return t.cast(int, t.cast(dict, request['data'])['version'])

            def get_source_version(
                self,
                source_graph_type: tt.BlueprintType,
                **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> int:
                '''Get a specific source version of a graph.

                :param source_graph_type: A source type of a version to request.
                '''
                return t.cast(int, t.cast(dict, t.cast(dict, self.graphql(
                    '{source_version(source_graph_type: "%s")}' % source_graph_type,
                    **kwargs))['data'])['source_version'])

            def deploy(
                self,
                data: _MAGIC.lollipop_type[
                'aos.scotch.blueprints.blueprint.DEPLOY_UPDATE_SCHEMA'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs]
            ) -> tt.JSON:
                '''Deploy blueprint.

                :param data: Deployment specification.
                '''
                return self._request('/deploy', method='PUT', data=data, **kwargs)

            def get_deploy(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.blueprints.blueprint.DEPLOY_SCHEMA']:
                '''Get deploy status of a blueprint.'''
                return self._request('/deploy', method='GET', **kwargs)

            def get_config_deployment_status(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> _MAGIC.lollipop_type[
                # pylint: disable=line-too-long
                'aos.scotch.schemas.deployment_status_schema.DEPLOYMENT_STATUS_SCHEMA']:
                '''Get config deployment status.'''
                return self._request('/configuration', method='GET', **kwargs)

            def preview_upgrade_config(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.schemas.config_rendering.PreviewConfigSummarySchema']:
                '''Preview and summarize device configs.'''
                return self._request(
                    '/preview-config-summary',
                    method='GET',
                    **kwargs
                )

            def diff(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs],
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.blueprints.blueprint_diff.DIFF_RESPONSE_SCHEMA']:
                '''Get diff between staged and deployed blueprints.'''
                return self._request('/diff', method='GET', **kwargs)

            def diff_status(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.blueprints.blueprint_diff_status.DIFF_STATUS_SCHEMA']:
                '''Get computation status of the diff between staged and
                deployed blueprints.'''
                return self._request('/diff-status', method='GET', **kwargs)

            def get_lock_status(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.blueprints.blueprint.GET_LOCK_STATUS_SCHEMA'
            ]:
                """Get lock status."""
                return self._request('/lock-status', method='GET', **kwargs)

            def lock_blueprint(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> tt.JSON:
                """Lock blueprint."""
                return self._request('/lock-blueprint', method='PUT', **kwargs)

            def unlock_blueprint(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> tt.JSON:
                """Unlock blueprint."""
                return self._request('/unlock-blueprint', method='PUT', **kwargs)

            def revert(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> tt.JSON:
                '''Revert blueprint to the latest backup version.'''
                return self._request('/revert', method='POST', **kwargs)

            def rollback(
                self,
                data: _MAGIC.lollipop_type[
                'aos.scotch.blueprints.blueprint.BLUEPRINT_ROLLBACK_REQUEST_SCHEMA'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs]
            ) -> tt.JSON:
                '''Rollback blueprint to the given version.

                :param data: Version specification.
                '''
                return self._request('/rollback', data=data, method='POST', **kwargs)

            def deploy_blueprint(self, timeout: tt.Timeout = 30) -> None:
                '''Deploy blueprint and wait until completed.

                :param timeout: Time limit of the deployment procedure.
                '''
                def wait_for_build() -> None:
                    """ This function waits for all build errors to be complete
                        before extracting current BP version and setting to deployed
                        BP version.

                        Using with_async_state allows this to retry until successful.
                    """

                    # Wait for no BP errors
                    expected: dict[str, dict] = dict(nodes={}, relationships={})
                    # pylint: disable=no-value-for-parameter
                    errors = self.errors.list()  # type: ignore[call-arg]
                    errors.pop('version', None)
                    assert expected == errors, 'Errors in BP are present\n%s'\
                                               % errors
                    bp_version = self.get_version()
                    assert bp_version > 0, 'Version is still 0'

                    self.deploy({'version': bp_version})

                    # Wait for successful build
                    deploy_status = self.get_deploy()
                    assert deploy_status['state'] == 'success', \
                        'Deploy failed: %s' % self.get_deploy()

                    assert deploy_status['version'] == bp_version, \
                        'bp_version %s != deploy version %s' % (
                            bp_version, deploy_status['version'])

                with_async_state(wait_for_build, timeout=timeout)

            def search(
                self,
                data: _MAGIC.lollipop_type[
                'aos.scotch.blueprints.search.REQUEST_SCHEMA'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs]
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.blueprints.search.RESPONSE_SCHEMA']:
                '''Search in blueprint.

                :param data: Query request.
                '''
                return self._request('/search', data=data, method='POST', **kwargs)

            def get_search_metadata(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.blueprints.search.METADATA_RESPONSE_SCHEMA']:
                '''Get search related metadata.'''
                return self._request('/search/metadata', method='GET', **kwargs)

            anomalies = resources(
                '/anomalies',
                collection_schema=lp_schema(
                    'scotch.schemas.alerts',
                    'ANOMALY_ONE_OF_SCHEMA'
                ),
                resource_name='anomaly',
                resource_names='anomalies',
            )

            @api('/anomalies-history')
            class anomalies_history(RestResources):

                def list(
                    self,
                    data: _MAGIC.lollipop_type[
                        'aos.scotch.schemas.alerts.'
                        'ANOMALIES_HISTORY_REQUEST_SCHEMA'
                    ],
                    **kw: te.Unpack[RestResource.TWriteKwargs]
                ) -> _MAGIC.lollipop_type[
                        'aos.scotch.schemas.alerts.'
                        'ANOMALY_HISTORY_RESPONSE_SCHEMA']:
                    return t.cast(
                        dict,
                        self._request(method='POST', data=data, **kw)
                    )

                def trace(
                    self,
                    data: _MAGIC.lollipop_type[
                        'aos.scotch.schemas.alerts.'
                        'ANOMALY_HISTORY_REQUEST_SCHEMA'
                    ],
                    **kw: te.Unpack[RestResource.TWriteKwargs]
                ) -> _MAGIC.lollipop_type[
                        'aos.scotch.schemas.alerts.'
                        'ANOMALY_HISTORY_RESPONSE_SCHEMA']:
                    return t.cast(
                        dict,
                        self._request(method='POST', url='/trace',
                                      data=data, **kw)
                    )

                def counts(
                    self,
                    data: _MAGIC.lollipop_type[
                        'aos.scotch.schemas.alerts.'
                        'ANOMALY_HISTORY_COUNTS_REQUEST_SCHEMA'
                    ],
                    **kw: te.Unpack[RestResource.TWriteKwargs]
                ) -> _MAGIC.lollipop_type[
                        'aos.scotch.schemas.alerts.'
                        'ANOMALY_HISTORY_COUNTS_RESPONSE_SCHEMA']:
                    return t.cast(
                        dict,
                        self._request(method='POST', url='/counts',
                                      data=data, **kw)
                    )

                def stats(self) -> _MAGIC.lollipop_type[
                        'aos.scotch.schemas.alerts.'
                        'ANOMALIES_HISTORY_STATS_RESPONSE_SCHEMA']:
                    return t.cast(
                        dict,
                        self._request(url='/stats')
                    )

            @api('/probes')
            class probes(
                RestResources,
                list__=lp_schema(
                    'scotch.libs.probe_schemas',
                    'GET_RESPONSE_SCHEMA'
                ),
                __list='List all blueprint probes.',
                create__data=lp_schema(
                    'scotch.libs.probe_schemas',
                    'POST_PROBE'
                ),
                create__=lp_schema(
                    'scotch.libs.probe_schemas',
                    'POST_RESPONSE_SCHEMA'
                ),
                __create='''
                    Create a new probe.

                    :param data: Probe properties.
                ''',
            ):
                # TODO(ikharin): Sould be derived from RestResources, however
                #                update and patch are not yet supported.
                @api('/{probe_id}')
                class resource(
                    RestResource,
                    patch__data=lp_schema(
                        'scotch.libs.probe_schemas',
                        'PATCH_PROBE'
                    ),
                    __patch='''
                        Partially update the probe.

                        :param data: Updated properties.
                    ''',
                    update__data=lp_schema(
                        'scotch.libs.probe_schemas',
                        'PUT_PROBE'
                    ),
                    __update='''
                        Update probe.

                        :param data: Updated probe data.
                    ''',
                    get__=lp_schema('scotch.libs.probe_schemas', 'GET_PROBE'),
                    __get='Get the probe.'
                ):
                    '''Manage probe.'''

                    def query(
                        self,
                        data: _MAGIC.lollipop_type[
                        'aos.scotch.libs.probe_schemas.REQUEST_STAGE_STATUS'],
                        **kwargs: te.Unpack[RestResource.TWriteKwargs]
                    ) -> _MAGIC.lollipop_type[
                        'aos.scotch.libs.probe_schemas.GET_STAGE_STATUS']:
                        '''Get probe state status.

                        :param data: Query to execute.
                        '''
                        return self._request(
                            '/query',
                            data=data,
                            method='POST',
                            **kwargs
                        )

            @api('/iba')
            class iba(RestResources):
                '''Manage IBA-specific resources.'''

                @api('/anomalous-stages')
                class anomalous_stages(Api):
                    '''Manage anomalous stages.'''

                    def get(
                        self,
                        # pylint: disable=redefined-builtin
                        filter: t.Optional[str] = None,
                        **kw: te.Unpack[RestResource.TReadKwargs]
                        ) -> _MAGIC.lollipop_type[
                        # pylint: disable=line-too-long
                        'aos.scotch.libs.dashboard_schemas.ANOMALOUS_STAGE_INFO_LIST']:
                        '''Get stages with anomalies.

                        :param filter: Stage filter specification.
                        '''
                        params = {
                            'filter': filter,
                        }
                        data = t.cast(dict, self._request(  # type: ignore[misc]
                            params={k: v for k, v in params.items()
                                    if v is not None},
                            **kw
                        ))
                        return data['items'] if data else data

                @api('/dashboards')
                class dashboards(RestResources):
                    '''Manage probe dashboards.'''

                    def list(
                        self,
                        **kw: te.Unpack[RestResource.TReadKwargs]
                    ) -> None | _MAGIC.lollipop_type[
                        'aos.scotch.libs.dashboard_schemas.GET_DASHBOARDS']:
                        '''Get all blueprint dashboards.'''
                        data = t.cast(dict, self._request(**kw))
                        return data['items'] if data else data

                    def create(
                        self,
                        data: _MAGIC.lollipop_type[
                        'aos.scotch.libs.dashboard_schemas.POST_DASHBOARD'],
                        **kw: te.Unpack[RestResource.TWriteKwargs]
                    ) -> str:
                        '''Create new IBA dashboard.

                        :param data: Dashboard specification.
                        '''
                        rv = self._request(method='POST', data=data, **kw)
                        return t.cast(dict, rv)['id']

                    def import_dashboard(
                        self,
                        data: _MAGIC.lollipop_type[
                        # pylint: disable=line-too-long
                        'aos.scotch.blueprints.iba_dashboards.POST_DASHBOARD_IMPORT'],
                        **kw: te.Unpack[RestResource.TWriteKwargs]
                    ) -> _MAGIC.lollipop_type[
                        'aos.scotch.libs.dashboard_schemas.POST_RESPONSE']:
                        '''Import dashboard into blueprint.

                        :param data: Import specification.
                        '''
                        return t.cast(
                            dict,
                            self._request(method='POST', url='/import',
                                          data=data, **kw)
                        )['id']

                    @api('/{dashboard_id}')
                    class resource(Api):
                        '''Manage IBA dashboard.'''

                        def get(self) -> _MAGIC.lollipop_type[
                            'aos.scotch.libs.dashboard_schemas.GET_DASHBOARD']:
                            '''Get dashboard.'''
                            return self._request()

                        def export(self) -> _MAGIC.lollipop_type[
                            # pylint: disable=line-too-long
                            'aos.scotch.blueprints.iba_dashboards.GET_DASHBOARD_EXPORT']:
                            '''Export configured dashboard.'''
                            return self._request(url='/export')

                        def update(
                            self,
                            data: _MAGIC.lollipop_type[
                            'aos.scotch.libs.dashboard_schemas.POST_DASHBOARD'],
                            **kw: te.Unpack[RestResource.TWriteKwargs]
                        ) -> str:
                            '''Update dashboard.

                            :param data: Data to update dashboard with.
                            '''
                            return t.cast(dict, self._request(
                                method='PUT', data=data, **kw))['id']

                        def delete(
                            self,
                            delete_resources: t.Optional[
                                t.Literal['true', 'false']] = None
                        ) -> tt.JSON:
                            '''Delete dashboard.

                            :param delete_resources: Delete dependent resources.
                            '''
                            params = {}
                            if delete_resources is not None:
                                params['delete_resources'] = delete_resources
                            # pylint: disable=line-too-long
                            return self._request(method='DELETE', params=params)  # type: ignore

                @api('/predefined-probes')
                class predefined_probes(Api):
                    '''Manage predefined probes.'''

                    def list(
                        self,
                        include_experimental: t.Optional[bool] = None,
                        **kw: te.Unpack[RestResource.TReadKwargs],
                    ) -> None | _MAGIC.lollipop_type[
                        # pylint: disable=line-too-long
                        'aos.scotch.libs.probe_schemas.PREDEFINED_PROBES_REGISTRY_ITEM_LIST']:
                        '''Get all predefined probes.

                        :param include_experimental: Include probes considered
                            experimental.
                        '''
                        params = t.cast(dict, kw.pop('params', None) or {})
                        if include_experimental is not None:
                            params['include_experimental'] = (
                                'true' if include_experimental else 'false'
                            )
                        data = t.cast(
                            dict,
                            self._request(params=params, **kw)  # type: ignore[misc]
                        )
                        return data['items'] if data else data

                    def create(
                        self,
                        data: _MAGIC.lollipop_type[
                        'aos.scotch.libs.probe_schemas.PREDEFINED_PROBE_PARAMETERS'],
                        **kw: te.Unpack[RestResource.TWriteKwargs]
                    ) -> str:
                        '''Create new probe from predefined.

                        :param data: Specification of a concrete probe.
                        '''
                        return t.cast(dict, self._request(
                            method='POST', data=data, **kw))['id']

                    @api('/{probe_name}')
                    class predefined_probe(Api):
                        '''Manage predefined probe.'''

                        def create(
                            self,
                            data: _MAGIC.lollipop_type[
                            # pylint: disable=line-too-long
                            'aos.scotch.libs.probe_schemas.PREDEFINED_PROBE_PARAMETERS'],
                            **kw: te.Unpack[RestResource.TWriteKwargs],
                        ) -> _MAGIC.lollipop_type[
                            'aos.scotch.schemas.schema.IdSchema']:
                            '''Create new predefined probe.

                            :param data: Probe data.
                            '''
                            return self._request(method='POST', data=data, **kw)

                        @api('/{probe_id}')
                        class resource(Api):
                            '''Manage created predefined probe.'''

                            def get(self) -> _MAGIC.lollipop_type[
                                # pylint: disable=line-too-long
                                'aos.scotch.libs.probe_schemas.PREDEFINED_PROBE_PARAMETERS']:
                                '''Get predefined probe.'''
                                return self._request()

                            def update(
                                self,
                                data: _MAGIC.lollipop_type[
                                    # pylint: disable=line-too-long
                                    'aos.scotch.libs.probe_schemas.PREDEFINED_PROBE_PARAMETERS'],
                            ) -> tt.JSON:
                                '''Update predefined probe.

                                :param data: Updated predefined probe data.
                                '''
                                return self._request(method='PUT', data=data)

                @api('/predefined-dashboards')
                class predefined_dashboards(RestResources):
                    '''Manage predefined dashboards.'''

                    def list(
                        self,
                        include_experimental: t.Optional[bool]=None,
                        **kw: te.Unpack[RestResource.TReadKwargs]
                    ) -> None | _MAGIC.lollipop_type[
                        # pylint: disable=line-too-long
                        'aos.scotch.libs.dashboard_schemas.GET_PREDEFINED_DASHBOARDS']:
                        '''List predefined dashboards.

                        :param include_experimental: Include probes considered
                            experimental
                        '''
                        params = {}
                        if include_experimental is not None:
                            params['include_experimental'] = (
                                'true' if include_experimental else 'false'
                            )
                        data = t.cast(
                            dict,
                            self._request(params=params, **kw)  # type: ignore[misc]
                        )
                        return data['items'] if data else data

                    @api('/{dashboard_name}')
                    class resource(Api):
                        '''Manage named dashboard.'''

                        def create(
                            self,
                            data: _MAGIC.lollipop_type[
                            # pylint: disable=line-too-long
                            'aos.scotch.libs.dashboard_schemas.LIST_OF_PARAMETERS'],
                            **kw: te.Unpack[RestResource.TWriteKwargs],
                        ) -> _MAGIC.lollipop_type[
                            'aos.scotch.libs.dashboard_schemas.POST_RESPONSE']:
                            '''Create new instance of named dashboard.

                            :param data: Dashboard specification.
                            '''
                            return t.cast(dict, self._request(
                                method='POST', data=data, **kw))['id']

                        def update(self, disabled: bool) -> str:
                            '''Update predefined dashboard.

                            :param disabled: Choose whether dashboard should
                                be disabled.
                            '''
                            return t.cast(dict, self._request(  # type: ignore
                                method='PATCH',
                                data={'disabled': bool(disabled)}
                            ))['id']

                def dashboards_batch_delete(
                    self,
                    dashboards: list[str],
                    delete_resources: t.Optional[t.Literal['true', 'false']] = None,
                    **kw: te.Unpack[RestResource.TWriteKwargs]
                ) -> _MAGIC.lollipop_type[
                    # pylint: disable=line-too-long
                    'aos.scotch.libs.dashboard_schemas.BATCH_DASHBOARDS_DELETE_RESPONSE_SCHEMA']:
                    '''Batch delete of IBA dashboards.

                    :param dashboards: Dashboard IDs to delete.
                    :param delete_resources: Do we need to delete all
                        dependent resources as well.
                    '''
                    params = {}
                    if delete_resources is not None:
                        params['delete_resources'] = str(delete_resources)
                    return self._request(  # type: ignore[misc]
                        url='/dashboards-batch-delete',
                        method='POST', data=t.cast(list, dashboards),
                        params=params, **kw)

                @api('/graph-annotation-properties/registry')
                class graph_annotation_properties_registry(Api):
                    '''Manage graph annotation property registry.'''
                    def get(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> _MAGIC.lollipop_type[
                        # pylint: disable=line-too-long
                        'aos.scotch.libs.probe_schemas.GRAPH_ANNOTATION_PROPERTIES_REGISTRY']:
                        '''Get graph annotation property.'''
                        return t.cast(
                            dict,
                            self._request(method='GET', **kwargs)
                        )['items']

            @api('/predefined-reports')
            class predefined_reports(Api):
                '''Manage registry of predefined reports.'''

                def list(
                    self,
                    **kw: te.Unpack[RestResource.TReadKwargs]
                ) -> None | _MAGIC.lollipop_type[
                    'aos.scotch.schemas.qba.QBA_PREDEFINED_REPORTS_REGISTRY_LIST']:
                    '''Get all predefined reports.'''
                    params = kw.pop('params', None) or {}
                    data = t.cast(
                        dict,
                        self._request(params=params, **kw)  # type: ignore[misc]
                    )
                    return data['items'] if data else data

                @api('/{report_name}')
                class predefined_report(Api):
                    '''Manage registry predefined report.'''
                    def get(self) -> _MAGIC.lollipop_type[
                        'aos.scotch.schemas.qba.QBA_PREDEFINED_REPORT_PARAMETERS']:
                        '''Get predefined report.'''
                        return self._request()

            @api('/predefined-report')
            class predefined_report(Api):
                '''Manage predefined reports.'''

                @api('/{report_name}')
                class _predefined_report(Api):
                    '''Manage predefined report.'''

                    def create(
                        self,
                        data: _MAGIC.lollipop_type[
                            'aos.scotch.schemas.qba.QBA_PREDEFINED_REPORT_REQUEST'],
                        **kw: te.Unpack[RestResource.TWriteKwargs]
                    ) -> _MAGIC.lollipop_type[
                        'aos.scotch.schemas.qba.QBA_PREDEFINED_REPORT_RESPONSE']:
                        '''Create new instance of predefined report.

                        :param data: A data to create predefined report with.
                        '''
                        return self._request(method='POST', data=data, **kw)

            arca = resources(
                '/arca',
                get_schema=lp_schema(
                    'scotch.blueprints.arca',
                    'GET_ARCA_INSTANCE'
                ),
                collection_schema=lp_schema(
                    'scotch.blueprints.arca',
                    'GET_ARCA_INSTANCE'
                ),
                post_schema=lp_schema(
                    'scotch.blueprints.arca',
                    'POST_ARCA_INSTANCE'
                ),
                put_schema=lp_schema(
                    'scotch.blueprints.arca',
                    'PUT_ARCA_INSTANCE'
                ),
                resource_name='ARCA instance',
            )

            def get_telemetry_processors(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs],
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.libs.probe_schemas.GET_TELEMETRY_PROCESSORS']:
                '''Get telemetry processors.'''
                return t.cast(
                    dict,
                    self._request('/telemetry/processors', **kwargs)
                )['items']

            tasks = resources(
                '/tasks',
                with_options=True,
                collection_schema=lp_schema(
                    'scotch.blueprints.blueprint',
                    'TASK_LIST_RESPONSE_SCHEMA',
                ),
                get_schema=lp_schema(
                    'scotch.blueprints.blueprint',
                    'TASK_DETAILS_SCHEMA',
                ),
                resource_name='task',
            )

            @api('/revisions')
            class revisions(RestResources):
                '''Manage blueprint revisions.'''

                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> _MAGIC.lollipop_type[
                    # pylint: disable=line-too-long
                    'aos.scotch.blueprints.blueprint.BLUEPRINT_REVISION_ITEM_LIST_SCHEMA']:
                    '''Get all blueprint revisions.'''
                    return t.cast(dict, self._request(**kwargs))['items']

                @api('/{revision_id}')
                class resource(Api):
                    '''Manage blueprint revision.'''

                    def keep(
                        self,
                        description: t.Optional[str] = None,
                        **kwargs: te.Unpack[RestResource.TWriteKwargs],
                    ) -> tt.JSON:
                        '''Save a recent blueprint revision permanent.

                        :param description: Description of a revision.
                        '''
                        data = dict(description=description) if description else None
                        return self._request(
                            '/keep', data=t.cast(dict, data),
                            method='POST', **kwargs)

                    def update(
                        self,
                        description: str,
                        **kwargs: te.Unpack[RestResource.TWriteKwargs],
                    ) -> tt.JSON:
                        '''Update blueprint revision.

                        :param description: Updated description.
                        '''
                        return self._request(
                            method='PATCH',
                            data=dict(description=description), **kwargs)

                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> tt.JSON:
                        '''Delete blueprint revision.'''
                        return self._request(method='DELETE', **kwargs)

                # TODO(michael): Add GET API for individual revisions
                def get_revision(
                    self,
                    revision_id: str
                ) -> None | _MAGIC.lollipop_type[
                    # pylint: disable=line-too-long
                    'aos.scotch.blueprints.blueprint.BLUEPRINT_REVISION_ITEM_SCHEMA']:
                    '''Get a revision.

                    :param revision_id: Id of a revision to return.
                    '''
                    for revision in self.list():
                        if revision['revision_id'] == revision_id:
                            return revision
                    return None

            def anomalies_services_count(
                self
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.schemas.alerts.ROLE_TYPE_COUNT_LIST_SCHEMA']:
                '''Get a number of anomalies per role.'''
                return t.cast(
                    dict,
                    self._request('/anomalies_services_count')
                )['items']

            def anomalies_nodes_count(
                self
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.schemas.alerts.NODE_TYPE_COUNT_ITEM_SCHEMA']:
                '''Get a number of anomalies per node.'''
                return t.cast(
                    dict,
                    self._request('/anomalies_nodes_count')
                )['items']

    @api('/packages')
    class packages(
        RestResources,
        list__=lp_schema('devpi_schema', 'PACKAGE_GET_SCHEMA'),
        __list='Get all packages.',
    ):
        '''Manage packages.'''

        @api('/{package_name}')
        class resource(
            RestResource,
            get__=lp_schema('devpi_schema', 'PACKAGE_GET_ONE_SCHEMA'),
            __get='Get package.',
        ):
            '''Manage package.'''

        def create(  # type: ignore[override]
            self,
            package_name: str,
            package_data: bytes | t.IO
        ) -> _MAGIC.lollipop_type[
            'aos.scotch.blueprints.devpi_api.UPLOAD_RESPONSE_SCHEMA']:
            '''Create new package.

            :param package_name: A name of the package.
            :param package_data: A contents of the package.
            '''
            result = self._client._transport.request(
                method='POST', url='/packages/upload',
                headers={
                    # pylint: disable=line-too-long
                    'AuthToken': self._client._auth_token,  # type: ignore[attr-defined]
                },
                files={
                    'package': (package_name, package_data),  # type: ignore
                })
            if result.status_code not in HTTP_2xx:
                if result.status_code == 404:
                    return None
                else:
                    raise ClientError(result.status_code, result.text)
            return result

    @api('/streaming-telemetry-schema')
    class streaming_telemetry_schema(Api):
        '''Manage schema of streaming telemetry.'''

        def get_message_schema(self) -> bytes:
            '''
            Get binary representation of the protobuf schema of
            streaming telemetry.

            This can be then imported by the protobuf in a following way:

            ```python
            file_descriptor_set = FileDescriptorSet()
            file_descriptor_set.ParseFromString(data)
            messages = message_factory.GetMessages(file_descriptor_set.file)
            msg_class = messages['aos.streaming.AosMessage']
            ```
            '''
            headers = {'AuthToken': self._client._auth_token}  # type: ignore

            response = self._client._transport.request(
                method='GET', url=self._url, headers=headers)

            if response.status_code not in HTTP_2xx:
                raise ClientError(response.status_code, response.text)

            return response.content

    telemetry_service_registry = resources(
        '/telemetry-service-registry',
        with_options=True,
        get_schema=lp_schema(
            'telemetry_service_registry_schema',
            'SERVICE_REGISTRY_GET_SCHEMA'
        ),
        collection_schema=lp_schema(
            'scotch.blueprints.telemetry_service_registry',
            'SERVICE_REGISTRY_LIST_SCHEMA'
        ),
        post_schema=lp_schema(
            'telemetry_service_registry_schema',
            'SERVICE_REGISTRY_POST_SCHEMA'
        ),
        put_schema=lp_schema(
            'telemetry_service_registry_schema',
            'SERVICE_REGISTRY_PUT_SCHEMA'
        ),
        patch_schema=lp_schema(
            'telemetry_service_registry_schema',
            'SERVICE_REGISTRY_PATCH_SCHEMA'
        ),
        resource_name='service registry',
    )

    @api('/telemetry/collectors')
    class telemetry_collectors(
        RestResources,
        list__=lp_schema(
            'scotch.blueprints.telemetry_service_collectors',
            'DDT_SERVICES_COLLECTORS_LIST_SCHEMA'
        ),
        __list='Get all telemetry collectors.',
        create__data=lp_schema(
            'scotch.blueprints.telemetry_service_collectors',
            'DDT_SERVICE_COLLECTORS_SCHEMA'
        ),
        create__=lp_schema(
            'scotch.blueprints.telemetry_service_collectors',
            'DDT_SERVICE_CREATE_RESPONSE_SCHEMA'
        ),
        __create='''
            Create new telemetry collector.

            :param data: Telemetry collector specification.
        '''
    ):
        '''Manage telemetry collectors.'''

        @api('/{service_name}')
        class resource(
            RestResource,
            get__=lp_schema(
                'scotch.blueprints.telemetry_service_collectors',
                'DDT_COLLECTOR_ITEM_LIST_SCHEMA'
            ),
            __get='Get a telemetry collector.',
            update__data=lp_schema(
                'scotch.blueprints.telemetry_service_collectors',
                'DDT_COLLECTORS_UPDATE_SCHEMA'
            ),
            __update='''
                Update a telemetry collector.

                :param data: Update telemetry collector data.
            ''',
            patch__data=lp_schema(
                'scotch.blueprints.telemetry_service_collectors',
                'DDT_COLLECTORS_UPDATE_SCHEMA'
            ),
            __patch='''
                Partially update telemetry collector.

                :param data: Updated collector properties.
            '''
        ):
            '''Manage telemetry collector.'''

            def get_collectors_list(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> _MAGIC.lollipop_type[
                    # pylint: disable=line-too-long
                'aos.scotch.blueprints.telemetry_service_collectors.DDT_COLLECTOR_LIST_SCHEMA']:
                '''Get all telemetry collectors as list.'''
                return t.cast(
                    dict,
                    self._request(method='GET', **kwargs)
                )['items']

            @api('/{os_type}')
            class resource(RestResource):
                '''Manage telemetry collectors for OS type.'''

                @api('/{family}')
                class resource(RestResource):
                    '''Manage telemetry collectors for OS family.'''

                    @api('/{os_version}')
                    class resource(
                        RestResource,
                        get__=lp_schema(
                            'scotch.blueprints.telemetry_service_collectors',
                            'DDT_COLLECTOR_SCHEMA',
                        ),
                        __get='Get telemetry collector.',
                    ):
                        '''Manage telemetry collectors for OS version.'''
                        def get_collector(
                            self,
                            model: t.Optional[str] = None
                        ) -> _MAGIC.lollipop_type[
                            # pylint: disable=line-too-long
                            'aos.scotch.blueprints.telemetry_service_collectors.DDT_COLLECTOR_SCHEMA']:
                            '''Get a collector.

                            :param model: Filter by model.
                            '''
                            params = {}
                            if model is not None:
                                params['model'] = model
                            return self._request(method='GET', params=params)

                        def delete_collector(
                            self,
                            model: t.Optional[str] = None
                        ) -> tt.JSON:
                            '''Delete collector.

                            :param model: Filter by model.
                            '''
                            params = {}
                            if model is not None:
                                params['model'] = model
                            return self._request(method='DELETE', params=params)

    @api('/cluster/nodes')
    class cluster(
        RestResources,
        options__=lp_schema('schema', 'OptionsSchema'),
        list__=lp_schema(
            'scotch.blueprints.cluster',
            'CLUSTER_NODE_GET_NODE_LIST_STATUS_SCHEMA'
        ),
        __list='Get all cluster nodes.',
        create__data=lp_schema(
            'scotch.blueprints.cluster',
            'CLUSTER_NODE_POST_SCHEMA'
        ),
        __create='''
            Create new cluster node.

            :param data: Description of a new node.
        '''
    ):
        @api('/{node_id}')
        class resource(
            RestResource,
            get__=lp_schema(
                'scotch.blueprints.cluster',
                'CLUSTER_NODE_GET_SCHEMA'
            ),
            __get='Get the cluster node.',
            patch__data=lp_schema(
                'scotch.blueprints.cluster',
                'CLUSTER_NODE_PATCH_SCHEMA'
            ),
            __patch='''
                Partially update cluster node.

                :param data: Updated properties.
            ''',
            update__data=lp_schema(
                'scotch.blueprints.cluster',
                'CLUSTER_NODE_PATCH_SCHEMA'
            ),
            __update='''
                Update cluster node.

                :param data: Updated cluster node.
            '''
        ):
            '''Manage cluster node.'''

            def errors(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.blueprints.cluster.NODE_ERROR_STATUS_SCHEMA']:
                '''Get errors from a cluster node.'''
                return self._request('/errors', **kwargs)

    @api('/cluster/application-weight')
    class cluster_weights(
        RestResource,
        get__=lp_schema(
            'scotch.blueprints.cluster',
            'APPLICATION_WEIGHT_GET_SCHEMA'
        ),
        __get='Get application weight.',
        update__data=lp_schema(
            'scotch.blueprints.cluster',
            'APPLICATION_WEIGHT_PUT_SCHEMA'
        ),
        __update='''
            Update application weight.

            :param data: Updated application weight description.
        ''',
        patch__data=lp_schema(
            'scotch.blueprints.cluster',
            'APPLICATION_WEIGHT_PATCH_SCHEMA'
        ),
        __patch='''
            Partially update application weight.

            :param data: Updated properties.
        '''
    ):
        '''Manage cluster weights.'''

    @api('/cluster/operation-mode')
    class cluster_operation_mode(
        RestResource,
        get__=lp_schema('scotch.blueprints.cluster', 'OPERATION_GET_SCHEMA'),
        __get='Get operation mode.',
        update__data=lp_schema(
            'scotch.blueprints.cluster',
            'OPERATION_PUT_SCHEMA'
        ),
        __update='''
            Update operation mode.

            :param data: Updated mode.
        '''
    ):
        '''Manage cluster operation mode.'''

    licenses = resources(
        '/cluster/licenses',
        with_options=True,
        get_schema=lp_schema(
            'scotch.blueprints.license',
            'GET_RESPONSE_SCHEMA'
        ),
        collection_schema=lp_schema(
            'scotch.blueprints.license',
            'LIST_RESPONSE_SCHEMA',
        ),
        post_schema=lp_schema(
            'scotch.blueprints.license',
            'POST_REQUEST_SCHEMA'
        ),
        resource_name='license',
        resource_names='licenses'
    )

    @api('/cluster/apstra-edge')
    class cluster_apstra_edge(
        RestResource,
        get__=lp_schema(
            'scotch.blueprints.cluster',
            'APSTRA_EDGE_GET_SCHEMA',
        ),
        __get='Get Apstra Edge info.',
        update__data=lp_schema(
            'scotch.blueprints.cluster',
            'APSTRA_EDGE_SCHEMA'
        ),
        __update='''
            Launch or update Apstra Edge.

            :param data: Launch data.
        ''',
        __delete='Stop Apstra Edge.',
    ):
        '''Manage Apstra Edge.'''

    @api('/iba-unit-config')
    class iba_unit_config(
        RestResource,
        get__=lp_schema('scotch.libs.probe_schemas', 'IBA_UNIT_CONFIG_SCHEMA'),
        __get='Get IBA unit config.',
    ):
        def update(
            self,
            data: _MAGIC.lollipop_type[
            'aos.scotch.libs.probe_schemas.IBA_UNIT_CONFIG_SCHEMA'],
            **kwargs: te.Unpack[RestResource.TWriteKwargs]
        ) -> tt.JSON:
            '''Update IBA unit config.

            :param data: Updated config.
            '''
            return self._request(method='POST', data=data, **kwargs)

    @api('/ztp')
    class ztp(RestResource):
        '''Manage ZTP configuration.'''

        @api('/device')
        class device(
            RestResources,
            create__data=lp_schema(
                'scotch.blueprints.ztp',
                'ZTP_STATUS_POST_SCHEMA'
            ),
            create__=lp_schema(
                'scotch.blueprints.ztp',
                'ZTP_STATUS_POST_RESPONSE_SCHEMA'
            ),
            __create='''
                Create new ZTP status of a device.

                :param data: ZTP status.
            ''',
            list__=lp_schema(
                'scotch.blueprints.ztp',
                'ZTP_STATUS_LIST_SCHEMA'
            ),
            __list='Get all ztp statuses for devices.'
        ):
            @api('/{ip_address}')
            class resource(RestResource):
                '''Manage device ZTP configurations by IP address.'''

                def status(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> _MAGIC.lollipop_type[
                    'aos.scotch.blueprints.ztp.ZTP_STATUS_GET_SCHEMA']:
                    '''Get a status of a device.'''
                    return self._request('/status', method='GET', **kwargs)

        @api('/service')
        class service(
            RestResources,
            list__=lp_schema(
                'scotch.blueprints.ztp',
                'ZTP_SERVICE_LIST_SCHEMA'
            ),
            __list='Get all service ZTP statuses.',
            create__data=lp_schema(
                'scotch.blueprints.ztp',
                'ZTP_SERVICE_POST_SCHEMA'
            ),
            create__=lp_schema(
                'scotch.blueprints.ztp',
                'ZTP_SERVICE_POST_RESPONSE_SCHEMA'
            ),
            __create='''
                Create a new ZTP server status.

                :param data: New status.
            '''
        ):
            '''Manage ZTP status services.'''

            @api('/{service_name}')
            class resource(RestResource):
                '''Manage ZTP status of service.'''

                def status(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type[
                    'aos.scotch.blueprints.ztp.ZTP_SERVICE_GET_SCHEMA']:
                    '''Get ZTP status of a server.'''
                    return self._request('/status', method='GET', **kwargs)

        @api('/{ip_address}')
        class resource(RestResource):
            '''Manage ZTP nodes.'''

            def logs(self) -> str:
                '''Get logs from a node.'''
                return t.cast(str, self._request('/logs', method='GET'))

    @api('/device-os')
    class device_os(RestResource):
        '''Manage device OSes.'''

        @api('/images-external')
        class images_external(
            RestResources,
            create__data=lp_schema(
                'scotch.blueprints.device_os_images',
                'DOS_EXTERNAL_POST_SCHEMA'
            ),
            __create='''
                Create new external image.

                :param data: Image properties.
            ''',
        ):
            '''Manage external images.'''

        @api('/images')
        class images(
            RestResources,
            options__=lp_schema('schema', 'OptionsSchema'),
            list__=lp_schema(
                'scotch.blueprints.device_os_images',
                'DOS_GET_ALL_SCHEMA'
            ),
            __list='Get all images.',
        ):

            '''Manage device OS images.'''
            # Override the default create method. The create request needs to
            # send file content and payload. The semantics are different from the
            # regular create method.
            # pylint: disable=arguments-differ
            def create(  # type: ignore[override]
                self,
                data: _MAGIC.lollipop_type[
                'aos.scotch.blueprints.device_os_images.DOS_UPLOAD_POST_SCHEMA'],
                file_name: str,
                file_content: str | t.IO
            ) -> _MAGIC.lollipop_type['aos.scotch.schemas.schema.IdSchema']:
                '''Create a new image.

                :param data: Metadata of device OS.
                :param file_name: The name of the image.
                :param file_content: The byte content of an image.
                '''
                # The implemented "raw_request" does a json.dumps on the data
                # provided as argument. The underlying requests library
                # requires it to be a dictionary when sending files. Considering
                # this caveat, we are reimplementing parts of code from the
                # http test client's raw_request implementation.
                response = self._client._transport.request(
                    url='/device-os/images',
                    method='POST',
                    data=data,
                    files={
                        'image': (file_name, file_content),  # type: ignore
                    },
                    headers={
                        'AuthToken': self._client._auth_token,  # type: ignore
                    },
                )
                if response.status_code not in HTTP_2xx:
                    raise ClientError(response.status_code, response.text)

                return json.loads(response.text) if len(response.text) > 0 else None

        def stats(
            self
        ) -> _MAGIC.lollipop_type[
            'aos.scotch.blueprints.device_os_images.DOS_IMAGES_DISK_USAGE_SCHEMA']:
            '''Get statistics of device OS images.'''
            return self._request('/stats')

        def validate_image(
            self,
            data: _MAGIC.lollipop_type[
            # pylint: disable=line-too-long
            'aos.scotch.blueprints.device_os_images.DOS_VALIDATE_UPLOAD_POST_SCHEMA']
        ) -> tt.JSON:
            '''Validate OS image before upload.

            :param data: Metadata of the image.
            '''
            return self._request(method='POST', url='/validate-image', data=data)

    @api('/system-agent')
    class system_agent(RestResource):
        '''Manage system agent.'''

        @api('/manager-config')
        class manager_config(RestResource):
            '''Control manager config.'''

            def get(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> _MAGIC.lollipop_type[
                # pylint: disable=line-too-long
                'aos.scotch.blueprints.system_agent.SYSTEM_AGENT_MANAGER_CONFIG_SCHEMA']:
                '''Get system agent manager config.'''
                return self._request(**kwargs)

            def update(
                self,
                data: _MAGIC.lollipop_type[
                # pylint: disable=line-too-long
                'aos.scotch.blueprints.system_agent.SYSTEM_AGENT_MANAGER_CONFIG_SCHEMA'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs]
            ) -> tt.JSON:
                '''Update system agent manager config.

                :param data: Updated config.
                '''
                return self._request(method='PUT', data=data, **kwargs)

    @api('/system-agents')
    class system_agents(
        RestResources,
        options__=lp_schema('schema', 'OptionsSchema'),
        list__=lp_schema(
            'scotch.blueprints.system_agent',
            'SYSTEM_AGENT_LIST_SCHEMA'
        ),
        __list='Get all system agents.',
        create__data=lp_schema(
            'scotch.blueprints.system_agent',
            'SYSTEM_AGENT_POST_SCHEMA'
        ),
        __create='''
            Create new system agent.

            :param data: System agent configuration.
        ''',
    ):
        '''Manage system agents.'''

        @api('/{agent_id}')
        class resource(
            RestResource,
            get__=lp_schema(
                'scotch.blueprints.system_agent',
                'SYSTEM_AGENT_GET_SCHEMA'
            ),
            __get='Get system agent.',
            update__data=lp_schema(
                'scotch.blueprints.system_agent',
                'SYSTEM_AGENT_PUT_SCHEMA'
            ),
            __update='''
                Update system agent.

                :param data: Updated configuration.
            ''',
            patch__data=lp_schema(
                'scotch.blueprints.system_agent',
                'SYSTEM_AGENT_PUT_SCHEMA'
            ),
            __patch='''
                Partially update system agent.

                :param data: Updated configuraton properties.
            '''
        ):
            def cancel(self) -> tt.JSON:
                '''Cancel a job for onbox system agent.'''
                return self._request('/cancel', method='POST', data={})

            def check(self) -> tt.JSON:
                '''Check if the system agent can authenitcate to the device.'''
                return self._request('/check', method='POST', data={})

            def install(self) -> tt.JSON:
                '''Install onbox system agent to the device.'''
                return self._request('/install-agent', method='POST', data={})

            def uninstall(self) -> tt.JSON:
                '''Uninstall system agent from the device.'''
                return self._request('/uninstall-agent', method='POST', data={})

            def show_tech(self) -> tt.JSON:
                '''Collect show tech from a device.'''
                return self._request('/show-tech', method='POST', data={})

            def dos_upgrade(self, image_id: str) -> tt.JSON:
                '''Update device OS.

                :param image_id: Image ID with device OS to use.
                '''
                return self._request(
                    '/dos-upgrade', method='POST', data=dict(image_id=image_id))

            def revert_to_pristine(self) -> tt.JSON:
                '''Revert device configuration to pristine state.'''
                return self._request('/revert-to-pristine', method='POST', data={})

            def collect_pristine(self) -> tt.JSON:
                '''Collect pristine config from the device.'''
                return self._request('/collect-pristine', method='POST', data={})

            def update_pristine(
                self,
                data: _MAGIC.lollipop_type[
                'aos.scotch.blueprints.deployment.pristine.PRISTINE_POST_SCHEMA']
            ) -> tt.JSON:
                '''Update device pristine config.

                :param data: Updated config.
                '''
                return self._request('/pristine-config', method='POST', data=data)

            def get_pristine(
                self
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.blueprints.deployment.pristine.PRISTINE_GET_SCHEMA']:
                '''Get device pristine config.'''
                return self._request('/pristine-config')

            def last_job_log(self) -> str:
                '''Collect log of the latest job.'''
                return self._raw_request('/last-job-log').text

            def job_history(
                self
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.blueprints.system_agent.JOB_LIST_SCHEMA']:
                '''Get a job history of system agent operations.'''
                return self._request('/job-history')

            @api('/job-logs')
            class job_logs(RestResources):
                '''Manage job logs.'''

                @api('/{job_id}')
                class resource(
                    RestResource,
                    get__='str',
                    __get='Get a job log.',
                ):
                    '''Manage job log.'''

    @api('/system-agent-jobs')
    class system_agent_jobs(RestResource):
        '''Manage system agent jobs.'''

        def pending_jobs(
            self
        ) -> _MAGIC.lollipop_type[
            'aos.scotch.blueprints.system_agent.JOB_LIST_SCHEMA']:
            '''Get a list of pending jobs.'''
            return self._request('/pending-jobs')

        def active_jobs(
            self
        ) -> _MAGIC.lollipop_type[
            'aos.scotch.blueprints.system_agent.JOB_LIST_SCHEMA']:
            '''Get a list of active jobs.'''
            return self._request('/active-jobs')

    @api('/system-agent-profiles')
    class system_agent_profiles(
        RestResources,
        options__=lp_schema('schema', 'OptionsSchema'),
        create__data=lp_schema(
            'scotch.blueprints.system_agent_profile',
            'PROFILE_CREATE_SCHEMA'
        ),
        create__=lp_schema('schema', 'IdSchema'),
        __create='''
            Create a new system agent profile.

            :param data: Profile configuration.
        ''',
        list__=lp_schema(
            'scotch.blueprints.system_agent_profile',
            'PROFILE_LIST_SCHEMA'
        ),
        __list='List system agent profiles.'
    ):
        '''Manage system agent profiles.'''

        @api('/{profile_id}')
        class resource(
            RestResource,
            get__=lp_schema(
                'scotch.blueprints.system_agent_profile',
                'PROFILE_GET_SCHEMA'
            ),
            __get='Get system agent profile.',
            update__data=lp_schema(
                'scotch.blueprints.system_agent_profile',
                'PROFILE_PUT_SCHEMA'
            ),
            __update='''
                Update system agent profile.

                :param data: Update profile.
            ''',
            patch__data=lp_schema(
                'scotch.blueprints.system_agent_profile',
                'PROFILE_PATCH_SCHEMA'
            ),
            __patch='''
                Partially update system agent profile.

                :param data: Updated profile properties.
            '''
        ):
            '''Manage system agent profile.'''

            def assign(
                self,
                data: _MAGIC.lollipop_type[
                'aos.scotch.blueprints.system_agent_profile.PROFILE_ASSIGN_SCHEMA']
            ) -> tt.JSON:
                '''Assign system agent profile to system agents.

                :param data: A list of system agent to assign profile to.
                '''
                return self._request('/assign', method='POST', data=data)

    @api('/show-tech')
    class show_tech(RestResource):
        '''Manage show tech dumps.'''

        @api('/jobs')
        class jobs(
            RestResources,
            options__=lp_schema('schema', 'OptionsSchema'),
            list__=lp_schema(
                'scotch.blueprints.show_tech',
                'SHOW_TECH_JOB_LIST_SCHEMA'
            ),
            __list='Get a list of all show tech jobs.'
        ):
            '''Manage show tech jobs.'''

        def batch_delete(self, job_ids: collections.abc.Sequence[str]) -> tt.JSON:
            '''Delete a batch of show tech jobs.

            :param job_ids: IDs of jobs to delete.
            '''
            return self._request(
                '/batch-delete',
                method='POST',
                data=list(job_ids)
            )

        def collect_controller(
            self,
            backup_mode: t.Literal['on', 'off'] = 'off'
        ) -> _MAGIC.lollipop_type['aos.scotch.schemas.schema.IdSchema']:
            '''Collect controller show tech.

            :param backup_mode: Collect in backup mode or not.
            '''
            return self._request('/controller', method='POST', data=dict(
                backup_mode=backup_mode,
            ))

        def collect_flow_data_collector(
            self,
            data: _MAGIC.lollipop_type[
            # pylint: disable=line-too-long
            'aos.scotch.blueprints.show_tech.FLOW_DATA_COLLECTOR_SHOW_TECH_POST_SCHEMA']
        ) -> _MAGIC.lollipop_type['aos.scotch.schemas.schema.IdSchema']:
            '''Generate show tech tarball for the given flow collector.

            :param data: Job specification.
            '''
            return self._request('/flow-data-collector', method='POST', data=data)

        def collect_cluster_node(
            self,
            data: _MAGIC.lollipop_type[
            'aos.scotch.blueprints.show_tech.CLUSTER_NODE_SHOW_TECH_POST_SCHEMA']
        ) -> _MAGIC.lollipop_type['aos.scotch.schemas.schema.IdSchema']:
            '''Collect show tech tarball for a given cluster node.

            :param data: Job specification.
            '''
            return self._request('/cluster-node', method='POST', data=data)

    @api('/telemetry/schemas')
    class telemetry_rpc_schemas(
        RestResources,
        options__=lp_schema(
            'scotch.blueprints.telemetry_rpc_schema_registry',
            'DDT_SCHEMA_ITEMS'
        ),
        __options='Get RPC schema index file contents',
    ):
        '''Manage RPC schemas.'''

        @api('/parse-device-os-version')
        class parse_device_os_version(RestResources):
            '''Parse device OS version.'''

            @api('/{device_os}')
            class resource(RestResources):
                '''Parse device OS version by given OS type.'''

                @api('/{version}')
                class resource(RestResources):
                    '''Parse device OS version by given OS type and version
                    spec.'''

        @api('/{source}')
        class resource(RestResource):
            '''Get RPC schema by source.'''

            @api('/{os_type}')
            class resource(RestResource):
                '''Get RPC schema by OS type.'''

                @api('/{family}')
                class resource(RestResource):
                    '''Get RPC schema by OS family.'''

                    @api('/{os_version}')
                    class resource(RestResource):
                        '''Get RPC schema by OS version.'''

                        def get_modules_list(
                            self
                        ) -> _MAGIC.lollipop_type[
                            # pylint: disable=line-too-long
                            'aos.scotch.blueprints.telemetry_rpc_schema_registry.DDT_SCHEMA_MODULE_NAME_LIST']:
                            '''Get list of all available modules.'''
                            return t.cast(
                                dict,
                                self._request('/modules')
                            )['items']

                        def get_cmd_rpc_map(self) -> tt.JSON:
                            '''Get a mapping of commands to their RPC names.'''
                            return t.cast(
                                dict,
                                self._request('/cmd_rpc_map')
                            )['items']

                        @api('/module')
                        class module(RestResources):
                            '''Manage RPC modules.'''

                            @api('/{module}')
                            class resource(
                                RestResource,
                                get__=lp_schema(
                                    # pylint: disable=line-too-long
                                    'scotch.blueprints.telemetry_rpc_schema_registry',
                                    'DDT_SCHEMA_MODULE_LIST',
                                ),
                                __get='Get information for the module.'
                            ):
                                '''Manage RPC module.'''

                        @api('/rpc')
                        class rpc(RestResources):
                            '''Manage information about RPC calls.'''

                            @api('/{rpc_name}')
                            class resource(
                                RestResource,
                                get__=lp_schema(
                                    # pylint: disable=line-too-long
                                    'scotch.blueprints.telemetry_rpc_schema_registry',
                                    'DDT_SCHEMA_CLI_RPC_LIST',
                                ),
                                __get='Get information about RPC call.',
                            ):
                                '''Manage RPC call information.'''

    flow_data_collectors = resources(
        '/telemetry/flow-data-collectors',
        with_options=True,
        get_schema=lp_schema(
            'scotch.blueprints.flow_data_collector',
            'GET_SCHEMA'
        ),
        collection_schema=lp_schema(
            'scotch.blueprints.flow_data_collector',
            'GET_ALL_SCHEMA'
        ),
        post_schema=lp_schema(
            'scotch.blueprints.flow_data_collector',
            'POST_SCHEMA'
        ),
        put_schema=lp_schema(
            'scotch.blueprints.flow_data_collector',
            'PUT_SCHEMA'
        ),
        patch_schema=lp_schema(
            'scotch.blueprints.flow_data_collector',
            'PATCH_SCHEMA'
        ),
        resource_name='flow data collector',
    )

    telemetry_services = resources(
        '/telemetry/services',
        with_options=True,
        collection_schema=lp_schema(
            'scotch.blueprints.telemetry_service',
            'SYSTEM_SERVICE_MAPPING_SCHEMA',
        ),
        get_schema=lp_schema(
            'scotch.blueprints.telemetry_service',
            'LIST_SERVICE_SYSTEM_SCHEMA',
        ),
        resource_name='telemetry service',
    )

    # [Note]: metricdb query is purposely not metricdb/{metric}/query.
    # {metric} is not an id but a path.
    @api('/metricdb/query')
    class metricdb_query(
        RestResources,
        create__data=lp_schema('metricdb', 'METRIC_QUERY_REQUEST'),
        create__=lp_schema('metricdb', 'METRIC_QUERY_RESPONSE'),
        __create='''
            Execute a metricdb query.

            :param data: Query to execute.
        '''
    ):
        '''Execute a metricdb query.'''

    # TODO(rajeev): Url should be plural to match others.
    @api('/metricdb/metric')
    class metricdb_metrics(
        RestResources,
        list__=lp_schema('metricdb', 'METRIC_GET_RESPONSE'),
        __list='Get all metrics.',
    ):
        '''Manage metricdb metrics.'''

        @api('/{metric_path}')
        class resource(
            RestResources,
            list__=lp_schema('metricdb', 'METRIC_GET_RESPONSE'),
            __list='Get relevant metricdb metrics.',
        ):
            '''Manage metricdb metrics by path.'''

            @api('/schema')
            class schema(
                RestResource,
                get__=lp_schema('metricdb', 'METRIC_SCHEMA_GET_RESPONSE'),
                __get='Get metricdb metric schema.',
            ):
                '''Manage metric schema.'''

            @api('/stats')
            class stats(
                RestResource,
                get__=lp_schema('metricdb', 'METRIC_STATS_GET_RESPONSE'),
                __get='Get metricdb metric stats.',
            ):
                '''Manage metric stats.'''

    @api('/webcons')
    class webcons(Api):
        '''Access database entries in file explorer view.'''

        def partitions(
            self,
            **kwargs: te.Unpack[RestResource.TReadKwargs]
        ) -> str:
            '''Show all partitions.'''
            return t.cast(str, self._request(**kwargs))

        def get_item(
            self,
            path: str,
            **kwargs: te.Unpack[RestResource.TReadKwargs]
        ) -> str:
            '''Return item by path.

            :param path: Path in filesystem notation.
            '''
            return t.cast(str, self._request(url=path, **kwargs))

    @api('/virtual-infra-managers')
    class virtual_infra_managers(
        RestResources,
        create__data=lp_schema(
            'scotch.blueprints.virtual_infra_manager',
            'VIRTUAL_INFRA_MANAGER_POST_SCHEMA'
        ),
        create__=lp_schema(
            'scotch.blueprints.virtual_infra_manager',
            'VIRTUAL_INFRA_MANAGER_RESPONSE_SCHEMA'
        ),
        __create='''
            Create new virtual infra manager.

            :param data: Manager properties.
        ''',
        list__=lp_schema(
            'scotch.blueprints.virtual_infra_manager',
            'VIRTUAL_INFRA_MANAGER_LIST_SCHEMA'
        ),
        __list='Get all virtual infra managers.',
    ):
        '''Control virtual infra managers.'''

        @api('/{virtual_infra_manager}')
        class resource(
            RestResource,
            get__=lp_schema(
                'scotch.blueprints.virtual_infra_manager',
                'VIRTUAL_INFRA_MANAGER_LIST_SCHEMA'
            ),
            __get='Get virtual infra manager.',
            patch__data=lp_schema(
                'scotch.blueprints.virtual_infra_manager',
                'VIRTUAL_INFRA_MANAGER_PATCH_SCHEMA'
            ),
            patch__=lp_schema(
                'scotch.blueprints.virtual_infra_manager',
                'VIRTUAL_INFRA_MANAGER_RESPONSE_SCHEMA'
            ),
            __patch='''
                Partially update virtual infra manager.

                :param data: Updated properties.
            ''',
            update__data=lp_schema(
                'scotch.blueprints.virtual_infra_manager',
                'VIRTUAL_INFRA_MANAGER_PUT_SCHEMA'
            ),
            update__=lp_schema(
                'scotch.blueprints.virtual_infra_manager',
                'VIRTUAL_INFRA_MANAGER_RESPONSE_SCHEMA'
            ),
            __update='''
                Update virtual infra manager.

                :param data: Updated configuration.
            '''
        ):
            '''Manage virtual infra manager.'''

            @api('/vcenters')
            class vcenters(
                RestResources,
                create__data=lp_schema(
                    'scotch.blueprints.virtual_infra_manager',
                    'VCENTER_POST_SCHEMA'
                ),
                create__=lp_schema('schema', 'IdSchema'),
                __create='''
                    Create a new instance of vCenter.

                    :param data: vCenter configuration.
                '''
            ):
                '''Manage virtual infra vCenters.'''

                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type[
                    # pylint: disable=line-too-long
                    'aos.scotch.blueprints.virtual_infra_manager.VIRTUAL_INFRA_MANAGER_LIST']:
                    '''Get all vCenters.'''
                    return t.cast(dict, self._request(**kwargs))['items']

    @api('/telemetry/fetchcmd')
    class telemetry_fetch_command(
        RestResources,
        create__data=lp_schema(
            'scotch.blueprints.telemetry_fetch_command',
            'DDT_SCHEMA_FETCHCMD_REQUEST'
        ),
        create__=lp_schema(
            'scotch.blueprints.telemetry_fetch_command',
            'DDT_SCHEMA_FETCHCMD_RESPONSE'
        ),
        __create='''
            Execute fetch command request.

            :param data: Request specification.
        '''
    ):
        '''Manage telemetry fetch commands.'''

        def make_request(
            self,
            system_id: str,
            command_text: str,
            output_format: t.Optional[t.Literal['json', 'xml', 'text']] = None
        ) -> _MAGIC.lollipop_type[
            # pylint: disable=line-too-long
            'aos.scotch.blueprints.telemetry_fetch_command.DDT_SCHEMA_FETCHCMD_RESPONSE']:
            '''Execute fetch command request (convenience wrapper).

            :param system_id: Id of a system to execute request to.
            :param command_text: Command to execute.
            :param output_format: Format of the response.
            '''
            return self._request(method='POST', data=dict(
                system_id=system_id,
                command_text=command_text,
                output_format=output_format
            ))

        @api('/{request_id}')
        class resource(
            RestResource,
            get__=lp_schema(
                'scotch.blueprints.telemetry_fetch_command',
                'DDT_SCHEMA_FETCHCMD_GETOUTPUT_RESPONSE'
            ),
            __get='Get result of fetch command request.'
        ):
            '''Manage fetch command request.'''

            def query(
                self,
                data: _MAGIC.lollipop_type[
                # pylint: disable=line-too-long
                'aos.scotch.blueprints.telemetry_fetch_command.DDT_SCHEMA_FETCHCMD_QUERY_REQUEST']
            ) -> _MAGIC.lollipop_type[
                # pylint: disable=line-too-long
                'aos.scotch.blueprints.telemetry_fetch_command.DDT_SCHEMA_FETCHCMD_QUERY_RESPONSE']:
                '''Run XML query on fetch command output.

                :param data: Query to execute.
                '''
                return self._request(method='POST', url='/query', data=data)

            def validate(
                self,
                data: _MAGIC.lollipop_type[
                # pylint: disable=line-too-long
                'aos.scotch.blueprints.telemetry_fetch_command.DDT_SCHEMA_FETCHCMD_VALIDATERPC_REQUEST']
            ) -> _MAGIC.lollipop_type[
                # pylint: disable=line-too-long
                'aos.scotch.blueprints.telemetry_fetch_command.DDT_SCHEMA_FETCHCMD_VALIDATERPC_RESPONSE']:
                '''Validate RPC call output against its schema.

                :param data: Request specification.
                '''
                return self._request(method='POST', url='/validate', data=data)

    @api('/product-usage')
    class product_usage(Api):
        """ Manage product usage statistic """
        def create(self, **kwargs: te.Unpack[RestResource.TWriteKwargs]) -> str:
            """ Request new report. """
            return self._request(method='POST', **kwargs)['id']

        def list(
                self, **kwargs: te.Unpack[RestResource.TWriteKwargs]
        ) -> _MAGIC.lollipop_type[
            'aos.scotch.blueprints.product_usage.PRODUCT_USAGE_REPORTS_SCHEMA']:
            """ Get all reports. """
            return self._request(method='GET', **kwargs)

        def digest(
                self, **kwargs: te.Unpack[RestResource.TWriteKwargs]
        ) -> _MAGIC.lollipop_type[
            'aos.scotch.blueprints.product_usage.PRODUCT_USAGE_DIGEST_SCHEMA']:
            """ Get reports digest.

            Returns all existing report IDs with their status, i.e. whether
            the report is completed or not.
            """
            return self._request(method='GET', url='/digest', **kwargs)

        @api('/{request_id}')
        class resource(Api):
            def get(
                    self, **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> _MAGIC.lollipop_type[
                'aos.scotch.blueprints.product_usage.PRODUCT_USAGE_REPORT_SCHEMA']:
                """ Get product usage report. """
                return self._request(method='GET', **kwargs)

            def delete(
                    self, **kwargs: te.Unpack[RestResource.TReadKwargs]
            ) -> tt.JSON:
                """ Delete product usage job. """
                return self._request(method='DELETE', **kwargs)

    @api('/product-usage-nightly')
    class product_usage_nightly(Api):
        def get(
                self, **kwargs: te.Unpack[RestResource.TReadKwargs]
        ) -> _MAGIC.lollipop_type[
            'aos.scotch.blueprints.product_usage.PRODUCT_USAGE_REPORT_SCHEMA']:
            """ Get product usage nightly report. """
            return self._request(method='GET', **kwargs)
