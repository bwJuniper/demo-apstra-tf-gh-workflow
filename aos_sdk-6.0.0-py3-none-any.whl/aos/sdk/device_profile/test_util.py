# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import aos.sdk.py3compat  # pylint: disable=unused-import

import os

from enum import Enum, unique
from six.moves import json

import aos.sdk.device_profile.device_profile as dp
import aos.sdk.device_profile.generator as g
from aos.sdk.py3compat import json_load_str

# pylint: disable=invalid-name
# pylint: disable=line-too-long
# pylint: disable=redefined-builtin
# pylint: disable=pointless-string-statement

"""
    Device profile generator used for unit testing purposes.
"""

CISCO_LINECARD_PORTS = [
    {
        "column_id": 1,
        "connector_type": "qsfp",
        "failure_domain_id": 1,
        "panel_id": 1,
        "port_id": i,
        "row_id": 1,
        "slot_id": "{{slot_id}}",
        "transformations": [
            {
                "interfaces": [
                    {
                        "interface_id": 1,
                        "name": "Ethernet{{slot_id}}/%s"%i,
                        "setting": "{\"interface\": {\"speed\": \"40000\"}, \"global\": {\"port_index\": -1, \"speed\": \"\", \"module_index\": -1}}",
                        "speed": {
                            "unit": "G",
                            "value": 40
                        },
                        "state": "active"
                    }
                ],
                "is_default": True,
                "transformation_id": 1
            },
            {
                "interfaces": [
                    {
                        "interface_id": 1,
                        "name": "Ethernet{{slot_id}}/%s/1"%i,
                        "setting": "{\"interface\": {\"speed\": \"10000\"}, \"global\": {\"port_index\": 1, \"speed\": \"10g-4x\", \"module_index\": -1}}",
                        "speed": {
                            "unit": "G",
                            "value": 10
                        },
                        "state": "active"
                    },
                    {
                        "interface_id": 2,
                        "name": "Ethernet{{slot_id}}/%s/2"%i,
                        "setting": "{\"interface\": {\"speed\": \"10000\"}, \"global\": {\"port_index\": -1, \"speed\": \"\", \"module_index\": -1}}",
                        "speed": {
                            "unit": "G",
                            "value": 10
                        },
                        "state": "active"
                    },
                    {
                        "interface_id": 3,
                        "name": "Ethernet{{slot_id}}/%s/3"%i,
                        "setting": "{\"interface\": {\"speed\": \"10000\"}, \"global\": {\"port_index\": -1, \"speed\": \"\", \"module_index\": -1}}",
                        "speed": {
                            "unit": "G",
                            "value": 10
                        },
                        "state": "active"
                    },
                    {
                        "interface_id": 4,
                        "name": "Ethernet{{slot_id}}/%s/4"%i,
                        "setting": "{\"interface\": {\"speed\": \"10000\"}, \"global\": {\"port_index\": -1, \"speed\": \"\", \"module_index\": -1}}",
                        "speed": {
                            "unit": "G",
                            "value": 10
                        },
                        "state": "active"
                    }
                ],
                "is_default": False,
                "transformation_id": 2
            }
        ]
    }
    for i in range(1, 13)
]

@unique
class DeviceProfileType(Enum):
    MONOLITHIC = 1
    MODULAR = 2

def gen_port(port_id=1, display_id=None, row_id=1, column_id=1, panel_id=1,
             connector='qsfp',
             transformations=None, slot_id=0, failure_domain_id=1,
             templatize=False):
    if not transformations:
        transformations = [
            dp.gen_transform([
                dp.gen_interface(
                    'test', 'active', intf_id=1, to_speed={
                        'value': 10,
                        'unit': 'G',
                    }
                )
            ], transformation_id=1, is_default=True),
        ]
    return dp.gen_port(
        port_id, row_id, column_id, panel_id,
        connector, transformations,
        slot_id, failure_domain_id,
        templatize=templatize,
        display_id=display_id,
    )


def gen_device_profile_for_arista_7050qx32():
    device_profile = g.gen_device_profile_for_arista_7050qx32()
    device_profile['id'] = 'TEST_Arista_DCS-7050QX-32_EOS'
    return device_profile

def gen_device_profile_for_cisco_9332pq():
    device_profile = g.gen_device_profile_for_cisco_9332pq()
    device_profile['id'] = 'TEST_Cisco_9332PQ_NXOS'
    return device_profile

def gen_device_profile_for_juniper_QFX5210_64C():
    device_profile = g.gen_device_profile_for_juniper_QFX5210_64C()
    device_profile['id'] = 'TEST_Juniper_QFX5210-64C'
    return device_profile

def gen_sonic_profile_for_sonic_dell_s6000():
    device_profile = g.gen_device_profile_for_dell_s6000_on_sonic_brcm_buzznik_plus()
    device_profile['id'] = 'TEST_DELL_S6000_ON_SONiC_BRCM_BUZZNIK_PLUS'
    return device_profile

def gen_device_profile_for_juniper_QFX5220_32CD():
    device_profile = g.gen_device_profile_for_juniper_QFX5220_32CD()
    device_profile['id'] = 'TEST_Juniper_QFX5220-32CD'
    return device_profile

def gen_test_device_profile_payload(vendor=None):
    vendor = (vendor or '').lower()
    if not vendor or vendor == "arista":
        device_profile = gen_device_profile_for_arista_7050qx32()
    elif vendor == "cisco":
        device_profile = gen_device_profile_for_cisco_9332pq()
    elif vendor == 'juniper':
        device_profile = gen_device_profile_for_juniper_QFX5210_64C()
    elif vendor == 'juniper_evo':
        device_profile = gen_device_profile_for_juniper_QFX5220_32CD()
    elif vendor == 'sonic':
        device_profile = gen_sonic_profile_for_sonic_dell_s6000()
    else:
        raise ValueError("Generators not supported for vendor %s" % vendor)
    device_profile['predefined'] = False
    device_profile['physical_device'] = True
    device_profile['dual_routing_engine'] = False
    return device_profile

def gen_test_device_profile_dict(vendor=None, pop_id=True):
    device_profile = gen_test_device_profile_payload(vendor)
    if pop_id:
        del device_profile['id']
    return device_profile

def gen_test_chassis_profile_dict(vendor=None):
    vendor = (vendor or '').lower()
    if not vendor or vendor == "juniper":
        chassis_profile_dict = {
            'hardware_capabilities': {'userland': 64, 'ram': 16, 'asic': 'T2',
                                      'form_factor': '1RU', 'ecmp_limit': 64,
                                      'cpu': 'x86'},
            'selector': {'os_version': 'abc', 'model': '712-54X-O.*', 'os': 'Junos',
                         'manufacturer': 'Edgecore|Accton'},
            'software_capabilities': {'onie': True,
                                      'config_apply_support': 'complete_only',
                                      'lxc_support': False},
            'reference_design_capabilities': {'freeform': 'full_support',
                                              'datacenter': 'full_support'},
            'linecard_slot_ids': [0, 1, 2, 3, 4, 5, 6, 7],
            'label': 'Juniper_QFX10008_BLAH',
            'id': 'Juniper_QFX10008_BLAH'}
    elif vendor == "arista":
        chassis_profile_dict = {
            'hardware_capabilities': {'userland': 32, 'ram': 32, 'asic': 'Jericho',
                                      'form_factor': '7RU', 'ecmp_limit': 128,
                                      'cpu': 'x86'},
            'selector': {'os_version': "4\\.(18|20|21|22|23|24|25)\\..*",
                         'model': "DCS-7504N", 'os': 'EOS',
                         'manufacturer': 'Arista'},
            'software_capabilities': {'onie': False,
                                      'config_apply_support': 'incremental',
                                      'lxc_support': False},
            'reference_design_capabilities': {'freeform': 'disabled',
                                              'datacenter': 'full_support'},
            'linecard_slot_ids': [0, 1, 2, 3, 4, 5, 6, 7],
            'label': 'Arista DCS-7504N 4x7500R',
            'id': 'Arista_DCS-7504N_4x7500R'}
    elif vendor == "cisco":
        chassis_profile_dict = {
            'hardware_capabilities': dp.gen_device_profile_hw_caps(),
            'selector': {'os_version': "9\\.[23]\\(\\w+\\)",
                         'model': "NXOS_CHASSIS", 'os': 'NXOS',
                         'manufacturer': 'Cisco'},
            'software_capabilities': {'onie': False,
                                      'config_apply_support': 'incremental',
                                      'lxc_support': False},
            'reference_design_capabilities': {'freeform': 'disabled',
                                              'datacenter': 'full_support'},
            'linecard_slot_ids': [1, 2, 3, 4, 5, 6, 7, 8],
            'label': 'Cisco NXOS Chassis',
            'id': 'NXOS_CHASSIS'}
    else:
        raise ValueError("Generators not supported for vendor %s" % vendor)
    chassis_profile_dict['predefined'] = False
    chassis_profile_dict['dual_routing_engine'] = True
    chassis_profile_dict['physical_device'] = True
    return chassis_profile_dict

EXAMPLE_COMPATIBLE_CHASSIS = {
    'chassis_model_1': [0, 1, 2, 3],
    'chassis_model_2': [],
    'chassis_model_3': None,  # In json, this will be translated as null.
    'chassis_model_4': [2, 3, 5, 6],
    'Juniper_QFX10008': [0, 1, 2, 3, 4, 5, 6, 7],
    'Arista_DCS-7504N_4x7500R': [0, 1, 2, 3, 4, 5, 6, 7],
}


# pylint: disable=dangerous-default-value
def gen_linecard_profile_payload(id_in_payload=True,
                                 selector_os='EOS',
                                 selector_model='DCS-7050QX-32',
                                 selector_version=None,
                                 compatible_chassis=EXAMPLE_COMPATIBLE_CHASSIS):
    # generate the linecard profile payload, modify from the payload of
    # device profile
    payload = gen_test_device_profile_payload()
    # no slot_count in linecard profile, delete it
    del payload['slot_count']

    # setup variable in ports
    for port in payload['ports']:
        port['slot_id'] = '{{slot_id}}'

        for trans in port['transformations']:
            for intf in trans['interfaces']:
                intf['name'] = 'name-{{slot_id}}'

    if not id_in_payload:
        del payload['id']

    payload['selector'] = {
        'os': selector_os,
        'model': selector_model,
    }
    if selector_version is not None:
        payload['selector']['version'] = selector_version

    payload['compatible_chassis'] = compatible_chassis

    return payload


def gen_test_linecard_profile_payload(id_in_payload=True, vendor=None):
    vendor = (vendor or '').lower()
    if not vendor or vendor == "juniper":
        payload = g.gen_linecard_profile_for_juniper_qfx10000_36q()
        payload['id'] = 'TEST_Junos_LC_10000_31q'
        payload['compatible_chassis']['Juniper_QFX10008_BLAH'] = \
            EXAMPLE_COMPATIBLE_CHASSIS['Juniper_QFX10008']
    elif vendor == "arista":
        payload = g.gen_linecard_profile_for_arista_dcs_7500r_36q_lc()
        payload['id'] = 'TEST_Arista_LC_7504N_x36q'
        payload['compatible_chassis'].update(EXAMPLE_COMPATIBLE_CHASSIS)
    elif vendor == "cisco":
        payload = g.gen_linecard_profile_for_arista_dcs_7500r_36q_lc()
        payload['id'] = 'NXOS_LINECARD'
        payload['ports'] = CISCO_LINECARD_PORTS
        payload['compatible_chassis'] = {'NXOS_CHASSIS': [1, 2, 3, 4, 5, 6, 7, 8]}
        payload['selector'] = {
            "manufacturer": "Cisco",
            "model": "NXOS_LINECARD",
            "os": "NXOS",
            "os_version": "9\\.[23]\\(\\w+\\)",
        }
        payload['hardware_capabilities']['breakout_capable'] = [
            {
                'module': -1,
                'value': True,
                'version': '.*',
            }
        ]
    else:
        raise ValueError("Generator not supported for vendor %s" % vendor)

    if not id_in_payload:
        del payload['id']
    payload['predefined'] = False
    return payload


def gen_test_modular_device_profile_payload(
        chassis_profile_id, linecard_profile_id, slots=None):
    if not slots:
        slots = [0, 1, 2, 3, 4, 5, 6, 7]
    return {
        'id': 'test-modular-dp',
        'label': 'test-modular-dp',
        'predefined': False,
        'device_profile_type': 'modular',
        'chassis_profile_id': chassis_profile_id,
        'slot_configuration': [
            {
                'linecard_profile_id': linecard_profile_id,
                'slot_id': slot_id
            }
            for slot_id in slots
        ]
    }


def gen_test_chassis_info(vendor=None):
    chassis_profile = gen_test_chassis_profile_dict(vendor)
    return {
        'chassis_profile_id': chassis_profile['id'],
        'selector': chassis_profile['selector'],
        'hardware_capabilities': chassis_profile['hardware_capabilities'],
        'software_capabilities': chassis_profile['software_capabilities'],
        'reference_design_capabilities':
            chassis_profile['reference_design_capabilities'],
        'linecard_slot_ids': chassis_profile['linecard_slot_ids'],
        'dual_routing_engine': chassis_profile['dual_routing_engine'],
        'physical_device': chassis_profile['physical_device'],
    }


def gen_test_linecards_info(vendor=None):
    linecard_profile = gen_test_linecard_profile_payload(vendor=vendor)
    return [{
        'linecard_profile_id': linecard_profile['id'],
        'selector': linecard_profile['selector'],
        'hardware_capabilities': linecard_profile['hardware_capabilities'],
    }]


def gen_test_modular_device_profile_dict():
    payload = gen_test_modular_device_profile_payload(
        'test_chassis_profile_id', 'test_linecard_profile_id')
    del payload['id']
    return payload


def write_to_file(file_name, data):
    dir_path = os.path.dirname(file_name)
    if not os.path.isdir(dir_path):
        os.makedirs(dir_path, 0o777)
    with open(file_name, "w") as write_file:
        json.dump(data, write_file, sort_keys=True, indent=2,
                  ensure_ascii=False, separators=(', ', ': '))
    write_file.close()


def read_from_file(file_name):
    with open(file_name) as json_data:
        read_file = json_load_str(json_data)
    return read_file
