# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from aos.sdk.device_profile.generator_helpers import port_speed
import aos.sdk.device_profile.device_profile as d

# pylint: disable=invalid-name
# pylint: disable=redefined-builtin

class ServerDeviceProfileGenerator(object):

    def gen_server_device_profile(self, model, ports, label,
                                  os, os_version, manufacturer,
                                  userland=64, form_factor='1RU',
                                  ecmp_limit=64, asic="", cpu='x86',
                                  ram=16, onie=False, lxc=False,
                                  config_apply_support='complete_only',
                                  slot_count=0,
                                  id=None):

        selector = d.gen_device_profile_selector(model, os_version,
                                                 manufacturer, os)
        hw_caps = d.gen_device_profile_hw_caps(
            userland, form_factor,
            ecmp_limit, asic, cpu, ram)
        sw_caps = d.gen_device_profile_sw_caps(onie, lxc, config_apply_support)
        ref_design_caps = d.gen_device_profile_ref_design_caps()

        return d.gen_device_profile(hw_caps, sw_caps, label, ports, selector,
                                    ref_design_caps,
                                    slot_count, id)


class ServerDeviceProfilePortGenerator(object):
    def __init__(self):
        self.xenial_interfaces = ['eno1', 'eno2', 'ens3f0', 'ens3f1']

    def make_linuxserver_setting_param(self, intf_speed):
        """
        The param is always empty for Generic servers
        """
        return ""

    def make_intf_name(self, port_id, slot_id=0, if_name_transform=False):
        return 'eth%s' % (port_id) if not if_name_transform\
            else self.xenial_interfaces[port_id]

    def make_command(self, name, speed):
        """Arg1:        interface name
           Arg2:        speed , assumes speed is in Gigabits/s
           Return:      the command string
        """
        return "ethtool -s %s speed %s" % (name, speed*1000)

    def gen_40G_no_breakout(self, port_id, slot_id, if_name_transform=False):
        return [d.gen_interface(
            self.make_intf_name(port_id-1, slot_id, if_name_transform),
            "active",
            port_speed(40),
            self.make_linuxserver_setting_param(40), intf_id=1)]

    def gen_25G_no_breakout(self, port_id, slot_id, if_name_transform=False):
        return [d.gen_interface(
            self.make_intf_name(port_id-1, slot_id, if_name_transform),
            "active",
            port_speed(25),
            self.make_linuxserver_setting_param(25), intf_id=1)]

    def gen_10G_no_breakout(self, port_id, slot_id, if_name_transform=False):
        return [d.gen_interface(
            self.make_intf_name(port_id-1, slot_id, if_name_transform),
            "active",
            port_speed(10),
            self.make_linuxserver_setting_param(10), intf_id=1)]

    def gen_1G_no_breakout(self, port_id, slot_id, if_name_transform=False):
        return [d.gen_interface(
            self.make_intf_name(port_id-1, slot_id, if_name_transform),
            "active",
            port_speed(1),
            self.make_linuxserver_setting_param(1), intf_id=1)]

    def gen_100G_no_breakout(self, port_id, slot_id, if_name_transform=False):
        return [d.gen_interface(
            self.make_intf_name(port_id-1, slot_id, if_name_transform),
            "active",
            port_speed(100),
            self.make_linuxserver_setting_param(100), intf_id=1)]

    def gen_200G_no_breakout(self, port_id, slot_id):
        dgxa100_intf_name = {
            1: "ibp75s0", 2: "ibp84s0", 3: "ibp186s0", 4: "ibp204s0a",
            5: "ibp12s0", 6: "ibp18s0", 7: "ibp141s0", 8: "ibp148s0"}
        return [d.gen_interface(
            dgxa100_intf_name[port_id],
            "active",
            port_speed(200),
            "", intf_id=1)]

    def gen_400G_no_breakout(self, port_id, slot_id):
        dgxh100_intf_name = {
            1: "ibp220s0", 2: "ibp154s0", 3: "ibp206s0", 4: "ibp192s0",
            5: "ibp79s0", 6: "ibp64s0", 7: "ibp94s0", 8: "ibp24s0"}
        return [d.gen_interface(
            dgxh100_intf_name[port_id],
            "active",
            port_speed(400),
            "", intf_id=1)]

    def gen_40G_non_breakout_capable_port(self, port_id, row_id, col_id,
                                          panel_id, slot_id, failure_domain_id,
                                          if_name_transform=False):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp",
                          [d.gen_transform(self.gen_40G_no_breakout(
                              port_id, slot_id, if_name_transform),
                                           transformation_id=1, is_default=True)],
                          slot_id, failure_domain_id)

    def gen_25G_non_breakout_capable_port(self, port_id, row_id, col_id,
                                          panel_id, slot_id, failure_domain_id,
                                          if_name_transform=False):
        return d.gen_port(port_id, row_id, col_id, panel_id, "sfp",
                          [d.gen_transform(self.gen_25G_no_breakout(
                              port_id, slot_id, if_name_transform),
                                           transformation_id=1, is_default=True)],
                          slot_id, failure_domain_id)

    def gen_10G_non_breakout_capable_port(self, port_id, row_id, col_id,
                                          panel_id, slot_id, failure_domain_id,
                                          if_name_transform=False):
        return d.gen_port(port_id, row_id, col_id, panel_id, "sfp",
                          [d.gen_transform(self.gen_10G_no_breakout(
                              port_id, slot_id, if_name_transform),
                                           transformation_id=1, is_default=True)],
                          slot_id, failure_domain_id)

    def gen_1G_non_breakout_capable_port(self, port_id, row_id, col_id,
                                         panel_id, slot_id, failure_domain_id,
                                         if_name_transform=False):
        return d.gen_port(port_id, row_id, col_id, panel_id, "sfp",
                          [d.gen_transform(self.gen_1G_no_breakout(
                              port_id, slot_id, if_name_transform),
                                           transformation_id=1, is_default=True)],
                          slot_id, failure_domain_id)

    def gen_100G_non_breakout_capable_port(self, port_id, row_id, col_id,
                                           panel_id, slot_id, failure_domain_id,
                                           if_name_transform=False):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp",
                          [d.gen_transform(self.gen_100G_no_breakout(
                              port_id, slot_id, if_name_transform),
                                           transformation_id=1, is_default=True)],
                          slot_id, failure_domain_id)

    def gen_200G_non_breakout_capable_port(self, port_id, row_id, col_id,
                                           panel_id, slot_id, failure_domain_id,
                                           if_name_transform=False):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp",
                          [d.gen_transform(self.gen_200G_no_breakout(
                              port_id, slot_id),
                                           transformation_id=1, is_default=True)],
                          slot_id, failure_domain_id)

    def gen_400G_non_breakout_capable_port(self, port_id, row_id, col_id,
                                           panel_id, slot_id, failure_domain_id,
                                           if_name_transform=False):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp",
                          [d.gen_transform(self.gen_400G_no_breakout(
                              port_id, slot_id),
                                           transformation_id=1, is_default=True)],
                          slot_id, failure_domain_id)

    def gen_1G_non_breakout_capable_ports(self, row_count, column_count,
                                          start_index, panel_id, slot_id=0,
                                          failure_domain_id=1,
                                          if_name_transform=False):
        return [self.gen_1G_non_breakout_capable_port(
            port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
            if_name_transform)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index)]

    def gen_10G_non_breakout_capable_ports(self, row_count, column_count,
                                           start_index, panel_id, slot_id=0,
                                           failure_domain_id=1,
                                           if_name_transform=False):
        return [self.gen_10G_non_breakout_capable_port(
            port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
            if_name_transform)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index)]

    def gen_25G_non_breakout_capable_ports(self, row_count, column_count,
                                           start_index, panel_id, slot_id=0,
                                           failure_domain_id=1,
                                           if_name_transform=False):
        return [self.gen_25G_non_breakout_capable_port(
            port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
            if_name_transform)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index)]

    def gen_40G_non_breakout_capable_ports(self, row_count, column_count,
                                           start_index, panel_id, slot_id=0,
                                           failure_domain_id=1,
                                           if_name_transform=False):
        return [self.gen_40G_non_breakout_capable_port(
            port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
            if_name_transform)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index)]

    def gen_100G_non_breakout_capable_ports(self, row_count, column_count,
                                            start_index, panel_id, slot_id=0,
                                            failure_domain_id=1,
                                            if_name_transform=False):
        return [self.gen_100G_non_breakout_capable_port(
            port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
            if_name_transform)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index)]

    def gen_200G_non_breakout_capable_ports(self, row_count, column_count,
                                           start_index, panel_id, slot_id=0,
                                           failure_domain_id=1,
                                           if_name_transform=False):
        return [self.gen_200G_non_breakout_capable_port(
            port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
            if_name_transform)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index)]

    def gen_400G_non_breakout_capable_ports(self, row_count, column_count,
                                           start_index, panel_id, slot_id=0,
                                           failure_domain_id=1,
                                           if_name_transform=False):
        return [self.gen_400G_non_breakout_capable_port(
            port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
            if_name_transform)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index)]



