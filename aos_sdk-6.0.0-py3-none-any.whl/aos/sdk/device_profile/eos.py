# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import json
from aos.sdk.device_profile.generator_helpers import port_speed, \
    gen_pg_speed_validations
import aos.sdk.device_profile.device_profile as d
from six.moves import range

# pylint: disable=invalid-name,line-too-long
# pylint: disable=redefined-builtin
# pylint: disable=pointless-string-statement
# pylint: disable=bad-continuation

"""
    Arista speed commands as per:
    https://www.arista.com/assets/data/pdf/user-manual/um-eos/Chapters/Ethernet%20Ports.pdf
    page 544

    - forced 10000full 10G full duplex.
    - forced 1000full 1G full duplex.
    - forced 1000half 1G half duplex.
    - forced 100gfull 100G full duplex.
    - forced 40gfull 40G full duplex.
"""
variable_slot = '{{slot_id}}'


def gen_port_group_name(port_num, num_of_ports_per_group):
    assert port_num > 0, "port_num value {} should be a positive integer".format(
        port_num)
    pg_first_index = num_of_ports_per_group * (
        (port_num - 1) // num_of_ports_per_group) + 1
    port_range = range(pg_first_index, pg_first_index + num_of_ports_per_group)
    return '_'.join('P'+ str(i) for i in port_range)


class EosDeviceProfileGenerator(object):

    WILDCARD_OS_VERSION = ".*"

    def gen_eos_selector(self, model, os_version, os="EOS",
                         manufacturer="Arista"):
        return {'os': os,
                'os_version': os_version,
                'manufacturer': manufacturer,
                'model': model}

    def gen_eos_linecard_selector(self, model, version='', os="EOS"):
        return {'os': os,
                'version': version,
                'model': model}

    def gen_arista_chassis_profile(self, model, label,
                                   userland=32, form_factor='1RU',
                                   ecmp_limit=64, asic="T2", cpu='x86',
                                   ram=16, onie=False, lxc=False,
                                   config_apply_support='incremental',
                                   linecard_slot_ids=None,
                                   id=None,
                                   os_version=WILDCARD_OS_VERSION,
                                   dual_re=True, physical_device=True):
        selector = self.gen_eos_selector(model, os_version)
        hw_caps = d.gen_device_profile_hw_caps(
            userland, form_factor, ecmp_limit, asic, cpu, ram)
        sw_caps = d.gen_device_profile_sw_caps(onie, lxc, config_apply_support)
        ref_design_caps = d.gen_device_profile_ref_design_caps(freeform='disabled')

        return d.gen_chassis_profile(
            hw_caps=hw_caps,
            sw_caps=sw_caps,
            label=label,
            selector=selector,
            linecard_slot_ids=linecard_slot_ids,
            ref_design_caps=ref_design_caps,
            id=id,
            dual_re=dual_re,
            physical_device=physical_device
        )

    def gen_arista_device_profile(self, model, ports, label,
                                  userland=32, form_factor='1RU',
                                  ecmp_limit=64, asic="T2", cpu='x86',
                                  ram=16, onie=False, lxc=False,
                                  config_apply_support='incremental',
                                  slot_count=0,
                                  id=None, os_version=WILDCARD_OS_VERSION,
                                  physical_device=True, dual_re=False):

        selector = self.gen_eos_selector(model, os_version)
        hw_caps = d.gen_device_profile_hw_caps(
            userland, form_factor, ecmp_limit, asic, cpu, ram)
        sw_caps = d.gen_device_profile_sw_caps(onie, lxc, config_apply_support)
        ref_design_caps = d.gen_device_profile_ref_design_caps(freeform='disabled')

        return d.gen_device_profile(hw_caps, sw_caps, label, ports, selector,
                                    ref_design_caps,
                                    slot_count, id,
                                    physical_device=physical_device,
                                    dual_re=dual_re)

    def gen_arista_linecard_profile(self, model, ports, label,
                                    compatible_chassis, userland=32,
                                    ecmp_limit=64, asic="T2", cpu='x86',
                                    ram=16, id=None, version='',
                                    os_version=WILDCARD_OS_VERSION):
        selector = self.gen_eos_linecard_selector(model=model, version=version)
        hw_caps = d.gen_device_profile_hw_caps(
            userland, '1RU', ecmp_limit, asic, cpu, ram)

        return d.gen_linecard_profile(hw_caps, label, ports, selector,
                                      compatible_chassis, id)


class EosDeviceProfilePortGenerator(object):

    def __init__(self, templatize=False):
        super(EosDeviceProfilePortGenerator, self).__init__()
        self.templatize = templatize

    def make_eos_global_param(self, port_group, select):
        return {
            "port_group": port_group,
            "select": select,
        }

    def make_eos_setting_param(
        self, intf_speed=None, select="", port_group=-1, validations=None):
        """Creates and returns EOS-specific dictionary represented as a string
           to be used as the value for Interface::setting.

           Args:
            intf_speed   Speed for interface (Aos::Resource::PortSpeed)

            For inactive interfaces we pass no speed, so the setting will still
            be generated but the interface->speed will be ""
        """
        if not intf_speed:
            speed = ""
        else:
            speed = {
                0: '',
                1: '1000full',
                10: '10000full',
                25: '25gfull',
                40: '40gfull',
                50: '50gfull',
                100: '100gfull',
                150: '150gfull',
                200: '200g-4',
                400: '400g-8',
            }[intf_speed]

        setting_dict = {
            "interface":  {"speed": speed},
            "global": self.make_eos_global_param(port_group, select),
        }
        if validations:
            setting_dict['validations'] = validations
        return json.dumps(setting_dict, sort_keys=True)

    def make_intf_name(self, port_id, lane_id=None, slot_id=0):
        if self.templatize:
            slot_prefix = variable_slot + '/'
        else:
            slot_prefix = '%d/' % slot_id if slot_id != 0 else ''
        lane_suffix = '/%d' % lane_id if lane_id is not None else ''
        return 'Ethernet%s%d%s' % (slot_prefix, port_id, lane_suffix)

    # Generators for interface collections. Each collection is for a particular
    # port transformation.

    def _gen_intfs_40G_no_breakout(self, port_id, slot_id):
        return [d.gen_interface(
            self.make_intf_name(port_id, slot_id=slot_id),
            "active",
            port_speed(40), '',
            intf_id=1)]

    def _gen_intfs_100G_no_breakout(self, port_id, slot_id):
        return [d.gen_interface(
            self.make_intf_name(port_id, lane_id=1, slot_id=slot_id),
            "active",
            port_speed(100),
            self.make_eos_setting_param(port_group=0),
            intf_id=1)]

    def _gen_intfs_25G_no_breakout(self, port_id, slot_id):
        return [d.gen_interface(
            self.make_intf_name(port_id, lane_id=1, slot_id=slot_id),
            "active",
            port_speed(25),
            self.make_eos_setting_param(port_group=0),
            intf_id=1)]

    def _gen_intfs_1G_no_breakout(self, port_id, slot_id):
        return [d.gen_interface(
            self.make_intf_name(port_id, lane_id=1, slot_id=slot_id),
            "active",
            port_speed(1),
            self.make_eos_setting_param(port_group=0),
            intf_id=1)]

    def _get_setting_params(self, port_id, model):
        select = ""
        port_group = -1
        if model == "DCS-7050QX-32S":
            if port_id == 5:
                select = "Et5/1-4"
                port_group = 1
            elif port_id == 1:
                select = "Et1-4"
                port_group = 1
        return select, port_group

    def _gen_intfs_1x40G_to_4x10G_breakout(self, port_id, slot_id, model, validations=None):
        select, port_group = self._get_setting_params(port_id, model)
        return [d.gen_interface(self.make_intf_name(port_id, 1, slot_id),
                                "active",
                                port_speed(10),
                                self.make_eos_setting_param(
                                    10, select, port_group, validations=validations),
                                intf_id=1)] +\
               [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "active",
                                port_speed(10),
                                self.make_eos_setting_param(10, validations=validations),
                                intf_id=lane_id) for lane_id in range(2, 4+1)]

    def _gen_intfs_1x40G_to_1_40G(self, port_id, slot_id, model, validations=None):
        select, port_group = self._get_setting_params(port_id, model)
        return [d.gen_interface(self.make_intf_name(port_id, 1, slot_id),
                                "active",
                                port_speed(40),
                                self.make_eos_setting_param(
                                    40, select, port_group, validations=validations),
                                intf_id=1)] +\
               [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "inactive",
                                setting='',
                                intf_id=lane_id)
                for lane_id in range(2, 4+1)]

    def _gen_intfs_all_four_inactive(self, port_id, slot_id, speed=40):
        return [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "inactive",
                                port_speed(speed),
                                setting='',
                                intf_id=lane_id)
                for lane_id in range(1, 4+1)]

    def _gen_intfs_inactive_odd_only(self, port_id, slot_id, speed=40):
        return [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "inactive",
                                port_speed(speed),
                                setting='',
                                intf_id=intf_id)
                for lane_id, intf_id in [(1, 1), (3, 2)]]

    def _gen_intfs_10G_to_1_10G(
        self, port_id, slot_id, model=None, validations=None):
        select, port_group = self._get_setting_params(port_id, model)
        return [d.gen_interface(self.make_intf_name(port_id, slot_id=slot_id),
                                "active",
                                port_speed(10),
                                self.make_eos_setting_param(
                                    10, select ,port_group, validations=validations),
                                intf_id=1)]

    def _gen_intfs_10G_to_1_10G_auto_neg(self, port_id, slot_id):
        """
            This builds a transformation with following:
                speed:      speed of the interface in the transformation which has
                            the single interface, hence interface with maximum speed
                state:      active
                setting:    where interface->speed=""
                name:       as per the naming conventions applicable to interface
                            with this speed
        """
        return [d.gen_interface(self.make_intf_name(port_id, slot_id=slot_id),
                                "active",
                                port_speed(10),
                                self.make_eos_setting_param(), intf_id=1)]

    def _gen_intfs_10G_to_1x1G_breakout(self, port_id, slot_id, model=None,
                                        validations=None):
        select, port_group = self._get_setting_params(port_id, model)
        return [d.gen_interface(self.make_intf_name(port_id, slot_id=slot_id),
                                "active", port_speed(1),
                                self.make_eos_setting_param(
                                    1, select, port_group, validations=validations),
                                intf_id=1)]

    def _gen_intfs_sfp_non_breakout_capable(self, port_id, slot_id):
        return [d.gen_interface(self.make_intf_name(port_id, slot_id=slot_id),
                                "active",
                                port_speed(10),
                                setting='',
                                intf_id=1)]

    def _gen_intfs_1x200G_to_2_200G_autoneg(self, port_id, slot_id):
        return [d.gen_interface(self.make_intf_name(port_id, 1, slot_id),
                                "active",
                                port_speed(200),
                                setting=self.make_eos_setting_param(),
                                intf_id=1)] +\
               [d.gen_interface(self.make_intf_name(port_id, 2, slot_id),
                                "inactive",
                                setting='',
                                intf_id=2)]

    def _gen_intfs_1x200G_to_2x100G_breakout_autoneg(self, port_id, slot_id):
        return [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "active",
                                port_speed(100),
                                setting=self.make_eos_setting_param(),
                                intf_id=lane_id) for lane_id in range(1, 2+1)]

    def _gen_intfs_qsfpdd_1x400G(self, port_id, slot_id):
        return [d.gen_interface(self.make_intf_name(port_id, 1, slot_id),
                                "active",
                                port_speed(400),
                                setting=self.make_eos_setting_param(400),
                                intf_id=1)]

    def _gen_intfs_1x400G_to_2x200G(self, port_id, slot_id):
        return [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "active",
                                port_speed(200),
                                self.make_eos_setting_param(200),
                                intf_id=lane_id)
                for lane_id in range(1, 2+1)]

    def _gen_intfs_qsfpdd_4x100G(self, port_id, slot_id):
        return [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "active",
                                port_speed(100),
                                self.make_eos_setting_param(100),
                                intf_id=lane_id)
                for lane_id in range(1, 4+1)]

    def _gen_intfs_qsfpdd_8x50G(self, port_id, slot_id):
        return [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "active",
                                port_speed(50),
                                self.make_eos_setting_param(50),
                                intf_id=lane_id)
                for lane_id in range(1, 8+1)]

    def _gen_intfs_qsfpdd_1x40G(self, port_id, slot_id):
        return [d.gen_interface(self.make_intf_name(port_id, 1, slot_id),
                                "active",
                                port_speed(40),
                                self.make_eos_setting_param(40),
                                intf_id=1)]

    def _gen_intfs_qsfpdd_8x25G(self, port_id, slot_id):
        return [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "active",
                                port_speed(25),
                                self.make_eos_setting_param(25),
                                intf_id=lane_id)
                for lane_id in range(1, 8+1)]

    def _gen_intfs_qsfpdd_8x10G(self, port_id, slot_id):
        return [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "active",
                                port_speed(10),
                                self.make_eos_setting_param(10),
                                intf_id=lane_id)
                for lane_id in range(1, 8+1)]

    # 100G interface generators

    # Interface generators for QSFP28 ports, 4x25G lanes per port
    def _gen_intfs_qsfp28_1x100G(self, port_id, slot_id, validations=None):
        return [d.gen_interface(self.make_intf_name(port_id, 1, slot_id),
                                "active",
                                port_speed(100),
                                setting=self.make_eos_setting_param(
                                    100, validations=validations),
                                intf_id=1)] +\
               [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "inactive",
                                setting='',
                                intf_id=lane_id)
                for lane_id in range(2, 4+1)]

    def _gen_intfs_qsfp28_1x100G_odd_only(self, port_id, slot_id, validations=None):
        return [d.gen_interface(self.make_intf_name(port_id, 1, slot_id),
                                "active",
                                port_speed(100),
                                setting=self.make_eos_setting_param(
                                    100, validations=validations),
                                intf_id=1)] +\
               [d.gen_interface(self.make_intf_name(port_id, 3, slot_id),
                                "inactive",
                                setting='',
                                intf_id=2)]

    def _gen_intfs_qsfp28_2x50G(self, port_id, slot_id, validations=None):
        return [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "active",
                                port_speed(50),
                                setting=self.make_eos_setting_param(
                                    50, validations=validations),
                                intf_id=lane_id)
                for lane_id in [1, 3]] +\
               [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "inactive",
                                setting='',
                                intf_id=lane_id)
                for lane_id in [2, 4]]

    def _gen_intfs_qsfp28_2x50G_odd_only(self, port_id, slot_id, validations=None):
        return [d.gen_interface(self.make_intf_name(port_id, 1, slot_id),
                                "active",
                                port_speed(50),
                                setting=self.make_eos_setting_param(
                                    50, validations=validations),
                                intf_id=1)] +\
               [d.gen_interface(self.make_intf_name(port_id, 3, slot_id),
                                "active",
                                port_speed(50),
                                setting=self.make_eos_setting_param(
                                    50, validations=validations),
                                intf_id=2)]

    def _gen_intfs_qsfp28_odd_2x50G_of_4(self, port_id, slot_id):
        ret = []
        for lane_id in range(1, 4+1):
            if lane_id % 2:
                ret.append(d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                           "active",
                                           port_speed(50),
                                           self.make_eos_setting_param(50),
                                           intf_id=lane_id))
            else:
                ret.append(d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                           "inactive",
                                           setting='',
                                           intf_id=lane_id))
        return ret

    def _gen_intfs_qsfp28_1x40G(self, port_id, slot_id, validations=None):
        return [d.gen_interface(self.make_intf_name(port_id, 1, slot_id),
                                "active", port_speed(40),
                                self.make_eos_setting_param(
                                    40, validations=validations),
                                intf_id=1)] +\
               [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "inactive",
                                setting='',
                                intf_id=lane_id)
                for lane_id in range(2, 4+1)]

    def _gen_intfs_qsfp28_1x40G_odd_only(self, port_id, slot_id, validations=None):
        return [d.gen_interface(self.make_intf_name(port_id, 1, slot_id),
                                "active", port_speed(40),
                                self.make_eos_setting_param(
                                    40, validations=validations),
                                intf_id=1)] +\
               [d.gen_interface(self.make_intf_name(port_id, 3, slot_id),
                                "inactive",
                                setting='',
                                intf_id=2)]

    def _gen_intfs_qsfp28_4x25G(self, port_id, slot_id, validations=None):
        return [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "active",
                                port_speed(25),
                                self.make_eos_setting_param(
                                    25, validations=validations),
                                intf_id=lane_id)
                for lane_id in range(1, 4+1)]

    def _gen_intfs_qsfp28_1x25G(self, port_id, slot_id):
        return [d.gen_interface(self.make_intf_name(port_id, 1, slot_id),
                                "active",
                                port_speed(25),
                                self.make_eos_setting_param(25),
                                intf_id=1)] +\
                [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                 "inactive",
                                 setting='',
                                 intf_id=lane_id)
                 for lane_id in range(2, 4+1)]

    def _gen_intfs_qsfp28_2x25G(self, port_id, slot_id):
        return [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "active",
                                port_speed(25),
                                self.make_eos_setting_param(25),
                                intf_id=lane_id)
                for lane_id in range(1, 3)] +\
               [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "inactive",
                                setting='',
                                intf_id=lane_id)
                for lane_id in range(3, 4+1)]

    def _gen_intfs_qsfp28_odd_2x25G_of_4(self, port_id, slot_id):
        ret = []
        for lane_id in range(1, 4+1):
            if lane_id % 2:
                ret.append(d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                           "active",
                                           port_speed(25),
                                           self.make_eos_setting_param(25),
                                           intf_id=lane_id))
            else:
                ret.append(d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                           "inactive",
                                           setting='',
                                           intf_id=lane_id))
        return ret

    def _gen_intfs_qsfp28_2x25G_odd_only(self, port_id, slot_id, validations=None):
        return [d.gen_interface(self.make_intf_name(port_id, 1, slot_id),
                                "active",
                                port_speed(25),
                                self.make_eos_setting_param(
                                    25, validations=validations),
                                intf_id=1)] +\
               [d.gen_interface(self.make_intf_name(port_id, 3, slot_id),
                                "active",
                                port_speed(25),
                                setting=self.make_eos_setting_param(
                                    25, validations=validations),
                                intf_id=2)]

    def _gen_intfs_qsfp28_4x10G(self, port_id, slot_id, validations=None):
        return [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "active",
                                port_speed(10),
                                setting=self.make_eos_setting_param(
                                    10, validations=validations),
                                intf_id=lane_id)
                for lane_id in range(1, 4+1)]

    def _gen_intfs_qsfp28_1x10G(self, port_id, slot_id):
        return [d.gen_interface(self.make_intf_name(port_id, 1, slot_id),
                                "active",
                                port_speed(10),
                                setting=self.make_eos_setting_param(10),
                                intf_id=1)] +\
                [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                 "inactive",
                                 setting='',
                                 intf_id=lane_id)
                 for lane_id in range(2, 4+1)]

    def _gen_intfs_qsfp28_2x10G(self, port_id, slot_id):
        return [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "active",
                                port_speed(10),
                                setting=self.make_eos_setting_param(10),
                                intf_id=lane_id)
                for lane_id in range(1, 3)] +\
               [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "inactive",
                                setting='',
                                intf_id=lane_id)
                for lane_id in range(3, 4+1)]

    def _gen_intfs_qsfp28_2x10G_odd_only(self, port_id, slot_id, validations=None):
        return [d.gen_interface(self.make_intf_name(port_id, 1, slot_id),
                                "active",
                                port_speed(10),
                                setting=self.make_eos_setting_param(
                                    10, validations=validations),
                                intf_id=1)] +\
               [d.gen_interface(self.make_intf_name(port_id, 3, slot_id),
                                "active",
                                port_speed(10),
                                setting=self.make_eos_setting_param(
                                    10, validations=validations),
                                intf_id=2)]

    def _gen_intfs_qsfp28_odd_2x10G_of_4(self, port_id, slot_id):
        ret = []
        for lane_id in range(1, 4+1):
            if lane_id % 2:
                ret.append(d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                           "active",
                                           port_speed(10),
                                           self.make_eos_setting_param(10),
                                           intf_id=lane_id))
            else:
                ret.append(d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                           "inactive",
                                           setting='',
                                           intf_id=lane_id))
        return ret


    # Interface generators for MXP ports, 12x10G lanes per port
    def _gen_intfs_mxp_1x100G(self, port_id, slot_id):
        return [d.gen_interface(self.make_intf_name(port_id, 1, slot_id),
                                "active",
                                port_speed(100),
                                setting=self.make_eos_setting_param(100),
                                intf_id=1)] +\
               [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "inactive",
                                setting='',
                                intf_id=lane_id)
                for lane_id in range(2, 12+1)]

    def _gen_intfs_mxp_12x10G(self, port_id, slot_id):
        return [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "active", port_speed(10),
                                setting=self.make_eos_setting_param(10),
                                intf_id=lane_id)
                for lane_id in range(1, 12+1)]

    def _gen_intfs_mxp_3x40G(self, port_id, slot_id):
        return [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "active", port_speed(40),
                                setting=self.make_eos_setting_param(40),
                                intf_id=lane_id)
                for lane_id in [1, 5, 9]] +\
               [d.gen_interface(self.make_intf_name(port_id, lane_id, slot_id),
                                "inactive",
                                setting='',
                                intf_id=lane_id)
                for lane_id in [2, 3, 4, 6, 7, 8, 10, 11, 12]]

    # 25G interface generators
    def _gen_intfs_1x25G_to_1_25G(self, port_id, slot_id, validations=None):
        return [d.gen_interface(
            self.make_intf_name(port_id, slot_id=slot_id),
            "active", port_speed(25),
            self.make_eos_setting_param(25, validations=validations),
            intf_id=1)]

    def _gen_intfs_1x25G_to_1x10G_breakout(self, port_id, slot_id, validations=None):
        return [d.gen_interface(
            self.make_intf_name(port_id, slot_id=slot_id),
            "active",
            port_speed(10),
            self.make_eos_setting_param(10, validations=validations),
            intf_id=1)]

    def _gen_intfs_1x25G_to_1_1G(self, port_id, slot_id, validations=None):
        return [d.gen_interface(
            self.make_intf_name(port_id, slot_id=slot_id),
            "active",
            port_speed(1),
            self.make_eos_setting_param(1, validations=validations),
            intf_id=1)]

    # port generators
    def gen_40G_to_4x10G_port(self, port_id, row_id, col_id, panel_id,
                              slot_id, failure_domain_id, port_offset, model):
        if model in ["DCS-7050QX-32S"] and port_id == 5:
            pg_name = gen_port_group_name(port_id, 5)
            validation = gen_pg_speed_validations([(pg_name, "no_ports1_4")])
        else:
            validation = None

        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp",
                          [d.gen_transform(self._gen_intfs_1x40G_to_1_40G(
                              port_id, slot_id, model, validations=validation),
                                           transformation_id=1),
                           d.gen_transform(self._gen_intfs_1x40G_to_4x10G_breakout(
                               port_id, slot_id, model, validations=validation),
                                           transformation_id=2, is_default=True)],
                          slot_id, failure_domain_id, port_offset, self.templatize)

    # This will produce a non-breakout capable port but of form e.g. Ethernet0/1, etc.
    # Whereas gen_40G_non_breakout_capable_port will produce Ethernet0, etc.
    def gen_40G_port(self, port_id, row_id, col_id, panel_id,
                     slot_id, failure_domain_id, port_offset, model):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp",
                          [d.gen_transform(self._gen_intfs_1x40G_to_1_40G(
                              port_id, slot_id, model)[0:1], transformation_id=1,
                                           is_default=True),
                          ],
                          slot_id, failure_domain_id, port_offset, self.templatize)

    def gen_40G_port_or_inactive(self, port_id, row_id, col_id, panel_id,
                                 slot_id, failure_domain_id, port_offset, model):
        if model in ["7280qra_c36s"]:
            pg_name = gen_port_group_name(port_id, 2)
            validations_1x40 = gen_pg_speed_validations(
                [(pg_name, "1x100Gor2x50Gor1x40G")])
        else:
            validations_1x40 = None

        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp",
                          [d.gen_transform(self._gen_intfs_1x40G_to_1_40G(
                              port_id, slot_id, model, validations=validations_1x40)[0:1], transformation_id=1,
                                           is_default=True),
                           d.gen_transform(self._gen_intfs_all_four_inactive(
                               port_id, slot_id, speed=40)[0:1],
                                           transformation_id=2,
                                           is_default=False),
                          ],
                          slot_id, failure_domain_id, port_offset, self.templatize)


    def gen_40G_non_breakout_capable_port(self, port_id, row_id, col_id,
                                          panel_id, slot_id, failure_domain_id,
                                          port_offset):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp",
                          [d.gen_transform(self._gen_intfs_40G_no_breakout(
                              port_id, slot_id), transformation_id=1,
                                           is_default=True)],
                          slot_id, failure_domain_id, port_offset, self.templatize)

    def gen_100G_non_breakout_capable_port(self, port_id, row_id, col_id,
                                           panel_id, slot_id, failure_domain_id,
                                           port_offset):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [d.gen_transform(self._gen_intfs_100G_no_breakout(
                              port_id, slot_id), transformation_id=1,
                                           is_default=True)],
                          slot_id, failure_domain_id, port_offset, self.templatize)

    def gen_25G_non_breakout_capable_port(self, port_id, row_id, col_id,
                                          panel_id, slot_id, failure_domain_id,
                                          port_offset, connector="sfp+"):
        return d.gen_port(port_id, row_id, col_id, panel_id, connector,
                          [d.gen_transform(self._gen_intfs_25G_no_breakout(
                              port_id, slot_id), transformation_id=1,
                                           is_default=True)],
                          slot_id, failure_domain_id, port_offset, self.templatize)

    def gen_1G_non_breakout_capable_port(self, port_id, row_id, col_id,
                                         panel_id, slot_id, failure_domain_id,
                                         port_offset, connector="RJ45"):
        return d.gen_port(port_id, row_id, col_id, panel_id, connector,
                          [d.gen_transform(self._gen_intfs_1G_no_breakout(
                              port_id, slot_id), transformation_id=1,
                                           is_default=True)],
                          slot_id, failure_domain_id, port_offset, self.templatize)

    def gen_10G_to_1x1G_port(self, port_id, row_id, col_id, panel_id,
                             slot_id, failure_domain_id, port_offset, model,
                             connector='sfp', validations=None):
        if model in ["DCS-7050QX-32S"]:
            pg_name = gen_port_group_name(port_id, 5)
            validation = gen_pg_speed_validations([(pg_name, "no_port5")])
        else:
            validation = None

        return d.gen_port(port_id, row_id, col_id, panel_id, connector,
                          [d.gen_transform(self._gen_intfs_10G_to_1_10G(
                              port_id, slot_id, model, validations=validation),
                                           transformation_id=1, is_default=True),
                           d.gen_transform(self._gen_intfs_10G_to_1x1G_breakout(
                               port_id, slot_id, model, validations=validation),
                                           transformation_id=2)],
                          slot_id, failure_domain_id, port_offset, self.templatize)

    def gen_10G_to_1x1G_or_inactive_port(self, port_id, row_id, col_id, panel_id,
                             slot_id, failure_domain_id, port_offset, model,
                             connector='sfp'):
        return d.gen_port(port_id, row_id, col_id, panel_id, connector,
                          [d.gen_transform(self._gen_intfs_10G_to_1_10G(
                              port_id, slot_id, model), transformation_id=1,
                              is_default=True),
                              d.gen_transform(
                                  self._gen_intfs_10G_to_1x1G_breakout(port_id,
                                                                       slot_id,
                                                                       model),
                                  transformation_id=2),
                              d.gen_transform(
                                  [d.gen_interface(self.make_intf_name(
                                      port_id, slot_id=slot_id),
                                      "inactive",
                                      port_speed(10),
                                      setting='',
                                      intf_id=1)],
                                  transformation_id=3)],

                          slot_id, failure_domain_id, port_offset, self.templatize)

            # This generates a port with transformation that show support for auto-neg
    def gen_10GBaseT_autoneg_port(self, port_id, row_id, col_id, panel_id,
                                  slot_id, failure_domain_id, port_offset):
        return d.gen_port(port_id, row_id, col_id, panel_id, "10GBaseT",
                          [d.gen_transform(self._gen_intfs_10G_to_1_10G_auto_neg(
                              port_id, slot_id), transformation_id=1,
                                           is_default=True),
                           d.gen_transform(self._gen_intfs_10G_to_1_10G(
                               port_id, slot_id), transformation_id=2),
                           d.gen_transform(self._gen_intfs_10G_to_1x1G_breakout(
                               port_id, slot_id), transformation_id=3)],
                          slot_id, failure_domain_id, port_offset, self.templatize)

    # Used for vEOS
    def _gen_port_sfp_non_breakout_capable(self, port_id, row_id, col_id,
                                           panel_id, slot_id,
                                           failure_domain_id, port_offset):
        return d.gen_port(
            port_id, row_id, col_id, panel_id, "sfp", slot_id=slot_id,
            failure_domain_id=failure_domain_id, port_offset=port_offset,
            transformations=[
                d.gen_transform(
                    self._gen_intfs_sfp_non_breakout_capable(port_id, slot_id),
                    transformation_id=1,
                    is_default=True
                )
            ])

    def gen_25G_to_1x10G_port(self, port_id, row_id, col_id, panel_id, slot_id,
                              failure_domain_id, port_offset):
        return d.gen_port(port_id, row_id, col_id, panel_id, "sfp28",
                          [d.gen_transform(self._gen_intfs_1x25G_to_1_25G(
                              port_id, slot_id), transformation_id=1),
                           d.gen_transform(self._gen_intfs_1x25G_to_1x10G_breakout(
                               port_id, slot_id), transformation_id=2,
                                           is_default=True)],
                          slot_id, failure_domain_id, port_offset, self.templatize)

    def gen_25G_to_1x10G_1x1G_port(self, port_id, row_id, col_id, panel_id, slot_id,
                                   failure_domain_id, port_offset, model=''):

        if model in ["7050sx3_96yc8", "7050sx3_48yc12"]:
            pg_name = gen_port_group_name(port_id, 4)
            validations_25 = gen_pg_speed_validations([(pg_name, "1x25G")])
            validations_10 = gen_pg_speed_validations([(pg_name, "1x10Gor1x1G")])
            validations_1 = gen_pg_speed_validations([(pg_name, "1x10Gor1x1G")])
        else:
            validations_25 = None
            validations_10 = None
            validations_1 = None

        return d.gen_port(port_id, row_id, col_id, panel_id, "sfp28",
                          [d.gen_transform(self._gen_intfs_1x25G_to_1_25G(
                              port_id, slot_id, validations=validations_25),
                                           transformation_id=1),
                           d.gen_transform(self._gen_intfs_1x25G_to_1x10G_breakout(
                               port_id, slot_id, validations=validations_10),
                                           transformation_id=2, is_default=True),
                           d.gen_transform(self._gen_intfs_1x25G_to_1_1G(
                               port_id, slot_id, validations=validations_1),
                                           transformation_id=3)],
                          slot_id, failure_domain_id, port_offset, self.templatize)

    def gen_100G_1x40_4x25_2x50_4x10_port(self, port_id, row_id, col_id,
                                          panel_id, slot_id, failure_domain_id,
                                          port_offset, connector_type="qsfp28",
                                          model=''):

        if model in ["7280cr3_32p4", "7280qra_c36s"]:
            pg_name = gen_port_group_name(port_id, 2)
            validations_1x100 = gen_pg_speed_validations(
                [(pg_name, "1x100Gor2x50Gor1x40G")])
            validations_2x50 = gen_pg_speed_validations(
                [(pg_name, "1x100Gor2x50Gor1x40G")])
            validations_1x40 = gen_pg_speed_validations(
                [(pg_name, "1x100Gor2x50Gor1x40G")])
            validations_4x25 = gen_pg_speed_validations([(pg_name, "4x25G_oddonly")])
            validations_4x10 = gen_pg_speed_validations([(pg_name, "4x10G_oddonly")])
        else:
            validations_1x100 = None
            validations_2x50 = None
            validations_1x40 = None
            validations_4x25 = None
            validations_4x10 = None

        return d.gen_port(port_id, row_id, col_id, panel_id, connector_type,
                          [
                              d.gen_transform(self._gen_intfs_qsfp28_1x100G(
                                  port_id, slot_id, validations=validations_1x100),
                                              transformation_id=1,is_default=True),
                              d.gen_transform(self._gen_intfs_qsfp28_2x50G(
                                  port_id, slot_id, validations=validations_2x50),
                                              transformation_id=2),
                              d.gen_transform(self._gen_intfs_qsfp28_1x40G(
                                  port_id, slot_id, validations=validations_1x40),
                                              transformation_id=3),
                              d.gen_transform(self._gen_intfs_qsfp28_4x25G(
                                  port_id, slot_id, validations=validations_4x25),
                                              transformation_id=4),
                              d.gen_transform(self._gen_intfs_qsfp28_4x10G(
                                  port_id, slot_id, validations=validations_4x10),
                                              transformation_id=5),
                          ], slot_id, failure_domain_id, port_offset,
                          self.templatize)

    def gen_100G_2x50G_1x40G_1x25G_1x10G_port(self, port_id, row_id, col_id,
                                              panel_id, slot_id, failure_domain_id,
                                              port_offset):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [
                              d.gen_transform(self._gen_intfs_qsfp28_1x100G(
                                  port_id, slot_id), transformation_id=1,
                                              is_default=True),
                              d.gen_transform(self._gen_intfs_qsfp28_2x50G(
                                  port_id, slot_id), transformation_id=2),
                              d.gen_transform(self._gen_intfs_qsfp28_1x40G(
                                  port_id, slot_id), transformation_id=3),
                              d.gen_transform(self._gen_intfs_qsfp28_1x25G(
                                  port_id, slot_id), transformation_id=4),
                              d.gen_transform(self._gen_intfs_qsfp28_1x10G(
                                  port_id, slot_id), transformation_id=5),
                          ], slot_id, failure_domain_id, port_offset,
                          self.templatize)

    def gen_100G_2x50G_1x40G_2x25G_2x10G_port_odd_only(self, port_id, row_id,
                                                       col_id, panel_id, slot_id,
                                                       failure_domain_id,
                                                       port_offset,
                                                       connector='qsfp28'):
        return d.gen_port(port_id, row_id, col_id, panel_id, connector,
                          [
                              d.gen_transform(self._gen_intfs_qsfp28_1x100G_odd_only(
                                  port_id, slot_id), transformation_id=1,
                                              is_default=True),
                              d.gen_transform(self._gen_intfs_qsfp28_2x50G_odd_only(
                                  port_id, slot_id), transformation_id=2),
                              d.gen_transform(self._gen_intfs_qsfp28_1x40G_odd_only(
                                  port_id, slot_id), transformation_id=3),
                              d.gen_transform(self._gen_intfs_qsfp28_2x25G_odd_only(
                                  port_id, slot_id), transformation_id=4),
                              d.gen_transform(self._gen_intfs_qsfp28_2x10G_odd_only(
                                  port_id, slot_id), transformation_id=5),
                          ], slot_id, failure_domain_id, port_offset,
                          self.templatize)

    def gen_100G_2x50G_1x40G_inactive_port_odd_only(self, port_id, row_id,
                                                       col_id, panel_id, slot_id,
                                                       failure_domain_id,
                                                       port_offset,
                                                       connector='qsfp28', model=''):
        if model in ["7280cr3_32p4",]:
            pg_name = gen_port_group_name(port_id, 2)
            validations_1x100 = gen_pg_speed_validations(
                [(pg_name, "1x100Gor2x50Gor1x40G")])
            validations_2x50 = gen_pg_speed_validations(
                [(pg_name, "1x100Gor2x50Gor1x40G")])
            validations_1x40 = gen_pg_speed_validations(
                [(pg_name, "1x100Gor2x50Gor1x40G")])
        else:
            validations_1x100 = None
            validations_2x50 = None
            validations_1x40 = None

        return d.gen_port(port_id, row_id, col_id, panel_id, connector,
                          [
                              d.gen_transform(self._gen_intfs_qsfp28_1x100G_odd_only(
                                  port_id, slot_id, validations=validations_1x100),
                                              transformation_id=1, is_default=True),
                              d.gen_transform(self._gen_intfs_qsfp28_2x50G_odd_only(
                                  port_id, slot_id, validations=validations_2x50),
                                              transformation_id=2),
                              d.gen_transform(self._gen_intfs_qsfp28_1x40G_odd_only(
                                  port_id, slot_id, validations=validations_1x40),
                                              transformation_id=3),
                              d.gen_transform(self._gen_intfs_inactive_odd_only(
                                  port_id, slot_id, 100), transformation_id=4),
                          ], slot_id, failure_domain_id, port_offset,
                          self.templatize)

    def gen_100G_1x40_4x10_port(self, port_id, row_id, col_id, panel_id, slot_id,
                                failure_domain_id, port_offset, connector_type="qsfp28"):
        return d.gen_port(port_id, row_id, col_id, panel_id, connector_type,
                          [
                              d.gen_transform(self._gen_intfs_qsfp28_1x100G(
                                  port_id, slot_id), transformation_id=1,
                                              is_default=True),
                              d.gen_transform(self._gen_intfs_qsfp28_1x40G(
                                  port_id, slot_id), transformation_id=2),
                              d.gen_transform(self._gen_intfs_qsfp28_4x10G(
                                  port_id, slot_id), transformation_id=3)
                          ], slot_id, failure_domain_id, port_offset,
                          self.templatize)

    def gen_100G_1x40_port(self, port_id, row_id, col_id, panel_id, slot_id,
                           failure_domain_id, port_offset):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [
                              d.gen_transform(self._gen_intfs_qsfp28_1x100G(
                                  port_id, slot_id), transformation_id=1,
                                              is_default=True),
                              d.gen_transform(self._gen_intfs_qsfp28_1x40G(
                                  port_id, slot_id), transformation_id=2),
                          ], slot_id, failure_domain_id, port_offset,
                          self.templatize)

    def gen_100G_3x40_12x10_port(self, port_id, row_id, col_id, panel_id, slot_id,
                                 failure_domain_id, port_offset):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [
                              d.gen_transform(self._gen_intfs_mxp_1x100G(
                                  port_id, slot_id), transformation_id=1,
                                              is_default=True),
                              d.gen_transform(self._gen_intfs_mxp_3x40G(
                                  port_id, slot_id), transformation_id=2),
                              d.gen_transform(self._gen_intfs_mxp_12x10G(
                                  port_id, slot_id), transformation_id=3)
                          ], slot_id, failure_domain_id, port_offset,
                          self.templatize)

    def gen_100G_2x50G_1x40G_2x25G_2x10G_port(self, port_id, row_id, col_id,
                                              panel_id, slot_id, failure_domain_id,
                                              port_offset, connector='qsfp28'):
        return d.gen_port(port_id, row_id, col_id, panel_id, connector,
                          [
                              d.gen_transform(self._gen_intfs_qsfp28_1x100G(
                                  port_id, slot_id), transformation_id=1,
                                              is_default=True),
                              d.gen_transform(self._gen_intfs_qsfp28_2x50G(
                                  port_id, slot_id), transformation_id=2),
                              d.gen_transform(self._gen_intfs_qsfp28_1x40G(
                                  port_id, slot_id), transformation_id=3),
                              d.gen_transform(self._gen_intfs_qsfp28_2x25G(
                                  port_id, slot_id), transformation_id=4),
                              d.gen_transform(self._gen_intfs_qsfp28_2x10G(
                                  port_id, slot_id), transformation_id=5),
                          ], slot_id, failure_domain_id, port_offset)

    def gen_200G_to_2x100G_port(self, port_id, row_id, col_id, panel_id,
                                slot_id, failure_domain_id, port_offset):
        return d.gen_port(port_id, row_id, col_id, panel_id, "CFP2",
                          [d.gen_transform(self._gen_intfs_1x200G_to_2_200G_autoneg(
                              port_id, slot_id), transformation_id=1, is_default=True),
                           d.gen_transform(self._gen_intfs_1x200G_to_2x100G_breakout_autoneg(
                               port_id, slot_id), transformation_id=2)],
                          slot_id, failure_domain_id, port_offset,
                          self.templatize)

    def gen_400G_to_2x200G_4x100G_8x50G_1x40G_8x25G_8x10G_port(self, port_id, row_id, col_id,
                                                               panel_id, slot_id, failure_domain_id,
                                                               port_offset, connector="osfp"):
        return d.gen_port(port_id, row_id, col_id, panel_id, connector,
                          [
                              d.gen_transform(self._gen_intfs_osfp_breakout(
                                  port_id, slot_id, 400, 1, 8),
                                  transformation_id=1, is_default=True),
                              d.gen_transform(self._gen_intfs_osfp_breakout(
                                  port_id, slot_id, 200, 2, 8), transformation_id=2),
                              d.gen_transform(self._gen_intfs_osfp_breakout(
                                  port_id, slot_id, 100, 4, 8), transformation_id=3),
                              d.gen_transform(self._gen_intfs_osfp_breakout(
                                  port_id, slot_id, 50, 8, 8), transformation_id=4),
                              d.gen_transform(self._gen_intfs_osfp_breakout(
                                  port_id, slot_id, 40, 1, 8), transformation_id=5),
                              d.gen_transform(self._gen_intfs_osfp_breakout(
                                  port_id, slot_id, 25, 8, 8), transformation_id=6),
                              d.gen_transform(self._gen_intfs_osfp_breakout(
                                  port_id, slot_id, 10, 8, 8), transformation_id=7),
                          ], slot_id, failure_domain_id, port_offset, self.templatize)


    def gen_400G_to_4x100G_8x50G_1x40G_8x25G_8x10G_2x200G_port(self, port_id, row_id, col_id,
                                                               panel_id, slot_id, failure_domain_id,
                                                               port_offset, connector="osfp"):
        return d.gen_port(port_id, row_id, col_id, panel_id, connector,
                          [
                              d.gen_transform(self._gen_intfs_osfp_breakout(
                                  port_id, slot_id, 400, 1, 8),
                                  transformation_id=1, is_default=True),
                              d.gen_transform(self._gen_intfs_osfp_breakout(
                                  port_id, slot_id, 100, 4, 8), transformation_id=2),
                              d.gen_transform(self._gen_intfs_osfp_breakout(
                                  port_id, slot_id, 50, 8, 8), transformation_id=3),
                              d.gen_transform(self._gen_intfs_osfp_breakout(
                                  port_id, slot_id, 40, 1, 8), transformation_id=4),
                              d.gen_transform(self._gen_intfs_osfp_breakout(
                                  port_id, slot_id, 25, 8, 8), transformation_id=5),
                              d.gen_transform(self._gen_intfs_osfp_breakout(
                                  port_id, slot_id, 10, 8, 8), transformation_id=6),
                              d.gen_transform(self._gen_intfs_osfp_breakout(
                                  port_id, slot_id, 200, 2, 8), transformation_id=7),
                          ], slot_id, failure_domain_id, port_offset)


    def _gen_intfs_osfp_breakout(self, port_id, slot_id, speed, active_intfs,
                                 total_intfs):
        ports = []
        for lane_id in range(1, total_intfs + 1):
            if (lane_id -1) % (total_intfs / active_intfs) == 0:
                ports.append(d.gen_interface(
                    self.make_intf_name(port_id, lane_id, slot_id),
                    "active",
                    port_speed(speed),
                    setting=self.make_eos_setting_param(speed),
                    intf_id=lane_id))
            else:
                ports.append(d.gen_interface(
                    self.make_intf_name(port_id, lane_id, slot_id),
                    "inactive",
                    setting='',
                    intf_id=lane_id))
        return ports

    def gen_400G_to_4x100G_8x50G_1x40G_8x25G_8x10G_port(self, port_id, row_id, col_id,
                                                        panel_id, slot_id, failure_domain_id,
                                                        port_offset, connector="qsfpdd"):
        return d.gen_port(port_id, row_id, col_id, panel_id, connector,
                          [
                              d.gen_transform(self._gen_intfs_qsfpdd_1x400G(
                                  port_id, slot_id), transformation_id=1,
                                              is_default=True),
                              d.gen_transform(self._gen_intfs_qsfpdd_4x100G(
                                  port_id, slot_id), transformation_id=2),
                              d.gen_transform(self._gen_intfs_qsfpdd_8x50G(
                                  port_id, slot_id), transformation_id=3),
                              d.gen_transform(self._gen_intfs_qsfpdd_1x40G(
                                  port_id, slot_id), transformation_id=4),
                              d.gen_transform(self._gen_intfs_qsfpdd_8x25G(
                                  port_id, slot_id), transformation_id=5),
                              d.gen_transform(self._gen_intfs_qsfpdd_8x10G(
                                  port_id, slot_id), transformation_id=6),
                          ], slot_id, failure_domain_id, port_offset)

    # port generators given panel information(row, column)
    def gen_10G_to_1x1G_ports(self, row_count, column_count, start_index,
                              panel_id, slot_id=0, failure_domain_id=1,
                              port_offset=0, row_offset=0, col_offset=0,
                              model=None, connector='sfp'):
        return [self.gen_10G_to_1x1G_port(port_id, row_id, column_id,
                                          panel_id, slot_id,
                                          failure_domain_id, port_offset, model,
                                          connector=connector)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    # These generate the auto-neg capable ports for 10GBaseT ports
    def gen_10GBaseT_autoneg_ports(self, row_count, column_count, start_index,
                                   panel_id, slot_id=0, failure_domain_id=1,
                                   port_offset=0, row_offset=0,
                                   col_offset=0):
        return [self.gen_10GBaseT_autoneg_port(port_id, row_id, column_id,
                                               panel_id, slot_id,
                                               failure_domain_id, port_offset)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_ports_sfp_non_breakout_capable(self, row_count, column_count, start_index,
                                           panel_id, slot_id=0,
                                           failure_domain_id=1, port_offset=0,
                                           row_offset=0, col_offset=0):
        return [
            self._gen_port_sfp_non_breakout_capable(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(row_count, column_count, start_index,
                               row_offset, col_offset)
        ]

    def gen_40G_to_4x10G_ports(self, row_count, column_count, start_index,
                               panel_id, slot_id=0, failure_domain_id=1,
                               port_offset=0, row_offset=0, col_offset=0,
                               model=None):
        return [self.gen_40G_to_4x10G_port(port_id, row_id, column_id,
                                           panel_id, slot_id,
                                           failure_domain_id, port_offset,
                                           model)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_40G_non_breakout_capable_ports(self, row_count, column_count,
                                           start_index, panel_id, slot_id=0,
                                           failure_domain_id=1, port_offset=0,
                                           row_offset=0, col_offset=0):
        return [self.gen_40G_non_breakout_capable_port(port_id, row_id, column_id,
                                                       panel_id, slot_id,
                                                       failure_domain_id,
                                                       port_offset)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_100G_non_breakout_capable_ports(self, row_count, column_count,
                                            start_index, panel_id, slot_id=0,
                                            failure_domain_id=1, port_offset=0,
                                            row_offset=0, col_offset=0):
        return [self.gen_100G_non_breakout_capable_port(port_id, row_id, column_id,
                                                        panel_id, slot_id,
                                                        failure_domain_id,
                                                        port_offset)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_25G_non_breakout_capable_ports(self, row_count, column_count,
                                           start_index, panel_id, slot_id=0,
                                           failure_domain_id=1, port_offset=0,
                                           row_offset=0, col_offset=0):
        return [self.gen_25G_non_breakout_capable_port(port_id, row_id, column_id,
                                                       panel_id, slot_id,
                                                       failure_domain_id,
                                                       port_offset)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_1G_non_breakout_capable_ports(self, row_count, column_count,
                                          start_index, panel_id, slot_id=0,
                                          failure_domain_id=1, port_offset=0,
                                          row_offset=0, col_offset=0):
        return [self.gen_1G_non_breakout_capable_port(port_id, row_id, column_id,
                                                      panel_id, slot_id,
                                                      failure_domain_id,
                                                      port_offset)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_25G_to_1x10G_ports(self, row_count, column_count, start_index,
                               panel_id, slot_id=0, failure_domain_id=1,
                               port_offset=0, row_offset=0, col_offset=0):
        return [self.gen_25G_to_1x10G_port(
            port_id, row_id, column_id, panel_id, slot_id,
            failure_domain_id, port_offset)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_25G_to_1x10G_1x1G_ports(self, row_count, column_count, start_index,
                                    panel_id, slot_id=0, failure_domain_id=1,
                                    port_offset=0, row_offset=0, col_offset=0,
                                    model=''):
        return [self.gen_25G_to_1x10G_1x1G_port(
            port_id, row_id, column_id, panel_id, slot_id,
            failure_domain_id, port_offset, model=model)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_100G_1x40_4x10_ports(self, row_count, column_count, start_index,
                                 panel_id, slot_id=0, failure_domain_id=1,
                                 port_offset=0, row_offset=0, col_offset=0,
                                 connector_type="qsfp28"):
        return [self.gen_100G_1x40_4x10_port(
            port_id, row_id, column_id, panel_id, slot_id,
            failure_domain_id, port_offset, connector_type=connector_type)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_100G_1x40_ports(self, row_count, column_count, start_index,
                            panel_id, slot_id=0, failure_domain_id=1,
                            port_offset=0, row_offset=0, col_offset=0):
        return [self.gen_100G_1x40_port(
            port_id, row_id, column_id, panel_id, slot_id,
            failure_domain_id, port_offset)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_100G_1x40_4x25_2x50_4x10_ports(self, row_count, column_count,
                                           start_index, panel_id, slot_id=0,
                                           failure_domain_id=1, port_offset=0,
                                           row_offset=0, col_offset=0,
                                           connector='qsfp28'):
        return [self.gen_100G_1x40_4x25_2x50_4x10_port(port_id, row_id,
                                                       column_id, panel_id,
                                                       slot_id,
                                                       failure_domain_id,
                                                       port_offset,
                                                       connector_type=connector)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_100G_2x50_1x40_4x25_2x25_4x10_2x10_port(self, port_id, row_id, col_id,
                                                    panel_id, slot_id, failure_domain_id,
                                                    port_offset, connector="qsfp28",
                                                    model=None):
        if model in ['7500R3_36CQ']:
            if self.templatize:
                slot_prefix = variable_slot + '/'
            else:
                slot_prefix = '%d/' % slot_id if slot_id != 0 else ''
            pg_name = slot_prefix + gen_port_group_name(port_id, 2)
            validation = gen_pg_speed_validations([(pg_name, "evenPortDisabled")])
        else:
            validation = None

        return d.gen_port(port_id, row_id, col_id, panel_id, connector,
                          [
                              d.gen_transform(self._gen_intfs_qsfp28_1x100G(
                                  port_id, slot_id), transformation_id=1,
                                  is_default=True),
                              d.gen_transform(self._gen_intfs_qsfp28_odd_2x50G_of_4(
                                  port_id, slot_id), transformation_id=2),
                              d.gen_transform(self._gen_intfs_qsfp28_1x40G(
                                  port_id, slot_id), transformation_id=3),
                              d.gen_transform(self._gen_intfs_qsfp28_4x25G(
                                  port_id, slot_id, validations=validation),
                                              transformation_id=4),
                              d.gen_transform(self._gen_intfs_qsfp28_odd_2x25G_of_4(
                                  port_id, slot_id), transformation_id=5),
                              d.gen_transform(self._gen_intfs_qsfp28_4x10G(
                                  port_id, slot_id, validations=validation),
                                              transformation_id=6),
                              d.gen_transform(self._gen_intfs_qsfp28_odd_2x10G_of_4(
                                  port_id, slot_id), transformation_id=7),
                          ], slot_id, failure_domain_id, port_offset,
                          self.templatize)

    def gen_100G_2x50_1x40_2x25_2x10_inactive_port_odd_only(self, port_id, row_id,
                                                            col_id, panel_id,
                                                            slot_id,
                                                            failure_domain_id,
                                                            port_offset,
                                                            connector="qsfp28",
                                                            model=None):
        if model in ['7500R3_36CQ']:
            if self.templatize:
                slot_prefix = variable_slot + '/'
            else:
                slot_prefix = '%d/' % slot_id if slot_id != 0 else ''
            pg_name = slot_prefix + gen_port_group_name(port_id, 2)
            validation = gen_pg_speed_validations([(pg_name, "no4x25no4x10")])
        else:
            validation = None
        return d.gen_port(port_id, row_id, col_id, panel_id, connector,
                          [
                              d.gen_transform(self._gen_intfs_qsfp28_1x100G_odd_only(
                                  port_id, slot_id, validations=validation),
                                              transformation_id=1, is_default=True),
                              d.gen_transform(self._gen_intfs_qsfp28_2x50G_odd_only(
                                  port_id, slot_id, validations=validation),
                                              transformation_id=2),
                              d.gen_transform(self._gen_intfs_qsfp28_1x40G_odd_only(
                                  port_id, slot_id, validations=validation),
                                              transformation_id=3),
                              d.gen_transform(self._gen_intfs_qsfp28_2x25G_odd_only(
                                  port_id, slot_id, validations=validation),
                                              transformation_id=4),
                              d.gen_transform(self._gen_intfs_qsfp28_2x10G_odd_only(
                                  port_id, slot_id, validations=validation),
                                              transformation_id=5),
                              d.gen_transform(self._gen_intfs_inactive_odd_only(
                                  port_id, slot_id, speed=100), transformation_id=6),
                          ], slot_id, failure_domain_id, port_offset, self.templatize)

    def gen_100G_2x50_1x40_2x25_2x10_inactive_port(self, port_id, row_id,
                                                            col_id, panel_id,
                                                            slot_id,
                                                            failure_domain_id,
                                                            port_offset,
                                                            connector="qsfp28"):
        return d.gen_port(port_id, row_id, col_id, panel_id, connector,
                          [
                              d.gen_transform(self._gen_intfs_qsfp28_1x100G(
                                  port_id, slot_id), transformation_id=1,
                                  is_default=True),
                              d.gen_transform(self._gen_intfs_qsfp28_odd_2x50G_of_4(
                                  port_id, slot_id), transformation_id=2),
                              d.gen_transform(self._gen_intfs_qsfp28_1x40G(
                                  port_id, slot_id), transformation_id=3),
                              d.gen_transform(self._gen_intfs_qsfp28_odd_2x25G_of_4(
                                  port_id, slot_id), transformation_id=4),
                              d.gen_transform(self._gen_intfs_qsfp28_odd_2x10G_of_4(
                                  port_id, slot_id), transformation_id=5),
                              d.gen_transform(self._gen_intfs_all_four_inactive(
                                  port_id, slot_id, speed=100), transformation_id=6),
                          ], slot_id, failure_domain_id, port_offset, self.templatize)

    def gen_100G_2x50G_1x40G_1x25G_1x10G_ports(self, row_count, column_count,
                                               start_index, panel_id, slot_id=0,
                                               failure_domain_id=1, port_offset=0,
                                               row_offset=0, col_offset=0):
        return [self.gen_100G_2x50G_1x40G_1x25G_1x10G_port(port_id, row_id,
                                                           column_id, panel_id,
                                                           slot_id,
                                                           failure_domain_id,
                                                           port_offset)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_7280cr3_32p4_qsfp_ports(self, row_count, column_count, start_index, panel_id,
                                    slot_id=0, failure_domain_id=1, port_offset=0,
                                    row_offset=0, col_offset=0, connector='qsfp100'):

        ports = []
        for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset):
            if port_id % 2 != 0:
                ports.extend([
                    self.gen_100G_1x40_4x25_2x50_4x10_port(
                        port_id, row_id, column_id, panel_id,
                        slot_id, failure_domain_id,
                        port_offset, connector_type=connector, model='7280cr3_32p4')
                ])
            else:
                ports.extend([
                    self.gen_100G_2x50G_1x40G_inactive_port_odd_only(
                        port_id, row_id, column_id, panel_id,
                        slot_id, failure_domain_id,
                        port_offset, connector=connector, model='7280cr3_32p4')
                ])
        return ports


    def gen_100G_2x50G_1x40G_2x25G_2x10G_ports_odd_only(self, row_count, column_count,
                                                        start_index, panel_id, slot_id=0,
                                                        failure_domain_id=1, port_offset=0,
                                                        row_offset=0, col_offset=0,
                                                        connector='qsfp28'):
        return [self.gen_100G_2x50G_1x40G_2x25G_2x10G_port_odd_only(port_id, row_id,
                                                                    column_id, panel_id,
                                                                    slot_id, failure_domain_id,
                                                                    port_offset,
                                                                    connector=connector)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]


    def gen_100G_3x40_12x10_ports(self, row_count, column_count, start_index,
                                  panel_id, slot_id=0, failure_domain_id=1,
                                  port_offset=0, row_offset=0, col_offset=0):
        """
        Required:

        row_count: number of rows in the port group panel
        column_count: number of columns in the port group panel
        start_index: the starting index of the port in this port group
        panel_id: the panel number as per the port panel view in the device

        Optional:

        slot_id: given the device is modular, the slot number for the line card
        failure_domain_id: failure domain id as it applies to a group of ports
        in the device
        port_offset: in case of modular, port offset represents the number
        of ports in one line card
        row_offset: in case of non-rectangualr panel form factors, row offet
        enables the user to specify the contiguity of ports in a single panel
        full of a variety of port groups.
        col_offset: enables the user to specify contiguous ports in a single
        panel full of a variety of port groups.
        """
        return [self.gen_100G_3x40_12x10_port(
            port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
            port_offset)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_200G_to_2x100G_ports(self, row_count, column_count, start_index,
                                 panel_id, slot_id=0, failure_domain_id=1,
                                 port_offset=0, row_offset=0, col_offset=0):
        return [self.gen_200G_to_2x100G_port(port_id, row_id, column_id,
                                             panel_id, slot_id,
                                             failure_domain_id, port_offset)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_400G_to_4x100G_8x50G_1x40G_8x25G_8x10G_2x200G_ports(self, row_count, column_count,
                                                                start_index, panel_id, slot_id=0,
                                                                failure_domain_id=1, port_offset=0,
                                                                row_offset=0, col_offset=0, connector='osfp'):
        return [self.gen_400G_to_4x100G_8x50G_1x40G_8x25G_8x10G_2x200G_port(port_id, row_id,
                                                                            column_id, panel_id,
                                                                            slot_id,
                                                                            failure_domain_id,
                                                                            port_offset, connector)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]


    def gen_400G_to_2x200G_4x100G_8x50G_1x40G_8x25G_8x10G_ports(self, row_count, column_count,
                                                                start_index, panel_id, slot_id=0,
                                                                failure_domain_id=1, port_offset=0,
                                                                row_offset=0, col_offset=0, connector='osfp'):
        return [self.gen_400G_to_2x200G_4x100G_8x50G_1x40G_8x25G_8x10G_port(port_id, row_id,
                                                                            column_id, panel_id,
                                                                            slot_id,
                                                                            failure_domain_id,
                                                                            port_offset, connector)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_400G_to_4x100G_8x50G_1x40G_8x25G_8x10G_ports(self, row_count, column_count,
                                                         start_index, panel_id, slot_id=0,
                                                         failure_domain_id=1, port_offset=0,
                                                         row_offset=0, col_offset=0, connector='qsfpdd'):
        return [self.gen_400G_to_4x100G_8x50G_1x40G_8x25G_8x10G_port(port_id, row_id,
                                                                     column_id, panel_id,
                                                                     slot_id,
                                                                     failure_domain_id,
                                                                     port_offset, connector)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_100G_2x50G_1x40G_2x25G_2x10G_ports(self, row_count, column_count,
                                               start_index, panel_id, slot_id=0,
                                               failure_domain_id=1, port_offset=0,
                                               row_offset=0, col_offset=0,
                                               connector='qsfp28'):
        return [self.gen_100G_2x50G_1x40G_2x25G_2x10G_port(port_id, row_id,
                                                           column_id, panel_id,
                                                           slot_id,
                                                           failure_domain_id,
                                                           port_offset,
                                                           connector=connector)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_100G_2x50G_1x40G_2x25G_2x10G_odd_only_on_even_ports(self, row_count, column_count,
                                                                start_index, panel_id, slot_id=0,
                                                                failure_domain_id=1, port_offset=0,
                                                                row_offset=0, col_offset=0,
                                                                connector='qsfp28'):
        ports = []
        for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset):
            if port_id % 2 != 0:
                ports.extend([
                    self.gen_100G_2x50G_1x40G_2x25G_2x10G_port(
                        port_id, row_id, column_id, panel_id,
                        slot_id, failure_domain_id,
                        port_offset, connector=connector)
                ])
            else:
                ports.extend([
                    self.gen_100G_2x50G_1x40G_2x25G_2x10G_port_odd_only(
                        port_id, row_id, column_id, panel_id,
                        slot_id, failure_domain_id,
                        port_offset, connector=connector)
                ])

        return ports
