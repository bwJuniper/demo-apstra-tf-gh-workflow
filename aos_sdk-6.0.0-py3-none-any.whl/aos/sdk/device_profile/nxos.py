# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"Cisco generators for device profile and ports inside device profile"

# pylint: disable=invalid-name
# pylint: disable=bad-continuation
# pylint: disable=redefined-builtin
# pylint: disable=pointless-string-statement

import json
from aos.sdk.device_profile.generator_helpers import port_speed, \
    gen_pg_speed_validations
import aos.sdk.device_profile.device_profile as d
from six.moves import range

variable_slot = '{{slot_id}}'

def gen_port_group_name(port_num, num_of_ports_per_group):

    pg_first_index = num_of_ports_per_group * (
        (port_num - 1) // num_of_ports_per_group) + 1
    port_range = range(pg_first_index, pg_first_index + num_of_ports_per_group)
    return '_'.join('P'+ str(i) for i in port_range)

class NxosDeviceProfileGenerator(object):

    WILDCARD_OS_VERSION = ".*"
    def gen_nxos_selector(self, model, os_version, os="NXOS",
                          manufacturer="Cisco"):
        return {'os': os,
                'os_version': os_version,
                'manufacturer': manufacturer,
                'model': model}

    def gen_cisco_linecard_selector(self, model, version='', os="NXOS"):
        return {'os': os,
                'version': version,
                'model': model}

    def gen_cisco_device_profile(self, model, ports, label,
                                 userland=64, form_factor='1RU',
                                 ecmp_limit=64, asic="T2", cpu='x86',
                                 ram=16, onie=False, lxc=False,
                                 config_apply_support='incremental',
                                 slot_count=0,
                                 id=None,
                                 os_version=WILDCARD_OS_VERSION,
                                 copp_strict=None, breakout_capable=None,
                                 as_seq_num_supported=None,
                                 physical_device=True, dual_re=False):

        selector = self.gen_nxos_selector(model, os_version)
        copp_strict = copp_strict or [{'version': '.*', 'value': True}]
        # most of the nxos devices AOS supports today have one module with
        # breakout capable ports
        breakout_capable = breakout_capable or [{'version': '.*', 'value':
                                                 True, 'module': 1}]
        as_seq_num_supported = as_seq_num_supported or [{
            'version': '.*', 'value': True}]
        hw_caps = d.gen_device_profile_hw_caps(
                userland, form_factor,
                ecmp_limit, asic, cpu, ram, copp_strict, breakout_capable,
                as_seq_num_supported)
        sw_caps = d.gen_device_profile_sw_caps(onie, lxc, config_apply_support)
        ref_design_caps = d.gen_device_profile_ref_design_caps(freeform='disabled')

        return d.gen_device_profile(
            hw_caps, sw_caps, label, ports, selector,
            ref_design_caps,
            slot_count, id, physical_device=physical_device,
            dual_re=dual_re)

    def gen_cisco_linecard_profile(self, model, ports, label,
                                   compatible_chassis, userland=64,
                                   ecmp_limit=64, asic="T2", cpu='x86',
                                   ram=16, id=None, version='',
                                   os_version="nxos", copp_strict=None,
                                   breakout_capable=None,
                                   as_seq_num_supported=None):
        selector = self.gen_cisco_linecard_selector(model=model, version=version)
        copp_strict = copp_strict or [{'version': '.*', 'value': True}]
        breakout_capable = breakout_capable or [{
            'version': '.*', 'value':True, 'module': 0}]
        as_seq_num_supported = as_seq_num_supported or [{
            'version': '.*', 'value': True}]

        hw_caps = d.gen_device_profile_hw_caps(
            userland, '1RU', ecmp_limit, asic, cpu, ram, copp_strict,
            breakout_capable, as_seq_num_supported)

        return d.gen_linecard_profile(hw_caps, label, ports, selector,
                                      compatible_chassis, id)

    def gen_cisco_chassis_profile(
            self, model, label, userland=64, form_factor='1RU', ecmp_limit=64,
            asic="T2", cpu='x86', ram=16, onie=False, lxc=False,
            config_apply_support='incremental', linecard_slot_ids=None, id=None,
            os_version=WILDCARD_OS_VERSION,
            copp_strict=None, breakout_capable=None, as_seq_num_supported=None,
            dual_re=False, physical_device=True):
        selector = self.gen_nxos_selector(model, os_version)
        copp_strict = copp_strict or [{'version': '.*', 'value': True}]
        # most of the nxos devices AOS supports today have one module with
        as_seq_num_supported = as_seq_num_supported or [{
            'version': '.*', 'value': True}]
        hw_caps = d.gen_device_profile_hw_caps(
            userland, form_factor, ecmp_limit, asic, cpu, ram, copp_strict,
            breakout_capable, as_seq_num_supported)
        sw_caps = d.gen_device_profile_sw_caps(onie, lxc, config_apply_support)
        ref_design_caps = d.gen_device_profile_ref_design_caps(freeform='disabled')

        return d.gen_chassis_profile(
            hw_caps, sw_caps,
            label, selector, linecard_slot_ids,
            ref_design_caps,
            id=id,
            dual_re=dual_re, physical_device=physical_device)


class NxosDeviceProfilePortGenerator(object):

    def make_nxos_global_param(self, module_id, port, global_param=None):
        return {
            'speed': global_param or '',
            'module_index': module_id if module_id else 1,
            'port_index': port}

    def make_nxos_setting_param(self, intf_speed=None, is_40G_qsa=False,
                                module_id=-1, port=-1, is_qsa=False, lane_id=1,
                                from_speed=None, validations=None):
        """Creates and returns NXOS-specific dictionary represented as a string
           Args:
            intf_speed   Speed for interface (Aos::Resource::PortSpeed)
        """
        if is_40G_qsa:
            return ""
        if not intf_speed:
            speed = ""
            global_param = ""
        else:
            speed = {
                0: '',
                0.1: '100',
                1: '1000',
                5: '5000',
                10: '10000',
                25: '25000',
                40: '40000',
                50: '50000',
                100: '100000',
                200: '200000',
                400: '400000', }[intf_speed]

            # 10g-4x: when speed of the interface is 10G, and if qsa model or
            # if the port is a breakout port and first of the broken out
            # interfaces or port is 1x25G->1x10G breakout, then '' else 10g-4x
            # 25g-4x: only if the form_speed is 100G, and 100G->4x25G breakout,
            # the global param needs to be 25g-4x, otherwise ''
            # 50g-2x: we only have device profiles which have interface speed
            # as 50G and breakout 1x100G->2x50G
            # 100g-4x: only if the form_speed is 400G and 400G->4x100G breakout
            # the global param needs to be 100g-4x, otherwise we leave it to None.
            global_param = {
                0: '',
                0.1: '',
                1: '',
                5: '',
                10: '' if (is_qsa or lane_id != 1 or from_speed == 25 or
                    from_speed == 10) else '10g-4x',
                25: '' if (lane_id != 1 or from_speed != 100) else '25g-4x',
                40:  None,
                50:  '' if lane_id != 1 else '50g-2x',
                100: '100g-4x' if from_speed == 400 and lane_id==1 else None,
                200: None,
                400: None,
            }[intf_speed]

        module_tag = (
            variable_slot if self.templatize and module_id != -1 else module_id)
        setting_dict = {
            'interface':  {'speed': speed},
            'global': self.make_nxos_global_param(module_tag, port, global_param),
        }
        if validations:
            setting_dict['validations'] = validations
        return json.dumps(setting_dict)

    def __init__(self, templatize=False):
        self.speed_cmd_100m = "speed 100"
        self.speed_cmd_1g = "speed 1000"
        self.speed_cmd_10g = "speed 10000"
        self.speed_cmd_25g = "speed 25000"
        self.speed_cmd_40g = "speed 40000"
        self.speed_cmd_50g = "speed 50000"
        self.speed_cmd_100g = "speed 100000"
        self.speed_cmd_200g = "speed 200000"
        self.speed_cmd_400g = "speed 400000"
        self.templatize = templatize

    def make_intf_name(self, port_id, lane_id=None, module_id=1):
        """
            Semantics for interface names for NXOS devices:
            1. For fixed function boxes, module_id is 0
                for cisco boxes, even if module_id is 0, module_id_prefix is '1/' and
                not ''
            2. For modular boxes, module_id is anything but 0
            3. Safe to think of module_id as a logical construct of a physical
               slot. So, we use module_id in interface name generation and slot_id to
               record the slot information per physical port.
            4. The only elements that go into the name generation: module_id,
               intf_if, lane_id(note, we don't use slot_id in addition to the
               module_id in names)
            5. For ports which do not support breakout, the format is
                Ethernet<module>/<port>
            6. For ports which support breakout, the format is
                Ethernet<module>/<port>/<lane>
        """
        module_id_prefix = ('%s/' %variable_slot if self.templatize
                            else '%d/' %module_id if module_id
                            else '1/')
        lane_suffix = '/%d' % lane_id if lane_id is not None else ''
        return 'Ethernet%s%d%s' % (module_id_prefix, port_id, lane_suffix)

    #100G generators
    def gen_1x100G_to_4_100G(self, port_id, module_id, validations=None):
        """
            For Cisco platform, we do not need to generate the inactive
            interfaces as they are not used for config rendering
            interface_name = 'Ethernet%d/%d' % (module_id, port_index)
        """
        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "active",
            port_speed(100),
            self.make_nxos_setting_param(100, validations=validations),
            intf_id=1)]

        #100G generators
    def gen_inactive(self, port_id, module_id):
        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "inactive",
            port_speed(10), "",
            intf_id=1)]

    def gen_1x400G_to_4_400G(self, port_id, module_id):

        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "active",
            port_speed(400), self.make_nxos_setting_param(400), intf_id=1)]

    def gen_1x400G_to_4x100G_breakout(self, port_id, module_id):
        """
        interface_name = 'Ethernet%d/%d/%d' % (module_id, port_index,
        lane_id)
        """
        return [d.gen_interface(
            self.make_intf_name(port_id, 1, module_id),
            "active",
            port_speed(100), self.make_nxos_setting_param(
                intf_speed=100, module_id=module_id, port=port_id,
                from_speed=400),
            intf_id=1)] + \
               [d.gen_interface(
                   self.make_intf_name(port_id, lane_id, module_id),
                   "active",
                   port_speed(100),
                   self.make_nxos_setting_param(100, lane_id=lane_id,
                                                from_speed=400),
                   intf_id=lane_id
               ) for lane_id in range(2, 4 + 1)]

    def gen_1x400G_to_2x200G_breakout(self, port_id, module_id):
        """
        interface_name = 'Ethernet%d/%d/%d' % (module_id, port_index,
        lane_id)
        """
        return [d.gen_interface(
            self.make_intf_name(port_id, 1, module_id),
            "active", port_speed(200),
            self.make_nxos_setting_param(intf_speed=200, module_id=module_id,
                                         port=port_id, from_speed=400),
            intf_id=1)] + \
            [d.gen_interface(
                self.make_intf_name(port_id, 2, module_id),
                "active", port_speed(200),
                self.make_nxos_setting_param(200, lane_id=2,
                                                from_speed=400),
                intf_id=2)]

    def gen_1x200G_to_4x50G_breakout(self, port_id, module_id):
        """
        interface_name = 'Ethernet%d/%d/%d' % (module_id, port_index,
        lane_id)
        """
        return [d.gen_interface(
            self.make_intf_name(port_id, 1, module_id),
            "active",
            port_speed(50), self.make_nxos_setting_param(
                intf_speed=50, module_id=module_id, port=port_id,
                from_speed=200),
            intf_id=1)] +\
               [d.gen_interface(
                    self.make_intf_name(port_id, lane_id, module_id),
                    "active",
                    port_speed(50),
                    self.make_nxos_setting_param(50, lane_id=lane_id,
                        from_speed=200),
                    intf_id=lane_id
                    ) for lane_id in range(2, 4+1)]


    def gen_1x100G_to_4x25G_breakout(self, port_id, module_id, validations=None):
        """
        interface_name = 'Ethernet%d/%d/%d' % (module_id, port_index,
        lane_id)
        """
        return [d.gen_interface(
            self.make_intf_name(port_id, 1, module_id),
            "active",
            port_speed(25), self.make_nxos_setting_param(
                intf_speed=25, module_id=module_id, port=port_id,
                from_speed=100, validations=validations),
            intf_id=1)] +\
               [d.gen_interface(
                    self.make_intf_name(port_id, lane_id, module_id),
                    "active",
                    port_speed(25),
                    self.make_nxos_setting_param(25, lane_id=lane_id,
                        from_speed=100, validations=validations),
                    intf_id=lane_id
                    ) for lane_id in range(2, 4+1)]

    def gen_1x100G_to_4x10G_breakout(self, port_id, module_id, validations=None):
        """
        interface_name = 'Ethernet%d/%d/%d' % (module_id, port_index,
        lane_id)
        """
        return [d.gen_interface(
            self.make_intf_name(port_id, 1, module_id),
            "active",
            port_speed(10),
            self.make_nxos_setting_param(intf_speed=10, module_id=module_id,
                                         port=port_id, validations=validations),
            intf_id=1)] +\
               [d.gen_interface(
                    self.make_intf_name(port_id, lane_id, module_id),
                    "active",
                    port_speed(10),
                    self.make_nxos_setting_param(10, lane_id=lane_id,
                                                 validations=validations),
                    intf_id=lane_id) for lane_id in range(2, 4+1)]

    def gen_1x100G_to_1x40G_breakout(self, port_id, module_id, validations=None):
        """
        interface_name = 'Ethernet%d/%d' % (slot_id, port_id)
        """
        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "active",
            port_speed(40),
            self.make_nxos_setting_param(intf_speed=40, validations=validations),
            intf_id=1)]

    def gen_1x100G_to_1x10G_breakout_qsa(self, port_id, module_id, validations=None):
        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "active",
            port_speed(10),
            self.make_nxos_setting_param(
                intf_speed=10, is_qsa=True, validations=validations),
            intf_id=1)]

    def gen_1x100G_to_1x1G_breakout_qsa(self, port_id, module_id):
        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "active",
            port_speed(1),
            self.make_nxos_setting_param(intf_speed=1, is_qsa=True),
            intf_id=1)]

    def gen_1x100G_to_1x50G_breakout(self, port_id, module_id):
        """
        interface_name = 'Ethernet%d/%d' % (slot_id, port_id)
        """
        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "active",
            port_speed(50), self.make_nxos_setting_param(intf_speed=50),
            intf_id=1)]

    def gen_1x100G_to_2x50G_breakout(self, port_id, module_id, validations=None):
        return [d.gen_interface(
            self.make_intf_name(port_id, 1, module_id=module_id),
            "active", port_speed(50),
            self.make_nxos_setting_param(intf_speed=50, module_id=module_id,
                                         port=port_id, validations=validations),
            intf_id=1)] +\
               [d.gen_interface(
                    self.make_intf_name(port_id, 2, module_id),
                    "active", port_speed(50),
                    self.make_nxos_setting_param(
                        50, lane_id=2, validations=validations),
                    intf_id=2)]

    def gen_1x40G_to_1x50G_breakout(self, port_id, module_id):
        return [
            d.gen_interface(
                self.make_intf_name(port_id, module_id=module_id),
                "active", port_speed(50),
                self.make_nxos_setting_param(intf_speed=50, lane_id=0),
                intf_id=1)
        ]

    def gen_1G_no_breakout(self, port_id, module_id, interface_speed=1):
        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "active",
            port_speed(1), self.make_nxos_setting_param(interface_speed),
            intf_id=1)]

    def gen_5G_no_breakout(self, port_id, module_id, interface_speed=5):
        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "active",
            port_speed(5), self.make_nxos_setting_param(interface_speed),
            intf_id=1)]


    # 10G port generators
    def gen_10G_to_1_10G(self, port_id, module_id, interface_speed=10):
        """
        for models like 9372PX, 9372TX, 9396PX which are all qsa models,
        and have 10g interfaces, the naming is:
        interface_name = 'Ethernet%d/%d'%(module_id, port_index)
        For 9396PX, the mod index is 2
        """
        name = self.make_intf_name(port_id, module_id=module_id)

        return [d.gen_interface(
            name, "active", port_speed(10),
            self.make_nxos_setting_param(interface_speed,
                                         from_speed=interface_speed),
            intf_id=1)]

    def gen_10G_to_1x1G_breakout(self, port_id, module_id):
        """
        for 1G interfaces, the naming convention is:
        interface_name = 'Ethernet%d/%d' % (module_id, port_index)
        """
        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "active",
            port_speed(1), self.make_nxos_setting_param(intf_speed=1),
            intf_id=1)]

    def gen_10G_no_breakout(self, port_id, module_id):
        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "active",
            port_speed(10), self.make_nxos_setting_param(10, lane_id=None),
            intf_id=1)]

    #40G generators
    def gen_40G_no_breakout(self, port_id, module_id, is_qsa):
        is_40G_qsa = False
        if is_qsa and port_id % 6 != 1:
            is_40G_qsa = True
        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "active",
            port_speed(40), self.make_nxos_setting_param(intf_speed=40,
                is_40G_qsa=is_40G_qsa), intf_id=1)]

    def gen_1x40G_to_4x10G_breakout(self, port_id, module_id):
        return [d.gen_interface(
            self.make_intf_name(port_id, 1, module_id),
            "active",
            port_speed(10), self.make_nxos_setting_param(intf_speed=10,
                module_id=module_id, port=port_id),
            intf_id=1)] +\
                    [d.gen_interface(
                        self.make_intf_name(port_id, lane_id, module_id),
                        "active",
                        port_speed(10),
                        self.make_nxos_setting_param(10, lane_id=lane_id),
                        intf_id=lane_id
                        ) for lane_id in range(2, 4+1)]

    def gen_1x100G_to_2x25G_breakout(self, port_id, module_id):
        return [d.gen_interface(
            self.make_intf_name(port_id, 1, module_id=module_id),
            "active", port_speed(25),
            self.make_nxos_setting_param(intf_speed=25, module_id=module_id,
                                         port=port_id),
            intf_id=1)] + \
               [d.gen_interface(
                   self.make_intf_name(port_id, 2, module_id),
                   "active", port_speed(25),
                   self.make_nxos_setting_param(25, lane_id=2),
                   intf_id=2)]

    def gen_1x100G_to_2x10G_breakout(self, port_id, module_id):
        return [d.gen_interface(
            self.make_intf_name(port_id, 1, module_id=module_id),
            "active", port_speed(10),
            self.make_nxos_setting_param(intf_speed=10, module_id=module_id,
                                         port=port_id),
            intf_id=1)] + \
               [d.gen_interface(
                   self.make_intf_name(port_id, 2, module_id),
                   "active", port_speed(10),
                   self.make_nxos_setting_param(10, lane_id=2),
                   intf_id=2)]

    def gen_1x40G_to_1x10G_breakout_qsa(self, port_id, module_id):
        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "active",
            port_speed(10),
            self.make_nxos_setting_param(intf_speed=10, is_qsa=True),
            intf_id=1)]

    def gen_1x40G_to_4_40G(self, port_id, module_id):
        """
            intf_speed is 40G, model is not qsa, hence interface name only
            contains mod and port ids and no lane id information
            interface_name = 'Ethernet%d/%d' % (module_id, port_index)
        """
        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "active",
                port_speed(40), self.make_nxos_setting_param(40), intf_id=1)]

    def gen_1x25G_to_1_25G(self, port_id, module_id, interface_speed=25):
        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "active",
            port_speed(25), self.make_nxos_setting_param(interface_speed),
            intf_id=1)]

    def gen_1x25G_to_1x1G_breakout(self, port_id, module_id):
        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "active",
                port_speed(1), self.make_nxos_setting_param(
                    intf_speed=1), intf_id=1)]

    def gen_1x25G_to_1x10G_breakout(self, port_id, module_id):
        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "active",
                port_speed(10), self.make_nxos_setting_param(
                    intf_speed=10, from_speed=25), intf_id=1)]

    # port generators
    def gen_40G_to_4x10G_port(self, port_id, row_id, col_id, panel_id,
                              slot_id, failure_domain_id, module_id, port_offset,
                              display_id=None):
        # if display_id is None:
        #     display_id = port_id

        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp",
                          [d.gen_transform(self.gen_1x40G_to_4_40G(
                              port_id, module_id), transformation_id=1,
                                           is_default=True),
                           d.gen_transform(self.gen_1x40G_to_4x10G_breakout(
                               port_id, module_id), transformation_id=2)],
                          slot_id, failure_domain_id, port_offset,
                          display_id=display_id, templatize=self.templatize)

    # port generators
    def gen_40G_to_1x10G_port(self, port_id, row_id, col_id, panel_id,
                              slot_id, failure_domain_id, module_id):
        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp",
            [
                d.gen_transform(
                    self.gen_40G_no_breakout(port_id, module_id, False),
                    transformation_id=1,
                    is_default=True
                ),
                d.gen_transform(
                    self.gen_1x40G_to_1x10G_breakout_qsa(port_id, module_id),
                    transformation_id=2
                )
            ],
            slot_id, failure_domain_id)

    def gen_40G_to_1x50G_1x10G_port(self, port_id, row_id, col_id, panel_id,
                                    slot_id, failure_domain_id, module_id):
        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp",
            [
                d.gen_transform(
                    self.gen_40G_no_breakout(port_id, module_id, False),
                    transformation_id=1,
                    is_default=True
                ),
                d.gen_transform(
                    self.gen_1x40G_to_1x50G_breakout(port_id, module_id),
                    transformation_id=2
                ),
                d.gen_transform(
                    self.gen_1x40G_to_1x10G_breakout_qsa(port_id, module_id),
                    transformation_id=3
                )
            ],
            slot_id, failure_domain_id)

    def gen_40G_non_breakout_capable_port(self, port_id, row_id, col_id,
                                          panel_id, slot_id, failure_domain_id,
                                          port_offset, is_qsa, module_id):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp",
                          [d.gen_transform(self.gen_40G_no_breakout(
                              port_id, module_id, is_qsa),
                              transformation_id=1, is_default=True)],
                          slot_id,
                          failure_domain_id, port_offset)

    def gen_200G_no_breakout(self, port_id, module_id):
        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "active",
            port_speed(200), self.make_nxos_setting_param(intf_speed=200),
            intf_id=1)]

    def gen_100G_no_breakout(self, port_id, module_id):
        return [d.gen_interface(
            self.make_intf_name(port_id, module_id=module_id),
            "active",
            port_speed(100), self.make_nxos_setting_param(intf_speed=100),
            intf_id=1)]

    def gen_100G_non_breakout_capable_port(self, port_id, row_id, col_id,
                                           panel_id, slot_id, failure_domain_id,
                                           port_offset, module_id):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [d.gen_transform(self.gen_100G_no_breakout(
                              port_id, module_id), transformation_id=1,
                                           is_default=True)], slot_id,
                          failure_domain_id, port_offset)

    def gen_10G_to_1x1G_port_no_autoneg(self, port_id, row_id, col_id, panel_id,
                                        slot_id, failure_domain_id,
                                        connector, module_id):
        return d.gen_port(port_id, row_id, col_id, panel_id, connector,
                          [d.gen_transform(self.gen_10G_to_1_10G(
                              port_id, module_id),
                              transformation_id=1, is_default=True),
                           d.gen_transform(self.gen_10G_to_1x1G_breakout(
                               port_id, module_id),
                               transformation_id=2)],
                          slot_id, failure_domain_id)

    def gen_10G_to_1x1G_port(self, port_id, row_id, col_id, panel_id,
                             slot_id, failure_domain_id,
                             connector, module_id):
        return d.gen_port(port_id, row_id, col_id, panel_id, connector,
                          [d.gen_transform(self.gen_10G_to_1_10G(
                              port_id, module_id,
                              interface_speed=None),
                              transformation_id=1, is_default=True),
                           d.gen_transform(self.gen_10G_to_1_10G(
                              port_id, module_id),
                              transformation_id=2),
                           d.gen_transform(self.gen_10G_to_1x1G_breakout(
                               port_id, module_id),
                               transformation_id=3)],
                          slot_id, failure_domain_id)

    def gen_10G_non_breakout_capable_port(self, port_id, row_id, col_id,
                                          panel_id, slot_id, failure_domain_id,
                                          module_id):
        return d.gen_port(port_id, row_id, col_id, panel_id, "sfp",
                          [d.gen_transform(self.gen_10G_no_breakout(
                              port_id, module_id), transformation_id=1,
                                           is_default=True)], slot_id,
                          failure_domain_id)

    def gen_100G_1x40_4x25_4x10_port(self, port_id, row_id, col_id, panel_id,
                                     slot_id, failure_domain_id, module_id,
                                     set_default_to_40g):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [
                           d.gen_transform(self.gen_1x100G_to_4_100G(
                               port_id, module_id), transformation_id=1,
                                           is_default=not set_default_to_40g),
                           d.gen_transform(self.gen_1x100G_to_1x40G_breakout(
                               port_id, module_id), transformation_id=2,
                                           is_default=bool(set_default_to_40g)),
                           d.gen_transform(self.gen_1x100G_to_4x25G_breakout(
                               port_id, module_id), transformation_id=3),
                           d.gen_transform(self.gen_1x100G_to_4x10G_breakout(
                               port_id, module_id), transformation_id=4)
                           ], slot_id, failure_domain_id)

    def gen_100G_1x40_4x25_port(self, port_id, row_id, col_id, panel_id,
                                slot_id, failure_domain_id, module_id,
                                set_default_to_40g):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [
                           d.gen_transform(self.gen_1x100G_to_4_100G(
                               port_id, module_id), transformation_id=1,
                                           is_default=not set_default_to_40g),
                           d.gen_transform(self.gen_1x100G_to_1x40G_breakout(
                               port_id, module_id), transformation_id=2,
                                           is_default=bool(set_default_to_40g)),
                           d.gen_transform(self.gen_1x100G_to_4x25G_breakout(
                               port_id, module_id), transformation_id=3)
                           ], slot_id, failure_domain_id)

    def gen_100G_1x40_4x25_4x10_1x10_port(self, port_id, row_id, col_id, panel_id,
                                     slot_id, failure_domain_id, module_id):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [
                           d.gen_transform(self.gen_1x100G_to_4_100G(
                               port_id, module_id), transformation_id=1),
                           d.gen_transform(self.gen_1x100G_to_1x40G_breakout(
                               port_id, module_id), transformation_id=2,
                               is_default=True),
                           d.gen_transform(self.gen_1x100G_to_4x25G_breakout(
                               port_id, module_id), transformation_id=3),
                           d.gen_transform(self.gen_1x100G_to_4x10G_breakout(
                               port_id, module_id), transformation_id=4),
                           d.gen_transform(self.gen_1x100G_to_1x10G_breakout_qsa(
                               port_id, module_id), transformation_id=5)
                           ], slot_id, failure_domain_id)

    def gen_100G_1x50_1x40_4x25_4x10_1x10_1x1_port(
            self, port_id, row_id, col_id, panel_id, slot_id,
            failure_domain_id, module_id):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [
                           d.gen_transform(self.gen_1x100G_to_4_100G(
                               port_id, module_id), transformation_id=1),
                           d.gen_transform(self.gen_1x100G_to_1x50G_breakout(
                               port_id, module_id), transformation_id=2),
                           d.gen_transform(self.gen_1x100G_to_1x40G_breakout(
                               port_id, module_id), transformation_id=3,
                               is_default=True),
                           d.gen_transform(self.gen_1x100G_to_4x25G_breakout(
                               port_id, module_id), transformation_id=4),
                           d.gen_transform(self.gen_1x100G_to_4x10G_breakout(
                               port_id, module_id), transformation_id=5),
                           d.gen_transform(self.gen_1x100G_to_1x10G_breakout_qsa(
                               port_id, module_id), transformation_id=6),
                           d.gen_transform(self.gen_1x100G_to_1x1G_breakout_qsa(
                               port_id, module_id), transformation_id=7)
                           ], slot_id, failure_domain_id)

    def gen_100G_2x50_1x40_4x25_4x10_1x10_1x1_port(
            self, port_id, row_id, col_id, panel_id, slot_id,
            failure_domain_id, port_offset, module_id):
        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp28",
            [
                d.gen_transform(self.gen_1x100G_to_4_100G(
                   port_id, module_id), transformation_id=1, is_default=True),
                d.gen_transform(self.gen_1x100G_to_2x50G_breakout(
                   port_id, module_id), transformation_id=2),
                d.gen_transform(self.gen_1x100G_to_1x40G_breakout(
                   port_id, module_id), transformation_id=3),
                d.gen_transform(self.gen_1x100G_to_4x25G_breakout(
                   port_id, module_id), transformation_id=4),
                d.gen_transform(self.gen_1x100G_to_4x10G_breakout(
                   port_id, module_id), transformation_id=5),
                d.gen_transform(self.gen_1x100G_to_1x10G_breakout_qsa(
                   port_id, module_id), transformation_id=6),
                d.gen_transform(self.gen_1x100G_to_1x1G_breakout_qsa(
                   port_id, module_id), transformation_id=7)
            ], slot_id, failure_domain_id, port_offset, templatize=self.templatize)

    def gen_100G_1x40_2x50_4x25_4x10_1x10_port(
            self, port_id, row_id, col_id, panel_id, slot_id,
            failure_domain_id, module_id):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [
                           d.gen_transform(self.gen_1x100G_to_4_100G(
                               port_id, module_id), transformation_id=1,
                                           is_default=True),
                           d.gen_transform(self.gen_1x100G_to_2x50G_breakout(
                               port_id, module_id), transformation_id=2),
                           d.gen_transform(self.gen_1x100G_to_1x40G_breakout(
                               port_id, module_id), transformation_id=3),
                           d.gen_transform(self.gen_1x100G_to_4x25G_breakout(
                               port_id, module_id), transformation_id=4),
                           d.gen_transform(self.gen_1x100G_to_4x10G_breakout(
                               port_id, module_id), transformation_id=5),
                           d.gen_transform(self.gen_1x100G_to_1x10G_breakout_qsa(
                               port_id, module_id), transformation_id=6)
                           ], slot_id, failure_domain_id)

    def gen_100G_1x40_2x50_2x25_2x10_1x10_port(
            self, port_id, row_id, col_id, panel_id, slot_id,
            failure_domain_id, module_id):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [
                           d.gen_transform(self.gen_1x100G_to_4_100G(
                               port_id, module_id), transformation_id=1,
                                           is_default=True),
                           d.gen_transform(self.gen_1x100G_to_2x50G_breakout(
                               port_id, module_id), transformation_id=2),
                           d.gen_transform(self.gen_1x100G_to_1x40G_breakout(
                               port_id, module_id), transformation_id=3),
                           d.gen_transform(self.gen_1x100G_to_2x25G_breakout(
                               port_id, module_id), transformation_id=4),
                           d.gen_transform(self.gen_1x100G_to_2x10G_breakout(
                               port_id, module_id), transformation_id=5),
                           d.gen_transform(self.gen_1x100G_to_1x10G_breakout_qsa(
                               port_id, module_id), transformation_id=6)
                           ], slot_id, failure_domain_id)

    def gen_100G_1x40_4x25_4x10_1x10_1x1_port(
            self, port_id, row_id, col_id, panel_id, slot_id,
            failure_domain_id, module_id):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [
                           d.gen_transform(self.gen_1x100G_to_4_100G(
                               port_id, module_id), transformation_id=1),
                           d.gen_transform(self.gen_1x100G_to_1x40G_breakout(
                               port_id, module_id), transformation_id=2,
                               is_default=True),
                           d.gen_transform(self.gen_1x100G_to_4x25G_breakout(
                               port_id, module_id), transformation_id=3),
                           d.gen_transform(self.gen_1x100G_to_4x10G_breakout(
                               port_id, module_id), transformation_id=4),
                           d.gen_transform(self.gen_1x100G_to_1x10G_breakout_qsa(
                               port_id, module_id), transformation_id=5),
                           d.gen_transform(self.gen_1x100G_to_1x1G_breakout_qsa(
                               port_id, module_id), transformation_id=6)
                           ], slot_id, failure_domain_id)

    def gen_100G_1x40_port(self, port_id, row_id, col_id, panel_id,
                           slot_id, failure_domain_id, module_id):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [
                              d.gen_transform(self.gen_1x100G_to_4_100G(
                                  port_id, module_id), transformation_id=1,
                                              is_default=True),
                              d.gen_transform(self.gen_1x100G_to_1x40G_breakout(
                                  port_id, module_id), transformation_id=2),
                          ], slot_id, failure_domain_id)

    def gen_25G_1x1_1x10_port(self, port_id, row_id, col_id, panel_id,
                              slot_id, failure_domain_id, module_id):
        return d.gen_port(port_id, row_id, col_id, panel_id, "sfp28",
                          [
                              d.gen_transform(self.gen_1x25G_to_1_25G(
                                  port_id, module_id, interface_speed=None),
                                              transformation_id=1,
                                              is_default=True),
                              d.gen_transform(self.gen_1x25G_to_1_25G(
                                  port_id, module_id), transformation_id=2),
                              d.gen_transform(self.gen_1x25G_to_1x10G_breakout(
                                  port_id, module_id), transformation_id=3),
                              d.gen_transform(self.gen_1x25G_to_1x1G_breakout(
                                  port_id, module_id), transformation_id=4)
                          ], slot_id, failure_domain_id)

    def gen_10G_1x1_1x100M_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            module_id):
        return d.gen_port(port_id, row_id, col_id, panel_id, "10GBaseT",
                          [
                              d.gen_transform(self.gen_10G_to_1_10G(
                                  port_id, module_id, interface_speed=None),
                                  transformation_id=1, is_default=True),
                              d.gen_transform(self.gen_10G_to_1_10G(
                                  port_id, module_id), transformation_id=2),
                              d.gen_transform(self.gen_1G_no_breakout(
                                  port_id, module_id), transformation_id=3),
                              d.gen_transform(self.gen_100M_no_breakout(
                                  port_id, module_id), transformation_id=4)
                          ], slot_id, failure_domain_id)

    def gen_100G_1x40_4x25_2x50_4x10_port(self, port_id, row_id, col_id,
                                          panel_id, slot_id, failure_domain_id,
                                          module_id):
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [
                              d.gen_transform(self.gen_1x100G_to_4_100G(
                                  port_id, module_id), transformation_id=1,
                                              is_default=True),
                              d.gen_transform(self.gen_1x100G_to_2x50G_breakout(
                                  port_id, module_id), transformation_id=2),
                              d.gen_transform(self.gen_1x100G_to_1x40G_breakout(
                                  port_id, module_id), transformation_id=3),
                              d.gen_transform(self.gen_1x100G_to_4x25G_breakout(
                                  port_id, module_id), transformation_id=4),
                              d.gen_transform(self.gen_1x100G_to_4x10G_breakout(
                                  port_id, module_id), transformation_id=5)
                          ], slot_id, failure_domain_id)

    def gen_1G_autoneg_port(self, port_id, row_id, col_id,
                            panel_id, slot_id, failure_domain_id,
                            module_id):
        return d.gen_port(port_id, row_id, col_id, panel_id, "1GBaseT",
                          [
                              d.gen_transform(self.gen_1G_no_breakout(
                                  port_id, module_id, interface_speed=None),
                                  transformation_id=1, is_default=True),
                              d.gen_transform(self.gen_1G_no_breakout(
                                  port_id, module_id), transformation_id=2)
                          ], slot_id, failure_domain_id)

    def gen_100M_no_breakout(self, port_id, module_id):
        return [d.gen_interface(self.make_intf_name(port_id, module_id=module_id),
                                "active", port_speed(100, unit='M'),
                                self.make_nxos_setting_param(intf_speed=0.1),
                                intf_id=1)]

    def gen_1G_autoneg_to_1x100M_port(self, port_id, row_id, col_id,
                                      panel_id, slot_id, failure_domain_id,
                                      module_id):
        return d.gen_port(port_id, row_id, col_id, panel_id, "1GBaseT",
                          [
                              d.gen_transform(self.gen_1G_no_breakout(
                                  port_id, module_id, interface_speed=None),
                                  transformation_id=1, is_default=True),
                              d.gen_transform(self.gen_1G_no_breakout(
                                  port_id, module_id), transformation_id=2),
                              d.gen_transform(self.gen_100M_no_breakout(
                                  port_id, module_id), transformation_id=3),
                          ], slot_id, failure_domain_id)

    # port generators given panel information(row, column)
    def gen_1G_autoneg_to_1x100M_ports(self, row_count, column_count,
                                       start_index, panel_id,
                                       slot_id=0, failure_domain_id=1,
                                       row_offset=0, col_offset=0,
                                       module_id=0):
        return [self.gen_1G_autoneg_to_1x100M_port(port_id, row_id,
                                                   col_id, panel_id,
                                                   slot_id,
                                                   failure_domain_id,
                                                   module_id)
                for (port_id, (col_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_10G_1x5_1x1_1x100M_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            module_id):
        return d.gen_port(port_id, row_id, col_id, panel_id, "10GBaseT",
                          [
                              d.gen_transform(self.gen_10G_to_1_10G(
                                  port_id, module_id, interface_speed=None),
                                  transformation_id=1, is_default=True),
                              d.gen_transform(self.gen_10G_to_1_10G(
                                  port_id, module_id), transformation_id=2),
                              d.gen_transform(self.gen_5G_no_breakout(
                                  port_id, module_id), transformation_id=3),
                              d.gen_transform(self.gen_1G_no_breakout(
                                  port_id, module_id), transformation_id=4),
                              d.gen_transform(self.gen_100M_no_breakout(
                                  port_id, module_id), transformation_id=5),
                          ], slot_id, failure_domain_id)

    def gen_10G_1x5_1x1_1x100M_ports(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, row_offset=0, col_offset=0, module_id=0):
        return [
            self.gen_10G_1x5_1x1_1x100M_port(
                port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
                module_id)
            for (port_id, (col_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_1GBaseT_autoneg_ports(self, row_count, column_count,
                                  start_index, panel_id,
                                  slot_id=0, failure_domain_id=1,
                                  row_offset=0, col_offset=0,
                                  module_id=0):
        return [self.gen_1G_autoneg_port(port_id, row_id, column_id,
                    panel_id, slot_id, failure_domain_id, module_id)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_10G_to_1x1G_no_autoneg_ports(self, row_count, column_count,
                                         start_index, panel_id,
                                         slot_id=0, failure_domain_id=1,
                                         row_offset=0, col_offset=0,
                                         connector='sfp', module_id=0):
        return [self.gen_10G_to_1x1G_port_no_autoneg(
                    port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                    connector, module_id)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_10G_to_1x1G_ports(self, row_count, column_count, start_index, panel_id,
                              slot_id=0, failure_domain_id=1,
                              row_offset=0, col_offset=0,
                              connector='sfp', module_id=0):
        return [self.gen_10G_to_1x1G_port(
                    port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                    connector, module_id)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_40G_to_4x10G_ports(self, row_count, column_count, start_index,
                               panel_id, slot_id=0, failure_domain_id=1,
                               row_offset=0, col_offset=0, port_offset=0,
                               module_id=0):
        return [self.gen_40G_to_4x10G_port(port_id, row_id, column_id,
                                           panel_id, slot_id, failure_domain_id,
                                           module_id, port_offset)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_40G_to_1x10G_ports(self, row_count, column_count, start_index,
                               panel_id, slot_id=0, failure_domain_id=1,
                               row_offset=0, col_offset=0, module_id=0):
        return [
            self.gen_40G_to_1x10G_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, module_id)
            for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_40G_to_1x50G_1x10G_ports(self, row_count, column_count, start_index,
                                     panel_id, slot_id=0, failure_domain_id=1,
                                     row_offset=0, col_offset=0, module_id=0):
        return [
            self.gen_40G_to_1x50G_1x10G_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, module_id)
            for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]


    def gen_40G_non_breakout_capable_ports(self, row_count, column_count,
                                           start_index, panel_id, slot_id=0,
                                           failure_domain_id=1, port_offset=0,
                                           is_qsa_model=False, row_offset=0,
                                           col_offset=0, module_id=0):
        return [self.gen_40G_non_breakout_capable_port(
                    port_id, row_id, column_id, panel_id,
                    slot_id, failure_domain_id,
                    port_offset, is_qsa_model, module_id)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_10G_non_breakout_capable_ports(self, row_count, column_count,
                                           start_index, panel_id, slot_id=0,
                                           failure_domain_id=1, row_offset=0,
                                           col_offset=0, module_id=0):
        return [self.gen_10G_non_breakout_capable_port(
                    port_id, row_id, column_id, panel_id, slot_id,
                    failure_domain_id, module_id)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_100G_1x40_4x25_4x10_ports(self, row_count, column_count,
                                      start_index, panel_id, slot_id=0,
                                      failure_domain_id=1, row_offset=0,
                                      col_offset=0, module_id=0,
                                      set_default_to_40g=False):
        return [self.gen_100G_1x40_4x25_4x10_port(port_id, row_id, column_id,
                                                  panel_id, slot_id,
                                                  failure_domain_id, module_id,
                                                  set_default_to_40g)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    # Not used currently by any DP.
    def gen_100G_1x40_4x25_ports(self, row_count, column_count,
                                 start_index, panel_id, slot_id=0,
                                 failure_domain_id=1, row_offset=0,
                                 col_offset=0, module_id=0,
                                 set_default_to_40g=False):
        return [self.gen_100G_1x40_4x25_port(port_id, row_id, column_id,
                                             panel_id, slot_id,
                                             failure_domain_id, module_id,
                                             set_default_to_40g)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_100G_1x40_4x25_4x10_1x10_ports(self, row_count, column_count,
                                           start_index, panel_id, slot_id=0,
                                           failure_domain_id=1, row_offset=0,
                                           col_offset=0, module_id=0):
        return [
            self.gen_100G_1x40_4x25_4x10_1x10_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, module_id)
            for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_100G_1x50_1x40_4x25_4x10_1x10_1x1_ports(self, row_count,
                                                  column_count,
                                           start_index, panel_id, slot_id=0,
                                           failure_domain_id=1, row_offset=0,
                                           col_offset=0, module_id=0):
        return [
            self.gen_100G_1x50_1x40_4x25_4x10_1x10_1x1_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, module_id)
            for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_100G_2x50_1x40_4x25_4x10_1x10_1x1_ports(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, row_offset=0, col_offset=0, port_offset=0,
            module_id=0):
        return [
            self.gen_100G_2x50_1x40_4x25_4x10_1x10_1x1_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, module_id)
            for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_100G_1x40_4x25_4x10_1x10_1x1_ports(self, row_count, column_count,
                                           start_index, panel_id, slot_id=0,
                                           failure_domain_id=1, row_offset=0,
                                           col_offset=0, module_id=0):
        return [
            self.gen_100G_1x40_4x25_4x10_1x10_1x1_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, module_id)
            for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_100G_1x40_ports(self, row_count, column_count,
                            start_index, panel_id, slot_id=0,
                            failure_domain_id=1, row_offset=0,
                            col_offset=0, module_id=0):
        return [self.gen_100G_1x40_port(port_id, row_id, column_id, panel_id,
                                        slot_id, failure_domain_id,
                                        module_id)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_100G_1x40_4x25_2x50_4x10_ports(self, row_count, column_count,
                                           start_index, panel_id, slot_id=0,
                                           failure_domain_id=1, row_offset=0,
                                           col_offset=0, module_id=0):
        return [self.gen_100G_1x40_4x25_2x50_4x10_port(port_id, row_id,
                                                       column_id, panel_id, slot_id,
                                                       failure_domain_id,
                                                       module_id)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_100G_1x40_4x25_2x50_4x10_1x10_ports(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, row_offset=0, col_offset=0, port_offset=0,
            module_id=0):
        def gen_100G_1x40_4x25_2x50_4x10_1x10_port(
                port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
                port_offset, module_id):
            return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                              [
                                  d.gen_transform(self.gen_1x100G_to_4_100G(
                                      port_id, module_id), transformation_id=1,
                                      is_default=True),
                                  d.gen_transform(self.gen_1x100G_to_2x50G_breakout(
                                      port_id, module_id), transformation_id=2),
                                  d.gen_transform(self.gen_1x100G_to_1x40G_breakout(
                                      port_id, module_id), transformation_id=3),
                                  d.gen_transform(self.gen_1x100G_to_4x25G_breakout(
                                      port_id, module_id), transformation_id=4),
                                  d.gen_transform(self.gen_1x100G_to_4x10G_breakout(
                                      port_id, module_id), transformation_id=5),
                                  d.gen_transform(
                                      self.gen_1x100G_to_1x10G_breakout_qsa(
                                          port_id, module_id), transformation_id=6)
                              ], slot_id, failure_domain_id, port_offset,
                              templatize=self.templatize)

        return [
            gen_100G_1x40_4x25_2x50_4x10_1x10_port(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                port_offset, module_id)
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(row_count, column_count, start_index,
                               row_offset, col_offset)]

    def gen_cisco_9332d_gx2b_ports(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, row_offset=0, col_offset=0, port_offset=0,
            module_id=0):
        # Note: This function is only used for the case of Cisco C9332D-GX2B
        return [
            self.gen_400G_2x200_4x100_200G_4x50_100G_4x25_40G_4x10_port(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                port_offset, module_id)
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(row_count, column_count, start_index,
                               row_offset, col_offset)]

    def gen_400G_2x200_4x100_200G_4x50_100G_4x25_40G_4x10_port(self,
            port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, module_id):

        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfpdd",
                          [
                              d.gen_transform(self.gen_1x400G_to_4_400G(
                                  port_id, module_id), transformation_id=1,
                                  is_default=True),
                              d.gen_transform(self.gen_1x400G_to_2x200G_breakout(
                                  port_id, module_id), transformation_id=2),
                              d.gen_transform(self.gen_1x400G_to_4x100G_breakout(
                                  port_id, module_id), transformation_id=3),
                              d.gen_transform(self.gen_200G_no_breakout(
                                  port_id, module_id), transformation_id=4),
                              d.gen_transform(self.gen_1x200G_to_4x50G_breakout(
                                  port_id, module_id), transformation_id=5),
                              d.gen_transform(self.gen_100G_no_breakout(
                                  port_id, module_id), transformation_id=6),
                              d.gen_transform(self.gen_1x100G_to_4x25G_breakout(
                                  port_id, module_id), transformation_id=7),
                              d.gen_transform(self.gen_1x100G_to_1x40G_breakout(
                                  port_id, module_id), transformation_id=8),
                              d.gen_transform(self.gen_1x40G_to_4x10G_breakout(
                                  port_id, module_id), transformation_id=9),
                          ],
                          slot_id, failure_domain_id, port_offset,
                          templatize=self.templatize)

    def gen_400G_4x100_1x40_4x25_2x50_4x10_1x10_ports_for_cisco_93600cd_gx(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, row_offset=0, col_offset=0, port_offset=0,
            module_id=0):
        # Note: This function is only used for the case of Cisco C93600CD-GX
        def gen_100G_1x40_4x25_2x50_4x10_1x10_port(
                port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
                port_offset, module_id):
            pg_name = gen_port_group_name(port_id, 4) if port_id < 25 \
                else gen_port_group_name(port_id, 2)
            validations_1x100 = gen_pg_speed_validations(
                [(pg_name, "1x40Gor1x100G")])
            validations_2x50 =  gen_pg_speed_validations([(pg_name, "2x50G")])
            validations_1x40 =  gen_pg_speed_validations(
                [(pg_name, "1x40Gor1x100G")])
            validations_1x10 =  gen_pg_speed_validations([(pg_name, "1x10G")])
            validations_4x25 =  gen_pg_speed_validations([(pg_name, "4x25G")])
            validations_4x10 =  gen_pg_speed_validations([(pg_name, "4x10G")])

            return d.gen_port(
                port_id, row_id, col_id, panel_id, "qsfp28",
                [d.gen_transform(self.gen_1x100G_to_4_100G(
                    port_id, module_id, validations=validations_1x100),
                                 transformation_id=1, is_default=True),
                 d.gen_transform(self.gen_1x100G_to_2x50G_breakout(
                     port_id, module_id, validations=validations_2x50),
                                 transformation_id=2),
                 d.gen_transform(self.gen_1x100G_to_1x40G_breakout(
                     port_id, module_id, validations=validations_1x40),
                                 transformation_id=3)] + \
                [d.gen_transform(self.gen_1x100G_to_1x10G_breakout_qsa(
                    port_id, module_id, validations=validations_1x10),
                                 transformation_id=4)] + \
                ([d.gen_transform(self.gen_1x100G_to_4x25G_breakout(
                    port_id, module_id, validations=validations_4x25),
                                  transformation_id=5),
                  d.gen_transform(self.gen_1x100G_to_4x10G_breakout(
                      port_id, module_id, validations=validations_4x10),
                                  transformation_id=6)] \
                    if port_id % 2 != 0 or port_id > 24 else []) + \
                [d.gen_transform(self.gen_inactive(port_id, module_id),
                                 transformation_id=7 if (
                                     port_id % 2 != 0 or port_id > 24) else 5),],
                slot_id, failure_domain_id, port_offset, templatize=self.templatize)

        def gen_400G_4x100G_1x40_4x25_2x50_4x10_1x10_port(
                port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
                port_offset, module_id):
            return d.gen_port(port_id, row_id, col_id, panel_id, "qsfpdd",
                              [
                                d.gen_transform(self.gen_1x400G_to_4_400G(
                                    port_id, module_id), transformation_id=1,
                                    is_default=True),
                                d.gen_transform(self.gen_1x400G_to_4x100G_breakout(
                                    port_id, module_id), transformation_id=2),
                                d.gen_transform(self.gen_1x100G_to_2x50G_breakout(
                                    port_id, module_id), transformation_id=3),
                                d.gen_transform(self.gen_1x100G_to_1x40G_breakout(
                                    port_id, module_id), transformation_id=4),
                                d.gen_transform(self.gen_1x100G_to_4x25G_breakout(
                                    port_id, module_id), transformation_id=5),
                                d.gen_transform(self.gen_1x100G_to_4x10G_breakout(
                                    port_id, module_id), transformation_id=6),
                                d.gen_transform(
                                    self.gen_1x100G_to_1x10G_breakout_qsa(
                                        port_id, module_id), transformation_id=7),
                                d.gen_transform(
                                    self.gen_inactive(port_id, module_id),
                                    transformation_id=8)
                              ], slot_id, failure_domain_id, port_offset,
                              templatize=self.templatize)

        return [
            gen_100G_1x40_4x25_2x50_4x10_1x10_port(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                port_offset, module_id) if port_id < 29 else
            gen_400G_4x100G_1x40_4x25_2x50_4x10_1x10_port(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                port_offset, module_id)
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(row_count, column_count, start_index,
                               row_offset, col_offset)]

    def gen_100G_non_breakout_capable_ports(self, row_count, column_count,
                                            start_index, panel_id, slot_id=0,
                                            failure_domain_id=1, port_offset=0,
                                            row_offset=0, col_offset=0,
                                            module_id=0):
        return [self.gen_100G_non_breakout_capable_port(
                    port_id, row_id, column_id, panel_id,
                    slot_id, failure_domain_id, port_offset, module_id)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_25G_1x1_1x10_ports(self, row_count, column_count, start_index,
                               panel_id, slot_id=0, failure_domain_id=1,
                               row_offset=0, col_offset=0, module_id=0):
        return [self.gen_25G_1x1_1x10_port(port_id, row_id,
                                           column_id, panel_id, slot_id,
                                           failure_domain_id, module_id)
                for (port_id, (column_id, row_id)) in
                d.get_port_indices(row_count, column_count, start_index,
                                   row_offset, col_offset)]

    def gen_10G_1x1_1x100M_ports(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, row_offset=0, col_offset=0, module_id=0):
        return [
            self.gen_10G_1x1_1x100M_port(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                module_id)
            for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_100G_1x40_2x50_2x25_2x10_ports(self, row_count, column_count,
                                           start_index, panel_id, slot_id=0,
                                           failure_domain_id=1, row_offset=0,
                                           col_offset=0, module_id=0):
        ports = []
        port_indices = d.get_port_indices(row_count, column_count, start_index,
                                          row_offset, col_offset)

        for port_id, (column_id, row_id) in port_indices:
            if port_id % 2 != 0:
                ports.append(
                    self.gen_100G_1x40_2x50_4x25_4x10_1x10_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, module_id)
                )
            else:
                ports.append(
                    self.gen_100G_1x40_2x50_2x25_2x10_1x10_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, module_id)
                )
        return ports
