# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import re
from aos.sdk.collection_utils import compact_dict
from aos.sdk.device_profile.generator_helpers import port_speed, \
    gen_pg_speed_validations
import aos.sdk.device_profile.device_profile as d
import json
from six.moves import range

# pylint: disable=invalid-name
# pylint: disable=redefined-builtin
# pylint: disable=line-too-long
# pylint: disable=anomalous-backslash-in-string
variable_fpc = variable_pic = '{{slot_id}}'

def get_master_port_id(port_id, port_group_count):
    # AOS lingo port id starts from 1, but port id on physical device starts from 0
    return (((port_id - 1) // port_group_count) * port_group_count) + 1

def gen_port_group_name(port_num, num_of_ports_per_group):

    pg_first_index = num_of_ports_per_group * (port_num // num_of_ports_per_group)
    port_range = range(pg_first_index, pg_first_index + num_of_ports_per_group)
    return '_'.join('P'+ str(i) for i in port_range)


class JunosDeviceProfileGenerator(object):

    WILDCARD_OS_VERSION = ".*"

    def gen_junos_selector(self, model, os_version, os="Junos",
                           manufacturer="Juniper"):
        return {'os': os,
                'os_version': os_version,
                'manufacturer': manufacturer,
                'model': model}

    def gen_junos_linecard_selector(self, model, version='', os="Junos"):
        return {'os': os,
                'version': version,
                'model': model}

    def gen_junos_device_profile(self, model, ports, label,
                                 userland=64, form_factor='1RU',
                                 ecmp_limit=64, asic="T2", cpu='x86',
                                 ram=16, onie=False, lxc=False,
                                 config_apply_support='complete_only',
                                 slot_count=0,
                                 chassis_count=None,
                                 id=None,
                                 os_version=WILDCARD_OS_VERSION,
                                 routing_instance_supported=None,
                                 physical_device=True, dual_re=False,
                                 freeform='full_support',
                                 datacenter='full_support'):

        selector = self.gen_junos_selector(model, os_version)
        routing_instance_supported = routing_instance_supported or [
            {'version': '.*', 'value': True}]
        hw_caps = d.gen_device_profile_hw_caps(
            userland, form_factor,
            ecmp_limit, asic, cpu, ram,
            routing_instance_supported=routing_instance_supported)
        sw_caps = d.gen_device_profile_sw_caps(onie, lxc, config_apply_support)
        ref_design_caps = d.gen_device_profile_ref_design_caps(
            freeform=freeform, datacenter=datacenter)

        return d.gen_device_profile(hw_caps, sw_caps, label, ports, selector,
                                    ref_design_caps,
                                    slot_count, id, chassis_count,
                                    physical_device=physical_device,
                                    dual_re=dual_re)

    def gen_junos_chassis_profile(self, model, label,
                                  userland=64, form_factor='1RU',
                                  ecmp_limit=64, asic="T2", cpu='x86',
                                  ram=16, onie=False, lxc=False,
                                  config_apply_support='complete_only',
                                  linecard_slot_ids=None,
                                  id=None,
                                  os_version=WILDCARD_OS_VERSION,
                                  routing_instance_supported=None,
                                  dual_re=True, physical_device=True,
                                  freeform='full_support',
                                  datacenter='full_support'):

        selector = self.gen_junos_selector(model, os_version)
        hw_caps = d.gen_device_profile_hw_caps(
            userland, form_factor, ecmp_limit, asic, cpu, ram,
            routing_instance_supported=
            routing_instance_supported or [{'version':'.*', 'value': True}])
        sw_caps = d.gen_device_profile_sw_caps(onie, lxc, config_apply_support)
        ref_design_caps = d.gen_device_profile_ref_design_caps(
            freeform=freeform, datacenter=datacenter)

        return d.gen_chassis_profile(
            hw_caps=hw_caps,
            sw_caps=sw_caps,
            label=label,
            selector=selector,
            linecard_slot_ids=linecard_slot_ids,
            ref_design_caps=ref_design_caps,
            id=id,
            dual_re=dual_re,
            physical_device=physical_device,
        )

    def gen_junos_linecard_profile(self, model, ports, label,
                                   compatible_chassis, userland=64,
                                   ecmp_limit=64, asic="T2", cpu='x86',
                                   ram=16, id=None, version='',
                                   os_version=WILDCARD_OS_VERSION):
        selector = self.gen_junos_linecard_selector(model=model, version=version)
        hw_caps = d.gen_device_profile_hw_caps(
            userland, '1RU', ecmp_limit, asic, cpu, ram)

        return d.gen_linecard_profile(hw_caps, label, ports, selector,
                                      compatible_chassis, id)


class JunosDeviceProfilePortGenerator(object):

    def __init__(self, templatize=False, templatize_pic=False):
        super(JunosDeviceProfilePortGenerator, self).__init__()
        self.templatize = templatize
        self.templatize_pic = templatize_pic

    def make_junos_global_param(
            self, global_speed, breakout, port_id, fpc, pic, master_port_id,
            subports_count=None, unused_port_list=None, speed_keyword=None):
        # There are three scenarios for port_id and master_port_id:
        # 1. They can both be None (for port that does not require explicit chassis
        #    speed set);
        # 2. They can both have values (for port in a port group that require
        #    master port speed to be set);
        # 3. port_id has value but master_port_id is None , this is the case for
        #    regular port (no port group) which require explicit chassis speed set.
        assert (port_id is not None and master_port_id is not None) or (
            port_id is None and master_port_id is None) or (
                port_id is not None and master_port_id is None)
        return compact_dict({
            'speed': global_speed,
            'breakout': breakout,
            'fpc': fpc,
            'pic': pic,
            'port': port_id,
            'master_port': master_port_id,
            'sub-ports-count': subports_count,
            'unused-port-list': unused_port_list,
            'speed-keyword': speed_keyword,
        })

    def make_junos_disabled_setting(self, validations=None):
        dis_setting = {
            'interface':  {
                'speed': 'disabled'
            },
            'global': {
                'speed': ''
            }
        }
        if validations:
            dis_setting['validations'] = validations
        return json.dumps(dis_setting)

    def populate_unused_port_list(self, model, port_id):
        '''
        This function is used to populate the ports that need to be set as
        "unused" when certain ports are set as breakout ports. These situations
        are seen in devices that support Junos Evolved OS. The conditons for
        unused ports can vary with devices and depends on the limitations of the
        device's drivers.s
        '''
        if model is None:
            return None

        assert port_id is not None

        if 'QFX5220-128C' in model:
            # Next three ports are set as unused
            return [port_id, port_id+1, port_id+2]    # Real port index is (port_id - 1)
        elif 'PTX10001-36MR' in model:
            # Only next port is set as unused
            return [port_id]
        if 'QFX5220-32CD' in model:
            # Only next port is set as unused
            return [port_id]

        return None

    # pylint: disable=too-many-return-statements
    def populate_unused_interfaces_list(self, model, port_id, fpc, pic,
                                        intf_prefix=None, speed=None,
                                        breakouts=None):
        '''
        This function is used to populate the interfaces that need to be set as
        "unused" when certain ports are set as breakout ports. These situations
        are seen in devices that support Junos Evolved OS. The conditons for
        unused interfaces can vary with devices and depends on the limitations of the
        device's drivers.
        '''
        if model is None:
            return None

        assert port_id is not None

        # Create fpc_tag for modular device profiles
        fpc_tag = 'fpc_tag' if self.templatize and fpc is not None else fpc

        if ('PTX10001-36MR' in model
                or 'PTX10K-LC1202-36MR' in model and port_id in [1, 3, 19, 21]):
            # Only next interface is set as unused
            return ["{}-{}/{}/{}".format(intf_prefix, fpc_tag, pic, port_id)]

        if model == 'ACX7100-32C':
            if port_id in range(1, 32 + 1) and speed not in [25]:
                # Only next interface is set as unused
                return ["{}-{}/{}/{}".format(
                    intf_prefix, fpc_tag, pic, port) for port in range(
                        2 * ((port_id - 1) // 2), 2 * (( port_id - 1) // 2) + 2
                        ) if port != port_id - 1]
            return ["{}-{}/{}/{}".format(
                intf_prefix, fpc_tag, pic, port) for port in range(
                    4 * ((port_id - 1) // 4), 4 * (( port_id - 1) // 4) + 4
                    ) if port != port_id - 1]

        if model == 'QFX5130-32CD' and port_id not in range(0, 30 + 1, 2) and \
                speed in [50]:
            # Only next interface is set as unused
            return ["{}-{}/{}/{}".format(intf_prefix, fpc_tag, pic, port_id)]

        if model in 'QFX5130-48C':
            port_mapping = {
                49: (0, range(0, 4 + 1)),
                50: (5, range(5, 9 + 1)),
                51: (12, range(12, 16 + 1)),
                52: (17, range(17, 21 + 1)),
                53: (24, range(24, 28 + 1)),
                54: (29, range(29, 33 + 1)),
                55: (36, range(36, 40 + 1)),
                56: (41, range(41, 45 + 1)),
            }
            if speed in [10, 25, 100] and port_mapping.get(port_id):
                return ["{}-{}/{}/{}".format(intf_prefix, fpc_tag, pic, port_mapping[port_id][0])]
            elif speed == 50 and port_mapping.get(port_id):
                return ["{}-{}/{}/{}".format(intf_prefix, fpc_tag, pic, _port_id)
                        for _port_id in port_mapping[port_id][1]]
            elif speed == 50 and port_id not in range(0, 49, 2):
                # Only next interface is set as unused
                return ["{}-{}/{}/{}".format(intf_prefix, fpc_tag, pic, port_id)]

        if model == 'JNP_FPC_16C_LC':
            if speed == 50:
                return ["{}-{}/{}/{}".format(intf_prefix, fpc_tag, pic, port_id)]
            return ["{}-{}/{}/{}".format(intf_prefix, fpc_tag, pic, _port_id) for
                    _port_id in range(port_id, port_id+3)]

        return None

    def make_junos_setting_param(
            self, speed_value=None, speed_unit='g', global_speed='', breakout=None, fpc=None, pic=None,
            port_id=None, master_port_id=None, disabled=False, link_mode=None, autoneg=None, subports_count=None,
            unused_port_list=None, parent_breakout_interface=None,
            unused_interfaces_list=None, speed_keyword=None, validations=None):
        '''
        speed:
          - https://www.juniper.net/documentation/en_US/junos/topics/reference/configuration-statement/speed-edit-interfaces-ethernet.html
          - When you configure the Tri-Rate Ethernet copper interface to operate
          at 1 Gbps, autonegotiation must be enabled. When you configure
          100BASE-FX SFP, you must set the port speed at 100 Mbps.
          - On 1/10G capable Gigabit Ethernet SFP interfaces, the duplex is always
          full and the speed matches that of the inserted optic. These interfaces
          support either 1G or 10G SFP optics. For EX and QFX products, the CLI
          configuration needs to match the optic speed. For 1G based optics,
          the configuration needs to start with ge-. For 10G inserted optics,
          the configuration needs to start with xe-. By default, both ge and xe
          choices are in the default configuration. User must match the CLI syntax
          to the optic speed. For SRX and MX products, the display and
          configuration is always xe- only, even if a 1G optic is inserted. The
          xe- value is used to denote that the interface is 10G capable. If a 1G
          optic is used, show commands for the interface will display the correct
          speed, but the config will always show as xe-
          - The port panel of the QFX5100-48S and QFX5100-48SH switches supports
          up to a maximum of 72 logical 10 GbE ports when operating as a
          standalone switch. Forty-eight physical ports(0 through 47) support 10
          Gigabit Ethernet small form-factor pluggable plus (SFP+) transceivers.
          These ports can also support 1 Gigabit SFP transceivers and can be
          configured at either 1 Gbps or 1 Gbps speeds using the set interface
          speed command. All 48 of these ports can be used for SFP+ transceivers
          or SFP+ direct attach copper (DAC) cables. You can use 1-Gigabit
          Ethernet SFP+, 10-Gigabit Ethernet SFP+ transceivers and SFP+ DAC cables
          in any access port.

        link-mode(For information only, by default all mode are in full-duplex):
          - https://www.juniper.net/documentation/en_US/junos/topics/reference/configuration-statement/link-mode-edit-interfaces.html
          - Member links of an aggregated Ethernet bundle must not be explicitly
          configured with a link mode. You must remove any such link-mode
          configuration before committing the aggregated Ethernet configuration.
          - Starting with Junos OS release 16.1R7 and later, the link-mode
          configuration is not supported on 10-Gigabit Ethernet Interfaces.
          - By default, the router's management Ethernet interface, fxp0 or em0,
          autonegotiates whether to operate in full-duplex or half-duplex mode.
          Fast Ethernet interfaces, can operate in either full-duplex or
          half-duplex mode, and all other interfaces can operate only in
          full-duplex mode. For Gigabit Ethernet and 10-Gigabit Ethernet, the link
          partner must also be set to full duplex.

        global_speed:
          - https://www.juniper.net/documentation/en_US/junos/topics/topic-map/switches-interface-port.html#id-channelizing-interfaces-overview
          - Used to set brokenout port channel-speed in chassis when breakout is
          set to True and auto-channelization for the platform is not enabled by
          default.
          - Used to set physical port speed of the first port in a port group of 4
          ports for SFP28 type ports (which is capable of 1G/10G(default)/25G). Some
          platforms (QFX5120-48Y, EX4650-48Y) SFP28 25G port supports 25G, 10G,
          1G. They have default 10G, and require speed manually set for 25G,
          1G to work, and the speed configuration is at quad level (e.g. port 0,
          1, 2, 3, only need to set speed at port 0)


        auto-negotiation:
          - https://www.juniper.net/documentation/en_US/junos/topics/reference/configuration-statement/auto-negotiation-edit-interfaces.html
          - https://www.juniper.net/documentation/en_US/junos/topics/reference/configuration-statement/autonegotiation-edit-interfaces-qfx-series.html
          - Autonegotiation is enabled by default on all Gigabit Ethernet and
          Tri-Rate Ethernet copper interfaces. However, you can explicitly enable
          autonegotiation to configure remote fault options manually.
          - For Gigabit Ethernet interfaces on M Series, MX Series, T Series,
          TX Matrix routers, and ACX Series routers explicitly enable
          autonegotiation and remote fault. For EX Series switches, explicitly
          enable autonegotiation only.
          - For QFX Series, autonegotiation is enabled by default, and will
          autonegotiate the speed with the link partner. We recommend that you
          keep autonegotiation enabled for interfaces operating at 1G and 10G. For
          a port to start with a specific speed, it is mandatory that both the
          auto-negotiation must be enabled and interface must be configured with a
          particular speed. Otherwise, the switch will remain with the last
          negotiated speed. If you only set the auto-negotiation option (and no
          speed option), then the switch will start with the last speed it
          connected at and will only advertise that to the server.

        subports_count:
          In devices that support Junos Evolved, when a port is chosen for a breakout transformation, then
          a corresponding config needs to be set under chassis which indicates the number of subports this interface
          will be broken into. This parameter is used to indicate the number of subports.
          Example config:
          set chassis fpc 0 pic 0 port 4 speed 25g number-of-sub-ports 4

        unused_port_list:
          In certain devices that support Junos Evolved, when a particular port is chosen for breakout transformation,
          there is a need to set certain other ports as 'unused' under their chassis configuration. This parameter is
          used to save the list of such dependent ports that need to be rendered as 'unused'.
          Example config:
          set chassis fpc 0 pic 0 port 5 unused
          set chassis fpc 0 pic 0 port 6 unused
          set chassis fpc 0 pic 0 port 7 unused
          set chassis fpc 0 pic 0 port 4 speed 25g number-of-sub-ports 4

        speed_keyword:
          Some devices need 'speed 10g', some need 'channel-speed 10g', some need
          'channelization-speed 10g' in their chassis section. The rendered
          keyword is controlled by this variable. If speed-keyword is missing,
          then the jinja will pick 'channel-speed'.

        :param speed_value: interface speed
        :param speed_unit: speed unit
        :param global_speed: physical port speed
        :param breakout: flag to identify if a port is brokenout or not,
        used together with global_speed for port speed/channel-speed rendering
        :param fpc: fcp slot id
        :param pic: pic slot id
        :param port_id: physical device port id, starts from 0; AOS lingo port id
        starts from 1, caller needs to subtract AOS port id by 1 before passing it to
        this method
        :param master_port_id: physical device master port id, starts from 0; AOS
        lingo port id starts from 1, caller needs to subtract AOS port id by 1
        before passing it to this method
        :param disabled: flag to determine if the interface should be disabled or not
        :param link_mode: link mode, when not set, use switch port default setting
        :param autoneg: flag to explicitly enable/disable auto negotiation,
        when not set, use switch port default setting
        :return:DeviceProfileConfigSchemaDeviceProfileConfigSchema
        '''
        fpc_tag = fpc
        if fpc is not None:
            if self.templatize:
                fpc_tag = 'fpc_tag'
            elif self.templatize_pic:
                # For linecard profiles, fpc is always string
                fpc_tag = str(fpc)
        pic_tag = 'pic_tag' if self.templatize_pic and pic is not None else pic

        dd = {
            'interface':  compact_dict({
                'speed': '' if not speed_value else '%s%s' % (
                    speed_value, speed_unit),
                'link_mode': link_mode,
                'auto_negotiation': autoneg,
                'parent_breakout_interface': parent_breakout_interface,
                'unused_interfaces_list': unused_interfaces_list,
            }),
            'global': self.make_junos_global_param(
                global_speed, breakout, port_id, fpc_tag, pic_tag, master_port_id,
                subports_count, unused_port_list, speed_keyword=speed_keyword),
        }
        if validations:
            dd['validations'] = validations
        jd = json.dumps(dd, sort_keys=True)

        if self.templatize:
            jd = jd.replace('fpc_tag', variable_fpc)
        if self.templatize_pic:
            jd = jd.replace('pic_tag', variable_pic)
        return jd

    def port_speed_to_prefix(self, speed, model=None):
        """Return Junos OS port name prefix given port speed"""
        if speed == 1:
            # For QFX5100-48T Switches, Gigabit Ethernet interfaces must be
            # configured as xe-fpc/pic/port, and not ge-fpc/pic/port
            # https://www.juniper.net/documentation/en_US/junos/topics/topic-map/switches-interface-gigabit.html#id-configuring-port-mode-on-qfx510048s-qfx510048t-qfx510024q-and-ex4600-switches
            return 'xe' if model and re.match('QFX5100-48T|QFX5120-48T', model) else 'ge'
        elif speed == 10:
            return 'xe'
        elif speed in [25, 40, 50, 100, 200, 400, 800]:
            return 'et'
        raise ValueError('Unsupported speed: %s' % speed)

    def make_intf_name(self, prefix, port_id, fpc=0, pic=0, lane_id=None):
        '''
        Network interfaces in Junos OS are specified as follows:
        type-fpc / pic / port

        ge-Gigabit Ethernet interface
        xe-10 Gigabit Ethernet interface
        et-40 Gigabit Ethernet interface

        https://www.juniper.net/documentation/en_US/junos/topics/topic-map/switches-interface-understanding.html

        On EX2200, EX2300, EX3200, EX3300, EX4200, EX4500 switch, and EX4550
        switches, the PIC number is 0 for all built-in interfaces (interfaces that
        are not uplink ports).

        On EX2200, EX2300, EX3200, EX3300, and EX4200 switches, the PIC number is
        1 for uplink ports.

        On EX2200, EX2300, EX3200, EX3300, EX3400, EX4200, EX4300, EX4500,
        and EX4550 switches, built-in network ports are numbered from left to
        right. On models that have two rows of ports, the ports on the top row
        start with 0 followed by the remaining even-numbered ports, and the ports
        on the bottom row start with 1 followed by the remaining odd-numbered ports.

        :param prefix:
        :param port_id:
        :param fpc: slot id of FPC. FPC's are similar to Linecards. FPC's (
        Flexible PIC Concentrator) houses  multiple PICs (Physical Interface
        Cards) which connect to the physical medium. It's similar to Linecards
        that both FPCs and Linecards are inserted into a chassis device.
        :param pic: slot id of PICs (Physical Interface Cards)
        :param lane_id: channel id for a brokenout port. When an et port is
        channelized to four xe ports, a colon is used to signify the four separate
        channels. For example, on a QFX3500 standalone switch with port 2 on PIC 1
        configured as four 10-Gigabit Ethernet ports, the interface names are
        xe-0/1/2:0, xe-0/1/2:1, xe-0/1/2:2, and xe-0/1/2:3
        :return:
        '''
        lane_suffix = ':%s' % lane_id if lane_id is not None else ''
        if self.templatize:
            fpc_id = variable_fpc
        else:
            fpc_id = str(fpc)

        pic_id = variable_pic if self.templatize_pic else str(pic)
        return '%s-%s/%s/%d%s' % (prefix, fpc_id, pic_id, port_id, lane_suffix)

    def _gen_intfs_1x1G(self, port_id, model, fpc=0, pic=0, intf_prefix=None):
        intf_prefix = intf_prefix or self.port_speed_to_prefix(1)
        return [
            d.gen_interface(
                self.make_intf_name(
                    intf_prefix, port_id - 1, fpc, pic),
                "active",
                port_speed(1),
                self.make_junos_setting_param(),
                intf_id=1)
        ]

    def _gen_intfs_1x1G_explicit_port_speed(
            self, port_id, model, fpc=0, pic=0, master_port_id=None,
            intf_prefix=None, set_speed_in_interfaces=False, setting_param=None):
        # the global speed is used to explicitly apply the speed on the physical
        # ports. The rule is that out of a port group of 4 sfp28 ports, the first
        # one is set with the port ID and global_speed value. The rest of the
        # following 3 ports have None values for global_speed

        # If you've plugged a JNP-SFP-25G-DAC cable into a QFX5120-48Y switch,
        # then the SFP28 ports come up with 10-Gbps speed by default. To configure
        #  the SFP28 ports to operate at 25-Gbps speed, you must explicitly
        # configure the speed of the first port in the port group using the set
        # chassis fpc 0 pic 0 port port-num speed 25g command.
        intf_prefix = intf_prefix or self.port_speed_to_prefix(1)
        if setting_param:
            junos_setting_param = setting_param
        else:
            junos_setting_param = self.make_junos_setting_param(
                fpc=fpc, pic=pic, port_id=port_id - 1,
                speed_value='1' if set_speed_in_interfaces else None,
                global_speed='1G' if not set_speed_in_interfaces else '',
                breakout=False,
                master_port_id=(
                    master_port_id - 1 if master_port_id is not None else None))
        return [
            d.gen_interface(
                self.make_intf_name(
                    intf_prefix, port_id - 1, fpc, pic),
                "active",
                port_speed(1),
                junos_setting_param,
                intf_id=1)
        ]

    def _gen_intfs_1x10G(self, port_id, model, fpc=0, pic=0, intf_prefix=None,
                         setting_param=None):
        intf_prefix = intf_prefix or self.port_speed_to_prefix(10)
        if setting_param is None:
            setting_param = self.make_junos_setting_param()
        return [
            d.gen_interface(
                self.make_intf_name(
                    intf_prefix, port_id - 1, fpc, pic),
                "active",
                port_speed(10),
                setting_param,
                intf_id=1)
        ]

    def _gen_intfs_1x10G_explicit_port_speed(self, port_id, model, fpc=0, pic=0,
                                             intf_prefix=None):
        intf_prefix = intf_prefix or self.port_speed_to_prefix(10)
        return [
            d.gen_interface(
                self.make_intf_name(
                    intf_prefix, port_id - 1, fpc, pic),
                "active",
                port_speed(10),
                self.make_junos_setting_param(speed_value=10, speed_unit='g'),
                intf_id=1)
        ]

    def _gen_intfs_1x10G_explicit(self, port_id, model, fpc=0, pic=0, master_port_id=None,
                                  intf_prefix=None, set_speed_in_interfaces=False,
                                  unused_interfaces_list=None, setting_param=None):
        intf_prefix = intf_prefix or self.port_speed_to_prefix(10)
        if setting_param:
            junos_setting_param = setting_param
        else:
            junos_setting_param = self.make_junos_setting_param(
                fpc=fpc, pic=pic, port_id=port_id - 1,
                speed_value='10' if set_speed_in_interfaces else None,
                global_speed='10g' if not set_speed_in_interfaces else '',
                breakout=False,
                unused_interfaces_list=unused_interfaces_list,
                master_port_id=(
                    master_port_id - 1 if master_port_id is not None else None)
            )

        return [
            d.gen_interface(
                self.make_intf_name(
                    intf_prefix, port_id - 1, fpc, pic),
                "active",
                port_speed(10),
                junos_setting_param,
                intf_id=1)
        ]

    # On extension modules, only port 0 can be configured with the global speed.
    # Other ports cannot be explicitly configured. junos_setting_param is set with
    # port_id of 0.
    def _gen_intfs_1x10G_ext_module(self, port_id, model, fpc=0, pic=0,
                                    intf_prefix=None):
        intf_prefix = intf_prefix or self.port_speed_to_prefix(10)
        junos_setting_param = self.make_junos_setting_param()
        assert port_id < 5
        junos_setting_param = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=0, global_speed='10g')

        return [
            d.gen_interface(
                self.make_intf_name(
                    intf_prefix, port_id - 1, fpc, pic),
                "active",
                port_speed(10),
                junos_setting_param,
                intf_id=1)
        ]

    def _gen_intfs_1x2dot5G(self, port_id, model, fpc=0, pic=0, intf_prefix=None):
        intf_prefix = intf_prefix or self.port_speed_to_prefix(10)
        return [
            d.gen_interface(
                self.make_intf_name(
                    intf_prefix, port_id - 1, fpc, pic),
                "active",
                port_speed(2.5),
                self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1, global_speed='2.5g',
                    breakout=False),
                intf_id=1)
        ]

    def _gen_intfs_1x25G(self, port_id, model, fpc=0, pic=0, setting_param=None):
        if setting_param is None:
            setting_param = self.make_junos_setting_param()
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(25), port_id - 1, fpc, pic),
                "active",
                port_speed(25),
                setting_param,
                intf_id=1)
        ]

    # On extension modules, only port 0 can be configured with the global speed.
    # Other ports cannot be explicitly configured. junos_setting_param is set with
    # port_id of 0.
    def _gen_intfs_1x25G_ext_module(self, port_id, model, fpc=0, pic=0):
        junos_setting_param = self.make_junos_setting_param()
        assert port_id < 5
        junos_setting_param = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=0, global_speed='25g')

        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(25), port_id - 1, fpc, pic),
                "active",
                port_speed(25),
                junos_setting_param,
                intf_id=1)
        ]

    def _gen_intfs_1x25G_explicit_port_speed(
            self, port_id, model, fpc=0, pic=0, master_port_id=None,
            set_speed_in_interfaces=False, setting_param=None):
        # the global speed is used to explicitly apply the speed on the physical
        # ports. The rule is that out of a port group of 4 sfp28 ports, the first
        # one is set with the port ID and global_speed value. The rest of the
        # following 3 ports have None values for global_speed

        # If you've plugged a JNP-SFP-25G-DAC cable into a QFX5120-48Y switch,
        # then the SFP28 ports come up with 10-Gbps speed by default. To configure
        #  the SFP28 ports to operate at 25-Gbps speed, you must explicitly
        # configure the speed of the first port in the port group using the set
        # chassis fpc 0 pic 0 port port-num speed 25g command.
        pg_name = self.make_intf_name('', master_port_id, fpc, pic)[1:] \
            if master_port_id is not None else None
        if setting_param:
            junos_setting_param = setting_param
        else:
            junos_setting_param = self.make_junos_setting_param(
                fpc=fpc, pic=pic, port_id=port_id - 1,
                speed_value='25' if set_speed_in_interfaces else None,
                global_speed='25g' if not set_speed_in_interfaces else '',
                breakout=False,
                master_port_id=(
                    master_port_id - 1 if master_port_id is not None else None),
                validations=self.pg_validations_master_port(pg_name, '25g')
            )
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(25), port_id - 1, fpc, pic),
                "active",
                port_speed(25),
                junos_setting_param,
                intf_id=1)
        ]

    def _gen_intfs_1x50G(
            self, port_id, model, fpc=0, pic=0, setting_param=None):
        if setting_param is None:
            setting_param = self.make_junos_setting_param()
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(50), port_id - 1, fpc, pic),
                "active",
                port_speed(50),
                setting_param,
                intf_id=1)
        ]

    def _gen_intfs_1x50G_explicit_port_speed(
            self, port_id, model, fpc=0, pic=0, master_port_id=None, set_speed_in_interfaces=False):
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(50), port_id - 1, fpc, pic),
                "active",
                port_speed(50),
                self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1,
                    speed_value='50' if set_speed_in_interfaces else None,
                    global_speed='50g' if not set_speed_in_interfaces else '', breakout=False,
                    master_port_id=(
                        master_port_id - 1 if master_port_id is not None else None)),
                intf_id=1)
        ]

    def _gen_intfs_1x100G(self, port_id, model, fpc=0, pic=0, master_port_id=None,
                          default=True, set_speed_in_interfaces=False):
        if default:
            junos_setting_param = self.make_junos_setting_param()
        else:
            junos_setting_param = self.make_junos_setting_param(
                fpc=fpc, pic=pic, port_id=port_id - 1,
                global_speed='100g' if not set_speed_in_interfaces else '',
                speed_value='100' if set_speed_in_interfaces else None,
                breakout=False,
                master_port_id=(
                    master_port_id - 1 if master_port_id is not None else None))

        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(100), port_id - 1, fpc, pic),
                "active",
                port_speed(100),
                junos_setting_param,
                intf_id=1)
        ]

    def _gen_intfs_1x100G_explicit_port_speed(
            self, port_id, model, fpc=0, pic=0, master_port_id=None,
            set_speed_in_interfaces=False, setting_param=None):
        if setting_param:
            junos_setting_param = setting_param
        else:
            junos_setting_param = self.make_junos_setting_param(
                fpc=fpc, pic=pic, port_id=port_id - 1, breakout=False,
                speed_value='100' if set_speed_in_interfaces else None,
                global_speed='100g' if not set_speed_in_interfaces else '',
                master_port_id=(
                    master_port_id - 1 if master_port_id is not None else None))
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(100), port_id - 1, fpc, pic),
                "active",
                port_speed(100),
                junos_setting_param,
                intf_id=1)
        ]

    def _gen_intfs_1x400G(self, port_id, model, fpc=0, pic=0):
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(400), port_id - 1, fpc, pic),
                "active",
                port_speed(400),
                self.make_junos_setting_param(),
                intf_id=1)
        ]

    def _gen_intfs_1x400G_explicit_port_speed(
            self, port_id, model, fpc=0, pic=0, master_port_id=None,
            set_speed_in_interfaces=False, speed_keyword=None, setting_param=None):

        if setting_param is None:
            setting_param = self.make_junos_setting_param(
                fpc=fpc, pic=pic, port_id=port_id - 1,
                global_speed='400g' if not set_speed_in_interfaces else '',
                speed_value='400' if set_speed_in_interfaces else None,
                breakout=False,
                speed_keyword=speed_keyword,
                master_port_id=(
                    master_port_id - 1 if master_port_id is not None else None))
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(400), port_id - 1, fpc, pic),
                "active",
                port_speed(400),
                setting_param,
                intf_id=1)
        ]

    def _gen_intfs_1x800G(self, port_id, model, fpc=0, pic=0, setting_param=None):
        if setting_param is None:
            setting_param = self.make_junos_setting_param()
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(800), port_id - 1, fpc, pic),
                "active",
                port_speed(800),
                setting_param,
                intf_id=1)
        ]
    def _gen_intfs_1x800G_explicit_port_speed(
            self, port_id, model, fpc=0, pic=0, master_port_id=None):
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(800), port_id - 1, fpc, pic),
                "active",
                port_speed(800),
                self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1, global_speed='800g',
                    breakout=False,
                    master_port_id=(
                        master_port_id - 1 if master_port_id is not None else None)),
                intf_id=1)
        ]

    def _gen_intfs_1x200G(self, port_id, model, fpc=0, pic=0):
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(200), port_id - 1, fpc, pic),
                "active",
                port_speed(200),
                self.make_junos_setting_param(),
                intf_id=1)
        ]

    def _gen_intfs_1x200G_explicit_port_speed(
            self, port_id, model, fpc=0, pic=0, master_port_id=None, set_speed_in_interfaces=False):
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(200), port_id - 1, fpc, pic),
                "active",
                port_speed(200),
                self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1,
                    global_speed='200g' if not set_speed_in_interfaces else '',
                    speed_value='200' if set_speed_in_interfaces else None,
                    breakout=False,
                    master_port_id=(
                        master_port_id - 1 if master_port_id is not None else None)),
                intf_id=1)
        ]

    def _gen_intfs_1x40G_explicit_port_speed(
            self, port_id, model, fpc=0, pic=0, master_port_id=None,
            set_speed_in_interfaces=False, unused_interfaces_list=None):
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(40), port_id - 1, fpc, pic),
                "active",
                port_speed(40),
                self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1, breakout=False,
                    speed_value='40' if set_speed_in_interfaces else None,
                    global_speed='40g' if not set_speed_in_interfaces else '',
                    unused_interfaces_list=unused_interfaces_list,
                    master_port_id=(
                        master_port_id - 1 if master_port_id is not None else None)),
                intf_id=1)
        ]

    def _gen_intfs_1x40G(self, port_id, model, fpc=0, pic=0, master_port_id=None,
                         default=False, set_speed_in_interfaces=False, setting_param=None):
        if setting_param:
            junos_setting_param = setting_param
        elif default:
            junos_setting_param = self.make_junos_setting_param()
        else:
            junos_setting_param = self.make_junos_setting_param(
                fpc=fpc, pic=pic, port_id=port_id - 1,
                speed_value='40' if set_speed_in_interfaces else None,
                global_speed='40g' if not set_speed_in_interfaces else '',
                breakout=False,
                master_port_id=(
                    master_port_id - 1 if master_port_id is not None else None))
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(40), port_id - 1, fpc, pic),
                "active",
                port_speed(40),
                junos_setting_param,
                intf_id=1)
        ]

    def _gen_intfs_1x40G_disabled(self, port_id, model, fpc=0, pic=0,
                                  setting_param=None):
        if setting_param is None:
            setting_param = self.make_junos_disabled_setting()
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(40), port_id - 1, fpc, pic),
                "inactive",
                port_speed(40),
                setting=setting_param,
                intf_id=1)
        ]

    def _gen_intfs_1x100G_disabled(self, port_id, model, fpc=0, pic=0):
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(100), port_id - 1, fpc, pic),
                "inactive",
                port_speed(100),
                setting=self.make_junos_disabled_setting(),
                intf_id=1)
        ]

    def _gen_intfs_1x10G_to_1x1G_default(
            self, port_id, model, fpc=0, pic=0):
        # This is used for 1/10G capable which have 10G as default,
        # and need interface speed explicitly set when they are used as 1G.
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(1, model=model),
                    port_id - 1, fpc, pic),
                "active",
                port_speed(1),
                self.make_junos_setting_param(),
                intf_id=1)
        ]

    def _gen_intfs_1x10G_to_1x1G_explicit_intf_speed(
            self, port_id, model, fpc=0, pic=0, intf_prefix=None):
        # This is used for 1/10G capable SFP interfaces which have 10G as default,
        # and need interface speed explicitly set when they are used as 1G.
        intf_prefix = intf_prefix or self.port_speed_to_prefix(1, model=model)
        return [
            d.gen_interface(
                self.make_intf_name(
                    intf_prefix, port_id - 1, fpc, pic),
                "active",
                port_speed(1),
                self.make_junos_setting_param(1),
                intf_id=1)
        ]

    def _gen_intfs_1x10G_to_1x1G_with_autoneg(self, port_id, model, fpc=0, pic=0,
                                              autoneg=False):
        # On 1/10G capable Gigabit Ethernet SFP interfaces, the duplex is always
        # full and the speed matches that of the inserted optic. These interfaces
        # support either 1G or 10G SFP optics. For EX and QFX products, the CLI
        # configuration needs to match the optic speed.

        # Default: Fast Ethernet interfaces can operate in either full-duplex or
        # half-duplex mode. The router's or switch's management Ethernet
        # interface, fxp0 or em0, and the built-in Fast Ethernet interfaces on the
        #  FIC (M7i router) autonegotiate whether to operate in full-duplex or
        # half-duplex mode. Unless otherwise noted here, all other interfaces
        # operate only in full-duplex mode. Hence full-duplex specified in this
        # method.

        # NOTE: On EX Series switches, if no-auto-negotiation is specified in [edit
        # interfaces interface-name ether-options], you can select only
        # full-duplex or half-duplex. If auto-negotiation is specified, you can
        # select any mode.
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(1), port_id - 1, fpc, pic),
                "active",
                port_speed(1),
                self.make_junos_setting_param(
                    1, autoneg=autoneg, link_mode='full-duplex'),
                intf_id=1)
        ]

    def _gen_intfs_1x10G_to_4x1G_explicit_breakout(
            self, port_id, model, fpc=0, pic=0, speed_keyword=None,
            subports_count=None):
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(1), port_id - 1,
                    fpc, pic, lane_id - 1),
                "active", port_speed(1),
                self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1,
                    global_speed='1g',
                    breakout=True,
                    subports_count=subports_count,
                    speed_keyword=speed_keyword),
                intf_id=lane_id
            )
            for lane_id in range(1, 4 + 1)
        ]

    def _gen_intfs_1x40G_to_4x10G_explicit_breakout(
            self, port_id, model, fpc=0, pic=0, master_port_id=None,
            speed_keyword=None, setting_param=None, subports_count=None):
        # the global speed is used to explicitly apply the channel speed on the
        # physical port when breakout flag is set to True and auto-channelization
        # is not supported on the platform. The rule is that in the device profile
        #  port settings, out of the 4 broken out channel interfaces, the first
        # one is set with the port ID and global_speed value. The rest of the
        # following 3 interfaces have None values for global_speed and port_id.
        # And the global_speed setting on the first interface will be used in aos
        # device configuration render jinja template to explicitly render
        # channel-speed.

        # This method is used for the qsfp port of platforms that do not support
        # auto-channelization by default and require explicit channelization
        # configuration
        if setting_param:
            junos_setting_param = setting_param
        else:
            junos_setting_param = self.make_junos_setting_param(
                fpc=fpc, pic=pic, port_id=port_id - 1, global_speed="10g",
                breakout=True,
                master_port_id=(
                    master_port_id - 1 if master_port_id is not None else None),
                speed_keyword=speed_keyword,
                subports_count=subports_count)
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(10), port_id - 1, fpc, pic, lane_id - 1),
                "active", port_speed(10),
                junos_setting_param,
                intf_id=lane_id
            )
            for lane_id in range(1, 4 + 1)
        ]

    def _gen_intfs_1x40G_to_4x10G_explicit_breakout_intf_name(
            self, port_id, model, fpc=0, pic=0, master_port_id=None,
            intf_prefix=None, unused_port_list=None,
            unused_interfaces_list=None, subports_count=None,
            breakout_parent=False, speed_keyword=None):
        parent_breakout_interface = (self.make_intf_name(intf_prefix, port_id - 1, fpc, pic), subports_count, "10g")\
            if breakout_parent else None
        return [
            d.gen_interface(
                self.make_intf_name(
                    intf_prefix, port_id - 1, fpc, pic, lane_id - 1),
                "active", port_speed(10),
                self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1,
                    global_speed="10g" if not breakout_parent else '',
                    breakout=True,
                    subports_count=subports_count if not breakout_parent else None,
                    unused_port_list=unused_port_list,
                    unused_interfaces_list=unused_interfaces_list,
                    parent_breakout_interface=parent_breakout_interface,
                    speed_keyword=speed_keyword,
                    master_port_id=(
                        master_port_id - 1 if master_port_id is not None else None)),
                intf_id=lane_id
            )
            for lane_id in range(1, 4 + 1)
        ]

    def _gen_intfs_1x40G_to_4x10G_breakout(
            self, port_id, model, fpc=0, pic=0, intf_prefix=None, junos_setting_param=None):
        # On QFX10002, QFX10008, and QFX10016 switches, there are 100-Gigabit
        # Ethernet ports that work either as 100-Gigabit Ethernet or as 40-Gigabit
        #  Ethernet, but are recognized as 40-Gigabit Ethernet by default.
        #
        # The 40-Gigabit Ethernet ports can operate independently or be
        # channelized into four 10-Gigabit Ethernet ports as part of a port range.
        #  Ports cannot be channelized individually.
        #
        # Only the first and fourth port in each 6XQSFP cage is available to
        # channelize as part of a port range. In a port range, the ports are
        # bundled with the next two consecutive ports. For example, if you want to
        #  channelize ports 0 through 2, you would channelize port 0 only. If you
        # try to channelize a port that is not supported, you will receive an
        # error message when you commit the configuration. Auto-channelization is
        # not supported on any ports.

        # This method is used to represent the individual ports within the port
        # range that are now allowed to configuration channelization.

        # This method is used to represent the qsfp port that has channelization
        # enabled by default and does not need explicit channelization configuration

        if junos_setting_param is None:
            junos_setting_param = self.make_junos_setting_param()
        intf_prefix = intf_prefix or self.port_speed_to_prefix(10)
        return [
            d.gen_interface(
                self.make_intf_name(
                    intf_prefix,
                    port_id - 1, fpc, pic, lane_id - 1),
                "active", port_speed(10),
                junos_setting_param, intf_id=lane_id
            )
            for lane_id in range(1, 4 + 1)
        ]

    def _gen_intfs_1x100G_to_4x25G_breakout(self, port_id, model, fpc=0, pic=0, junos_setting_param=None):
        # This method is used to represent the qsfp port that has channelization
        # enabled by default and does not need explicit channelization configuration
        if junos_setting_param is None:
            junos_setting_param = self.make_junos_setting_param()
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(25), port_id - 1,
                    fpc, pic, lane_id - 1),
                "active", port_speed(25),
                junos_setting_param,
                intf_id=lane_id
            )
            for lane_id in range(1, 4 + 1)
        ]

    def _gen_intfs_1x100G_to_4x25G_breakout_explicit(self, port_id, model, fpc=0,
                                                     pic=0, unused_port_list=None,
                                                     unused_interfaces_list=None,
                                                     subports_count=None, breakout_parent=False,
                                                     speed_keyword=None):
        # This method is used to represent the qsfp port that has channelization
        # enabled by default and needs explicit channelization configuration
        parent_breakout_interface = (self.make_intf_name(self.port_speed_to_prefix(25), port_id - 1, fpc, pic), subports_count, "25g")\
            if breakout_parent else None
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(25), port_id - 1,
                    fpc, pic, lane_id - 1),
                "active", port_speed(25),
                self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1,
                    global_speed='25g' if not breakout_parent else '',
                    breakout=True,
                    subports_count=subports_count if not breakout_parent else None,
                    unused_port_list=unused_port_list,
                    unused_interfaces_list=unused_interfaces_list,
                    parent_breakout_interface=parent_breakout_interface,
                    speed_keyword=speed_keyword
                ),
                intf_id=lane_id
            )
            for lane_id in range(1, 4 + 1)
        ]

    def _gen_intfs_1x100G_to_4x10G_breakout_explicit(self, port_id, model, fpc=0, pic=0, unused_port_list=None, subports_count=None):
        # This method is used to represent the qsfp port that has channelization
        # enabled by default and needs explicit channelization configuration
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(10), port_id - 1,
                    fpc, pic, lane_id - 1),
                "active", port_speed(10),
                self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1, global_speed='10g',
                    breakout=True, subports_count=subports_count, unused_port_list=unused_port_list),
                intf_id=lane_id
            )
            for lane_id in range(1, 4 + 1)
        ]

    def _gen_intfs_1x100G_to_2x50G_breakout(self, port_id, model, fpc=0, pic=0,
                                            junos_setting_param=None):
        # This method is used to represent the qsfp port that has channelization
        # enabled by default and does not need explicit channelization configuration
        if junos_setting_param is None:
            junos_setting_param = self.make_junos_setting_param()
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(50), port_id - 1,
                    fpc, pic, lane_id - 1),
                "active", port_speed(50),
                junos_setting_param,
                intf_id=lane_id
            )
            for lane_id in range(1, 3)
        ]

    def _gen_intfs_1x100G_to_2x50G_breakout_explicit(self, port_id, model, fpc=0,
                                                     pic=0,
                                                     unused_interfaces_list=None,
                                                     subports_count=None,
                                                     breakout_parent=False):
        parent_breakout_interface = (self.make_intf_name(self.port_speed_to_prefix(50), port_id - 1, fpc, pic), subports_count, "50g") \
            if breakout_parent else None
        junos_setting_param = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1,
            global_speed='50g' if not breakout_parent else '',
            parent_breakout_interface=parent_breakout_interface,
            breakout=True,
            unused_interfaces_list=unused_interfaces_list,
            subports_count=subports_count if not breakout_parent else None,
        )
        return self._gen_intfs_1x100G_to_2x50G_breakout(
            port_id, model, fpc, pic, junos_setting_param)

    def _gen_intfs_1x800G_to_2x400G_breakout_explicit(self, port_id, model, fpc=0,
                                                      pic=0, subports_count=None,
                                                      breakout_parent=False,
                                                      setting_param=None):
        parent_breakout_interface = (self.make_intf_name(self.port_speed_to_prefix(400), port_id - 1, fpc, pic), subports_count, "400g") \
            if breakout_parent else None
        junos_setting_param = self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1,
                    global_speed='400g' if not breakout_parent else '',
                    breakout=True,
                    subports_count=subports_count if not breakout_parent else None,
                    parent_breakout_interface=parent_breakout_interface,
                ) if setting_param is None else setting_param
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(400), port_id - 1,
                    fpc, pic, lane_id - 1),
                "active", port_speed(400),
                junos_setting_param,
                intf_id=lane_id
            )
            for lane_id in range(1, 3)
        ]

    def _gen_intfs_1x800G_to_4x200G_breakout_explicit(self, port_id, model, fpc=0,  pic=0, setting_param=None, subports_count=None, breakout_parent=False):
        parent_breakout_interface = (
            self.make_intf_name(
                self.port_speed_to_prefix(200), port_id - 1, fpc, pic),
            subports_count, "200g") if breakout_parent else None
        junos_setting_param = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1,
            global_speed='200g' if not breakout_parent else '', breakout=True,
            subports_count=subports_count if not breakout_parent else None,
            parent_breakout_interface=parent_breakout_interface
            ) if setting_param is None else setting_param
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(200), port_id - 1,
                    fpc, pic, lane_id - 1),
                "active", port_speed(200),
                junos_setting_param,
                intf_id=lane_id
            )
            for lane_id in range(1, 4 + 1)
        ]


    def _gen_intfs_1x400G_to_2x200G_breakout_explicit(self, port_id, model, fpc=0,
                                                      pic=0,
                                                      setting_param=None,
                                                      subports_count=None,
                                                      breakout_parent=False):
        parent_breakout_interface = (self.make_intf_name(self.port_speed_to_prefix(200), port_id - 1, fpc, pic), subports_count, "200g") \
            if breakout_parent else None
        junos_setting_param = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1,
            global_speed='200g' if not breakout_parent else '',
            breakout=True,
            subports_count=subports_count if not breakout_parent else None,
            parent_breakout_interface=parent_breakout_interface,
            ) if setting_param is None else setting_param

        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(200), port_id - 1,
                    fpc, pic, lane_id - 1),
                "active", port_speed(200),
                junos_setting_param,
                intf_id=lane_id
            )
            for lane_id in range(1, 3)
        ]

    def _gen_intfs_1x800G_to_8x100G_breakout_explicit(self, port_id, fpc=0, pic=0, junos_setting_param=None):
        if junos_setting_param is None:
            junos_setting_param = self.make_junos_setting_param()

        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(100), port_id - 1,
                    fpc, pic, lane_id - 1),
                "active", port_speed(100),
                junos_setting_param,
                intf_id=lane_id
            )
            for lane_id in range(1, 8 + 1)
        ]

    def _gen_intfs_1x400G_to_4x100G_breakout_explicit(
            self, port_id, model, fpc=0, pic=0, subports_count=None,
            breakout_parent=False, speed_keyword=None, setting_param=None):
        parent_breakout_interface = (self.make_intf_name(self.port_speed_to_prefix(100), port_id - 1, fpc, pic), subports_count, "100g")\
            if breakout_parent else None
        if setting_param is None:
            setting_param = self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1,
                    global_speed='100g' if not breakout_parent else '',
                    breakout=True,
                    subports_count=subports_count if not breakout_parent else None,
                    parent_breakout_interface=parent_breakout_interface,
                    speed_keyword=speed_keyword
            )
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(100), port_id - 1,
                    fpc, pic, lane_id - 1),
                "active", port_speed(100),
                setting_param,
                intf_id=lane_id
            )
            for lane_id in range(1, 4 + 1)
        ]

    def _gen_intfs_1x400G_to_3x100G_breakout_explicit(
            self, port_id, model, fpc=0, pic=0, subports_count=None,
            breakout_parent=False, speed_keyword=None):
        parent_breakout_interface = (self.make_intf_name(self.port_speed_to_prefix(100), port_id - 1, fpc, pic), subports_count, "100g")\
            if breakout_parent else None
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(100), port_id - 1,
                    fpc, pic, lane_id - 1),
                "active", port_speed(100),
                self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1,
                    global_speed='100g' if not breakout_parent else '',
                    breakout=True,
                    subports_count=subports_count if not breakout_parent else None,
                    parent_breakout_interface=parent_breakout_interface,
                    speed_keyword=speed_keyword,
                ),
                intf_id=lane_id
            )
            for lane_id in range(1, 3 + 1)
        ]

    def _gen_intfs_1x100G_to_4x100G_breakout(self, port_id, model, fpc=0, pic=0,
                                             junos_setting_param=None):
        if junos_setting_param is None:
            junos_setting_param = self.make_junos_setting_param()
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(100), port_id - 1,
                    fpc, pic, lane_id - 1),
                "active", port_speed(100),
                junos_setting_param,
                intf_id=lane_id
            )
            for lane_id in range(1, 4 + 1)
        ]

    def _gen_intfs_1x400G_to_8x50G_breakout(self, port_id, model, fpc=0, pic=0,
                                            junos_setting_param=None):
        if junos_setting_param is None:
            junos_setting_param = self.make_junos_setting_param()
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(50), port_id - 1,
                    fpc, pic, lane_id - 1),
                "active", port_speed(50),
                junos_setting_param,
                intf_id=lane_id
            )
            for lane_id in range(1, 8 + 1)
        ]

    def _gen_intfs_1x400G_to_8x50G_breakout_explicit(self, port_id, model, fpc=0,
                                                     pic=0, setting_param=None,
                                                     subports_count=None,
                                                     breakout_parent=False,
                                                     speed_keyword=None):
        parent_breakout_interface = (self.make_intf_name(self.port_speed_to_prefix(50), port_id - 1, fpc, pic), subports_count, "50g") \
            if breakout_parent else None
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(50), port_id - 1,
                    fpc, pic, lane_id - 1),
                "active", port_speed(50),
                self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1,
                    global_speed='50g' if not breakout_parent else '',
                    breakout=True,
                    subports_count=subports_count if not breakout_parent else None,
                    parent_breakout_interface=parent_breakout_interface,
                    speed_keyword=speed_keyword,
                ) if setting_param is None else setting_param,
                intf_id=lane_id
            )
            for lane_id in range(1, 8 + 1)
        ]

    def _gen_intfs_1x200G_to_2x100G_breakout_explicit(self, port_id, model, fpc=0,
                                                      pic=0, subports_count=None,
                                                      breakout_parent=False,
                                                      speed_keyword=None):
        parent_breakout_interface = (self.make_intf_name(self.port_speed_to_prefix(100), port_id - 1, fpc, pic), subports_count, "100g") \
            if breakout_parent else None
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(100), port_id - 1,
                    fpc, pic, lane_id - 1),
                "active", port_speed(100),
                self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1,
                    global_speed='100g' if not breakout_parent else '',
                    breakout=True,
                    parent_breakout_interface=parent_breakout_interface,
                    subports_count=subports_count if not breakout_parent else None,
                    speed_keyword=speed_keyword,
                ),
                intf_id=lane_id
            )
            for lane_id in range(1, 2 + 1)
        ]

    def _gen_intfs_1x200G_to_4x50G_breakout_explicit(self, port_id, model, fpc=0,
                                                     pic=0, subports_count=None,
                                                     breakout_parent=False):
        parent_breakout_interface = (self.make_intf_name(self.port_speed_to_prefix(100), port_id - 1, fpc, pic), subports_count, "50g") \
            if breakout_parent else None
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(50), port_id - 1,
                    fpc, pic, lane_id - 1),
                "active", port_speed(50),
                self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1,
                    global_speed='50g' if not breakout_parent else '',
                    breakout=True,
                    parent_breakout_interface=parent_breakout_interface,
                    subports_count=subports_count if not breakout_parent else None,
                ),
                intf_id=lane_id
            )
            for lane_id in range(1, 4 + 1)
        ]

    def _gen_intfs_nxmG_breakout_explicit(self, port_id, model, fpc=0,
                                          pic=0, subports_count=None, unused_port_list=None,
                                          speed=None, breakout_parent=False):
        parent_breakout_interface = (self.make_intf_name(self.port_speed_to_prefix(speed), port_id - 1, fpc, pic), subports_count, "{}g".format(speed)) \
            if breakout_parent else None
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(speed), port_id - 1,
                    fpc, pic, lane_id - 1),
                "active", port_speed(speed),
                self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1,
                    global_speed='{}g'.format(speed) if not breakout_parent else '',
                    breakout=True,
                    parent_breakout_interface=parent_breakout_interface,
                    subports_count=subports_count if not breakout_parent else None,
                    unused_port_list=unused_port_list,
                ),
                intf_id=lane_id
            )
            for lane_id in range(1, subports_count + 1)
        ]

    def _gen_intfs_1x200G_to_8x25G_breakout_explicit(self, port_id, model, fpc=0,
                                                     pic=0, subports_count=None,
                                                     breakout_parent=False):
        parent_breakout_interface = (self.make_intf_name(self.port_speed_to_prefix(25), port_id - 1, fpc, pic), subports_count, "25g") \
            if breakout_parent else None
        return [
            d.gen_interface(
                self.make_intf_name(
                    self.port_speed_to_prefix(25), port_id - 1,
                    fpc, pic, lane_id - 1),
                "active", port_speed(25),
                self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1,
                    global_speed='25g' if not breakout_parent else '',
                    parent_breakout_interface=parent_breakout_interface,
                    breakout=True,
                    subports_count=subports_count if not breakout_parent else None,
                ),
                intf_id=lane_id
            )
            for lane_id in range(1, 8 + 1)
        ]

    def _gen_intfs_1x10M(self, port_id, model, fpc=0, pic=0, intf_prefix='ge'):
        return [
            d.gen_interface(
                self.make_intf_name(
                    intf_prefix, port_id - 1, fpc, pic),
                "active",
                port_speed(10, 'M'),
                self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1, global_speed='10m',
                    breakout=False),
                intf_id=1)
        ]

    def _gen_intfs_1x10M_explicit_port_speed(self, port_id, model, fpc=0, pic=0, intf_prefix='ge'):
        return [
            d.gen_interface(
                self.make_intf_name(
                    intf_prefix, port_id - 1, fpc, pic),
                "active",
                port_speed(10, 'M'),
                self.make_junos_setting_param(speed_value=10, speed_unit='m'),
                intf_id=1)
        ]

    # 100M interfaces are present in EX4300-48MP device with
    # ge/mge interface.
    def _gen_intfs_1x100M(self, port_id, model, fpc=0, pic=0, intf_prefix='ge',
                          set_speed_in_interfaces=False):
        return [
            d.gen_interface(
                self.make_intf_name(
                    intf_prefix, port_id - 1, fpc, pic),
                "active",
                port_speed(100, 'M'),
                self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1,
                    speed_unit='m',
                    speed_value='100' if set_speed_in_interfaces else None,
                    global_speed='100m' if not set_speed_in_interfaces else '',
                    breakout=False),
                intf_id=1)
        ]

    def _gen_intfs_1x100M_explicit_port_speed(self, port_id, model, fpc=0, pic=0, intf_prefix='ge'):
        return [
            d.gen_interface(
                self.make_intf_name(
                    intf_prefix, port_id - 1, fpc, pic),
                "active",
                port_speed(100, 'M'),
                self.make_junos_setting_param(speed_value=100, speed_unit='m'),
                intf_id=1)
        ]

    def _gen_intfs_1x5G(self, port_id, model, fpc=0, pic=0, intf_prefix='mge',
                        set_speed_in_interfaces=False):
        return [
            d.gen_interface(
                self.make_intf_name(
                    intf_prefix, port_id - 1, fpc, pic),
                "active",
                port_speed(5),
                self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1,
                    speed_value='5' if set_speed_in_interfaces else None,
                    global_speed='5G' if not set_speed_in_interfaces else '',
                    breakout=False),
                intf_id=1)
        ]

    def _gen_intfs_1x5G_explicit_port_speed(self, port_id, model, fpc=0, pic=0, intf_prefix='mge'):
        return [
            d.gen_interface(
                self.make_intf_name(
                    intf_prefix, port_id - 1, fpc, pic),
                "active",
                port_speed(5),
                self.make_junos_setting_param(speed_value=5, speed_unit='g'),
                intf_id=1)
        ]

    def gen_10G_to_1x1G_port(self, port_id, row_id, col_id, panel_id,
                             slot_id, failure_domain_id, port_offset,
                             model, fpc=0, pic=0, intf_prefix=None,
                             display_id=None):
        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "sfp+",
            [
                d.gen_transform(
                    self._gen_intfs_1x10G(port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x10G_to_1x1G_explicit_intf_speed(
                        port_id, model, fpc, pic, intf_prefix),
                    transformation_id=2)],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_10G_to_1x1G_port_with_select_autoneg(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, intf_prefix=None, autoneg_port_ids=None,
            display_id=None):

        if not autoneg_port_ids:
            autoneg_port_ids = []

        if display_id is None:
            display_id = port_id + port_offset - 1

        if port_id in autoneg_port_ids:
            return d.gen_port(
                port_id, row_id, col_id, panel_id, "sfp+",
                [
                    d.gen_transform(
                        self._gen_intfs_1x10G(port_id, model, fpc, pic),
                        transformation_id=1, is_default=True),
                    d.gen_transform(
                        self._gen_intfs_1x10G_to_1x1G_explicit_intf_speed(
                            port_id, model, fpc, pic),
                        transformation_id=2),
                    d.gen_transform(
                        self._gen_intfs_1x10G_to_1x1G_with_autoneg(
                            port_id, model, fpc, pic, autoneg=True),
                        transformation_id=3)],
                slot_id, failure_domain_id, port_offset,
                display_id=display_id, templatize=self.templatize,
            )
        return d.gen_port(
            port_id, row_id, col_id, panel_id, "sfp+",
            [
                d.gen_transform(
                    self._gen_intfs_1x10G(port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x10G_to_1x1G_explicit_intf_speed(
                        port_id, model, fpc, pic, intf_prefix),
                    transformation_id=2)],
            slot_id, failure_domain_id, port_offset, display_id=display_id,
            templatize=self.templatize)

    # There are 4 uplink ports in EX4300-48MP which has interface names like
    # xe-0/2/0 - xe-0/2/3. The port_ids have to be from 49 - 52. The interface names
    # are generated from port_ids. But in this case, port_ids need to be hardcoded
    # to start from 49.
    def gen_10G_to_1x1G_port_for_ex4300_48mp(self, port_id, row_id, col_id, panel_id,
                                             slot_id, failure_domain_id, port_offset,
                                             model, fpc=0, pic=0, intf_prefix=None,
                                             display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "sfp+",
            [
                d.gen_transform(
                    self._gen_intfs_1x10G(port_id-48, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x10G_to_1x1G_explicit_intf_speed(
                        port_id-48, model, fpc, pic, intf_prefix),
                    transformation_id=2)],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_10G_to_1x1G_port_with_autoneg_disable(
            self, port_id, row_id, col_id, panel_id,
            slot_id, failure_domain_id, port_offset,
            model, fpc=0, pic=0, display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "sfp+",
            [
                d.gen_transform(
                    self._gen_intfs_1x10G(port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x10G_to_1x1G_explicit_intf_speed(
                        port_id, model, fpc, pic),
                    transformation_id=2),
                # In one example, we observed that on the EX2300C access switch,
                # interface speed needs to be explicitly set, auto-negotiation
                # needs to be explicitly disabled and link-mode needs to be set to
                # full-duplex, otherwise the link goes down. Hence add the
                # transformation here.
                d.gen_transform(
                    self._gen_intfs_1x10G_to_1x1G_with_autoneg(
                        port_id, model, fpc, pic),
                    transformation_id=3)],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_10G_to_1x1G_ports(self, row_count, column_count, start_index, panel_id,
                              slot_id=0, failure_domain_id=1, port_offset=0,
                              row_offset=0, col_offset=0, model=None, fpc=0, pic=0):
        # model info is used to decide the values of fpc and pic
        return [
            self.gen_10G_to_1x1G_port_with_autoneg_disable(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=model, fpc=fpc, pic=pic
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_10G_1x1G_with_master_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, master_port_id=None, display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        master_port_id = get_master_port_id(port_id, 4) - 1
        pg_name = self.make_intf_name(
            '', get_master_port_id(port_id, 4) - 1, fpc, pic)[1:]

        setting_param_10g = self.make_junos_setting_param(
                fpc=fpc, pic=pic, port_id=port_id - 1,
                global_speed='10g',
                breakout=False,
                master_port_id=master_port_id,
                validations=self.pg_validations_master_port(pg_name, '10g')
            )
        setting_param_1g = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1,
            global_speed='1G',
            breakout=False,
            master_port_id=master_port_id,
            validations=self.pg_validations_master_port(pg_name, '1G'))

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "sfp+",
            [
                d.gen_transform(
                    self._gen_intfs_1x10G_explicit(
                        port_id, model, fpc, pic, setting_param=setting_param_10g),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x1G_explicit_port_speed(
                        port_id, model, fpc, pic, setting_param=setting_param_1g),
                    transformation_id=2)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_10G_1x1G_ports(self, row_count, column_count, start_index,
                           panel_id, slot_id=0, failure_domain_id=1,
                           port_offset=0, row_offset=0, col_offset=0,
                           model=None, fpc=0, pic=0):
        return [
            self.gen_10G_1x1G_with_master_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=model, fpc=fpc, pic=pic,
                master_port_id=get_master_port_id(port_id, 4)
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_10G_to_1x1G_explicit_speed_port(self, port_id, row_id, col_id, panel_id,
                                            slot_id, failure_domain_id, port_offset,
                                            model, fpc=0, pic=0, display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "10GBaseT",
            [
                d.gen_transform(
                    self._gen_intfs_1x10G(port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x10G_to_1x1G_explicit_intf_speed(
                        port_id, model, fpc, pic),
                    transformation_id=2)],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_10G_to_1x1G_explicit_speed_ports(self, row_count, column_count, start_index, panel_id,
                                             slot_id=0, failure_domain_id=1, port_offset=0,
                                             row_offset=0, col_offset=0, model=None, fpc=0, pic=0):
        return [
            self.gen_10G_to_1x1G_explicit_speed_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=model, fpc=fpc, pic=pic
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_10G_to_1x1G_explicit_speed_port_intf_prefix(
            self, port_id, row_id, col_id, panel_id,
            slot_id, failure_domain_id, port_offset,
            model, fpc=0, pic=0, intf_prefix=None, display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "sfp+",
            [
                d.gen_transform(
                    self._gen_intfs_1x10G(port_id, model, fpc, pic, intf_prefix=intf_prefix),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x10G_to_1x1G_explicit_intf_speed(
                        port_id, model, fpc, pic, intf_prefix=intf_prefix),
                    transformation_id=2)],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_10G_to_1x1G_explicit_speed_ports_intf_prefix(self, row_count, column_count, start_index, panel_id,
                                                         slot_id=0, failure_domain_id=1, port_offset=0,
                                                         row_offset=0, col_offset=0, model=None, fpc=0,
                                                         pic=0, intf_prefix=None):
        return [
            self.gen_10G_to_1x1G_explicit_speed_port_intf_prefix(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=model, fpc=fpc,
                pic=pic, intf_prefix=intf_prefix
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_10G_port_intf_prefix(self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
                                 port_offset, model, fpc=0, pic=0, intf_prefix=None,
                                 display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "sfp+",
            [
                d.gen_transform(
                    self._gen_intfs_1x10G(port_id, model, fpc, pic, intf_prefix=intf_prefix),
                    transformation_id=1, is_default=True)],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_10G_ports_intf_prefix(self, row_count, column_count, start_index, panel_id, slot_id=0,
                                  failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
                                  model=None, fpc=0, pic=0, intf_prefix=None):
        return [
            self.gen_10G_port_intf_prefix(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=model, fpc=fpc,
                pic=pic, intf_prefix=intf_prefix
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_10GBaseT_port(self, port_id, row_id, col_id, panel_id,
                          slot_id, failure_domain_id, port_offset,
                          model, fpc=0, pic=0, display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "10GBaseT",
            [
                d.gen_transform(
                    self._gen_intfs_1x10G(port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x10G_to_1x1G_default(
                        port_id, model, fpc, pic),
                    transformation_id=2)],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_10GBaseT_ports(self, row_count, column_count, start_index, panel_id,
                           slot_id=0, failure_domain_id=1, port_offset=0,
                           row_offset=0, col_offset=0, model=None, fpc=0, pic=0):
        # model info is used to decide the values of fpc and pic
        return [
            self.gen_10GBaseT_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=model, fpc=fpc, pic=pic
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_25G_1x25G_to_1x10G_1x1G_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "sfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x25G(port_id, model, fpc, pic),
                    transformation_id=1),
                d.gen_transform(
                    self._gen_intfs_1x10G(port_id, model, fpc, pic),
                    transformation_id=2, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x1G(port_id, model, fpc, pic),
                    transformation_id=3)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_25G_1x25G_to_1x10G_1x1G_explicit_speed_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, display_id=None,
            ):

        if display_id is None:
            display_id = port_id + port_offset - 1

        junos_setting_param_10g = self.make_junos_setting_param(
                fpc=fpc, pic=pic, port_id=port_id - 1,
                speed_value='10', breakout=False,
            )
        junos_setting_param_1g = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1,
            speed_value='1', breakout=False
        )
        return d.gen_port(
            port_id, row_id, col_id, panel_id, "sfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x25G_explicit_port_speed(
                        port_id, model, fpc, pic,
                        setting_param=self.make_junos_setting_param()),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x10G_explicit(
                        port_id, model, fpc, pic, intf_prefix='et',
                        setting_param=junos_setting_param_10g),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x1G_explicit_port_speed(
                        port_id, model, fpc, pic,
                        intf_prefix='et',
                        setting_param=junos_setting_param_1g),
                    transformation_id=3)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def pg_validations_master_port(self, mp_id, identifier):
        if mp_id is None:
            return None
        validations= gen_pg_speed_validations([(mp_id, identifier)])
        return validations


    def gen_25G_1x25G_to_1x10G_1x1G_explicit_speed_port_master(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, master_port_id=None,
            display_id=None):
        # for all the platforms we support so far that have 25G SFP28 ports,
        # by default they come up on the device as 10G, hence make 10G default.
        # And we are keeping the transformation in speed descending to align with
        # all other platforms/vendors. (EOS 25G port has the same
        # transformations/default as well)

        if display_id is None:
            display_id = port_id + port_offset - 1
        master_port_id = get_master_port_id(port_id, 4) - 1
        pg_name = self.make_intf_name('', get_master_port_id(port_id, 4) - 1, fpc, pic)[1:]
        junos_setting_param_25g = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1,
            global_speed='25g',
            breakout=False,
            master_port_id=None if (port_id-1)%4==0 else master_port_id,
            validations=self.pg_validations_master_port(pg_name, '25g')
        )
        junos_setting_param_10g = self.make_junos_setting_param(
            validations=self.pg_validations_master_port(pg_name, '10g')
        )
        junos_setting_param_1g = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1,
            global_speed='1G',
            breakout=False,
            master_port_id=None if (port_id-1)%4==0 else master_port_id,
            validations=self.pg_validations_master_port(pg_name, '1G')
        )
        return d.gen_port(
            port_id, row_id, col_id, panel_id, "sfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x25G_explicit_port_speed(
                        port_id, model, fpc, pic, setting_param=junos_setting_param_25g),
                    transformation_id=1),
                d.gen_transform(
                    self._gen_intfs_1x10G_explicit(
                        port_id, model, fpc, pic,
                        setting_param=junos_setting_param_10g),
                    transformation_id=2, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x1G_explicit_port_speed(
                        port_id, model, fpc, pic, setting_param=junos_setting_param_1g),
                    transformation_id=3)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )



    def gen_25G_1x25G_to_1x10G_1x1G_ports(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
            model=None, fpc=0, pic=0):
        # The SFP28 speed can be applied only for individual quads (four ports). The
        # speed cannot be configured for a single port.

        # The native 25-G ports can operate in 1-G, 10-G, or 25-G speeds based on
        # the configuration set at the quad level. When 10-G interface is
        # supported by default, you need to manually configure 1-G and 25-G
        # interface speeds in order to support 1-G and 25-G optics when required.
        # To support 10-G speed for the same port slot, you need to delete the
        # 1-G/ 25-G port configuration that was set earlier.
        return [
            self.gen_25G_1x25G_to_1x10G_1x1G_explicit_speed_port_master(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                port_offset, model=model, fpc=fpc, pic=pic
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset
            )
        ]

    def gen_25G_to_1x10G_ext_module_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "sfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x25G_ext_module(
                        port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x10G_ext_module(
                        port_id, model, fpc, pic),
                    transformation_id=2)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_25G_to_1x10G_ext_module_ports(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
            model=None, fpc=0, pic=0):
        return [
            self.gen_25G_to_1x10G_ext_module_port(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                port_offset, model=model, fpc=fpc, pic=pic
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset
            )
        ]

    def gen_25G_to_1x10G_explicit_speed_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, master_port_id=None, display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        master_port_id= master_port_id - 1 if master_port_id is not None else None
        pg_name = self.make_intf_name('', master_port_id, fpc, pic)[1:] \
                if master_port_id is not None else None

        setting_param_25g = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1,
            global_speed='25g',
            breakout=False,
            master_port_id=master_port_id,
            validations=self.pg_validations_master_port(pg_name, '25g')
        )
        setting_param_10g = self.make_junos_setting_param(
                fpc=fpc, pic=pic, port_id=port_id - 1,
                speed_value=None,
                global_speed='10g',
                breakout=False,
                master_port_id=master_port_id,
                validations=self.pg_validations_master_port(pg_name, '10g')
            )

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "sfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x25G_explicit_port_speed(
                        port_id, model, fpc, pic,
                        setting_param=setting_param_25g),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x10G_explicit(
                        port_id, model, fpc, pic,
                        setting_param=setting_param_10g),
                    transformation_id=2)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_25G_to_1x10G_extension_module_ports(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
            model=None, fpc=0, pic=0):
        return [
            self.gen_25G_to_1x10G_explicit_speed_port(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                port_offset, model=model, fpc=fpc, pic=pic,
                master_port_id=get_master_port_id(port_id, 4)
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset
            )
        ]

    def gen_25G_to_1x10G_ports(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "sfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x25G(
                        port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x10G_explicit_port_speed(
                        port_id, model, fpc, pic, intf_prefix='et'),
                    transformation_id=2)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    # port generators
    def gen_100G_non_breakout_capable_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x100G(port_id, model, fpc, pic),
                    transformation_id=1, is_default=True
                ),
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_100G_non_breakout_capable_ports(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
            model=None, fpc=0, pic=0):
        return [
            self.gen_100G_non_breakout_capable_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=model, fpc=fpc, pic=pic)
            for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_40G_non_breakout_capable_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp+",
            [
                d.gen_transform(
                    self._gen_intfs_1x40G(port_id, model, fpc, pic),
                    transformation_id=1, is_default=True
                ),
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_40G_non_breakout_capable_ports(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
            model=None, fpc=0, pic=0):
        return [
            self.gen_40G_non_breakout_capable_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=model, fpc=fpc, pic=pic)
            for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_40G_to_4x10G_port(self, port_id, row_id, col_id, panel_id, slot_id,
                              failure_domain_id, port_offset, model, fpc=0, pic=0,
                              display_id=None):
        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp+",
                          [d.gen_transform(
                              self._gen_intfs_1x40G(port_id, model, fpc, pic, default=True),
                              transformation_id=1,
                              is_default=True),
                           d.gen_transform(
                               self._gen_intfs_1x40G_to_4x10G_breakout(
                                   port_id, model, fpc, pic),
                               transformation_id=2)],
                          slot_id, failure_domain_id, port_offset,
                          display_id=display_id, templatize=self.templatize,)

    def gen_4x10G_ports_40G_to_4x10G_ports_explicit_breakout_port(self, port_id, row_id, col_id, panel_id, slot_id,
                              failure_domain_id, port_offset, model, fpc=0, pic=0,
                              display_id=None, intf_speed=None):
        if display_id is None:
            display_id = port_id + port_offset - 1
        if intf_speed:
            setting_param=self.make_junos_setting_param(10)
        else:
            setting_param=None

        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp+",
                          [d.gen_transform(
                              self._gen_intfs_1x40G(port_id, model, fpc, pic, default=True),
                              transformation_id=1,
                              is_default=True),
                           d.gen_transform(
                               self._gen_intfs_1x40G_to_4x10G_breakout(
                                   port_id, model, fpc, pic),
                               transformation_id=2),
                           d.gen_transform(
                               self._gen_intfs_1x40G_to_4x10G_explicit_breakout(
                                   port_id, model, fpc, pic, setting_param=setting_param),
                               transformation_id=3)],
                          slot_id, failure_domain_id, port_offset,
                          display_id=display_id, templatize=self.templatize,)

    def gen_40G_to_4x10G_explicit_breakout_port(
            self, port_id, row_id, col_id, panel_id, slot_id,
            failure_domain_id, port_offset, model, fpc=0, pic=0,
            display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp+",
                          [d.gen_transform(
                              self._gen_intfs_1x40G(port_id, model, fpc, pic, default=True),
                              transformation_id=1,
                              is_default=True),
                           d.gen_transform(
                               self._gen_intfs_1x40G_to_4x10G_explicit_breakout(
                                   port_id, model, fpc, pic),
                               transformation_id=2)],
                          slot_id, failure_domain_id, port_offset,
                          display_id=display_id, templatize=self.templatize,)

    def gen_40G_to_4x10G_ports(self, row_count, column_count, start_index,
                               panel_id, slot_id=0, failure_domain_id=1,
                               port_offset=0, row_offset=0, col_offset=0,
                               model=None, fpc=0, pic=0):
        # Use this when the 40-Gbps QSFP+ ports on the switch are channelized
        # automatically by default (auto-channelized) if any of the four channels
        # on a 40-Gbps QSFP+ port receive data, unless you have configured
        # channelization either at the chassis level or at the port level
        return [
            self.gen_40G_to_4x10G_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=model, fpc=fpc, pic=pic)
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_40G_to_4x10G_ports_explicit_breakout(self, row_count, column_count, start_index,
                                                 panel_id, slot_id=0, failure_domain_id=1,
                                                 port_offset=0, row_offset=0, col_offset=0,
                                                 model=None, fpc=0, pic=0):
        # Use this when the 40-Gbps QSFP+ ports on the switch are not channelized
        # automatically by default (auto-channelized), the channelization speed should be
        #  configured at the chassis level.
        return [
            self.gen_40G_to_4x10G_explicit_breakout_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=model, fpc=fpc, pic=pic)
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_4x10G_ports_40G_to_4x10G_ports_explicit_breakout(self, row_count, column_count, start_index,
                                                 panel_id, slot_id=0, failure_domain_id=1,
                                                 port_offset=0, row_offset=0, col_offset=0,
                                                 model=None, fpc=0, pic=0, intf_speed=None):
        # Use this when the 40-Gbps QSFP+ ports on the switch are not channelized
        # automatically by default (auto-channelized), the channelization speed should be
        #  configured at the chassis level.
        return [
            self.gen_4x10G_ports_40G_to_4x10G_ports_explicit_breakout_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=model, fpc=fpc, pic=pic, intf_speed=intf_speed)
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_40G_40G_disabled_4x10G_explicit_breakout_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, master_port_id=None,
            display_id=None):
        # On QFX10002, QFX10008, and QFX10016 switches, there are 100-Gigabit
        # Ethernet ports that work either as 100-Gigabit Ethernet or as 40-Gigabit
        #  Ethernet, but are recognized as 40-Gigabit Ethernet by default. When a
        # 40-Gigabit Ethernet transceiver is inserted into a 100-Gigabit Ethernet
        # port, the port recognizes the 40-Gigabit Ethernet port speed. When a
        # 100-Gigabit Ethernet transceiver is inserted into the port and enabled
        # in the CLI, the port recognizes the 100-Gigabit Ethernet speed and
        # disables two adjacent 40-Gigabit Ethernet ports. Hence add
        # _gen_intfs_1x40G_disabled as one of the transformation.

        if display_id is None:
            display_id = port_id + port_offset - 1
        master_port_id= master_port_id - 1 if master_port_id is not None else None
        pg_name = self.make_intf_name('', master_port_id, fpc, pic)[1:] \
                if master_port_id is not None else None
        setting_param_1x40g = self.make_junos_setting_param(
            validations=self.pg_validations_master_port(pg_name, '1x40g'))
        setting_param_1x40g_disabled =  self.make_junos_disabled_setting(
            validations=self.pg_validations_master_port(pg_name, 'no_constraint'))
        setting_param_4x10g = self.make_junos_setting_param(
                fpc=fpc,
                pic=pic, port_id=port_id - 1, global_speed="10g",
                breakout=True,
                master_port_id=master_port_id,
                validations=self.pg_validations_master_port(pg_name, '4x10g'))

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp+",
            [
                d.gen_transform(
                    self._gen_intfs_1x40G(
                        port_id, model, fpc, pic, setting_param=setting_param_1x40g),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x40G_disabled(
                        port_id, model, fpc, pic,
                        setting_param=setting_param_1x40g_disabled),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_explicit_breakout(
                        port_id, model, fpc, pic, setting_param=setting_param_4x10g),
                    transformation_id=3)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_50G_1x50G_to_1x25G_1x10G_intf_name_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, display_id=None, intf_prefix=None,
            set_speed_in_interfaces=False):

        if display_id is None:
            display_id = port_id + port_offset - 1

        transformations = [
            d.gen_transform(
                self._gen_intfs_1x50G_explicit_port_speed(
                    port_id, model, fpc, pic,
                    set_speed_in_interfaces=set_speed_in_interfaces),
                transformation_id=1),
            d.gen_transform(
                self._gen_intfs_1x25G(port_id, model, fpc, pic),
                transformation_id=2, is_default=True),
            d.gen_transform(
                self._gen_intfs_1x10G_explicit(
                    port_id, model, fpc, pic, intf_prefix=intf_prefix or 'xe',
                    set_speed_in_interfaces=set_speed_in_interfaces),
                transformation_id=3)
        ]

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "sfp56",
            transformations,
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_100G_disabled_100G_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, master_port_id=None,
            set_speed_in_interfaces=False, display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x100G(
                        port_id, model, fpc, pic, set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x100G_disabled(
                        port_id, model, fpc, pic),
                    transformation_id=2)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_100G_40G_disabled_40G_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, master_port_id=None,
            display_id=None):
        # On QFX10002-60C, when ports are channelized, some physical ports are to be
        # disabled. There is a need for 100G, 40G and disabled 40G transformation.

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x40G(port_id, model, fpc, pic, default=True),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x100G(port_id, model, fpc, pic, default=True),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x40G_disabled(
                        port_id, model, fpc, pic),
                    transformation_id=3)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_40G_40G_disabled_4x10G_breakout_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, display_id=None):
        # On QFX10002, QFX10008, and QFX10016 switches, there are 100-Gigabit
        # Ethernet ports that work either as 100-Gigabit Ethernet or as 40-Gigabit
        #  Ethernet, but are recognized as 40-Gigabit Ethernet by default. When a
        # 40-Gigabit Ethernet transceiver is inserted into a 100-Gigabit Ethernet
        # port, the port recognizes the 40-Gigabit Ethernet port speed. When a
        # 100-Gigabit Ethernet transceiver is inserted into the port and enabled
        # in the CLI, the port recognizes the 100-Gigabit Ethernet speed and
        # disables two adjacent 40-Gigabit Ethernet ports. Hence add
        # _gen_intfs_1x40G_disabled as one of the transformation.

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp+",
            [
                d.gen_transform(
                    self._gen_intfs_1x40G(port_id, model, fpc, pic, default=True),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x40G_disabled(
                        port_id, model, fpc, pic),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_breakout(
                        port_id, model, fpc, pic),
                    transformation_id=3)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_40G_40G_disabled_4x10G_breakout_ports(self, row_count, column_count,
                                                  start_index, panel_id, slot_id=0,
                                                  failure_domain_id=1, port_offset=0,
                                                  row_offset=0, col_offset=0,
                                                  model=None, fpc=0, pic=0):
        # Use this when the 40-Gbps QSFP+ ports on the switch are channelized
        # automatically by default (auto-channelized) if any of the four channels
        # on a 40-Gbps QSFP+ port receive data, unless you have configured
        # channelization either at the chassis level or at the port level
        return [
            self.gen_40G_40G_disabled_4x10G_breakout_port(port_id, row_id, column_id,
                                                          panel_id, slot_id,
                                                          failure_domain_id,
                                                          port_offset, model=model,
                                                          fpc=fpc, pic=pic)
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_40G_100G_1x40G_to_4x10G_explicit_breakout_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, master_port_id=None,
            display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x40G(port_id, model, fpc, pic, default=True),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x100G(port_id, model, fpc, pic),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_explicit_breakout(
                        port_id, model, fpc, pic, master_port_id),
                    transformation_id=3)
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_qfx10002_100G_40G_1x40G_to_4x10G_explicit_breakout_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, master_port_id=None,
            disabled_transform=False, display_id=None):
        # pylint: disable=line-too-long
        # For qfx10002 series 40G/100G ports, when a 40-Gigabit Ethernet
        # transceiver is inserted into a 100-Gigabit Ethernet port, the port
        # recognizes the 40-Gigabit Ethernet port speed. However, when an
        # 100-Gigabit Ethernet transceiver is inserted into the port,
        # the transceiver is not automatically recognized and is not seen in the
        # output of the show chassis hardware command. To enable 100-Gigabit
        # Ethernet on the marked ports, use the set chassis fpc command

        # page 30 at https://www.juniper.net/documentation/en_US/release-independent/junos/information-products/pathway-pages/hardware/qfx-series/qfx10002.pdf

        if display_id is None:
            display_id = port_id + port_offset - 1
        master_port_id=(master_port_id - 1 if master_port_id is not None else None)
        pg_name = self.make_intf_name('', master_port_id, fpc, pic)[1:] \
            if master_port_id is not None else None
        junos_setting_param_40g = self.make_junos_setting_param(
            validations=self.pg_validations_master_port(pg_name, '1x40g')
        )
        junos_setting_param_100g = self.make_junos_setting_param(
                fpc=fpc, pic=pic, port_id=port_id - 1, breakout=False,
                global_speed='100g',
                validations=self.pg_validations_master_port(pg_name, '1x100g'))
        junos_setting_param_4x10g = self.make_junos_setting_param(
                fpc=fpc, pic=pic, port_id=port_id - 1, global_speed="10g",
                breakout=True,
                master_port_id=master_port_id,
                validations=self.pg_validations_master_port(pg_name, '4x10g'))
        port = d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x40G(port_id, model, fpc, pic, setting_param=junos_setting_param_40g),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x100G_explicit_port_speed(
                        port_id, model, fpc, pic, setting_param=junos_setting_param_100g),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_explicit_breakout(
                        port_id, model, fpc, pic, setting_param=junos_setting_param_4x10g),
                    transformation_id=3)
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,)

        if disabled_transform:
            port['transformations'].extend([
                d.gen_transform(
                    self._gen_intfs_1x40G_disabled(
                        port_id, model, fpc, pic),
                    transformation_id=4)
            ])
        return port

    def gen_implicit_100G_and_40G_plus_1x40G_to_4x10G_explicit_breakout_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, master_port_id=None,
            disabled_transform=False, speed_keyword=None,
            display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        port = d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x40G(port_id, model, fpc, pic, default=True),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x100G(port_id, model, fpc, pic, default=True),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_explicit_breakout(
                        port_id, model, fpc, pic, master_port_id, speed_keyword=speed_keyword),
                    transformation_id=3)
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

        if disabled_transform:
            port['transformations'].extend([
                d.gen_transform(
                    self._gen_intfs_1x40G_disabled(
                        port_id, model, fpc, pic),
                    transformation_id=4)])
        return port

    def gen_qfx10008_40G_1x40G_to_4x10G_explicit_breakout_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, master_port_id=None,
            display_id=None):
        # pylint: disable=line-too-long
        # For qfx10002 series 40G/100G ports, when a 40-Gigabit Ethernet
        # transceiver is inserted into a 100-Gigabit Ethernet port, the port
        # recognizes the 40-Gigabit Ethernet port speed. However, when an
        # 100-Gigabit Ethernet transceiver is inserted into the port,
        # the transceiver is not automatically recognized and is not seen in the
        # output of the show chassis hardware command. To enable 100-Gigabit
        # Ethernet on the marked ports, use the set chassis fpc command

        # page 30 at https://www.juniper.net/documentation/en_US/release-independent/junos/information-products/pathway-pages/hardware/qfx-series/qfx10002.pdf

        if display_id is None:
            display_id = port_id + port_offset - 1

        port = d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp+",
            [
                d.gen_transform(
                    self._gen_intfs_1x40G(port_id, model, fpc, pic, default=True),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_explicit_breakout(
                        port_id, model, fpc, pic, master_port_id),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x40G_disabled(
                        port_id, model, fpc, pic),
                    transformation_id=3)
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )
        return port

    def gen_40G_100G_1x40G_to_4x10G_explicit_breakout_ports(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
            model=None, fpc=0, pic=0):
        # Use this when auto-channelization is not enabled by default on the switch
        # This will be used for manually configuring the channel speed
        return [
            self.gen_40G_100G_1x40G_to_4x10G_explicit_breakout_port(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                port_offset, model=model, fpc=fpc, pic=pic)
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_40G_100G_1x40G_to_4x10G_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x40G(port_id, model, fpc, pic, default=True),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x100G(port_id, model, fpc, pic),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_breakout(
                        port_id, model, fpc, pic),
                    transformation_id=3)
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_40G_100G_1x40G_to_4x10G_ports(self, row_count, column_count, start_index,
                                          panel_id, slot_id=0, failure_domain_id=1,
                                          port_offset=0, row_offset=0,
                                          col_offset=0, model=None, fpc=0, pic=0):
        # Use this when the 40-Gbps QSFP+ ports on the switch are channelized
        # automatically by default (auto-channelized) if any of the four channels
        # on a 40-Gbps QSFP+ port receive data, unless you have configured
        # channelization either at the chassis level or at the port level
        return [
            self.gen_40G_100G_1x40G_to_4x10G_port(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                port_offset, model=model, fpc=fpc, pic=pic)
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_100G_to_4x25G_40G_to_4x10G_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        # Using junos_setting_param_4x10_breakout for model QFX5120-48Y and EX4650-48Y
        # in transformation 5, to render global speed information for 4x10 breakout.
        junos_setting_param_4x10_breakout = \
            self.breakout_setting_param(10, '10g', 4, model, port_id, fpc, pic)

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x40G(port_id, model, fpc, pic, default=True),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x100G_explicit_port_speed(port_id, model, fpc, pic),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_4x25G_breakout_explicit(
                        port_id, model, fpc, pic),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_breakout(
                        port_id, model, fpc, pic),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_breakout(
                        port_id, model, fpc, pic,
                        junos_setting_param=junos_setting_param_4x10_breakout),
                    transformation_id=5)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_100G_to_1x100G_1x40G_4x25G_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0):
        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x100G(port_id-52, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x40G(port_id-52, model, fpc, pic),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_4x25G_breakout_explicit(
                        port_id-52, model, fpc, pic),
                    transformation_id=3)
            ],
            slot_id, failure_domain_id, port_offset
        )

    def gen_100G_to_4x25G_40G_to_4x10G_intf_name_explicit_breakout_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, intf_prefix=None,
            set_speed_in_interfaces=False, display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        unused_port_list = self.populate_unused_port_list(model=model, port_id=port_id)
        unused_interfaces_list = self.populate_unused_interfaces_list(
            model=model, fpc=fpc, pic=pic, intf_prefix=intf_prefix or 'xe', port_id=port_id)
        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x100G(
                        port_id, model, fpc, pic, set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x40G_explicit_port_speed(
                        port_id, model, fpc, pic, set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_4x25G_breakout_explicit(
                        port_id, model, fpc, pic,
                        unused_port_list=unused_port_list if not set_speed_in_interfaces else None,
                        unused_interfaces_list=unused_interfaces_list if set_speed_in_interfaces else None,
                        subports_count=4,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_explicit_breakout_intf_name(
                        port_id, model, fpc, pic, intf_prefix=intf_prefix or 'xe', subports_count=4,
                        unused_port_list=unused_port_list if not set_speed_in_interfaces else None,
                        unused_interfaces_list=unused_interfaces_list if set_speed_in_interfaces else None,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=4)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_100G_to_4x25G_40G_to_4x10G_ports(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
            model=None, fpc=0, pic=0):
        # Use this when the QSFP+/QSFP28 ports on the switch are channelized
        # automatically by default (auto-channelized) if any of the four channels
        # on a port receive data, unless you have configured
        # channelization either at the chassis level or at the port level

        # However we observed that the interface physical link status is Down when
        # QSFP+ 100g breakout to 4x25g for both QFX5120-48Y and EX4650-48Y models.
        # After add the channel-speed statement, the interfaces successfuly come
        # up. 4x10G automatically come up without channel-speed statement.
        return [
            self.gen_100G_to_4x25G_40G_to_4x10G_port(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                port_offset, model=model, fpc=fpc, pic=pic
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_100G_40G_disabled_100G_port(self, port_id, row_id, col_id, panel_id,
                                        slot_id, failure_domain_id,
                                        port_offset, model, fpc=0, pic=0,
                                        display_id=None,
                                        set_speed_in_interfaces=False):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x100G(
                        port_id, model, fpc, pic,
                        set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x40G_explicit_port_speed(
                        port_id, model, fpc, pic,
                        set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x100G_disabled(port_id, model, fpc, pic),
                    transformation_id=3)
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,)

    def gen_40G_100G_port(self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
                          port_offset, model, fpc=0, pic=0, default_speed='100g',
                          display_id=None):
        assert default_speed in ['100g', '40g']

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [
                              d.gen_transform(
                                  self._gen_intfs_1x100G(port_id, model, fpc, pic,
                                                         default=(default_speed == '100g')),
                                  transformation_id=1, is_default=(default_speed == '100g')),
                              d.gen_transform(
                                  self._gen_intfs_1x40G(port_id, model, fpc, pic,
                                                        default=(default_speed == '40g')),
                                  transformation_id=2, is_default=(default_speed == '40g'))
                          ], slot_id, failure_domain_id, port_offset,
                          display_id=display_id, templatize=self.templatize,)

    def gen_40G_100G_port_default(self, port_id, row_id, col_id, panel_id, slot_id,
                                  failure_domain_id, port_offset, model, fpc=0, pic=0,
                                  display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [
                              d.gen_transform(
                                  self._gen_intfs_1x100G(port_id, model, fpc, pic, default=True),
                                  transformation_id=1, is_default=True),
                              d.gen_transform(
                                  self._gen_intfs_1x40G(port_id, model, fpc, pic, default=True),
                                  transformation_id=2)
                          ], slot_id, failure_domain_id, port_offset,
                          display_id=display_id, templatize=self.templatize,)

    def gen_40G_100G_ports(self, row_count, column_count, start_index,
                           panel_id, slot_id=0, failure_domain_id=1,
                           port_offset=0, row_offset=0,
                           col_offset=0, model=None, fpc=0, pic=0):
        return [
            self.gen_40G_100G_port(port_id, row_id, column_id,
                                   panel_id, slot_id,
                                   failure_domain_id,
                                   port_offset, model=model,
                                   fpc=fpc, pic=pic)
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_100G_to_4x25G_4x10G_port(self, port_id, row_id, col_id, panel_id, slot_id,
                                     failure_domain_id, port_offset, model, fpc=0, pic=0,
                                     display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [d.gen_transform(
                              self._gen_intfs_1x100G(port_id, model, fpc, pic),
                              transformation_id=1,
                              is_default=True),
                           d.gen_transform(
                               self._gen_intfs_1x100G_to_4x25G_breakout_explicit(
                                   port_id, model, fpc, pic),
                               transformation_id=2),
                           d.gen_transform(
                               self._gen_intfs_1x100G_to_4x10G_breakout_explicit(
                                   port_id, model, fpc, pic),
                               transformation_id=3)],
                          slot_id, failure_domain_id, port_offset,
                          display_id=display_id, templatize=self.templatize,)

    def gen_100G_to_4x25G_4x10G_ports(self, row_count, column_count, start_index,
                                      panel_id, slot_id=0, failure_domain_id=1,
                                      port_offset=0, row_offset=0, col_offset=0,
                                      model=None, fpc=0, pic=0):
        return [
            self.gen_100G_to_4x25G_4x10G_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=model, fpc=fpc, pic=pic)
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_100G_to_4x25G_4x10G_1x40G_port(self, port_id, row_id, col_id, panel_id,
                                           slot_id,
                                           failure_domain_id, port_offset, model,
                                           fpc=0, pic=0,
                                           display_id=None):
        if display_id is None:
            display_id = port_id + port_offset - 1
        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [d.gen_transform(
                              self._gen_intfs_1x100G(port_id, model, fpc, pic),
                              transformation_id=1, is_default=True),
                              d.gen_transform(
                                  self._gen_intfs_1x100G_to_4x25G_breakout_explicit(
                                      port_id, model, fpc, pic),
                                  transformation_id=2),
                              d.gen_transform(
                                  self._gen_intfs_1x100G_to_4x10G_breakout_explicit(
                                      port_id, model, fpc, pic),
                                  transformation_id=3),
                              d.gen_transform(
                                  self._gen_intfs_1x40G(
                                      port_id, model, fpc, pic, default=True),
                                  transformation_id=4)],
                          slot_id, failure_domain_id, port_offset,
                          display_id=display_id, templatize=self.templatize)

    def gen_100G_to_4x25G_4x10G_1x40G_ports(self, row_count, column_count,
                                           start_index,
                                      panel_id, slot_id=0, failure_domain_id=1,
                                      port_offset=0, row_offset=0, col_offset=0,
                                      model=None, fpc=0, pic=0):
        return [
            self.gen_100G_to_4x25G_4x10G_1x40G_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=model, fpc=fpc, pic=pic)
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]


    def gen_100G_to_1x100G_port(self, port_id, row_id, col_id, panel_id, slot_id,
                                failure_domain_id, port_offset, model, fpc=0, pic=0,
                                display_id=None):
        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [d.gen_transform(
                              self._gen_intfs_1x100G_explicit_port_speed(
                                  port_id, model, fpc, pic),
                              transformation_id=1,
                              is_default=True)
                          ],
                          slot_id, failure_domain_id, port_offset,
                          display_id=display_id, templatize=self.templatize)

    def gen_100G_to_1x100G_ports(self, row_count, column_count, start_index,
                                 panel_id, slot_id=0, failure_domain_id=1,
                                 port_offset=0, row_offset=0, col_offset=0,
                                 model=None, fpc=0, pic=0):
        return [
            self.gen_100G_to_1x100G_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=model, fpc=fpc, pic=pic)
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_juniper_acx7100_48l_sfp56_ports(self, row_count, column_count, start_index,
                                            panel_id, slot_id=0, failure_domain_id=1,
                                            port_offset=0, row_offset=0,
                                            col_offset=0):

        return [
            self.gen_10G_25G_50G(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=None, fpc=0, pic=0,
            )
            if port_id != 48
            else self.gen_10G_25G(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=None, fpc=0, pic=0,
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset
            )
        ]

    def gen_juniper_qfx10002_36q_ports(self, row_count, column_count, start_index,
                                       panel_id, slot_id=0, failure_domain_id=1,
                                       port_offset=0, row_offset=0,
                                       col_offset=0, model=None, fpc=0, pic=0):
        ports = []
        for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset):
            # Only the first and fourth port in each 6XQSFP cage is available to
            # channelize as part of a port range. In a port range, the ports are
            # bundled with the next two consecutive ports.
            if port_id in range(1, 35, 3):
                # Channelization configuration is allowed
                ports.extend([
                    self.gen_40G_40G_disabled_4x10G_explicit_breakout_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model,
                        fpc=fpc, pic=pic)
                ])
            elif port_id in [2, 6, 8, 12, 14, 18, 20, 24, 26, 30, 32, 36]:
                # Supports 4x10G breakout but channelization configuration is only
                # allowed on master port.
                ports.extend([
                    self.gen_qfx10002_100G_40G_1x40G_to_4x10G_explicit_breakout_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model,
                        fpc=fpc, pic=pic,
                        master_port_id=get_master_port_id(port_id, 3))
                ])
            else:
                # Supports 4x10G breakout but channelization configuration is only
                # allowed on master port.
                ports.extend([
                    self.gen_40G_40G_disabled_4x10G_explicit_breakout_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model,
                        fpc=fpc, pic=pic,
                        master_port_id=get_master_port_id(port_id, 3))
                ])
        return ports

    def gen_juniper_qfx10002_72q_ports(self, row_count, column_count, start_index,
                                       panel_id, slot_id=0, failure_domain_id=1,
                                       port_offset=0, row_offset=0,
                                       col_offset=0, model=None, fpc=0, pic=0):
        ports = []
        for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset):
            # Only the first and fourth port in each 6XQSFP cage is available to
            # channelize as part of a port range. In a port range, the ports are
            # bundled with the next two consecutive ports.
            if port_id in range(1, 71, 3):
                # Channelization configuration is allowed
                ports.extend([
                    self.gen_40G_40G_disabled_4x10G_explicit_breakout_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model,
                        fpc=fpc, pic=pic)
                ])
            elif port_id in [2, 6, 8, 12, 14, 18, 20, 24, 26, 30, 32, 36,
                             38, 42, 44, 48, 50, 54, 56, 60, 62, 66, 68, 72]:
                # Supports 4x10G breakout but channelization configuration is only
                # allowed on master port.
                ports.extend([
                    self.gen_qfx10002_100G_40G_1x40G_to_4x10G_explicit_breakout_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model,
                        fpc=fpc, pic=pic,
                        master_port_id=get_master_port_id(port_id, 3))
                ])
            else:
                # Supports 4x10G breakout but channelization configuration is only
                # allowed on master port.
                ports.extend([
                    self.gen_40G_40G_disabled_4x10G_explicit_breakout_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model,
                        fpc=fpc, pic=pic,
                        master_port_id=get_master_port_id(port_id, 3))
                ])
        return ports

    def gen_juniper_qfx10002_60c_ports(self, row_count, column_count, start_index,
                                       panel_id, slot_id=0, failure_domain_id=1,
                                       port_offset=0, row_offset=0,
                                       col_offset=0, model=None, fpc=0, pic=0):
        ports = []
        for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset):
            # Ports on juniper start with 0 where as in DP the port ids starts from 1
            # Here juniper ports 6, 7 requires a specific transformation which
            # correlates to port ids 7, 8 in DP.
            if port_id in [7, 8, 17, 18, 27, 28, 37, 38, 47, 48, 57, 58]:
                ports.extend([
                    self.gen_100G_40G_disabled_40G_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model,
                        fpc=fpc, pic=pic)
                ])
            else:
                ports.extend([
                    self.gen_implicit_100G_and_40G_plus_1x40G_to_4x10G_explicit_breakout_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model,
                        fpc=fpc, pic=pic, speed_keyword='speed')
                ])
        return ports

    def gen_juniper_qfx10008_30c_ports(self, row_count, column_count, start_index,
                                       panel_id, slot_id=0, failure_domain_id=1,
                                       port_offset=0, row_offset=0,
                                       col_offset=0, model=None, pic=0):
        ports = []
        for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset):
            # Ports on juniper start with 0 where as in DP the port ids starts from 1
            # Here juniper ports 6, 7 requires a specific transformation which
            # correlates to port ids 7, 8 in DP.
            if port_id in [7, 8, 17, 18, 27, 28]:
                ports.extend([
                    self.gen_100G_40G_disabled_40G_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model,
                        fpc=slot_id, pic=pic)
                ])
            else:
                ports.extend([
                    self.gen_implicit_100G_and_40G_plus_1x40G_to_4x10G_explicit_breakout_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model,
                        fpc=slot_id, pic=pic)
                ])
        return ports

    def gen_juniper_acx7100_qsfp56dd_ports(self, row_count, column_count,
                                           start_index, panel_id, slot_id=0,
                                           failure_domain_id=1, port_offset=0,
                                           row_offset=0, col_offset=0):
        return [
            self.gen_400G_to_4x100G_8x50G_100G_to_4x25G_2x50G_40G_to_4x10G_2x100G(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=None, fpc=0, pic=0,
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset=row_offset, col_offset=col_offset
            )
        ]

    def gen_juniper_acx7024_qsfp28_ports(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0):
        return [
            self.gen_100G_1x40_4x25_2x50_4x10_port_breakout_explicit(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                port_offset, model=None, intf_prefix='et',
                set_speed_in_interfaces=True)
            for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset=row_offset,
                col_offset=col_offset)
        ]

    def gen_juniper_qfx5240_sfp28_ports(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
            model=None, fpc=0, pic=0):
        return [
            self.gen_25G_to_1x10G_ports(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                port_offset, model=model, fpc=fpc, pic=pic
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset
            )
        ]

    def gen_juniper_acx7024_sfp28_ports(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0):
        return [
            self.gen_25G_1x25G_to_1x10G_1x1G_explicit_speed_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=None)
            for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_juniper_acx7100_32C_qsfp28_ports(self, row_count, column_count,
                                             start_index, panel_id, slot_id=0,
                                             failure_domain_id=1, port_offset=0,
                                             row_offset=0, col_offset=0):

        def gen_acx7100_32C_qsfp28_port(port_id, row_id, column_id, panel_id,
                                        slot_id, failure_domain_id, port_offset):
            if (port_id - 1) % 2 == 0:
                return self.gen_100G_1x40_4x25_2x50_4x10_1x25G_1x10G_port_breakout_explicit(
                    port_id, row_id, column_id, panel_id, slot_id,
                    failure_domain_id, port_offset, model='ACX7100-32C', fpc=0,
                    pic=0, connector='qsfpdd')
            return self.gen_100G_to_2x50G_1x40G_1x25G_1x10G_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model='ACX7100-32C', fpc=0, pic=0,
                connector='qsfpdd')
        return [
            gen_acx7100_32C_qsfp28_port(port_id, row_id, column_id, panel_id,
                                        slot_id, failure_domain_id, port_offset)
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset
            )
        ]

    def gen_juniper_qfx10008_36q_ports(self, row_count, column_count, start_index,
                                       panel_id, slot_id=0, failure_domain_id=1,
                                       port_offset=0, row_offset=0,
                                       col_offset=0, model=None, pic=0):
        ports = []
        for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset):
            # Ports on juniper start with 0 where as in DP the port ids starts from 1
            # Here juniper ports 6, 7 requires a specific transformation which
            # correlates to port ids 7, 8 in DP.
            if port_id in [1, 3, 4, 5, 7, 9, 10, 11, 13, 15, 16, 17, 19, 21, 22, 23, 25, 27, 28, 29, 31, 33, 34, 35]:
                ports.extend([
                    self.gen_40G_40G_disabled_4x10G_explicit_breakout_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model,
                        fpc=slot_id, pic=pic,
                        master_port_id=get_master_port_id(port_id, 3),
                        )
                ])
            else:
                ports.extend([
                    self.gen_qfx10002_100G_40G_1x40G_to_4x10G_explicit_breakout_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model,
                        fpc=slot_id, pic=pic,
                        master_port_id=get_master_port_id(port_id, 3)
                        )
                ])
        return ports

    def gen_juniper_qfx10008_36q_ports_400_test_only(self, row_count, column_count,
                                                     start_index, panel_id,
                                                     slot_id=0, failure_domain_id=1,
                                                     port_offset=0, row_offset=0,
                                                     col_offset=0, model=None, pic=0):
        ports = []
        for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset):
            # Ports on juniper start with 0 where as in DP the port ids starts from 1
            # Here juniper ports 6, 7 requires a specific transformation which
            # correlates to port ids 7, 8 in DP.
            if port_id in [1, 3, 4, 5, 7, 9, 10, 11, 13, 15, 16, 17, 19, 21, 22, 23, 25, 27, 28, 29, 31, 33, 34, 35]:
                ports.extend([
                    self.gen_qfx10002_100G_40G_1x40G_to_4x10G_explicit_breakout_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model,
                        fpc=slot_id, pic=pic,
                        master_port_id=get_master_port_id(port_id, 3),
                        disabled_transform=True
                        )
                ])
            else:
                ports.extend([
                    self.gen_qfx10002_100G_40G_1x40G_to_4x10G_explicit_breakout_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model,
                        fpc=slot_id, pic=pic,
                        master_port_id=get_master_port_id(port_id, 3)
                        )
                ])
        return ports

    def gen_juniper_qfx10008_60s_6q_ports(self, row_count, column_count, start_index,
                                          panel_id, slot_id=0, failure_domain_id=1,
                                          port_offset=0, row_offset=0,
                                          col_offset=0, model=None, pic=0):
        autoneg_port_ids = [2, 3, 5, 6, 8, 9, 11, 12,
                            14, 15, 17, 18, 20, 21, 23, 24,
                            26, 27, 29, 30, 32, 33, 35, 36,
                            38, 39, 41, 42, 44, 45, 47, 48,
                            50, 51, 53, 54, 56, 57, 59, 60]
        ports = [
            self.gen_10G_to_1x1G_port_with_select_autoneg(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=None, fpc=slot_id, pic=pic,
                autoneg_port_ids=autoneg_port_ids
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                3, 20, 1, 0, 0)
        ]
        ports.extend([
            self.gen_qfx10002_100G_40G_1x40G_to_4x10G_explicit_breakout_port(
                61, 1, 1, panel_id+1, slot_id,
                failure_domain_id, port_offset, model=model,
                fpc=slot_id, pic=pic)
        ])
        for (port_id, row_id, column_id) in [(62, 2, 1), (63, 1, 2), (64, 2, 2)]:
            ports.extend([
                self.gen_40G_40G_disabled_4x10G_explicit_breakout_port(
                    port_id, row_id, column_id, panel_id+1, slot_id,
                    failure_domain_id, port_offset, model=model,
                    fpc=slot_id, pic=pic)
            ])
        ports.extend([
            self.gen_qfx10002_100G_40G_1x40G_to_4x10G_explicit_breakout_port(
                65, 1, 3, panel_id+1, slot_id,
                failure_domain_id, port_offset, model=model,
                fpc=slot_id, pic=pic)
        ])
        ports.extend([
            self.gen_40G_40G_disabled_4x10G_explicit_breakout_port(
                66, 2, 3, panel_id+1, slot_id,
                failure_domain_id, port_offset, model=model,
                fpc=slot_id, pic=pic)
        ])
        return ports

    def gen_juniper_jnp_fpc_4cd_ports_interfaces(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
            model='JNP_FPC_4CD_LC', fpc=0, pic=0):
        return [
            self.gen_400G_to_4x100G_2x200G_8x50G_200G_to_2x100G_8x25G_100G_1x40_4x25_2x50_4x10(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                port_offset, model=model, fpc=fpc, pic=pic,
                set_speed_in_interfaces=True, connector='qsfp56dd')
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_juniper_jnp_fpc_16c_ports_interfaces(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
            model='JNP_FPC_16C_LC', fpc=0, pic=0):
        ports = []
        for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset):
            # Ports on juniper start with 0 where as in DP the port ids starts from 1
            # Here juniper ports 0, 4 requires a specific transformation which
            # correlates to port ids 1, 5 in DP.
            if port_id in [1, 5, 9, 13]:
                ports.extend([
                    self.gen_100G_1x40_4x25_2x50_4x10_port_breakout_explicit(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model, fpc=fpc,
                        pic=pic, intf_prefix='et', set_speed_in_interfaces=True)
                ])
            elif port_id in [3, 7, 11, 15]:
                ports.extend([
                    self.gen_100G_2x50_1x40_disabled_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model, fpc=fpc,
                        pic=pic, set_speed_in_interfaces=True)
                ])
            else:
                ports.extend([
                    self.gen_100G_40G_disabled_100G_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model, fpc=fpc,
                        pic=pic, set_speed_in_interfaces=True)
                ])
        return ports

    def gen_juniper_jnp_fpc_20y_ports(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
            model=None, fpc=0, pic=0):
        return [
            self.gen_50G_1x50G_to_1x25G_1x10G_intf_name_port(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                port_offset, model=model, fpc=fpc, pic=pic, intf_prefix='et',
                set_speed_in_interfaces=True)
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_juniper_ptx10k_lc1201_36cd_ports_interfaces(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
            model='PTX10K-LC1201-36CD', fpc=0, pic=0):
        return [
            self.gen_400G_to_4x100G_2x200G_8x50G_200G_to_2x100G_8x25G_100G_1x40_4x25_2x50_4x10_1x10(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                port_offset, model=model, fpc=fpc, pic=pic,
                set_speed_in_interfaces=True)
            for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_juniper_ptx10k_lc1202_36mr_ports_interfaces(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
            model='PTX10K-LC1202-36MR', fpc=0, pic=0):
        ports = []
        for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset):
            # Ports on juniper start with 0 where as in DP the port ids starts from 1
            # Here juniper ports 0, 4 requires a specific transformation which
            # correlates to port ids 1, 5 in DP.
            if port_id in [5, 11, 25, 31]:
                ports.extend([
                    self.gen_400G_to_4x100G_2x200G_8x50G_200G_to_2x100G_8x25G_100G_1x40_4x25_2x50_4x10_1x10(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model, fpc=fpc,
                        pic=pic, set_speed_in_interfaces=True)
                ])
            elif port_id in [2, 4, 20, 22]:
                ports.extend([
                    self.gen_100G_disabled_100G_port(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model, fpc=fpc,
                        pic=pic, set_speed_in_interfaces=True)
                ])
            else:
                ports.extend([
                    self.gen_100G_1x40_4x25_2x50_4x10_1x10G_port_breakout_explicit(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model=model, fpc=fpc,
                        pic=pic, intf_prefix='et', set_speed_in_interfaces=True)
                ])
        return ports

    def _gen_10G_non_breakout_port(self, port_id, row_id, col_id, panel_id,
                                   slot_id, failure_domain_id, port_offset,
                                   model, fpc=0, pic=0, display_id=None,
                                   intf_prefix=None, explicit_speed_10G=False):

        _gen_intfs_1x10G = \
            self._gen_intfs_1x10G_explicit_port_speed if explicit_speed_10G \
            else self._gen_intfs_1x10G

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(port_id, row_id, col_id, panel_id, "sfp",
                          [d.gen_transform(
                              _gen_intfs_1x10G(port_id, model, fpc, pic,
                                               intf_prefix),
                              transformation_id=1, is_default=True)],
                          slot_id, failure_domain_id, port_offset,
                          display_id=display_id, templatize=self.templatize,)

    def _gen_10G_1G_non_breakout_port(self, port_id, row_id, col_id, panel_id,
                                      slot_id, failure_domain_id, port_offset,
                                      model, fpc=0, pic=0, display_id=None,
                                      intf_prefix=None, explicit_speed_10G=False):

        if display_id is None:
            display_id = port_id + port_offset - 1

        gen_intfs_1x10G = self._gen_intfs_1x10G_explicit_port_speed \
                if explicit_speed_10G else self._gen_intfs_1x10G

        return d.gen_port(port_id, row_id, col_id, panel_id, "sfp",
                          [d.gen_transform(
                              gen_intfs_1x10G(port_id, model, fpc, pic,
                                              intf_prefix),
                              transformation_id=1, is_default=True),
                           d.gen_transform(
                               self._gen_intfs_1x1G(port_id, model, fpc, pic,
                                                    intf_prefix),
                               transformation_id=2, is_default=False),
                          ],
                          slot_id, failure_domain_id, port_offset,
                          display_id=display_id, templatize=self.templatize,)

    def gen_ports_10G_1G(self, row_count, column_count,
                         start_index, panel_id, slot_id=0,
                         failure_domain_id=1, port_offset=0,
                         row_offset=0, col_offset=0,
                         model=None, fpc=0, pic=0,
                         intf_prefix=None, explicit_speed_10G=False):
        return [
            self._gen_10G_1G_non_breakout_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=model, fpc=fpc, pic=pic,
                intf_prefix=intf_prefix,
                explicit_speed_10G=explicit_speed_10G,
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def _gen_10G_1G_global_non_breakout_port(self, port_id, row_id, col_id, panel_id,
                                             slot_id, failure_domain_id, port_offset,
                                             model, fpc=0, pic=0, display_id=None,
                                             intf_prefix=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(port_id, row_id, col_id, panel_id, "sfp+",
                          [d.gen_transform(
                              self._gen_intfs_1x10G(port_id, model, fpc, pic,
                                              intf_prefix),
                              transformation_id=1, is_default=True),
                           d.gen_transform(
                               self._gen_intfs_1x1G_explicit_port_speed(
                                   port_id, model, fpc, pic, intf_prefix),
                               transformation_id=2, is_default=False),
                          ],
                          slot_id, failure_domain_id, port_offset,
                          display_id=display_id, templatize=self.templatize)

    def gen_ports_10G_1x1G_global(self, row_count, column_count, start_index,
                                  panel_id, slot_id=0, failure_domain_id=1,
                                  port_offset=0, row_offset=0, col_offset=0,
                                  model=None, fpc=0, pic=0, intf_prefix=None):
        return [
            self._gen_10G_1G_global_non_breakout_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=model, fpc=fpc, pic=pic,
                intf_prefix=intf_prefix,
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_ports_sfp_non_breakout_capable(self, row_count, column_count,
                                           start_index, panel_id, slot_id=0,
                                           failure_domain_id=1, port_offset=0,
                                           row_offset=0, col_offset=0,
                                           model=None, fpc=0, pic=0,
                                           intf_prefix=None, explicit_speed_10G=False):
        return [
            self._gen_10G_non_breakout_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=model, fpc=fpc, pic=pic,
                intf_prefix=intf_prefix,
                explicit_speed_10G=explicit_speed_10G,
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def _gen_1G_non_breakout_port(
            self, port_id, row_id, col_id, panel_id,
            slot_id, failure_domain_id, port_offset, model, fpc=0, pic=0,
            display_id=None, connector_type='1GBaseT'):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(port_id, row_id, col_id, panel_id, connector_type,
                          [
                              d.gen_transform(
                                  self._gen_intfs_1x1G(port_id, model, fpc, pic),
                                  transformation_id=1, is_default=True)
                          ],
                          slot_id, failure_domain_id, port_offset,
                          display_id=display_id, templatize=self.templatize,)

    def gen_1G_non_breakout_capable_ports(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
            model=None, fpc=0, pic=0, connector_type='1GBaseT'):
        return [
            self._gen_1G_non_breakout_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=model, fpc=fpc, pic=pic,
                connector_type=connector_type,
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_100G_to_2x50G_1x40G_port(self, port_id, row_id, col_id,
                                     panel_id, slot_id, failure_domain_id,
                                     port_offset, model, fpc=0, pic=0,
                                     explicit_speed_50G=False, default_100G=True,
                                     default_40G=False, display_id=None,
                                     intf_prefix=None, set_speed_in_interfaces=False):

        if explicit_speed_50G:
            transformation_2_1x100G_to_2x50G = d.gen_transform(
                self._gen_intfs_1x100G_to_2x50G_breakout_explicit(
                    port_id, model, fpc, pic), transformation_id=2)
        else:
            if set_speed_in_interfaces:
                parent_breakout_interface = (self.make_intf_name(self.port_speed_to_prefix(50),
                                                                 port_id - 1, fpc, pic), 2, "50g")
                junos_setting_param_2x50_breakout = self.make_junos_setting_param(
                    fpc=fpc, pic=pic, port_id=port_id - 1,
                    global_speed='',
                    parent_breakout_interface=parent_breakout_interface,
                    breakout=True,
                )
            else:
                junos_setting_param_2x50_breakout = None
            transformation_2_1x100G_to_2x50G = d.gen_transform(
                self._gen_intfs_1x100G_to_2x50G_breakout(
                    port_id, model, fpc, pic, junos_setting_param_2x50_breakout
                ), transformation_id=2)

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(port_id, row_id, col_id, panel_id, "qsfp28",
                          [
                              d.gen_transform(
                                  self._gen_intfs_1x100G(port_id, model, fpc, pic, default=default_100G,
                                                         set_speed_in_interfaces=set_speed_in_interfaces),
                                  transformation_id=1,
                                  is_default=True),
                              transformation_2_1x100G_to_2x50G,
                              d.gen_transform(
                                  self._gen_intfs_1x40G(port_id, model, fpc, pic, default=default_40G,
                                                        set_speed_in_interfaces=set_speed_in_interfaces),
                                  transformation_id=3)
                          ], slot_id, failure_domain_id, port_offset,
                          display_id=display_id, templatize=self.templatize,)

    def gen_100G_1x40_4x25_2x50_4x10_port(self, port_id, row_id, col_id,
                                          panel_id, slot_id, failure_domain_id,
                                          port_offset, model, fpc=0, pic=0,
                                          default_speed='100G', display_id=None):
        if default_speed == '100G':
            gen_intfs_1x100G = self._gen_intfs_1x100G
        else:
            gen_intfs_1x100G = self._gen_intfs_1x100G_explicit_port_speed

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp28",
            [
                d.gen_transform(
                    gen_intfs_1x100G(port_id, model, fpc, pic),
                    transformation_id=1,
                    is_default=(default_speed == '100G')),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_2x50G_breakout(
                        port_id, model, fpc, pic),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x40G(port_id, model, fpc, pic,
                                          default=(default_speed == '40G')),
                    transformation_id=3, is_default=(default_speed == '40G')),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_4x25G_breakout(
                        port_id, model, fpc, pic),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_breakout(
                        port_id, model, fpc, pic),
                    transformation_id=5),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_explicit_breakout(
                        port_id, model, fpc, pic),
                    transformation_id=6),
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def breakout_setting_param(self, speed, speed_txt, breakouts, model, port_id,
                               fpc, pic, intf_prefix=None,
                               set_speed_in_interfaces=False,
                               unused_interfaces_list=None,
                               validations=None):

        prefix = intf_prefix or self.port_speed_to_prefix(speed)
        parent_breakout_interface = (
            self.make_intf_name(prefix, port_id - 1, fpc, pic),
            breakouts, speed_txt) if set_speed_in_interfaces else None
        if unused_interfaces_list is None:
            unused_interfaces_list = self.populate_unused_interfaces_list(
                model, port_id, fpc, pic, intf_prefix=intf_prefix or 'xe',
                speed=speed, breakouts=breakouts
                ) if set_speed_in_interfaces else None

        return self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id-1,
            global_speed=speed_txt if not set_speed_in_interfaces else '',
            parent_breakout_interface=parent_breakout_interface,
            unused_interfaces_list=unused_interfaces_list, breakout=True,
            validations=validations
        )

    def gen_100G_1x40_4x25_2x50_4x10_port_breakout_explicit(self, port_id, row_id, col_id,
                                                            panel_id, slot_id, failure_domain_id,
                                                            port_offset, model,
                                                            fpc=0, pic=0,
                                                            default_100G=True,
                                                            default_40G=False,
                                                            display_id=None,
                                                            intf_prefix=None,
                                                            set_speed_in_interfaces=False,
                                                            connector="qsfp28"):
        # Note: The default value isn't explicitly rendered. In the QFX5120-32C,
        # a "speed 40g" operand is NOT accepted in the chassis section for a port.
        # So if we want 40g, we must not say anything and use default=True.

        if display_id is None:
            display_id = port_id + port_offset - 1
        junos_setting_param_2x50_breakout = \
            self.breakout_setting_param(50, '50g', 2, model, port_id, fpc, pic,
                                        intf_prefix=intf_prefix,
                                        set_speed_in_interfaces=set_speed_in_interfaces)
        junos_setting_param_4x10_breakout = \
            self.breakout_setting_param(10, '10g', 4, model, port_id, fpc, pic,
                                        intf_prefix=intf_prefix,
                                        set_speed_in_interfaces=set_speed_in_interfaces)
        junos_setting_param_4x25_breakout = \
            self.breakout_setting_param(25, '25g', 4, model, port_id, fpc, pic,
                                        intf_prefix=intf_prefix,
                                        set_speed_in_interfaces=set_speed_in_interfaces)
        return d.gen_port(
            port_id, row_id, col_id, panel_id, connector,
            [
                d.gen_transform(
                    self._gen_intfs_1x100G(port_id, model, fpc, pic,
                                           default=default_100G, set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=1,
                    is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_2x50G_breakout(
                        port_id, model, fpc, pic, junos_setting_param=junos_setting_param_2x50_breakout),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x40G(port_id, model, fpc, pic,
                                          default=default_40G, set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_4x25G_breakout(
                        port_id, model, fpc, pic, junos_setting_param=junos_setting_param_4x25_breakout),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_breakout(
                        port_id, model, fpc, pic, intf_prefix, junos_setting_param=junos_setting_param_4x10_breakout),
                    transformation_id=5)
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    # This is for the higher order ports of the QFX5210.
    def gen_100G_1x40_2x50_disabled_4x25_4x10(self, port_id, row_id, col_id,
                                              panel_id, slot_id, failure_domain_id,
                                              port_offset, model,
                                              fpc=0, pic=0,
                                              default_100G=True,
                                              default_40G=False,
                                              display_id=None,
                                              intf_prefix=None,
                                              set_speed_in_interfaces=False,
                                              connector="qsfp28"):
        # Note: The default value isn't explicitly rendered. In the QFX5120-32C,
        # a "speed 40g" operand is NOT accepted in the chassis section for a port.
        # So if we want 40g, we must not say anything and use default=True.

        if display_id is None:
            display_id = port_id + port_offset - 1
        junos_setting_param_2x50_breakout = \
            self.breakout_setting_param(50, '50g', 2, model, port_id, fpc, pic,
                                        intf_prefix=intf_prefix,
                                        set_speed_in_interfaces=set_speed_in_interfaces)
        junos_setting_param_4x10_breakout = \
            self.breakout_setting_param(10, '10g', 4, model, port_id, fpc, pic,
                                        intf_prefix=intf_prefix,
                                        set_speed_in_interfaces=set_speed_in_interfaces)
        junos_setting_param_4x25_breakout = \
            self.breakout_setting_param(25, '25g', 4, model, port_id, fpc, pic,
                                        intf_prefix=intf_prefix,
                                        set_speed_in_interfaces=set_speed_in_interfaces)
        return d.gen_port(
            port_id, row_id, col_id, panel_id, connector,
            [
                d.gen_transform(
                    self._gen_intfs_1x100G(port_id, model, fpc, pic,
                                           default=default_100G, set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=1,
                    is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x40G(port_id, model, fpc, pic,
                                          default=default_40G, set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_2x50G_breakout(
                        port_id, model, fpc, pic, junos_setting_param=junos_setting_param_2x50_breakout),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x100G_disabled(
                        port_id, model, fpc, pic),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_4x25G_breakout(
                        port_id, model, fpc, pic, junos_setting_param=junos_setting_param_4x25_breakout),
                    transformation_id=5),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_breakout(
                        port_id, model, fpc, pic, intf_prefix, junos_setting_param=junos_setting_param_4x10_breakout),
                    transformation_id=6)
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_100G_1x40_4x25_2x50_4x10_1x25G_1x10G_port_breakout_explicit(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model='ACX7100-32C', fpc=0, pic=0, display_id=None,
            connector="qsfp28"):
        # Note: This function is only used for the case of ACX7100-32C
        # 'ACX7100-32C' model here is used as a trigger that controls generating an
        # unused_interfaces_list
        pg_2 = gen_port_group_name(port_id - 1, 2)
        pg_4 = gen_port_group_name(port_id - 1, 4)
        validations_1x100G = gen_pg_speed_validations(
            [(pg_2, '1x40or1x100'), (pg_4, 'not1x25not4x25')])
        validations_2x50G = gen_pg_speed_validations(
            [(pg_2, '2x50'), (pg_4, 'not1x25not4x25')])
        validations_4x10G = gen_pg_speed_validations(
            [(pg_2, '4x10upper'), (pg_4, 'no_constraint')])
        validations_4x25G = gen_pg_speed_validations(
            [(pg_2, '4x25upper'), (pg_4, 'not1x100not2x50')])
        validations_1x10G = gen_pg_speed_validations(
            [(pg_2, '1x25or1x10'), (pg_4, 'no_constraint')])
        validations_1x40G = gen_pg_speed_validations(
            [(pg_2, '1x40or1x100'), (pg_4, 'no_constraint')])
        validations_1x25G = gen_pg_speed_validations(
            [(pg_2, '1x25or1x10'), (pg_4, 'not1x100not2x50')])

        if display_id is None:
            display_id = port_id + port_offset - 1
        junos_setting_param_100G = self.make_junos_setting_param(
            validations=validations_1x100G)
        junos_setting_param_2x50_breakout = self.breakout_setting_param(
            50, '50g', 2, model, port_id, fpc, pic, intf_prefix='et',set_speed_in_interfaces=True, validations = validations_2x50G)
        junos_setting_param_4x10_breakout = self.breakout_setting_param(
            10, '10g', 4, model, port_id, fpc, pic, intf_prefix='et',
            set_speed_in_interfaces=True, validations = validations_4x10G)
        junos_setting_param_4x25_breakout = self.breakout_setting_param(
            25, '25g', 4, model, port_id, fpc, pic, intf_prefix='et',
            set_speed_in_interfaces=True, validations = validations_4x25G)
        junos_setting_param_10G = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1, speed_value='10', breakout=False,
            validations = validations_1x10G)
        junos_setting_param_40G = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1, speed_value='40', breakout=False,
            validations=validations_1x40G)
        junos_setting_param_25G = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1, speed_value='25', breakout=False,
            unused_interfaces_list=self.populate_unused_interfaces_list(
                model, port_id, fpc, pic, intf_prefix='et', speed=25),
            validations=validations_1x25G)

        return d.gen_port(
            port_id, row_id, col_id, panel_id, connector,
            [
                d.gen_transform(
                    self._gen_intfs_1x100G_explicit_port_speed(
                        port_id, model, fpc, pic,
                        setting_param=junos_setting_param_100G),
                    transformation_id=1,
                    is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_2x50G_breakout(
                        port_id, model, fpc, pic, junos_setting_param=junos_setting_param_2x50_breakout),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x40G(
                        port_id, model, fpc, pic,setting_param=junos_setting_param_40G),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_4x25G_breakout(
                        port_id, model, fpc, pic, junos_setting_param=junos_setting_param_4x25_breakout),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_breakout(
                        port_id, model, fpc, pic, intf_prefix='et', junos_setting_param=junos_setting_param_4x10_breakout),
                    transformation_id=5),
                d.gen_transform(
                    self._gen_intfs_1x25G(
                        port_id, model, fpc, pic,setting_param=junos_setting_param_25G),
                    transformation_id=6),
                d.gen_transform(
                    self._gen_intfs_1x10G(
                        port_id, model, fpc, pic, intf_prefix='et', setting_param=junos_setting_param_10G),
                    transformation_id=7)
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_100G_to_2x50G_1x40G_1x25G_1x10G_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, display_id=None, connector="qsfp28"):
        # Note: This function is only used for the case of ACX7100-32C

        if display_id is None:
            display_id = port_id + port_offset - 1

        pg_2 = gen_port_group_name(port_id - 1, 2)
        pg_4 = gen_port_group_name(port_id - 1, 4)
        validations_1x100G = gen_pg_speed_validations(
            [(pg_2, '1x40or1x100'), (pg_4, 'not1x25not4x25')])
        validations_2x50G = gen_pg_speed_validations(
            [(pg_2, '2x50'), (pg_4, 'not1x25not4x25')])
        validations_1x10G = gen_pg_speed_validations(
            [(pg_2, '1x25or1x10'), (pg_4, 'no_constraint')])
        validations_1x40G = gen_pg_speed_validations(
            [(pg_2, '1x40or1x100'), (pg_4, 'no_constraint')])
        validations_1x25G = gen_pg_speed_validations(
            [(pg_2, '1x25or1x10'), (pg_4, 'not1x100not2x50')])

        junos_setting_param_100G = self.make_junos_setting_param(
            validations=validations_1x100G)
        junos_setting_param_2x50_breakout = self.breakout_setting_param(
            50, '50g', 2, model, port_id, fpc, pic, intf_prefix='et',
            set_speed_in_interfaces=True,
            validations=validations_2x50G)
        junos_setting_param_10G = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id-1, speed_value='10', breakout=False,
            validations=validations_1x10G)
        junos_setting_param_40G = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id-1, speed_value='40', breakout=False,
            validations=validations_1x40G)
        junos_setting_param_25G = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id-1, speed_value='25', breakout=False,
            unused_interfaces_list=self.populate_unused_interfaces_list(
                model, port_id, fpc, pic, intf_prefix='et', speed=25),
            validations=validations_1x25G)


        return d.gen_port(
            port_id, row_id, col_id, panel_id, connector,
            [
                d.gen_transform(
                    self._gen_intfs_1x100G_explicit_port_speed(
                        port_id, model, fpc, pic,
                        setting_param=junos_setting_param_100G),
                    transformation_id=1,
                    is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_2x50G_breakout(
                        port_id, model, fpc, pic,
                        junos_setting_param=junos_setting_param_2x50_breakout),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x40G(
                        port_id, model, fpc, pic,setting_param=junos_setting_param_40G),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x25G(
                        port_id, model, fpc, pic, setting_param=junos_setting_param_25G),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x10G(
                        port_id, model, fpc, pic, intf_prefix='et',
                        setting_param=junos_setting_param_10G),
                    transformation_id=5)
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_100G_to_2x50G_1x40G_1x25G_1x10G_1x1G_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, default_100G=True,
            default_40G=False, display_id=None, intf_prefix=None,
            set_speed_in_interfaces=False, connector="qsfp28"):
        # Note: The default value isn't explicitly rendered. In the QFX5120-32C,
        # a "speed 40g" operand is NOT accepted in the chassis section for a port.
        # So if we want 40g, we must not say anything and use default=True.

        if display_id is None:
            display_id = port_id + port_offset - 1
        junos_setting_param_2x50_breakout = \
            self.breakout_setting_param(50, '50g', 2, model, port_id, fpc, pic,
                                        intf_prefix=intf_prefix,
                                        set_speed_in_interfaces=set_speed_in_interfaces)
        junos_setting_param_10G = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1, speed_value='10', breakout=False)
        junos_setting_param_25G = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1, speed_value='25', breakout=False)

        return d.gen_port(
            port_id, row_id, col_id, panel_id, connector,
            [
                d.gen_transform(
                    self._gen_intfs_1x100G(port_id, model, fpc, pic,
                                           default=default_100G,
                                           set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=1,
                    is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_2x50G_breakout(
                        port_id, model, fpc, pic,
                        junos_setting_param=junos_setting_param_2x50_breakout),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x40G(
                        port_id, model, fpc, pic, default=default_40G,
                        set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x25G(
                        port_id, model, fpc, pic,
                        setting_param=junos_setting_param_25G),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x10G(
                        port_id, model, fpc, pic, intf_prefix='et',
                        setting_param=junos_setting_param_10G),
                    transformation_id=5),
                d.gen_transform(
                    self._gen_intfs_1x1G(
                        port_id, model, fpc, pic, intf_prefix='et'),
                    transformation_id=6)
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_100G_1x40_4x25_2x50_4x10_1x10G_port_breakout_explicit(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, display_id=None, intf_prefix=None,
            set_speed_in_interfaces=False):
        if display_id is None:
            display_id = port_id + port_offset - 1

        unused_interfaces_list = self.populate_unused_interfaces_list(
            model=model, fpc=fpc, pic=pic, intf_prefix=intf_prefix or 'xe',
            port_id=port_id) if set_speed_in_interfaces else None

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x100G(
                        port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_2x50G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=2,
                        breakout_parent=set_speed_in_interfaces,
                        unused_interfaces_list=unused_interfaces_list),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x40G_explicit_port_speed(
                        port_id, model, fpc, pic,
                        set_speed_in_interfaces=set_speed_in_interfaces,
                        unused_interfaces_list=unused_interfaces_list),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_4x25G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=4,
                        breakout_parent=set_speed_in_interfaces,
                        unused_interfaces_list=unused_interfaces_list),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_explicit_breakout_intf_name(
                        port_id, model, fpc, pic, intf_prefix=intf_prefix or 'xe',
                        subports_count=4, breakout_parent=set_speed_in_interfaces,
                        unused_interfaces_list=unused_interfaces_list),
                    transformation_id=5),
                d.gen_transform(
                    self._gen_intfs_1x10G_explicit(
                        port_id, model, fpc, pic, intf_prefix=intf_prefix or 'xe',
                        set_speed_in_interfaces=set_speed_in_interfaces,
                        unused_interfaces_list=unused_interfaces_list),
                    transformation_id=6)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_10G_25G_50G(self, port_id, row_id, col_id,
                        panel_id, slot_id, failure_domain_id,
                        port_offset, model, fpc=0, pic=0,
                        display_id=None):
        if display_id is None:
            display_id = port_id + port_offset - 1
        setting_param_10G = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1, speed_value='10', breakout=False)
        setting_param_25G = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1, speed_value='25', breakout=False)
        setting_param_50G = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1, speed_value='50', breakout=False)

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "sfp56",
            [
                d.gen_transform(
                    self._gen_intfs_1x10G(port_id, model, fpc, pic, intf_prefix='et',
                                          setting_param=setting_param_10G),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x25G(
                        port_id, model, fpc, pic, setting_param=setting_param_25G),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x50G(
                        port_id, model, fpc, pic, setting_param=setting_param_50G),
                    transformation_id=3),
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_10G_25G(self, port_id, row_id, col_id,
                    panel_id, slot_id, failure_domain_id,
                    port_offset, model, fpc=0, pic=0,
                    display_id=None):
        if display_id is None:
            display_id = port_id + port_offset - 1
        setting_param_10G = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1, speed_value='10', breakout=False)
        setting_param_25G = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1, speed_value='25', breakout=False)
        return d.gen_port(
            port_id, row_id, col_id, panel_id, "sfp56",
            [
                d.gen_transform(
                    self._gen_intfs_1x10G(port_id, model, fpc, pic, intf_prefix='et',
                                          setting_param=setting_param_10G),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x25G(
                        port_id, model, fpc, pic, setting_param=setting_param_25G),
                    transformation_id=2),
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_400G_to_1x400G_2x200G_4x100G_1x100G_8x50G_1x40G_4x25G_4x10(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, intf_prefix=None, set_speed_in_interfaces=False,
            display_id=None, connector='qsfpdd', breakout_parent=False):
        if display_id is None:
            display_id = port_id + port_offset - 1

        junos_setting_param_4x100_breakout = \
            self.breakout_setting_param(100, '100g', 4, 'QFX5130-48C', port_id, fpc, pic,
                                        intf_prefix=intf_prefix,
                                        set_speed_in_interfaces=set_speed_in_interfaces)
        junos_setting_param_4x25_breakout = \
            self.breakout_setting_param(25, '25g', 4, 'QFX5130-48C', port_id, fpc, pic,
                                        intf_prefix=intf_prefix,
                                        set_speed_in_interfaces=set_speed_in_interfaces)
        junos_setting_param_4x10_breakout = \
            self.breakout_setting_param(10, '10g', 4, 'QFX5130-48C', port_id, fpc, pic,
                                        intf_prefix=intf_prefix,
                                        set_speed_in_interfaces=set_speed_in_interfaces)
        junos_setting_param_8x50_breakout = \
            self.breakout_setting_param(50, '50g', 8, 'QFX5130-48C', port_id, fpc, pic,
                                        intf_prefix=intf_prefix,
                                        set_speed_in_interfaces=set_speed_in_interfaces)

        return d.gen_port(
            port_id, row_id, col_id, panel_id, connector,
            [
                d.gen_transform(
                    self._gen_intfs_1x400G(port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x400G_to_2x200G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=2,
                        breakout_parent=breakout_parent),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_4x100G_breakout(
                        port_id, model, fpc, pic, junos_setting_param=junos_setting_param_4x100_breakout),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x100G_explicit_port_speed(
                        port_id, model, fpc, pic, set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x400G_to_8x50G_breakout(
                        port_id, model, fpc, pic,
                        junos_setting_param=junos_setting_param_8x50_breakout),
                    transformation_id=5),
                d.gen_transform(
                    self._gen_intfs_1x40G_explicit_port_speed(
                        port_id, model, fpc, pic, set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=6),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_4x25G_breakout(
                        port_id, model, fpc, pic, junos_setting_param=junos_setting_param_4x25_breakout),
                    transformation_id=7),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_breakout(
                        port_id, model, fpc, pic, junos_setting_param=junos_setting_param_4x10_breakout, intf_prefix=intf_prefix),
                    transformation_id=8),
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )


    def gen_400G_to_4x100G_2x200G_8x50G_200G_to_2x100G_8x25G_100G_1x40_4x25_2x50_4x10(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, set_speed_in_interfaces=False,
            display_id=None, connector='qsfpdd'):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, connector,
            [
                d.gen_transform(
                    self._gen_intfs_1x400G(port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x400G_to_4x100G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=4, breakout_parent=set_speed_in_interfaces),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x400G_to_2x200G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=2,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x400G_to_8x50G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=8,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x200G_explicit_port_speed(
                        port_id, model, fpc, pic, set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=5),
                d.gen_transform(
                    self._gen_intfs_1x200G_to_2x100G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=2,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=6),
                d.gen_transform(
                    self._gen_intfs_1x200G_to_8x25G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=8,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=7),
                d.gen_transform(
                    self._gen_intfs_1x100G_explicit_port_speed(
                        port_id, model, fpc, pic, set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=8),
                d.gen_transform(
                    self._gen_intfs_1x40G_explicit_port_speed(
                        port_id, model, fpc, pic, set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=9),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_2x50G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=2,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=10),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_4x25G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=4,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=11),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_explicit_breakout_intf_name(
                        port_id, model, fpc, pic, intf_prefix='et',
                        subports_count=4,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=12)
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_400G_to_4x100G_2x200G_8x50G_200G_to_2x100G_8x25G_100G_1x40_4x25_2x50_4x10_1x10(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, set_speed_in_interfaces=False,
            display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, 'qsfp56dd',
            [
                d.gen_transform(
                    self._gen_intfs_1x400G(port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x400G_to_4x100G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=4,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x400G_to_2x200G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=2,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x400G_to_8x50G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=8,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x200G_explicit_port_speed(
                        port_id, model, fpc, pic,
                        set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=5),
                d.gen_transform(
                    self._gen_intfs_1x200G_to_2x100G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=2,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=6),
                d.gen_transform(
                    self._gen_intfs_1x200G_to_8x25G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=8,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=7),
                d.gen_transform(
                    self._gen_intfs_1x100G_explicit_port_speed(
                        port_id, model, fpc, pic,
                        set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=8),
                d.gen_transform(
                    self._gen_intfs_1x40G_explicit_port_speed(
                        port_id, model, fpc, pic,
                        set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=9),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_2x50G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=2,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=10),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_4x25G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=4,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=11),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_explicit_breakout_intf_name(
                        port_id, model, fpc, pic, intf_prefix='et',
                        subports_count=4,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=12),
                d.gen_transform(
                    self._gen_intfs_1x10G_explicit(
                        port_id, model, fpc, pic, intf_prefix='et',
                        set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=13),
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_qfx5240_64OD_osfp_port(
        self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
        model, fpc=0, pic=0, intf_prefix='et', connector='osfp',
        ver='any'):

        display_id = port_id - 1
        if ver == '22.2':
            validations_none = None
            validations_4x = None
            validations_8x = None
            # interface et-0/0/33,et-0/0/35,et-0/0/37...et-0/0/63 is set as unused
            # when interface et-0/0/0,et-0/0/2,et-0/0/4...et-0/0/30 is set as 8x100
            # interface et-0/0/1,et-0/0/3,et-0/0/5...et-0/0/31 is set as unused
            # when interface et-0/0/32,et-0/0/34,et-0/0/36...et-0/0/62 is set as
            # 8x100
            unused_interfaces_list_8x100 = ["{}-{}/{}/{}".format(
                intf_prefix, fpc, pic,
                port_id + 32 if port_id < 32 else port_id - 32)]
        else:
            top_id = 4 * (display_id // 4)
            if display_id - top_id in [0, 3]:
                pg = '_'.join('P'+ str(i) for i in [top_id, top_id + 3])
            else:
                pg = '_'.join('P'+ str(i) for i in [top_id + 1, top_id + 2])
            validations_none = gen_pg_speed_validations([(pg, 'no_constraint')])
            validations_4x = gen_pg_speed_validations([(pg, 'not8x100not8x50')])
            validations_8x = gen_pg_speed_validations([(pg, 'not4x100not4x200')])
            # interface et-0/0/3,et-0/0/7,et-0/0/11...et-0/0/63 is set as unused
            # when interface et-0/0/0,et-0/0/4,et-0/0/8...et-0/0/60 is set as 8x100
            # interface et-0/0/1,et-0/0/5,et-0/0/9...et-0/0/61 is set as unused
            # when interface et-0/0/2,et-0/0/4,et-0/0/6...et-0/0/62 is set as 8x100
            unused_interfaces_list_8x100 = ["{}-{}/{}/{}".format(
                    intf_prefix, fpc, pic,
                    display_id + 3 if top_id == display_id else display_id - 1)]
        junos_setting_param_1x800 = self.make_junos_setting_param(
            validations=validations_none)
        junos_setting_param_2x400_breakout = \
            self.breakout_setting_param(
                400, '400g', 2, 'QFX5240-64QD', port_id, fpc, pic,
                intf_prefix=intf_prefix, set_speed_in_interfaces=True,
                validations=validations_none)
        junos_setting_param_8x100_breakout = \
            self.breakout_setting_param(
                100, '100g', 8, 'QFX5240-64OD', port_id, fpc, pic,
                intf_prefix=intf_prefix, set_speed_in_interfaces=True,
                unused_interfaces_list=unused_interfaces_list_8x100,
                validations=validations_8x)
        junos_setting_param_4x200_breakout = \
            self.breakout_setting_param(
                200, '200g', 4, 'QFX5240-64OD', port_id, fpc, pic,
                intf_prefix=intf_prefix, set_speed_in_interfaces=True,
                validations=validations_4x)
        return d.gen_port(
            port_id, row_id, col_id, panel_id, connector,
            [
                d.gen_transform(
                    self._gen_intfs_1x800G(port_id, model, fpc, pic,
                        setting_param=junos_setting_param_1x800),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x800G_to_2x400G_breakout_explicit(
                        port_id, model, fpc, pic,
                        setting_param=junos_setting_param_2x400_breakout),
                    transformation_id=2),
            ] + ([
                d.gen_transform(
                    self._gen_intfs_1x800G_to_8x100G_breakout_explicit(
                        port_id, fpc, pic,
                        junos_setting_param=junos_setting_param_8x100_breakout),
                    transformation_id=3),
            ] if (port_id - 1) % 2 == 0 else []) + ([] if ver == '22.2' else[
                d.gen_transform(
                    self._gen_intfs_1x800G_to_4x200G_breakout_explicit(
                        port_id, fpc, pic,
                        setting_param=junos_setting_param_4x200_breakout),
                    transformation_id=4 if (port_id - 1) % 2 == 0 else 3),
            ]), slot_id, failure_domain_id, display_id=display_id,
            templatize=self.templatize,
        )

    def gen_qfx5240_64QD_port(
        self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
        port_offset, model, fpc=0, pic=0, intf_prefix='et', connector='qsfpdd',
        ver='any'):

        display_id = port_id + port_offset - 1
        if ver == '22.2':
            validations_none = None
            validations_4x = None
            validations_8x = None
        else:
            pg = gen_port_group_name(display_id, 2)
            validations_none = gen_pg_speed_validations([(pg, 'no_constraint')])
            validations_4x = gen_pg_speed_validations([(pg, 'not8x100not8x50')])
            validations_8x = gen_pg_speed_validations([(pg, 'not4x100not4x200')])
        junos_setting_param_1x800 = self.make_junos_setting_param(
            validations=validations_none)
        junos_setting_param_2x400_breakout = \
            self.breakout_setting_param(
                400, '400g', 2, 'QFX5240-64QD', port_id, fpc, pic,
                intf_prefix=intf_prefix, set_speed_in_interfaces=True,
                validations=validations_none)
        junos_setting_param_1x400 = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1, speed_value='400',
            breakout=False, validations=validations_none,)
        junos_setting_param_4x100_breakout = \
            self.breakout_setting_param(
                100, '100g', 4, 'QFX5240-64QD', port_id, fpc, pic,
                intf_prefix=intf_prefix, set_speed_in_interfaces=True,
                validations=validations_4x)
        junos_setting_param_1x100 = self.make_junos_setting_param(
            fpc=fpc, pic=pic, port_id=port_id - 1, speed_value='100',
            breakout=False, validations=validations_none,)
        junos_setting_param_8x100_breakout = \
            self.breakout_setting_param(
                100, '100g', 8, 'QFX5240-64QD', port_id, fpc, pic,
                intf_prefix=intf_prefix, set_speed_in_interfaces=True,
                unused_interfaces_list=["{}-{}/{}/{}".format(
                    intf_prefix, fpc, pic, port_id)],
                validations=validations_8x)
        junos_setting_param_8x50_breakout = \
            self.breakout_setting_param(
                50, '50g', 8, 'QFX5240-64QD', port_id, fpc, pic,
                intf_prefix=intf_prefix, set_speed_in_interfaces=True,
                unused_interfaces_list=["{}-{}/{}/{}".format(
                    intf_prefix, fpc, pic, port_id)],
                validations=validations_8x)
        junos_setting_param_4x200_breakout = \
            self.breakout_setting_param(
                200, '200g', 4, 'QFX5240-64QD', port_id, fpc, pic,
                intf_prefix=intf_prefix, set_speed_in_interfaces=True,
                validations=validations_4x)
        junos_setting_param_2x200_breakout = \
            self.breakout_setting_param(
                200, '200g', 2, 'QFX5240-64QD', port_id, fpc, pic,intf_prefix=intf_prefix, set_speed_in_interfaces=True,
                validations=validations_none)

        return d.gen_port(
            port_id, row_id, col_id, panel_id, connector,
            [
                d.gen_transform(
                    self._gen_intfs_1x800G(port_id, model, fpc, pic,
                    setting_param=junos_setting_param_1x800),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x800G_to_2x400G_breakout_explicit(
                        port_id, model, fpc, pic,
                        setting_param=junos_setting_param_2x400_breakout),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x400G_explicit_port_speed(
                        port_id, model, fpc, pic,
                    setting_param=junos_setting_param_1x400),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x400G_to_4x100G_breakout_explicit(
                        port_id, model, fpc, pic,
                        setting_param=junos_setting_param_4x100_breakout),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x100G_explicit_port_speed(
                        port_id, model, fpc, pic,
                        setting_param=junos_setting_param_1x100),
                    transformation_id=5),
            ] + ([
                d.gen_transform(
                    self._gen_intfs_1x800G_to_8x100G_breakout_explicit(
                        port_id, fpc, pic,
                        junos_setting_param=junos_setting_param_8x100_breakout),
                    transformation_id=6),
                d.gen_transform(
                    self._gen_intfs_1x400G_to_8x50G_breakout_explicit(
                        port_id, fpc, pic,
                        setting_param=junos_setting_param_8x50_breakout),
                    transformation_id=7),
            ] if (port_id -1) % 2 == 0 else []) + ([] if ver == '22.2' else[
                d.gen_transform(
                    self._gen_intfs_1x800G_to_4x200G_breakout_explicit(
                        port_id, fpc, pic,
                        setting_param=junos_setting_param_4x200_breakout),
                    transformation_id=8 if (port_id -1) % 2 == 0 else 6),
                d.gen_transform(
                    self._gen_intfs_1x400G_to_2x200G_breakout_explicit(
                        port_id, fpc, pic,
                        setting_param=junos_setting_param_2x200_breakout),
                    transformation_id=9 if (port_id -1) % 2 == 0 else 7),
            ]), slot_id, failure_domain_id, port_offset, display_id=display_id,
            templatize=self.templatize,
        )

    def gen_400G_to_4x100G_8x50G_100G_to_4x25G_2x50G_40G_to_4x10G_2x100G(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, set_speed_in_interfaces=True,
            display_id=None, connector='qsfp56dd'):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, connector,
            [
                d.gen_transform(
                    self._gen_intfs_1x400G(port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x400G_to_4x100G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=4,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x400G_to_8x50G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=8,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x100G_explicit_port_speed(
                        port_id, model, fpc, pic,
                        set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_2x50G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=2,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=5),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_4x25G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=4,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=6),
                d.gen_transform(
                    self._gen_intfs_1x40G_explicit_port_speed(
                        port_id, model, fpc, pic,
                        set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=7),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_explicit_breakout_intf_name(
                        port_id, model, fpc, pic, intf_prefix='et',
                        subports_count=4, breakout_parent=set_speed_in_interfaces),
                    transformation_id=8),
                d.gen_transform(
                    self._gen_intfs_1x200G_to_2x100G_breakout_explicit(
                        port_id, model, fpc, pic=0,
                        subports_count=2,
                        breakout_parent=set_speed_in_interfaces), transformation_id=9)
            ], slot_id, failure_domain_id, port_offset, display_id=display_id,
            templatize=self.templatize,
        )

    def gen_400G_4x100G_100G_to_4x25G_40G_to_4x10G_2x200G_8x50G_1x200G_2x100G_intf_name_explicit_breakout_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset,
            model, fpc=0, pic=0, intf_prefix=None, set_speed_in_interfaces=False,
            breakout_parent=False, display_id=None):

        unused_port_list = self.populate_unused_port_list(model="QFX5220-32CD", port_id=port_id)
        junos_setting_param_8x50_breakout = \
            self.breakout_setting_param(50, '50g', 8, 'QFX5130-32CD', port_id, fpc, pic,
                                        intf_prefix=intf_prefix,
                                        set_speed_in_interfaces=set_speed_in_interfaces)

        if display_id is None:
            display_id = port_id + port_offset - 1

        transformation = [
            d.gen_transform(
                self._gen_intfs_1x400G(port_id, model, fpc, pic),
                transformation_id=1, is_default=True),
            d.gen_transform(
                self._gen_intfs_1x400G_to_4x100G_breakout_explicit(
                    port_id, model, fpc, pic, subports_count=4, breakout_parent=breakout_parent),
                transformation_id=2),
            d.gen_transform(
                self._gen_intfs_1x100G_explicit_port_speed(
                    port_id, model, fpc, pic, set_speed_in_interfaces=set_speed_in_interfaces),
                transformation_id=3),
            d.gen_transform(
                self._gen_intfs_1x100G_to_4x25G_breakout_explicit(
                    port_id, model, fpc, pic, subports_count=4, breakout_parent=breakout_parent),
                transformation_id=4),
            d.gen_transform(
                self._gen_intfs_1x40G_explicit_port_speed(
                    port_id, model, fpc, pic, set_speed_in_interfaces=set_speed_in_interfaces),
                transformation_id=5),
            d.gen_transform(
                self._gen_intfs_1x40G_to_4x10G_explicit_breakout_intf_name(
                    port_id, model, fpc, pic, intf_prefix=intf_prefix or 'xe', subports_count=4,
                    breakout_parent=breakout_parent),
                transformation_id=6),
            d.gen_transform(
                self._gen_intfs_1x400G_to_2x200G_breakout_explicit(
                    port_id, model, fpc, pic, subports_count=2,
                    breakout_parent=breakout_parent),
                transformation_id=7),
            d.gen_transform(
                self._gen_intfs_1x200G_explicit_port_speed(
                    port_id, model, fpc, pic, set_speed_in_interfaces=set_speed_in_interfaces),
                transformation_id=8),
            d.gen_transform(
                self._gen_intfs_1x200G_to_2x100G_breakout_explicit(
                    port_id, model, fpc, pic, subports_count=2,
                    breakout_parent=set_speed_in_interfaces),
                transformation_id=9),
            d.gen_transform(
                self._gen_intfs_1x100G_to_2x50G_breakout_explicit(
                    port_id, model, fpc, pic, subports_count=2,
                    breakout_parent=set_speed_in_interfaces),
                transformation_id=10)
            ]
        if port_id in range(1, 31 + 1, 2):
            if model == "QFX5220-32CD":
                transformation.append(d.gen_transform(
                    self._gen_intfs_nxmG_breakout_explicit(
                        port_id, model, fpc, pic,
                        subports_count=8, speed=50, unused_port_list=unused_port_list),
                    transformation_id=len(transformation) + 1))
            else:
                transformation.append(d.gen_transform(
                    self._gen_intfs_1x400G_to_8x50G_breakout(
                        port_id, model, fpc, pic,
                        junos_setting_param=junos_setting_param_8x50_breakout),
                    transformation_id=len(transformation) + 1))
        if model == "QFX5220-32CD":
            transformation.append(
                d.gen_transform(
                    self._gen_intfs_1x50G_explicit_port_speed(
                        port_id, model, fpc, pic, set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=len(transformation) + 1))
            if port_id in [1, 4, 5, 8, 9, 12, 13, 16, 17, 20, 21, 24, 25, 28, 29, 32]:
                transformation.append(d.gen_transform(
                    self._gen_intfs_nxmG_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=3,
                        speed=100, breakout_parent=set_speed_in_interfaces),
                    transformation_id=len(transformation) + 1))

        return d.gen_port(
            port_id, row_id, col_id, panel_id, 'qsfpdd',
            transformation,
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_100G_to_1x100G_1x50G_1x25G_1x10G_2x50G(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset,
            model, fpc=0, pic=0, intf_prefix=None, set_speed_in_interfaces=False,
            breakout_parent=False, display_id=None, connector='sfpdd'):
        junos_setting_param_2x50_breakout = \
            self.breakout_setting_param(50, '50g', 2, 'QFX5130-48C', port_id, fpc, pic,
                                        intf_prefix=intf_prefix,
                                        set_speed_in_interfaces=set_speed_in_interfaces)

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, connector,
            [
                d.gen_transform(
                    self._gen_intfs_1x100G(port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x50G_explicit_port_speed(
                        port_id, model, fpc, pic, set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x25G_explicit_port_speed(
                        port_id, model, fpc, pic, set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x10G_explicit(port_id, model, fpc, pic, intf_prefix=intf_prefix,
                                                   set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_2x50G_breakout(
                        port_id, model, fpc, pic, junos_setting_param=junos_setting_param_2x50_breakout),
                    transformation_id=5)
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_100G_to_1x100G_1x50G_1x25G_1x10G(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset,
            model, fpc=0, pic=0, intf_prefix=None, set_speed_in_interfaces=False,
            breakout_parent=False, display_id=None, connector='sfpdd'):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, connector,
            [
                d.gen_transform(
                    self._gen_intfs_1x100G(port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x50G_explicit_port_speed(
                        port_id, model, fpc, pic, set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x25G_explicit_port_speed(
                        port_id, model, fpc, pic, set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x10G_explicit(port_id, model, fpc, pic, intf_prefix=intf_prefix,
                                                   set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=4),
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_400G_4x100G_2x200_3x100_200G_2x100_4x50_100G_to_4x25G_2x50_50G_40G_to_4x10G_intf_name_explicit_breakout_port(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset,
            model, fpc=0, pic=0, intf_prefix=None, set_speed_in_interfaces=False,
            display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, 'qsfpdd',
            [
                d.gen_transform(
                    self._gen_intfs_1x400G(port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x400G_to_4x100G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=4,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x400G_to_2x200G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=2,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x200G_explicit_port_speed(port_id, model, fpc, pic,
                                                               set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x200G_to_2x100G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=2,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=5),
                d.gen_transform(
                    self._gen_intfs_1x200G_to_4x50G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=4,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=6),
                d.gen_transform(
                    self._gen_intfs_1x100G_explicit_port_speed(port_id, model, fpc, pic,
                                                               set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=7),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_4x25G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=4,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=8),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_2x50G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=2,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=9),
                d.gen_transform(
                    self._gen_intfs_1x50G_explicit_port_speed(port_id, model, fpc, pic,
                                                              set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=10),
                d.gen_transform(
                    self._gen_intfs_1x40G_explicit_port_speed(port_id, model, fpc, pic,
                                                              set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=11),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_explicit_breakout_intf_name(
                        port_id, model, fpc, pic, intf_prefix=intf_prefix, subports_count=4,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=12)
            ] + ([
                d.gen_transform(
                    self._gen_intfs_1x400G_to_3x100G_breakout_explicit(
                        port_id, model, fpc, pic, subports_count=3,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=13),
            ] if port_id in range(34, 64 + 1, 2) else []),
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_100G_2x50_1x40_disabled_port(self, port_id, row_id, col_id,
                                         panel_id, slot_id, failure_domain_id,
                                         port_offset, model, fpc=0, pic=0,
                                         set_speed_in_interfaces=False,
                                         display_id=None):
        if display_id is None:
            display_id = port_id + port_offset - 1

        unused_interfaces_list = self.populate_unused_interfaces_list(
            model, port_id, fpc, pic, intf_prefix='et', speed=50)

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x100G(port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_2x50G_breakout_explicit(
                        port_id, model, fpc, pic,
                        subports_count=2,
                        unused_interfaces_list=unused_interfaces_list if
                        set_speed_in_interfaces else None,
                        breakout_parent=set_speed_in_interfaces),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x40G_explicit_port_speed(
                        port_id, model, fpc, pic,
                        set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x100G_disabled(
                        port_id, model, fpc, pic),
                    transformation_id=4)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_100G_1x40_2x50_disabled_port(self, port_id, row_id, col_id,
                                         panel_id, slot_id, failure_domain_id,
                                         port_offset, model, fpc=0, pic=0,
                                         display_id=None):
        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x100G(port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x40G_explicit_port_speed(
                        port_id, model, fpc, pic),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_2x50G_breakout_explicit(
                        port_id, model, fpc, pic),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x100G_disabled(
                        port_id, model, fpc, pic),
                    transformation_id=4)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_1G_100M_10M_port(self, port_id, row_id, col_id,
                             panel_id, slot_id, failure_domain_id,
                             port_offset, model, fpc=0, pic=0,
                             display_id=None, explicit_1G=False,
                             explicit_100M=False, explicit_10M=False):
        if display_id is None:
            display_id = port_id + port_offset - 1

        gen_1G = (self._gen_intfs_1x10G_to_1x1G_explicit_intf_speed
                  if explicit_1G else self._gen_intfs_1x1G)
        gen_100M = (self._gen_intfs_1x100M_explicit_port_speed
                    if explicit_100M else self._gen_intfs_1x100M)
        gen_10M = (self._gen_intfs_1x10M_explicit_port_speed
                   if explicit_10M else self._gen_intfs_1x10M)

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "1GBaseT",
            [
                d.gen_transform(
                    gen_1G(port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    gen_100M(
                        port_id, model, fpc, pic),
                    transformation_id=2),
                d.gen_transform(
                    gen_10M(
                        port_id, model, fpc, pic),
                    transformation_id=3)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_1G_100M_10M_ports(self, row_count, column_count, start_index,
                              panel_id, slot_id=0, failure_domain_id=1,
                              port_offset=0, row_offset=0, col_offset=0,
                              model=None, fpc=0, pic=0, explicit_1G=False,
                              explicit_100M=False, explicit_10M=False):
        return [
            self.gen_1G_100M_10M_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model, fpc=fpc, pic=pic,
                explicit_1G=explicit_1G, explicit_100M=explicit_100M,
                explicit_10M=explicit_10M
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_1G_100M_port(self, port_id, row_id, col_id,
                         panel_id, slot_id, failure_domain_id,
                         port_offset, model, fpc=0, pic=0,
                         display_id=None, connector_type='sfp',
                         intf_prefix=None, set_speed_in_interfaces=False):
        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, connector_type,
            [
                d.gen_transform(
                    self._gen_intfs_1x1G(port_id, model, fpc, pic,
                                         intf_prefix=intf_prefix),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x100M(
                        port_id, model, fpc, pic,
                        intf_prefix=intf_prefix or 'ge',
                        set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=2)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id,
        )

    def gen_1G_100M_ports(self, row_count, column_count, start_index,
                          panel_id, slot_id=0, failure_domain_id=1,
                          port_offset=0, row_offset=0, col_offset=0,
                          fpc=0, pic=0, connector_type="sfp", model=None,
                          intf_prefix=None, set_speed_in_interfaces=False):
        return [
            self.gen_1G_100M_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model, fpc=fpc, pic=pic,
                connector_type=connector_type, intf_prefix=intf_prefix,
                set_speed_in_interfaces=set_speed_in_interfaces
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_10G_5G_2dot5G_1G_100M(self, port_id, row_id, col_id,
                                  panel_id, slot_id, failure_domain_id,
                                  port_offset, model, fpc=0, pic=0,
                                  display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "10GBaseT",
            [
                d.gen_transform(
                    self._gen_intfs_1x10G(port_id, model, fpc, pic, intf_prefix='mge'),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x5G(port_id, model, fpc, pic, intf_prefix='mge'),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x2dot5G(
                        port_id, model, fpc, pic, intf_prefix='mge'),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x1G_explicit_port_speed(
                        port_id, model, fpc, pic, intf_prefix='mge'),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x100M(
                        port_id, model, fpc, pic, intf_prefix='mge'),
                    transformation_id=5)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_10G_5G_1G_100M_ports(self, row_count, column_count, start_index,
                                 panel_id, slot_id=0, failure_domain_id=1,
                                 port_offset=0, row_offset=0, col_offset=0,
                                 model=None, fpc=0, pic=0,
                                 set_speed_in_interfaces=False,
                                 connector_type="10GBaseT", intf_prefix=None):
        return [
            self.gen_10G_5G_1G_100M(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model, fpc=fpc, pic=pic,
                set_speed_in_interfaces=set_speed_in_interfaces,
                connector_type=connector_type, intf_prefix=intf_prefix or 'ge'
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_10G_5G_1G_100M(self, port_id, row_id, col_id,
                           panel_id, slot_id, failure_domain_id,
                           port_offset, model, fpc=0, pic=0,
                           set_speed_in_interfaces=False, display_id=None,
                           connector_type='10GBaseT', intf_prefix=None):
        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, connector_type,
            [
                d.gen_transform(
                    self._gen_intfs_1x10G(port_id, model, fpc, pic, intf_prefix=intf_prefix),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x5G(
                        port_id, model, fpc, pic, intf_prefix=intf_prefix,
                        set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x1G_explicit_port_speed(
                        port_id, model, fpc, pic, intf_prefix=intf_prefix,
                        set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x100M(
                        port_id, model, fpc, pic, intf_prefix=intf_prefix,
                        set_speed_in_interfaces=set_speed_in_interfaces),
                    transformation_id=4)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_10G_5G_1G_100M_mge_ports(self, port_id, row_id, col_id,
                                     panel_id, slot_id, failure_domain_id,
                                     port_offset, model, fpc=0, pic=0,
                                     display_id=None, connector_type='10GBaseT'):
        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, connector_type,
            [
                d.gen_transform(
                    self._gen_intfs_1x10G_explicit_port_speed(port_id, model, fpc, pic, intf_prefix='mge'),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x5G_explicit_port_speed(port_id, model, fpc, pic, intf_prefix='mge'),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x10G_to_1x1G_explicit_intf_speed(
                        port_id, model, fpc, pic, intf_prefix='mge'),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x100M_explicit_port_speed(
                        port_id, model, fpc, pic, intf_prefix='mge'),
                    transformation_id=4)
            ],
            slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_juniper_qfx5120_32c_ports(self, row_count, column_count,
                                      start_index, panel_id, slot_id=0,
                                      failure_domain_id=1, port_offset=0,
                                      row_offset=0, col_offset=0, fpc=0, pic=0):
        return [
            self.gen_100G_1x40_4x25_2x50_4x10_port_breakout_explicit(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=None, fpc=fpc, pic=pic,
                default_100G=False, default_40G=True
            )
            if port_id != 32
            else self.gen_100G_to_2x50G_1x40G_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=None, fpc=fpc, pic=pic,
                explicit_speed_50G=True, default_100G=False, default_40G=True,
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_juniper_qfx5200_32c_ports(self, row_count, column_count,
                                      start_index, panel_id, slot_id=0,
                                      failure_domain_id=1, port_offset=0,
                                      row_offset=0, col_offset=0, fpc=0, pic=0):
        return [
            self.gen_100G_1x40_4x25_2x50_4x10_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=None, fpc=fpc, pic=pic
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_juniper_qfx5230_64cd_ports(self, row_count, column_count,
                                       start_index, panel_id, slot_id=0,
                                       failure_domain_id=1, port_offset=0,
                                       row_offset=0, col_offset=0, fpc=0, pic=0):
        return [
            self.gen_400G_4x100G_2x200_3x100_200G_2x100_4x50_100G_to_4x25G_2x50_50G_40G_to_4x10G_intf_name_explicit_breakout_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=None, fpc=fpc, pic=pic,
                intf_prefix='et', set_speed_in_interfaces=True
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_juniper_qfx5210_64c_ports(self, row_count, column_count,
                                      start_index, panel_id, slot_id=0,
                                      failure_domain_id=1, port_offset=0,
                                      row_offset=0, col_offset=0, fpc=0, pic=0):
        return [
            self.gen_100G_1x40_4x25_2x50_4x10_port_breakout_explicit(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=None, fpc=slot_id, pic=pic
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count//2, start_index, row_offset, col_offset)
        ] + \
        [
            self.gen_100G_1x40_2x50_disabled_4x25_4x10(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=None, fpc=slot_id, pic=pic
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count//2, start_index+32, row_offset=2,
                col_offset=col_offset)
        ] + \
        [
            self.gen_10G_to_1x1G_port(
                port_id, row_id, column_id, panel_id+1, slot_id,
                failure_domain_id, port_offset, model=None, fpc=slot_id, pic=pic
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                2, 1, 65, 0, 0)
        ]

    def gen_juniper_ex4300_48mp_ports(self, row_count, column_count,
                                      start_index, panel_id, slot_id=0,
                                      failure_domain_id=1, port_offset=0,
                                      row_offset=0, col_offset=0, fpc=0, pic=0):

        return [
            self.gen_1G_100M_10M_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=None, fpc=slot_id, pic=pic,
                explicit_1G=True, explicit_100M=True, explicit_10M=True
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count//2, start_index, row_offset, col_offset)

        ] + \
        [
            self.gen_10G_5G_1G_100M_mge_ports(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=None, fpc=slot_id, pic=pic
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count//2, start_index+24, row_offset, col_offset=12)
        ] + \
        [
            self.gen_10G_to_1x1G_port_for_ex4300_48mp(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=None, fpc=slot_id, pic=2,
                intf_prefix='xe'
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(2, 2, 49, 0, col_offset=24)
        ] + \
        [
            self.gen_100G_to_1x100G_1x40G_4x25G_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=None, fpc=slot_id, pic=2
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(2, 1, 53, 0, col_offset=26)
        ]

    def gen_juniper_qfx5240_64od_ports(
        self, row_count, column_count, start_index, panel_id, slot_id=0,
        failure_domain_id=1, row_offset=0, col_offset=0,
        fpc=0, pic=0, ver='any'):
        return [
            self.gen_qfx5240_64OD_osfp_port(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                model='QFX5240-64OD', fpc=fpc, pic=pic, intf_prefix='et', ver=ver)
            for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset
            )
        ]

    def gen_juniper_qfx5240_64qd_ports(
        self, row_count, column_count, start_index, panel_id, slot_id=0,
        failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
        fpc=0, pic=0, ver='any'):

        return [
            self.gen_qfx5240_64QD_port(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                port_offset, model='QFX5240-64QD', fpc=fpc, pic=pic,
                intf_prefix='et', ver=ver)
            for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_juniper_qfx5220_128c_ports(self, row_count, column_count, start_index, panel_id, slot_id=0,
                                       failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
                                       model=None, fpc=0, pic=0):
        ports = []
        for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset):
            # Any of the QSFP28 ports can be configured as 100 Gbps or 40 Gbps.
            # Every fourth port (0, 4, 8...124) can be configured as channelized
            # 4 x 25 Gbps. However before configuring a port as channelized,
            # the next three ports must be configured as unused.
            if port_id in range(1, 128, 4):
                # Channelization configuration is allowed
                ports.extend([
                    self.gen_100G_to_4x25G_40G_to_4x10G_intf_name_explicit_breakout_port(
                        port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                        port_offset, model=model, fpc=fpc, pic=pic, intf_prefix='et')
                ])
            else:
                # Channelization configuration is not available
                ports.extend([
                    self.gen_100G_40G_disabled_100G_port(port_id, row_id, column_id, panel_id, slot_id,
                                                         failure_domain_id, port_offset, model=model,
                                                         fpc=fpc, pic=pic)
                ])
        return ports

    def gen_juniper_ptx10001_36mr_ports_interfaces(self, row_count, column_count,
                                                   start_index, panel_id, slot_id=0,
                                                   failure_domain_id=1,
                                                   port_offset=0,
                                                   row_offset=0, col_offset=0,
                                                   model=None, fpc=0, pic=0):
        ports = []
        for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset):
            if port_id in [6, 8]:
                ports.extend([
                    self.gen_100G_disabled_100G_port(port_id, row_id, column_id, panel_id, slot_id,
                                                     failure_domain_id, port_offset, model=model,
                                                     fpc=fpc, pic=pic, set_speed_in_interfaces=True)
                ])
            elif port_id in [5, 7]:
                ports.extend([
                    self.gen_100G_to_4x25G_40G_to_4x10G_intf_name_explicit_breakout_port(
                        port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                        port_offset, model=model, fpc=fpc, pic=pic,
                        intf_prefix='et', set_speed_in_interfaces=True)
                ])
            else:
                ports.extend([
                    self.gen_400G_to_4x100G_2x200G_8x50G_200G_to_2x100G_8x25G_100G_1x40_4x25_2x50_4x10(
                        port_id, row_id, column_id, panel_id, slot_id, failure_domain_id, port_offset,
                        model=model, fpc=fpc, pic=pic, set_speed_in_interfaces=True)
                ])
        return ports

    def gen_juniper_ptx10001_36mr_ports_chassis(self, row_count, column_count,
                                                start_index, panel_id, slot_id=0,
                                                failure_domain_id=1, port_offset=0,
                                                row_offset=0, col_offset=0,
                                                model=None, fpc=0, pic=0):
        ports = []
        for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset):
            if port_id in [6, 8]:
                ports.extend([
                    self.gen_100G_disabled_100G_port(port_id, row_id, column_id, panel_id, slot_id,
                                                     failure_domain_id, port_offset, model=model,
                                                     fpc=fpc, pic=pic)
                ])
            elif port_id in [5, 7]:
                ports.extend([
                    self.gen_100G_to_4x25G_40G_to_4x10G_intf_name_explicit_breakout_port(
                        port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                        port_offset, model=model, fpc=fpc, pic=pic, intf_prefix='et')
                ])
            else:
                ports.extend([
                    self.gen_400G_to_4x100G_2x200G_8x50G_200G_to_2x100G_8x25G_100G_1x40_4x25_2x50_4x10(
                        port_id, row_id, column_id, panel_id, slot_id, failure_domain_id, port_offset,
                        model=model, fpc=fpc, pic=pic)
                ])
        return ports

    def gen_juniper_qfx5220_32cd_ports(self, row_count, column_count, start_index, panel_id, slot_id=0,
                                       failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
                                       fpc=0, pic=0):
        return [
            self.gen_400G_4x100G_100G_to_4x25G_40G_to_4x10G_2x200G_8x50G_1x200G_2x100G_intf_name_explicit_breakout_port(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                port_offset, model="QFX5220-32CD", fpc=fpc, pic=pic, intf_prefix='et'
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_juniper_qfx5130_32cd_ports(self, row_count, column_count, start_index, panel_id, slot_id=0,
                                       failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
                                       fpc=0, pic=0):
        return [
            self.gen_400G_4x100G_100G_to_4x25G_40G_to_4x10G_2x200G_8x50G_1x200G_2x100G_intf_name_explicit_breakout_port(
                port_id, row_id, column_id, panel_id, slot_id, failure_domain_id, port_offset, model=None,
                fpc=fpc, pic=pic, intf_prefix='et', breakout_parent=True, set_speed_in_interfaces=True
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_juniper_qfx5130_48c_ports(self, row_count, column_count, start_index, panel_id, slot_id=0,
                                      failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
                                      fpc=0, pic=0):
        ports = []

        for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset):
            if port_id in range(0, 48 + 1, 2):
                ports.extend([
                    self.gen_100G_to_1x100G_1x50G_1x25G_1x10G(
                        port_id, row_id, column_id, panel_id, slot_id, failure_domain_id, port_offset, model=None,
                        fpc=fpc, pic=pic, intf_prefix='et', set_speed_in_interfaces=True, connector="sfpdd")
                ])
            elif port_id in range(49, 56 + 1):
                ports.extend([
                    self.gen_400G_to_1x400G_2x200G_4x100G_1x100G_8x50G_1x40G_4x25G_4x10(
                        port_id, row_id, column_id, panel_id, slot_id, failure_domain_id, port_offset, model=None,
                        fpc=fpc, pic=pic, intf_prefix='et', set_speed_in_interfaces=True, breakout_parent=True)
                ])
            else:
                ports.extend([
                    self.gen_100G_to_1x100G_1x50G_1x25G_1x10G_2x50G(
                        port_id, row_id, column_id, panel_id, slot_id, failure_domain_id, port_offset, model=None,
                        fpc=fpc, pic=pic, intf_prefix='et', breakout_parent=True, set_speed_in_interfaces=True)
                ])
        return ports

    def gen_40G_100G_1x100G_to_2x50G_4x25G_1x40G_to_4x10G_ports_QFX5120_48T(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
            model=None, fpc=0, pic=0):
        return [
            self.gen_100G_to_2x50G_1x40G_port(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=None, fpc=fpc, pic=pic,
                explicit_speed_50G=True, default_100G=False, default_40G=True
            )
            if port_id != 51 and port_id != 52  # pylint: disable=consider-using-in
            else self.gen_40G_100G_1x100G_to_2x50G_4x25G_1x40G_to_4x10G_port_explicit(
                port_id, row_id, column_id, panel_id, slot_id,
                failure_domain_id, port_offset, model=None, fpc=fpc, pic=pic
            )
            for (port_id, (column_id, row_id)) in
            d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset)
        ]

    def gen_40G_100G_1x100G_to_2x50G_4x25G_1x40G_to_4x10G_port_explicit(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0,
            display_id=None):

        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, "qsfp28",
            [
                d.gen_transform(
                    self._gen_intfs_1x100G_explicit_port_speed(port_id, model, fpc, pic),
                    transformation_id=1,
                    is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_2x50G_breakout_explicit(
                        port_id, model, fpc, pic),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x40G(port_id, model, fpc, pic, default=True),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_4x25G_breakout_explicit(
                        port_id, model, fpc, pic),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_explicit_breakout(
                        port_id, model, fpc, pic),
                    transformation_id=5)
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize,
        )

    def gen_40G_100G_1x100G_to_2x50G_4x25G_1x40G_to_4x10G_ports_QFX5120_48YM(self, row_count, column_count,
                                                                             start_index, panel_id,
                                                                             slot_id=0, failure_domain_id=1,
                                                                             port_offset=0, model=None,
                                                                             row_offset=0, col_offset=0,
                                                                             fpc=0, pic=0):
        ports = []
        for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset):
            if port_id in [51, 53]:
                ports.extend([
                    self.gen_100G_1x40_4x25_2x50_4x10_port_breakout_explicit(
                        port_id, row_id, column_id, panel_id, slot_id, failure_domain_id,
                        port_offset, model=model, fpc=fpc, pic=pic,
                        default_100G=False, default_40G=True,)
                ])
            else:
                ports.extend([
                    self.gen_40G_100G_port_default(
                        port_id, row_id, column_id, panel_id, slot_id, failure_domain_id, port_offset,
                        model=model, fpc=fpc, pic=pic)
                ])
        return ports

    def gen_400G_4x100_8x50_3x100_2x100_1x100_1x25_1x10_1x1(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, display_id=None):
        speed_keyword = 'speed'
        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, 'QSFPDD',
            [
                d.gen_transform(
                    self._gen_intfs_1x400G_explicit_port_speed(
                        port_id, model, fpc, pic, speed_keyword=speed_keyword),
                    transformation_id=1),
                d.gen_transform(
                    self._gen_intfs_1x400G_to_4x100G_breakout_explicit(
                        port_id, model, fpc, pic, speed_keyword=speed_keyword,
                        subports_count=4),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x400G_to_8x50G_breakout_explicit(
                        port_id, model, fpc, pic, speed_keyword=speed_keyword,
                        subports_count=8),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x400G_to_3x100G_breakout_explicit(
                        port_id, model, fpc, pic, speed_keyword=speed_keyword,
                        subports_count=3),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x200G_to_2x100G_breakout_explicit(
                        port_id, model, fpc, pic, speed_keyword=speed_keyword,
                        subports_count=2),
                    transformation_id=5),
                d.gen_transform(
                    self._gen_intfs_1x100G_explicit_port_speed(
                        port_id, model, fpc, pic),
                    transformation_id=6, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x25G_explicit_port_speed(
                        port_id, model, fpc, pic),
                    transformation_id=7),
                d.gen_transform(
                    self._gen_intfs_1x10G_explicit(
                        port_id, model, fpc, pic),
                    transformation_id=8),
                d.gen_transform(
                    self._gen_intfs_1x1G_explicit_port_speed(
                        port_id, model, fpc, pic),
                    transformation_id=9),
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize_pic,
        )

    def gen_100G_1x25_1x10_1x1(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, display_id=None):
        if display_id is None:
            display_id = port_id + port_offset - 1
        return d.gen_port(
            port_id, row_id, col_id, panel_id, 'QSFP28',
            [
                d.gen_transform(
                    self._gen_intfs_1x100G_explicit_port_speed(
                        port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x25G_explicit_port_speed(
                        port_id, model, fpc, pic),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x10G_explicit(
                        port_id, model, fpc, pic),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x1G_explicit_port_speed(
                        port_id, model, fpc, pic),
                    transformation_id=4),
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize_pic,
        )

    def gen_100G_4x25_1x40_4x10_1x25_1x10_4x1_1x1(
            self, port_id, row_id, col_id, panel_id, slot_id, failure_domain_id,
            port_offset, model, fpc=0, pic=0, display_id=None):
        speed_keyword = 'speed'
        if display_id is None:
            display_id = port_id + port_offset - 1

        return d.gen_port(
            port_id, row_id, col_id, panel_id, 'QSFP28',
            [
                d.gen_transform(
                    self._gen_intfs_1x100G_explicit_port_speed(
                        port_id, model, fpc, pic),
                    transformation_id=1, is_default=True),
                d.gen_transform(
                    self._gen_intfs_1x100G_to_4x25G_breakout_explicit(
                        port_id, model, fpc, pic, speed_keyword=speed_keyword,
                        subports_count=4),
                    transformation_id=2),
                d.gen_transform(
                    self._gen_intfs_1x40G_explicit_port_speed(
                        port_id, model, fpc, pic),
                    transformation_id=3),
                d.gen_transform(
                    self._gen_intfs_1x25G_explicit_port_speed(
                        port_id, model, fpc, pic),
                    transformation_id=4),
                d.gen_transform(
                    self._gen_intfs_1x40G_to_4x10G_explicit_breakout(
                        port_id, model, fpc, pic, speed_keyword=speed_keyword,
                        subports_count=4),
                    transformation_id=5),
                d.gen_transform(
                    self._gen_intfs_1x10G_explicit(
                        port_id, model, fpc, pic),
                    transformation_id=6),
                d.gen_transform(
                    self._gen_intfs_1x10G_to_4x1G_explicit_breakout(
                        port_id, model, fpc, pic, speed_keyword=speed_keyword,
                        subports_count=4),
                    transformation_id=7),
                d.gen_transform(
                    self._gen_intfs_1x1G_explicit_port_speed(
                        port_id, model, fpc, pic),
                    transformation_id=8),
            ], slot_id, failure_domain_id, port_offset,
            display_id=display_id, templatize=self.templatize_pic,
        )

    def gen_juniper_jnp304_lmic16_interfaces(
            self, row_count, column_count, start_index, panel_id, slot_id=0,
            failure_domain_id=1, port_offset=0, row_offset=0, col_offset=0,
            model=None, fpc=0, pic=0):
        # https://www.juniper.net/documentation/us/en/software/junos/interfaces-ethernet/topics/topic-map/port-speed-configuration.html#concept_shw_4jn_dvb
        ports = []
        for (port_id, (column_id, row_id)) in d.get_port_indices(
                row_count, column_count, start_index, row_offset, col_offset):
            if port_id in [1, 7, 9, 15]:
                ports.extend([
                    self.gen_400G_4x100_8x50_3x100_2x100_1x100_1x25_1x10_1x1(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model, fpc, pic=slot_id,

                    )
                ])
            elif port_id in [3, 5, 11, 13]:
                ports.extend([
                    self.gen_100G_1x25_1x10_1x1(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model, fpc, pic=slot_id
                    )
                ])
            else:
                ports.extend([
                    self.gen_100G_4x25_1x40_4x10_1x25_1x10_4x1_1x1(
                        port_id, row_id, column_id, panel_id, slot_id,
                        failure_domain_id, port_offset, model, fpc, pic=slot_id
                    )
                ])
        return ports
