# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=redefined-builtin

import uuid
import re
from itertools import product
from aos.sdk.generator import compact_dict
from six.moves import range

# port object generator
def gen_port(port_id, row_id, column_id, panel_id, connector, transformations,
             slot_id, failure_domain_id, port_offset=0, templatize=False,
             display_id=None):
    """
    Generates a port as required by the device profile

    Args:
        port_id (int):
            ID for the port as found on the device's front
            panel. This usually starts with 1, is unique across the DP
            and is sequential
        row_id (int):
            the row the port belongs to as seen on the device's front panel
            This does not affect any configurations and is purely for
            displaying the ports.
        column_id (int):
            the column the port belongs to as seen on the device's front panel
            This does not affect any configurations and is purely for
            displaying the ports.
        panel_id (int):
            the panel to which the port belongs as seen on the device's front panel.
            The panel ID is useful when displaying the ports on the UI.
            This does not affect any configurations and is purely for
            displaying the ports.
        connector (string):
            port transciever as specified on the device's spec
        transformations (list):
            represents the breakout capability of the port.
            If a port is capable of 40G->4x10G, then there will be two
            transformations, one for the 40G and the other for the 4x10G.
            Refer to the function gen_transform() to know how to generate
            a transformation.
        slot_id (int):
            the ID of the slot this port belongs to. If the device
            is a non-modular box, then the slot_id is always 0.
        failure_domain_id(int):
            if a device has multiple failure_domains, this
            field represents the one the port is currently active in. The
            recommended value is 1 unless a different value applies.
        port_offset (int):
            port_offset helps in offsetting the port_id by an integer, where
            the effective port_id is the sum of port_offset and the port_id of
            this port.
            Usualy just the port_id suffices to capture the port number, however
            sometimes ports in a certain panel can start from something other than 1.
            This field is especially helpful when generating ports for modulars
        templatize (bool):
            set slot_id to string '{{slot_id}}' if True
        display_id (int, optional):
            ID used in visualization of the port. If not provided, then the
            device profile API uses the value of port_id. Unlike port_id,
            display_id values can be reused across ports.
            Examples where a display_id value different from port_id are useful:

            1. In a Junos/EVO device, port numbering starts from 0 instead of 1
            2. In a modular device profile, you might want to better visualize
               ports by numbering them relative to the linecard, i.e. display_id
               starts from 0 or 1 for each slot.

    Returns:
        port dictionary as required by the device profile model
    """
    port = {'port_id': port_id + port_offset,
            'row_id': row_id,
            'column_id': column_id,
            'panel_id': panel_id,
            'slot_id': '{{slot_id}}' if templatize else slot_id,
            'failure_domain_id': failure_domain_id,
            'connector_type': connector,
            'transformations': transformations}
    if display_id is not None:
        port['display_id'] = display_id
    return port

def gen_interface(name, state, to_speed=None, setting="", intf_id=None):
    """
        Generates an interface in a port transformation as required by the
        device profile

    Args:
        name (string):
            name of the interface as required for interface
            configurations on the device
        state (string):
            state of the interface. This could either be 'active'
            or 'inactive'.

            Example 1, consider the Arista 7050QX-32 qsfp port.
            The port is capable of 40G->4x10G, transformation #1 will
            have 1 active 40G interface and 3 inactive interfaces. Note Arista
            requires the inactive interfaces to be present in the
            configuration, thus we include them in the DP too.
            Transformation #2 will have 4 active 10G interfaces.

            Example 2, consider the Accton 6712-32X-O qsfp port.
            The port is capable of 40G->4x10G, transformation #1 will
            have 1 active 40G interface. Note Cumulus does not need the
            inactive interfaces to be configured, thus we omit them in the DP
            too.
            Transformation #2 will have 4 active 10G interfaces.
        to_speed (Speed):
            where Speed schema is as follows

            Speed = Dict({'value': Integer(description='scalar multiplier for '
                                                       'the speed of the interface'),
                          'unit': String(validate=AnyOf(["", "M", "G"]),
                                         description='Indicates if \'value\' is in '
                                                     'units of Gbps or Mbps')})
            Speed with "" unit means there is no unit multiplier and the Speed
            value needs to be read as face value.
        setting (string):
            This captures the vendor specific command to apply an
            interface speed and and to bring the port into selected breakout mode.
            If the speed string for an active interface inside the setting is
            set to "", then that indicates it is an autoneg port.

            Example:
                {
                    "interface": {
                        "command": "",
                        "speed": "40G"
                    }
                }
        intf_id (int):
            ID of the interface. This has to be unique withing a given
            transformation.

            Example:
                If there are 4x10G interfaces, then the interface ID ranges from 1-4

    Returns:
        interface dictionary as required by the device profile model
    """
    if intf_id is None:
        intf_id = int(str(uuid.uuid4().int >> 64)[0:32])
    return compact_dict({
        "interface_id": intf_id,
        "name": name,
        "state": state,
        "setting": setting,
        "speed": to_speed,
    })

def assign_transform_id(transform, id):
    transform['transformation_id'] = id
    return transform

def gen_transform(transformation, transformation_id=None, is_default=False):
    """
    Generates the transformation within a given port as required by the device
    profile

    Args:
        transformation (list):
            list of interfaces in this breakout transformation.

            Example:
                for the 4x10G transformation, it will be a list of 4 interfaces.
        transformation_id (int):
            ID of this transformation. This information is used in the creation
            of IM. This has to be unique inside a given port.
        is_default (bool):
            If marked default, this transformation is used to configure interfaces
            when a device are not in any blueprint.
            There must be exactly one default transformation in a port.
            Example:
                for a qsfp28 port, which has the following breakout
                capabilities, the 100G is the default speed, thus
                trnasformation#1 has the is_default set to 1

                transformation #1: 100G(default)
                transformation #2: 100G->2x50G
                transformation #3: 100G->1x40G
                transformation #4: 100G->4x25G
                transformation #5: 100G->4x10G
    Returns:
        transformation dictionary as required by the device profile model
    """
    if transformation_id is None:
        transformation_id = int(str(uuid.uuid4().int >> 64)[0:16])
    return {
        'transformation_id': transformation_id,
        'interfaces': transformation,
        'is_default': is_default,
    }

def get_port_indices(row, col, start_index, row_offset=0, col_offset=0):
    return enumerate(product(range(col_offset+1, col_offset+col+1),
                             range(row_offset+1, row_offset+row+1)),
                     start_index)

def gen_device_profile_hw_caps(userland=32, form_factor='1RU', ecmp_limit=64,
                               asic='T2', cpu='x86', ram=16, copp_strict=None,
                               breakout_capable=None, as_seq_num_supported=None,
                               routing_instance_supported=None):
    """
    Generates a dictionary with hardware capabilities as required in the device
    profile for the 'hardware_capabilities' key

    Args:
        userland (int):
            The type of application binary/kernel that the device supports.
            Usually this value is 32 or 64. Refer the device specs to find
            exact value.
        form_factor (string):
            How much rack space/units does the device need
        ecmp_limit (int):
            Maximum number of next hops for ECMP routes. This value needs to be
            correct. Specifying a value greater than what the device is capable of
            will result in configuration deployment errors.
        asic (string):
            Type of chipset on the device
        cpu (string):
            What is the cpu architecture of the device
        ram (int):
            How much memory does the device have
        copp_strict, (:obj:`list of dict/s`, optional):
            when set to True, generate strict copp profile config for NXOS.
            Does not apply to other vendors
        breakout_capable, (:obj:`list of dict/s`, optional):
            When set to true for a module, indicates that ports of that module are
            breakout capable. Applicable only for NXOS, does not apply to other
            vendors.
        as_seq_num_supported, (:obj:`str`, optional):
            when set to False, skips rendering AS related config because
            sequencing an AS entry does not apply on this device. Applicable
            only for NXOS, does not apply to other vendors.
        routing_instance_supported, (:obj:`str`, optional):
            indicates if the device supports 'routing instance' variable usage for
            AAA server. Applicable only for Junos, does not apply to other vendors.
    Returns:
        A dictionary with hardware_capabilities as required by the device
        profile model
    """
    return compact_dict({
        'userland': userland,
        'form_factor': form_factor,
        'ecmp_limit': ecmp_limit,
        'asic': asic,
        'cpu': cpu,
        'ram': ram,
        'copp_strict': copp_strict,
        'breakout_capable': breakout_capable,
        'as_seq_num_supported': as_seq_num_supported,
        'routing_instance_supported': routing_instance_supported
    })

def gen_device_profile_sw_caps(onie=False, lxc=False,
                               config_apply_support='complete_only'):
    """
    Generates a dictionary for the software_capabilities key as required in the
    device profile

    Args:
        onie (bool):
            does the device support onie, applies to devices running Cumulus OS
        lxc (bool):
            does the device support Linux containers
        config_apply_support (str from enum):
            what type of config can the device handle, complete_only or incremental

    Returns:
        A dictionary with software_capabilities as required by the device
        profile model

    """
    return compact_dict({
        'onie': onie,
        'lxc_support': lxc,
        'config_apply_support': config_apply_support,
    })


def gen_device_profile_ref_design_caps(freeform='full_support',
                                       datacenter='full_support'):
    return compact_dict({
        'freeform': freeform,
        'datacenter': datacenter,
    })


def gen_device_profile_selector(model, os_version, manufacturer, os):
    """
    Generates a dictionary with selector information as required in the device
    profile
    The fields in the selector have to match exactly as found on the device for
    AOS to match the device profile to the device during discovery.

    Args:
        model (string):
            regex for model of the device represented in string format
        os_version (string):
            regex for os_version/s supported by the device represented in
            string format
        manufacturer (string):
            manufacturer/vendor informations for the device
        os (string):
            OS family for the device.

    Returns:
        A dictionary with selector as required by the device profile
    """
    return {'os': os,
            'os_version': os_version,
            'manufacturer': manufacturer,
            'model': model}


def gen_device_profile(hw_caps, sw_caps, label, ports, selector,
                       ref_design_caps,
                       slot_count=0, id=None, chassis_count=None,
                       device_profile_type='monolithic',
                       physical_device=True, dual_re=False):
    """
    Generates a device profile dictionary

    Args:
        hw_caps (dict):
            a dictionary of hardware capabilities of the device
        sw_caps (dict):
            a dictionary of software capabilities of the device
        label (string):
            a human friendly name for the device profile
        ports (list):
            list of ports as applicable to the device, as seen on the
            front panel of the device
        selector (dict):
            model, manufacturer, os informations for the device
        slot_count (int):
            Number of slots in the device. This number is 0 if
            the device is a non-modular device.
        chassis_count (int):
            Number of switches in the virtual chassis. This is None if
            the switch is operating stand alone.
        id, (:obj:`str`, optional):
            Unique identifier for the device profile.
            If not provided, AOS will generate a UUID.

    Returns:
        A dictionary of device profile with keys and values as required by AOS
    """
    if id is None:
        id = label

    dp = {'hardware_capabilities': hw_caps,
          'software_capabilities': sw_caps,
          'id': id,
          'label': label,
          'predefined': True,
          'ports': ports,
          'selector': selector,
          'slot_count': slot_count,
          'reference_design_capabilities': ref_design_caps,
          'physical_device': physical_device,
          'dual_routing_engine': dual_re,
         }

    dp['device_profile_type'] = device_profile_type
    if chassis_count:
        dp['chassis_count'] = chassis_count

    return dp

def gen_linecard_profile_selector(model, version, os):
    """
    Generates a linecard profile selector

    Args:
        model (string):
            regex for model of the linecard
        version (string):
            regex for hardware versions / revisions supported by this profile
        os (string):
            OS family of the modular device using linecards with this profile
    """
    return {
        'model': model,
        'version': version,
        'os': os,
    }

def gen_linecard_profile(hw_caps, label, ports, selector,
                         compatible_chassis, id=None):
    """
    Generates a linecard profile dictionary

    Args:
        hw_caps (dict):
            a dictionary of hardware capabilities of the device
        label (string):
            a human friendly name for the device profile
        ports (list):
            list of ports as applicable to the device, as seen on the
            front panel of the device
        selector (dict):
            model, os, hardware ver information for the linecard
        compatible_chassis (dict):
            dict of chassis profile ids (keys) and slot ids (values)
            for compatibility check
        id (:obj:`str`, optional):
            Unique identifier for the linecard profile.
            If not provided, AOS will generate a UUID.

    Returns:
        A dictionary of device profile with keys and values as required by AOS
    """
    if id is None:
        id = label

    lp = {'hardware_capabilities': hw_caps,
          'id': id,
          'label': label,
          'predefined': True,
          'ports': ports,
          'selector': selector,
          'compatible_chassis': compatible_chassis}
    return lp


def gen_chassis_profile(hw_caps, sw_caps,
                        label, selector,
                        linecard_slot_ids,
                        ref_design_caps,
                        id=None,
                        dual_re=True, physical_device=True):
    """
    Generates a chassis profile dictionary

    Args:
        hw_caps (dict):
            a dictionary of hardware capabilities of the chassis
        sw_caps (dict):
            a dictionary of software capabilities of the chassis
        ref_design_caps (dict):
            a dictionary of reference design capabilities of the chassis
        label (string):
            a human friendly name for the chassis profile
        selector (dict):
            model, manufacturer, os informations for the chassis
        linecard_slot_ids (list):
            a list of the valid slot id numbers in this chassis
        id, (:obj:`str`, optional):
            Unique identifier for the chassis profile.
            If not provided, AOS will generate a UUID.

    Returns:
        A dictionary of chassis profile with keys and values as required by AOS
    """
    if id is None:
        id = re.sub(r'\s', '_', label)

    return {
        'hardware_capabilities': hw_caps,
        'software_capabilities': sw_caps,
        'id': id,
        'label': label,
        'predefined': True,
        'selector': selector,
        'linecard_slot_ids': linecard_slot_ids,
        'dual_routing_engine': dual_re,
        'physical_device': physical_device,
        'reference_design_capabilities': ref_design_caps,
    }

def gen_modular_device_profile(label, chassis_profile_id,
                               slot_configuration,
                               id=None):
    """
    Generates a modular device profile dictionary

    Args:
        label (string):
            a human friendly name for the device profile
        chassis_profile_id (string):
            The ID of chassis profile that will be used at the Chassis of
            this Device Profile.
        slot_configuration (array):
            An array of dicts representing the linecards inserted to the
            slots of this particular device. Each dict contains exactly 2
            keys: 'slot_id' which is integer and 'linecard_profile_id' which
            is string.
        id, (:obj:`str`, optional):
            Unique identifier for the device profile.
            If not provided, AOS will generate a UUID.

    Returns:
        A dictionary of device profile with keys and values as required by AOS
    """
    if id is None:
        id = re.sub(r'\s', '_', label)

    return {
        'id': id,
        'label': label,
        'predefined': True,
        'chassis_profile_id': chassis_profile_id,
        'slot_configuration': slot_configuration,
        'device_profile_type': 'modular',
    }
