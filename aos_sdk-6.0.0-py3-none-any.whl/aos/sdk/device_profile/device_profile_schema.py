# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

""" This module captures the schema definitions for the device profile which
can be resused across modules

All schema is defined using the Python package lollipop 1.1.5
which can further be used for serialization/deserialization,
validation etc. in consumer modules.
"""

import aos.sdk.device_profile.basic_types as s
from itertools import chain

selector_schema_fields = {
    'os_version': s.String(
        validate=s.Length(min=1),
        description='OS version that AOS will use to '
        'match and assign a system device to the Device Profile'
    ),
    'model': s.String(
        validate=s.Length(min=1),
        description='Model info that AOS will use to '
        'match and assign a system device to the Device Profile'
    ),
    'os': s.String(
        validate=s.Length(min=1),
        description=
        'OS info that AOS will use to '
        'match and assign a system device to the Device Profile'
    ),
    'manufacturer': s.String(
        validate=s.Length(min=1),
        description=
        'Manufacturer info that AOS will use to match and assign '
        'a system device to the Device Profile'
    )
}
selector_schema = s.Dict(selector_schema_fields)

linecard_selector_schema = s.Dict({
    'os': s.String(validate=s.Length(min=1),
                   description=
                   'OS of the modular device this linecard is going to be used ' \
                   'with.'),
    'model': s.String(validate=s.Length(min=1),
                      description='Hardware model of the linecard.'),
    'version': s.Optional(
        s.String(description='Hardware revision of the linecard.')
    ),
})

feature_version_schema = s.String(validate=s.Length(min=1),
                                  description="versions which support the feature "
                                  "setting. The version is expressed a regex, "
                                  "the one with the most specific match selected.")

dual_re_field = s.Optional(s.Boolean(
    description='True if device is capable of dual routing engine '
                '(supervisor) cards'), load_default=False)

phys_device_field = s.Optional(s.Boolean(
    description='True if profile represents '
                'a physical device'), load_default=True)

copp_schema = s.Dict({'version': feature_version_schema,
                      'value': s.Boolean()})

intf_breakout_schema = s.Dict({'module': s.Integer(),
                               'version': feature_version_schema,
                               'value': s.Boolean()})

as_seq_num_schema = s.Dict({'version': feature_version_schema,
                            'value': s.Boolean()})

routing_instance_schema = s.Dict({'version': feature_version_schema,
                                  'value': s.Boolean()})

hw_caps = s.Dict({'userland': s.Integer(description='What type of userland '
                                                    '(application binary/kernel) '
                                                    'does the device support.'),
                  'form_factor': s.String(
                      validate=s.Length(min=1),
                      description='How much rack space does the device need.'),
                  'ecmp_limit': s.Integer(
                      description='What is the maximum number of Equal Cost '
                                  'Multi Path routes. This field changes BGP '
                                  'configuration on the device (ecmp max-paths).'),
                  'asic': s.String(
                      description='Type of Chipset (ASIC) on the device.'),
                  'cpu': s.String(
                      validate=s.Length(min=1),
                      description='What is the CPU architecture of the device.'),
                  'ram': s.Integer(
                      description='How much memory does the device have.'),
                  'vxlan_supported': s.Optional(s.Boolean(
                      description='Does the device support vxlan.'
                  )),
                  'copp_strict': s.Optional(s.List(copp_schema,
                                                   validate=s.Length(min=1),
                                                   description='when set to '
                                                   'True, generate strict copp '
                                                   'profile config for NXOS')),
                  'breakout_capable': s.Optional(s.List(intf_breakout_schema,
                                                        validate=s.Length(min=1),
                                                        description='when set to '
                                                        'True for a module, '
                                                        'indicates that the '
                                                        'ports of this module '
                                                        'are breakout capable')),
                  'as_seq_num_supported': s.Optional(s.List(
                      as_seq_num_schema, validate=s.Length(min=1),
                      description='when set to False, skips  rendering anything '
                                  'due to the inability to sequence the AS entry')),
                  'routing_instance_supported': s.Optional(s.List(
                      routing_instance_schema, validate=s.Length(min=1),
                      description='The flag indicates whether the device supports'
                                  '"routing instance" command. This field is further'
                                  'used for AAA server related configuration'
                                  'on Junos. When set to True,'
                                  'routing instance command is used with'
                                  'pre-configured mgmt_junos interface; Otherwise,'
                                  'source address is used with the management IP'
                                  'address.')),
                  'bfd_supported': s.Optional(s.Boolean(
                      description='Does the device support BFD.'
                  )),
                  'vrf_limit': s.Optional(s.Integer(
                      validate=s.Range(min=1),
                      description='VRF range supported by the device.'
                  )),
                  'vtep_limit': s.Optional(s.Integer(
                      validate=s.Range(min=1),
                      description='Number of VTEPs supported by the device.'
                  )),
                  'vtep_flood_limit': s.Optional(s.Integer(
                      validate=s.Range(min=1),
                      description='Number of flood lists supported per VTEP on the '
                                  'device.'
                  )),
                  'max_l2_mtu': s.Optional(s.Integer(
                      validate=s.Range(min=1),
                      description='Maximum L2 MTU supported on the device.'
                  )),
                  'max_l3_mtu': s.Optional(s.Integer(
                      validate=s.Range(min=1),
                      description='Maximum L3 MTU supported on the device.'
                  ))}
                 )

sw_caps = s.Dict({'onie': s.Boolean(description='Does the device or device OS '
                                    'support onie'),
                  'lxc_support': s.Boolean(description='Does the device support '
                                                       'LXC containers'),
                  'config_apply_support': s.Enum(
                      ['complete_only', 'incremental'],
                      description='Enumeration describing what types of '
                                  'configuration can the device support. '
                                  '1.complete_only: Every config push on the '
                                  'device is complete config push. 2.incremental: '
                                  'Every day2 config push on the device is '
                                  'incremental. Complete config push is'
                                  'supported.')},
                 description="This includes native capabilities of Device OS "
                             "software and AOS management software for devices "
                             "of this profile")

ref_design_caps = s.Dict({
    'datacenter': s.Optional(
        s.Enum(['disabled', 'full_support']),
        load_default='full_support'),
    'freeform': s.Optional(
        s.Enum(['disabled', 'full_support']),
        load_default='full_support')})

interface_schema = s.Dict({
    'interface_id': s.Integer(description='Interface ID'),
    'name': s.String(validate=s.Length(min=1), description='Interface name'),
    'state': s.Enum(['active', 'inactive'], description='Is the interface '
                    'active or inactive'),
    'setting': s.Optional(s.String(), load_default="", description='Interface '
                          'setting used to configure the interface on the device'),
    'speed': s.Optional(s.Speed, description='Speed that the interface will be '
                        'configured to run on the device')})

port_transformation_schema = s.Dict({
    'transformation_id': s.Integer(description='Transformation ID'),
    'is_default': s.Boolean(description='Is the speed this transformation '
                                        'respresents, the primary/default speed '
                                        'that the port can run in'),
    'interfaces': s.List(interface_schema, validate=s.Length(min=1),
                         description='Interfaces available in this speed'
                                     'transformation')})

port_id_and_display_id_validator = s.Range(min=0, max=2**16-1)

port_info_fields = {
    'port_id': s.Integer(description='Port ID',
                         validate=port_id_and_display_id_validator),
    'display_id': s.Optional(s.Integer(
        description='Number to be displayed in the visualization of this port. '
                    'Unlike port ID, multiple ports can have same display ID. '
                    'When linecard profile ports are added to a modular device '
                    'profile, their display IDs are retained. This enables a '
                    'simple way of visualizing port numbers grouped by slot. '
                    'When creating or updating a monolithic device profile, '
                    'or a linecard profile, if display_id is not given, '
                    'then the value of port_id is used.',
        validate=port_id_and_display_id_validator)),
    'row_id': s.Integer(description='The row this port belongs to'),
    'panel_id': s.Integer(description='The panel this port belongs to'),
    'column_id': s.Integer(description='The column this port belongs to'),
    'slot_id': s.Integer(validate=s.Range(min=0), description='The module/slot '
                         'this port belongs to'),
    'failure_domain_id': s.Integer(validate=s.Range(min=0), description='This '
                                   'information may be used later when doing '
                                   'the cabling plan to ensure that 2 uplinks '
                                   'are not attached to the same failure domain.'),
    'connector_type': s.String(validate=s.Length(min=1), description='Port '
                               'transceiver type'),
    'transformations': s.List(port_transformation_schema,
                              validate=s.Length(min=1), description='Available '
                              'speed tranformations on this port'),
}

port_info_schema = s.Dict(port_info_fields)

chassis_profile_id_schema = s.String(validate=s.Length(min=1))

slot_configuration_schema = s.List(
    s.Dict(
        {
            "slot_id": s.Integer(
                validate=s.Range(min=0),
                description="Slot number of the linecard in the physical device. "
                            "Must be a non-negative integer."
            ),
            "linecard_profile_id": s.String(
                validate=s.Length(min=1),
                description="ID of the linecard profile in global catalog."
                            "The ID must be present in an entry in the device "
                            "profile's linecards_info list.",
            )
        },
    ),
    validate=s.Length(min=1)
)

# This is differentiated from linecard_slot_ids_schema to allow
# upgrades from previous AOS versions, where the linecard_slot_ids is
# missing from the chassis_info of a DP. Please AOS-37768 for a discussion
# of the problem.
linecard_slot_ids_schema_for_chassis_info = \
    s.Optional(s.List(
        s.Integer(validate=s.Range(min=0)),
        validate=[
            s.Length(min=1),
            s.Unique(),
        ],
    ))

chassis_info_schema = s.Dict({
    'chassis_profile_id': s.String(validate=s.Length(min=1)),
    'selector': selector_schema,
    'hardware_capabilities': hw_caps,
    'software_capabilities': sw_caps,
    'reference_design_capabilities': s.Optional(
        ref_design_caps, load_default=ref_design_caps.load({})),
    'dual_routing_engine': dual_re_field,
    'linecard_slot_ids': linecard_slot_ids_schema_for_chassis_info,
    'physical_device': phys_device_field,
})

linecards_info_schema = s.List(
    s.Dict({
        'linecard_profile_id': s.String(
            validate=s.Length(min=1),
            description="ID of the linecard profile in global catalog.",
        ),
        'selector': linecard_selector_schema,
        'hardware_capabilities': hw_caps}),
    validate=s.Length(min=1))

device_profile_other = {
    'hardware_capabilities': s.Optional(hw_caps),
    'ports': s.Optional(s.List(port_info_schema, validate=s.Length(min=1))),
    'software_capabilities': s.Optional(sw_caps),
    'chassis_profile_id': s.Optional(chassis_profile_id_schema),
    'slot_configuration': s.Optional(slot_configuration_schema),
}

device_profile_digest_head = {
    'label': s.String(validate=s.Length(min=1, max=64), description='Human '
                      'friendly name for the Device Profile as read on UI'),
    'predefined': s.Optional(s.Boolean(
        description='Indicates whether the device profile is predefined '
                    'and therefore intended to be immutable. If True, '
                    'the profile must not be updated '
                    'by user.'), load_default=False),
    'dual_routing_engine': dual_re_field,
    'physical_device': phys_device_field,
    'device_profile_type': s.Optional(
        s.Enum(['monolithic', 'modular']),
        load_default='monolithic',
        dump_default='monolithic',
    ),
    'selector': s.Optional(selector_schema),
    'reference_design_capabilities': s.Optional(
        ref_design_caps, load_default=ref_design_caps.load({})),
    'slot_count': s.Optional(s.Integer()),
    'chassis_count': s.Optional(s.Integer(
        description='Applicable only when switch operates in virtual chassis mode.'
                    'Device profile for switches operating in standalone mode'
                    'will not have this field.')),
    'chassis_info': s.Optional(chassis_info_schema),
    'linecards_info': s.Optional(linecards_info_schema)
}

device_profile_digest = dict(chain(
    device_profile_digest_head.items(),
    {
        'hardware_capabilities': s.Optional(s.Dict({
            'asic': s.String(description='Type of Chipset (ASIC) on the '
                                         'device.')
        }))
    }.items()
))

device_profile_fields = dict(chain(device_profile_digest_head.items(),
                                   device_profile_other.items()))

device_profile_schema = s.Object(device_profile_fields)

ims_clone_schema = s.Optional(s.List(
    s.Dict(
        {
            "original_id": s.String(
                validate=s.Length(min=1),
                description="ID of existing interface map referencing the "
                            "device profile and selected for cloning."
            ),
            "clone_label": s.String(
                validate=s.Length(min=1),
                description="User provided label for the clone "
                            "of this interface map."
            )  # clone_label is generated by UI
        },
    ),
    validate=s.Length(min=1)
))

device_profile_clone_fields = dict(chain(
    {
        'clone_interface_maps': ims_clone_schema,
    }.items(),
    device_profile_digest_head.items(),
    device_profile_other.items()))

device_profile_clone_schema = s.Object(device_profile_clone_fields)

linecard_slot_ids_schema = \
    s.List(
        s.Integer(validate=s.Range(min=0)),
        validate=[
            s.Length(min=1),
            s.Unique(),
        ],
    )

chassis_profile_fields = dict(
    label=s.String(
        validate=s.Length(min=1, max=64),
        description='Human friendly name for the Chassis Profile as read on UI'
    ),
    predefined=s.Optional(s.Boolean(
        description='Indicates whether the chassis profile is predefined '
                    'and therefore intended to be immutable. If True, '
                    'the profile must not be updated '
                    'by user.'), load_default=False),
    dual_routing_engine=dual_re_field,
    physical_device=phys_device_field,
    selector=selector_schema,
    hardware_capabilities=hw_caps,
    software_capabilities=sw_caps,
    reference_design_capabilities=s.Optional(
        ref_design_caps, load_default=ref_design_caps.load({})),
    linecard_slot_ids=linecard_slot_ids_schema,
)

CHASSIS_POST_SCHEMA = s.Object(chassis_profile_fields)

# allowing slot_id to accept string type in linecard profile
linecard_port_info_fields = port_info_fields.copy()
linecard_port_info_fields['slot_id'] = s.OneOf([
    s.String(validate=s.Length(min=1),
             description='The module/slot this port belongs to'),
    s.Integer(validate=s.Range(min=0),
              description='The module/slot this port belongs to'),
])

compatible_chassis_schema = \
    s.Dict(
        # Optional will catch the null case, e.g. {.. 'chassis_profile_id': null ..}
        s.Optional(
            s.List(
                s.Integer(validate=s.Range(min=0)),
                validate=s.Unique(),
            ),
        ),
        description="Models the chassis profiles which support instances of this "
                    "linecard profile. Each key is an ID of a chassis profile. The "
                    "value is a list of slot IDs in that chassis profile into "
                    "which an instance of this linecard can be plugged. "
                    "If the value is an empty list or null, then the linecard can "
                    "be plugged into all slots of the chassis.",
    )

linecard_profile_fields = dict(
    label=s.String(
        validate=s.Length(min=1, max=64),
        description='Human friendly name for the Device Profile as read on UI'
    ),
    predefined=s.Optional(s.Boolean(
        description='Indicates whether the linecard profile is predefined '
                    'and therefore intended to be immutable. If True, '
                    'the profile must not be updated '
                    'by user.'), load_default=False),
    selector=linecard_selector_schema,
    hardware_capabilities=hw_caps,
    ports=s.List(s.Dict(linecard_port_info_fields), validate=s.Length(min=1)),
    compatible_chassis=compatible_chassis_schema
)

linecard_profile_schema = s.Object(linecard_profile_fields)


validations_schema = s.Optional(s.List(s.Dict({
        'constraint': s.String(
            description='This is a string that describes the constraint '
            'of the interface. All interfaces in a port group must have '
            'a common constraint value. "no_constraint" is a special value '
            'that works as a wildcard',
            validate=s.Length(min=1)),
        'port_group': s.String(
            description='This is an opaque string that is common for all '
            'interfaces belonging in a single set of interfaces (port group)',
            validate=s.Length(min=1)),
   })), load_default=list)

'''
Introduce the vendor based schema for the port setting

Example of a typical EOS port setting:

"setting":"{"interface":{
  "speed":"40gfull"
},
"global":{
  "select":"",
  "port_group":-1
}
}"
'''
eos_port_setting = s.Dict({
    'interface': s.Dict({
        'speed': s.Enum([
            '', '1000full', '10000full', '25gfull', '40gfull', '50gfull',
            '100gfull', '150gfull', '200gfull', '200g', '200g-2', '200g-4',
            '400gfull', '400g', '400g-4', '400g-8'
        ])}),
    'global': s.Dict({
        'port_group': s.Integer(),
        'select': s.String()
        }),
    'validations': validations_schema
    })

'''
Example of a typical NXOS port setting:

"setting":{
  "interface":{
    "speed":"40000"
  },
  "global":{
    "port_index":-1,
    "speed":"",
    "module_index":-1
  }
}
'''
nxos_port_setting = s.Dict({
    'interface': s.Dict({
        'speed': s.Enum([
            '', '100', '1000', '5000', '10000', '25000', '40000',
            '50000', '100000', '200000', '400000',
        ])}),
    'global': s.Dict({
        "port_index": s.Integer(),
        "speed": s.String(),
        "module_index": s.Integer()
        }),
    'validations': validations_schema
    })

nxos_linecard_port_setting = s.Dict({
    'interface': s.Dict({
        'speed': s.Enum([
            '', '100', '1000', '10000', '25000', '40000', '50000', '100000',
            '200000', '400000',
        ])}),
    'global': s.Dict({
        "port_index": s.Integer(),
        "speed": s.String(),
        "module_index": s.OneOf([
            s.String(),
            s.Integer(s.Range(min=-1, max=-1))
            ])
        }),
    'validations': validations_schema
    })

junos_port_setting = s.Dict({
    'interface': s.Dict({
        'speed': s.Enum(
            ['', 'disabled', 'auto', '10m', '100m', '1g', '5g', '10g', '25g', '40g',
             '50g', '100g', '200g', '400g', '800g'],
            description='When you configure a port using the speed auto option, '
                        'the port deletes the last configured speed, comes up '
                        'again and advertises all the possible speeds. For a port '
                        'to only advertise a specific speed, start with a specific '
                        'speed, it is mandatory that both the auto-negotiation '
                        'option must be set (enabled) and the interface must also '
                        'be configured with a specific supported speed. When the '
                        'value is set to empty string, AOS does not explicitly '
                        'configure interface speed, interface\'s default speed '
                        'seting is honored.'),
        'auto_negotiation': s.Optional(
            s.Boolean(),
            description='When this value is set, AOS configures the interface to '
                        'explicitly enable/disable auto-negotiation. When not set, '
                        'interface\'s default setting is honored.'),
        'link_mode': s.Optional(s.Enum(
            ['automatic', 'full-duplex', 'half-duplex'],
            description='When this value is set, AOS explicitly configures the '
                        'interface link mode to the value. When not set, '
                        'interface\'s default setting is honored. full-duplex '
                        'communication means that both ends of the '
                        'communication can send and receive signals at the same '
                        'time. half-duplex is also bidirectional communication, '
                        'but signals can flow in only one direction at a time. '
                        'automatic means link mode is negotiated. '))
    }),
    'global': s.Dict({
        'speed': s.Enum(
            # Juniper models such as EX4650-48Y and QFX5120-48Y with SFP28 25G
            # ports require the chassis speed statement to be upper case for 1G,
            # configuring the speed in lower case 1g would result in configuration
            # error.
            ['', '10m', '100m', '1g', '1G', '5g', '10g', '25g', '40g',
             '50g', '100g', '200g', '400g'],
            description='When the value is set, AOS explicitly configures the '
                        'physical port speed/channel-speed under chassis. This is '
                        'used together with \'breakout\' flag.  When breakout is '
                        'set to True, the speed is used to render breakout port '
                        'channel-speed. When breakout is set to False, the speed '
                        'is used to explicity render port speed. Port speed '
                        'configuration is used for some platforms with SFP28 25G '
                        'ports that support 25G, 10G, 1G. They have default 10G, '
                        'and require speed manually set for 25G, 1G to work, '
                        'and the speed configuration is at quad level (e.g. port '
                        '0, 1, 2, 3, only need to set speed at port 0)'),
        'breakout': s.Optional(
            s.Boolean(),
            description='Flag to identify if a physical port is brokenout or not'
        ),
        'master_port': s.Optional(
            s.Integer(),
            description='Id of master port. Used to set speed of master port when '
                        'speed configuration is not allowed on current port. E.g '
                        'ports with 25g sfp28 transceivers, speed configuration is '
                        'at quad level, for a quad ports 0, 1, 2, 3, chassis speed '
                        'is only allowed to be set at port 0 (master port), '
                        'for port 1, 2, 3, we set their master_port field to 0 so '
                        'that AOS will explicitly configure their master port '
                        'speed/channel-speed on device.'),
        "port": s.Optional(
            s.Integer(),
            description='Id of a physical port. When value is set, AOS explicitly '
                        'configures the speed/channel-speed of current port. '
                        'Unless the current port belongs to a port group and is not '
                        'the master port of the port group, in this case AOS '
                        'explicitly configures the speed/channel-speed of '
                        'master_port.'
        ),
        "fpc": s.Optional(s.Integer()),
        "pic": s.Optional(s.Integer())
    }),
    'validations': validations_schema
})

junos_linecard_port_setting = s.Dict({
    'interface': s.Dict({
        'speed': s.Enum(
            ['', 'disabled', 'auto', '10m', '100m', '1g', '5g', '10g', '25g', '40g',
             '50g', '100g', '200g', '400g', '800g'],
            description='When you configure a port using the speed auto option, '
                        'the port deletes the last configured speed, comes up '
                        'again and advertises all the possible speeds. For a port '
                        'to only advertise a specific speed, start with a specific '
                        'speed, it is mandatory that both the auto-negotiation '
                        'option must be set (enabled) and the interface must also '
                        'be configured with a specific supported speed. When the '
                        'value is set to empty string, AOS does not explicitly '
                        'configure interface speed, interface\'s default speed '
                        'seting is honored.'),
        'auto_negotiation': s.Optional(
            s.Boolean(),
            description='When this value is set, AOS configures the interface to '
                        'explicitly enable/disable auto-negotiation. When not set, '
                        'interface\'s default setting is honored.'),
        'link_mode': s.Optional(s.Enum(
            ['automatic', 'full-duplex', 'half-duplex'],
            description='When this value is set, AOS explicitly configures the '
                        'interface link mode to the value. When not set, '
                        'interface\'s default setting is honored. full-duplex '
                        'communication means that both ends of the '
                        'communication can send and receive signals at the same '
                        'time. half-duplex is also bidirectional communication, '
                        'but signals can flow in only one direction at a time. '
                        'automatic means link mode is negotiated. '))
    }),
    'global': s.Dict({
        'speed': s.Enum(
            # Juniper models such as EX4650-48Y and QFX5120-48Y with SFP28 25G
            # ports require the chassis speed statement to be upper case for 1G,
            # configuring the speed in lower case 1g would result in configuration
            # error.
            ['', '10m', '100m', '1g', '1G', '5g', '10g', '25g', '40g',
             '50g', '100g', '200g', '400g'],
            description='When the value is set, AOS explicitly configures the '
                        'physical port speed/channel-speed under chassis. This is '
                        'used together with \'breakout\' flag.  When breakout is '
                        'set to True, the speed is used to render breakout port '
                        'channel-speed. When breakout is set to False, the speed '
                        'is used to explicity render port speed. Port speed '
                        'configuration is used for some platforms with SFP28 25G '
                        'ports that support 25G, 10G, 1G. They have default 10G, '
                        'and require speed manually set for 25G, 1G to work, '
                        'and the speed configuration is at quad level (e.g. port '
                        '0, 1, 2, 3, only need to set speed at port 0)'),
        'breakout': s.Optional(
            s.Boolean(),
            description='Flag to identify if a physical port is brokenout or not'
        ),
        'master_port': s.Optional(
            s.Integer(),
            description='Id of master port. Used to set speed of master port when '
                        'speed configuration is not allowed on current port. E.g '
                        'ports with 25g sfp28 transceivers, speed configuration is '
                        'at quad level, for a quad ports 0, 1, 2, 3, chassis speed '
                        'is only allowed to be set at port 0 (master port), '
                        'for port 1, 2, 3, we set their master_port field to 0 so '
                        'that AOS will explicitly configure their master port '
                        'speed/channel-speed on device.'),
        "port": s.Optional(
            s.Integer(),
            description='Id of a physical port. When value is set, AOS explicitly '
                        'configures the speed/channel-speed of current port. '
                        'Unless the current port belongs to a port group and is not '
                        'the master port of the port group, in this case AOS '
                        'explicitly configures the speed/channel-speed of '
                        'master_port.'
        ),
        "fpc": s.Optional(s.String()),
        "pic": s.Optional(s.OneOf([
            s.String(validate=s.Length(min=1)),
            s.Integer(validate=s.Range(min=0)),
        ])),
    }),
    'validations': validations_schema
})

'''
Example of a typical SONIC port setting:
setting":{
  "interface":{
    "speed":"10000",
    "lane_map":"13",
    "brkout_mode":"1x100G",
    "port":"1/1",
    "master":"Ethernet0", # Ethernet0 is master for Ethernet0-3.
    "index": "12"
  }
}
'''
sonic_port_setting = s.Dict({
    'interface': s.Dict({
        # some models like mellanox 2100 need command
        "command": s.Optional(s.String()),
        "speed": s.String(),
        # some models like mellanox 2100 do not have lane_map
        "lane_map": s.Optional(s.String()),
        # speed breakout mode a port in a particular trnasformation
        "brkout_mode": s.Optional(s.String()),
        # physical mapping of port on the device slot_id/port_id
        "port": s.Optional(s.String()),
        # master interface name for  abreakout capable port
        "master": s.Optional(s.String()),
        # index field from the platform.json interface entry
        "index": s.Optional(s.String()),
        # for some models ports are defined as part of a port group
        "port_group": s.Optional(s.String()),
        "port_group_speed": s.Optional(s.String()),
        "valid_speeds": s.Optional(s.String()),
        "alias": s.Optional(s.String()),
        }),
    'validations': validations_schema
    })

def get_port_setting_schema(vendor):
    # Todo(Mallika): Ideally we should map every supported OS to a port setting
    # schema(explicitly mapping to None, as in case of let's say centos is
    # fine). Do not ignore unknown OS silently, see AOS-10966 for details.
    return {
        'eos': eos_port_setting,
        'nxos': nxos_port_setting,
        'sonic': sonic_port_setting,
        'junos': junos_port_setting,
        'centos': None,
        'ubuntu gnu/linux': None,
    }.get(vendor.lower())

def get_linecared_port_setting_schema(vendor):
    return {
        'eos': eos_port_setting,
        'nxos': nxos_linecard_port_setting,
        'sonic': sonic_port_setting,
        'junos': junos_linecard_port_setting,
        'centos': None,
        'ubuntu gnu/linux': None,
    }.get(vendor.lower())
