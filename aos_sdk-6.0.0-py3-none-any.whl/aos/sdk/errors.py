# Copyright 2022-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=no-init

__all__ = [
    'ResolutionData',
    'Resolutions',
    'DisplayCategories',
    'ErrorMetaData',
    'Errors',
    'ErrorsBase',

    'build_related_entity_ids',
    'prepare_resolutions',
    'make_resolution',
]

import copy

VALUE_WAS_ALREADY_ALLOCATED_ERROR = 'Value was already allocated'


def build_related_entity_ids(related_entity_ids=None):
    """
    Generate "qualifier" to distinguish errors of the same type on the same
    node/relationship which happens due to other entities.

    :param related_entity_ids: list of node/relationship ids.
    """
    # TODO (psokolkov): Add hashing
    related_entity_ids = related_entity_ids or []
    return '_'.join(related_entity_ids)


class ResolutionData(object):
    # pylint: disable=invalid-name
    def __init__(self, resolution_id=None, hint='', entity_id=None):
        """
        :param resolution_id: string identifier for resolutions stored in TAC, also
                              used for UI mappings: see dump() method
        # :param category: string identifier for UI mapping
        :param hint: user facing helper text
        :param entity_id: string identifier for which
                          node/relationship/UI element/entity this resolution is
        """
        self.id = resolution_id or 'unknown'
        self.hint = hint or ''
        self.entity_id = entity_id

    def __eq__(self, other):
        return (self.id == other.id and
                self.hint == other.hint and
                self.entity_id == other.entity_id)

    def __repr__(self):
        return (
            'ResolutionData(resolution_id={resolution_id}, hint={hint}, '
            'entity_id={entity_id})'.format(
                resolution_id=self.id, hint=self.hint, entity_id=self.entity_id)
        )

    @classmethod
    def loads(cls, resolution_dict):
        return cls(**resolution_dict)

    def copy_with_changes(self, **changes):
        # Take unbound resolution as base and rewrite some fields, e.g. 'hint'
        new_resolution = copy.deepcopy(self)

        for key, value in changes.items():
            setattr(new_resolution, key, value)
        return new_resolution

    def dump(self):
        return {
            'category': self.id,
            'entity_id': self.entity_id,
            'hint': self.hint
        }


def make_resolution(resolution_id, entity_id, hint=None):
    resolution = {
        'resolution_id': resolution_id,
        'entity_id': entity_id
    }
    if hint:
        resolution['hint'] = hint
    return resolution


def prepare_resolutions(error_type, *args):
    """
    Helper function to easily fill entity_ids in error resolutions

    If number of passed entity_ids (len(args)) is less than number of resolutions,
    then the last entity_id is copied for convenience of usage.
    If number of passed entity_ids (len(args)) is greater than number of resolutions,
    then the last resolution is copied for convenience of usage.
    """
    resolutions = error_type.resolutions
    args = list(args)
    missing_entity_ids = len(resolutions) - len(args)
    if missing_entity_ids > 0:
        args.extend([args[-1]] * missing_entity_ids)
    elif missing_entity_ids < 0 and resolutions:
        # We need a copy not to affect error_type itself
        resolutions = copy.deepcopy(resolutions)
        resolutions.extend([resolutions[-1]] * -missing_entity_ids)

    return [
        make_resolution(resolution.id, entity_id)
        for resolution, entity_id in zip(resolutions, args)
    ]


class Resolutions(object):
    UNKNOWN = ResolutionData('unknown', 'unknown')

    RESOURCES_OVERRIDE = ResolutionData(
        'resources-override',
        'Reset resource group overrides via special button in resource group'
    )


class DisplayCategories(object):
    UNKNOWN = 'unknown'

    RESOURCES = 'resources'


class EntityTypes(object):
    UNKNOWN = 'unknown'


# pylint: disable=invalid-name
class ErrorMetaData(object):
    def __init__(self, _id, error_pattern, resolutions=None,
                 unbound_resolutions=None, display_category=None,
                 entity_type=None):
        """
        Defines the error type.

        Unbound resolutions are the resolutions that are not bound to any
        specific entity by entity ID.
        """
        self.id = _id
        self.entity_type = entity_type or EntityTypes.UNKNOWN
        self.error_pattern = error_pattern
        self.resolutions = resolutions or []
        # Resolutions that do not require entity_id and are common for a group
        # of graph entities (e.g. errors that require pool assignment, but not
        # specified by node)
        self.unbound_resolutions = unbound_resolutions or []
        self.display_category = display_category or DisplayCategories.UNKNOWN

    def __eq__(self, other):
        return (self.id == other.id and
                self.error_pattern == other.error_pattern and
                self.resolutions == other.resolutions and
                self.unbound_resolutions == other.unbound_resolutions and
                self.display_category == other.display_category)

    def __repr__(self):
        return (
            'ErrorMetaData(_id={id}, '
            'error_pattern={error_pattern}, '
            'resolutions={resolutions}, '
            'unbound_resolutions={unbound_resolutions}, '
            'display_category={display_category})'.format(
                id=self.id,
                error_pattern=self.error_pattern,
                resolutions=repr(self.resolutions),
                unbound_resolutions=repr(self.unbound_resolutions),
                display_category=self.display_category)
        )

    def get_error_message(self, context=None):
        context = context or {}
        message = self.error_pattern.format(**context)
        # Get rid of extra spaces. Main idea is to remove double spaces between
        # words. This helps to conveniently write error patterns when some pattern
        # arguments are not required
        message = ' '.join(message.split())
        return message

    def get_resolutions(self, error_resolutions):
        """
        Dump resolutions

        There are 3 possible cases:
        1. Resolution is passed via error_resolutions and present in
           ErrorMetaData.resolutions:
            - fill entity_id from passed error_resolution
            - fill hint from ErrorMetaData
        2. Resolution is not passed via error_resolutions, but present in
           ErrorMetaData.unbound_resolutions:
            Does not require explicit resolution_id<->entity_id mapping.
            - fill data from ErrorMetaData
        3. Resolution is passed via error_resolutions, but not present in
           ErrorMetaData:
            User specific case and is not common for errors of this type.
            Pass all user data as is.
        """
        predefined_resolutions = {resolution.id: resolution
                                  for resolution in self.resolutions}

        resolutions = []
        for resolution in error_resolutions:
            predefined_resolution = predefined_resolutions.get(
                resolution['resolution_id'])
            # case 1
            if predefined_resolution:
                predefined_resolution = copy.deepcopy(predefined_resolution)
                predefined_resolution.entity_id = resolution['entity_id']
                if resolution.get('hint') is not None:
                    predefined_resolution.hint = resolution['hint']
                resolutions.append(predefined_resolution)
                continue
            # case 3, resolution here is a plain dict. Load and dump later, so we
            # can control the format of response
            resolutions.append(ResolutionData.loads(resolution))

        # case 2
        resolutions.extend(self.unbound_resolutions)

        return [resolution.dump() for resolution in resolutions]

    def copy_with_changes(self, **changes):
        # Take base and rewrite some fields, e.g. 'display_category'
        new_resolution = copy.deepcopy(self)

        for key, value in changes.items():
            setattr(new_resolution, key, value)
        return new_resolution


class ErrorsMeta(type):
    def __new__(mcs, name, bases, attrs):
        errors = {}
        # Collect errors from the base classes
        for base in reversed(bases):
            if issubclass(base, ErrorsBase):
                errors.update(base.errors)

        # Collect errors from the new class
        errors.update({
            attr.id: attr for attr in attrs.values()
            if isinstance(attr, ErrorMetaData)
        })

        # Set errors as the errors attribute
        attrs['errors'] = errors
        return super(ErrorsMeta, mcs).__new__(mcs, name, bases, attrs)


class ErrorsBase(metaclass=ErrorsMeta):
    """
    Base class for validation errors.
    """
    errors = {}

    def __new__(cls):
        raise TypeError('Static class')

    @classmethod
    def get_error_message(cls, error_type, context=None):
        error_type_id = (error_type.id
                         if isinstance(error_type, ErrorMetaData)
                         else error_type)
        error_pattern = cls.errors[error_type_id].error_pattern
        if context:
            return error_pattern.format(**context)
        return error_pattern


class Errors(ErrorsBase):
    """
    Common validation errors for different reference designs.

    This class must be used as a parent class for a reference design Errors class.
    For non reference design modules, as extensions, ErrorsBase must be used.
    """
    RESOURCE_ALLOCATION_ERROR = ErrorMetaData(
        'RESOURCE_ALLOCATION_ERROR',
        'Resource "{group_name}" ({group_type}) allocation error: {message}')

    RESOURCE_ALREADY_ALLOCATED = ErrorMetaData(
        'RESOURCE_ALREADY_ALLOCATED',
        'Resource "{group_name}" ({group_type}) allocation error: {message}',
        unbound_resolutions=[Resolutions.RESOURCES_OVERRIDE],
        display_category=DisplayCategories.RESOURCES,
    )


def get_resource_allocation_error_type(error_message):
    return (Errors.RESOURCE_ALREADY_ALLOCATED
            if error_message == VALUE_WAS_ALREADY_ALLOCATED_ERROR else
            Errors.RESOURCE_ALLOCATION_ERROR)
