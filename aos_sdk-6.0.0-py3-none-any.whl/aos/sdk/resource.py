#!/usr/bin/env python3
# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""
Model various types of resources used by AOS when building blueprint
"""

# pylint: disable=undefined-loop-variable
class RestObject(object):
    """
    AOS REST API uses json to exchange data with client
    """
    def json(self):
        """Return json representation of this object"""
        raise NotImplementedError()


class AsnPool(RestObject):
    """A Pool of multiple ASN ranges"""
    API_URL = '/api/resources/asn-pools'

    def __init__(self, name):
        super(AsnPool, self).__init__()
        self.name = name
        self.ranges = []

    def add_range(self, first, last):
        """Add ASN range to the pool"""
        self.ranges.append((first, last))

    def json(self):
        return {
            'display_name': self.name,
            'status': None,
            'ranges': [{'first': 60000, 'last': 64000}],
            'tags': []
        }


class IpPool(RestObject):
    """A Pool of multiple IP subnets"""
    API_URL = '/api/resources/ip-pools'

    def __init__(self, name):
        super(IpPool, self).__init__()
        self.name = name
        self.subnets = []

    def add_subnet(self, subnet):
        """Add ipv4 subnet to the pool"""
        self.subnets.append(subnet)

    def json(self):
        return {
            'display_name': self.name,
            'status': None,
            'subnets': [{'network': subnet} for subnet in self.subnets],
            'tags': []
        }


class VniPool(RestObject):
    """A Pool of multiple VNI ranges"""
    API_URL = '/api/resources/vni-pools'

    def __init__(self, name):
        super(VniPool, self).__init__()
        self.name = name
        self.ranges = []

    def add_range(self, first, last):
        """Add VNI range to the pool"""
        self.ranges.append((first, last))

    def json(self):
        return {
            'display_name': self.name,
            'status': None,
            'ranges': [
                {'first': vni_range[0], 'last': vni_range[1]}
                for vni_range in self.ranges
            ],
            'tags': []
        }

class IntegerPool(RestObject):
    """A Pool of multiple VNI ranges"""
    API_URL = '/api/resources/integer-pools'

    def __init__(self, name):
        super(IntegerPool, self).__init__()
        self.name = name
        self.ranges = []

    def add_range(self, first, last):
        """Add VNI range to the pool"""
        self.ranges.append((first, last))

    def json(self):
        return {
            'display_name': self.name,
            'status': None,
            'ranges': [
                {'first': integer_range[0], 'last': integer_range[1]}
                for integer_range in self.ranges
            ],
            'tags': []
        }

