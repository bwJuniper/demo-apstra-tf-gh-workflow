# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=invalid-name
# pylint: disable=redefined-builtin
import json
import copy
from aos.sdk.collection_utils import find
from aos.sdk.generator import format_speed
import six
from six.moves import range

def is_10G(interface_speed):
    return interface_speed['value'] == 10 and interface_speed['unit'] == 'G'

def is_25G(interface_speed):
    return interface_speed['value'] == 25 and interface_speed['unit'] == 'G'

def is_40G(interface_speed):
    return interface_speed['value'] == 40 and interface_speed['unit'] == 'G'

def is_50G(interface_speed):
    return interface_speed['value'] == 50 and interface_speed['unit'] == 'G'

def is_100G(interface_speed):
    return interface_speed['value'] == 100 and interface_speed['unit'] == 'G'

def make_setting(param):
    return {'param': param}

def gen_interface(pos, state, speed, name, param, mapping, roles=None):
    roles = roles or ['unused']
    return {'position': pos,
            'state': state,
            'speed': speed,
            'setting': make_setting(param),
            'name': name,
            'mapping': mapping,
            'roles': roles}

def gen_default_interfaces_from_dp(device_profile):
    interfaces = []
    for interface in device_profile['ports']:
        for transform in interface['transformations']:
            if transform['is_default']:
                for intf in transform['interfaces']:
                    interfaces.append(intf)
    if device_profile['selector']['model'] == "DCS-7050QX-32S":
        interfaces_to_remove = ['Ethernet%d' % i for i in range(1, 4+1)]
        interfaces = [interface for interface in interfaces if
                      interface['name'] not in interfaces_to_remove]
    if device_profile['selector']['os'] == "NXOS":
        #global should not have speed as per NXOS jinja
        for interface in interfaces:
            if interface['setting']:
                old_param = json.loads(interface['setting'])
                old_param['global']['speed'] = ""
                interface['setting'] = json.dumps(old_param)
    return interfaces

def gen_default_interface_map(device_profile, id=None):
    if id is None:
        id = 'interface_map_%s' % device_profile['id']
    interfaces = gen_default_interfaces_from_dp(device_profile)
    return {'label': 'interface_map_%s' % device_profile['id'],
            'id': id,
            'device_profile_id': device_profile['id'],
            'interfaces': [gen_interface(
                pos=idx+1, state=interface['state'],
                speed=interface.get('speed'),
                name=interface['name'],
                param=interface.get('setting'),
                mapping=interface.get('mapping'))
                           for idx, interface in enumerate(interfaces)]}

def gen_interface_map(device_profile, logical_device, dp_usage, label=None, id=None):
    """Generate an interface map from device profile and logical device.
       Logical ports are mapped sequentially to device profile interfaces
       specified in dp_usage.

       Args:
        device_profile  Device profile as dictionary
        logical_device  Logical device as dictionary
        dp_usage    A list of tuples denoting which interfaces are used to
                    map to logical ports. Each tuple can be of one of the
                    following forms:

                    1. (<port id>, <transformation id>) - all active interfaces
                       in the given transformation are used; active interfaces
                       are mapped in the order they appear in the transformation.
                    2. (<port id>, <transformation id>, <interface id>) - the
                       particular interface in the transformation is used in
                       mapping.
        label   User-friendly name for the interface map; if None, generates
                one from device profile ID and logical device ID
        id      Unique identifier of the interface map in the global catalog;
                if None, generates one from device profile ID and logical device ID
    """
    ports = {
        port['port_id']: {
            transformation['transformation_id']: {
                intf['interface_id']: intf
                for intf in transformation['interfaces']
            }
            for transformation in port['transformations']
        }
        for port in device_profile['ports']
    }


    def parse_usage(usage):
        if len(usage) == 2:
            return usage[0], usage[1], None
        return usage

    # Check that used interfaces exist and are all active with speed
    dp_usage = [parse_usage(u) for u in dp_usage]
    for port_id, transformation_id, intf_id in dp_usage:
        if port_id not in ports:
            raise ValueError('Port id %d does not exist in device profile %s' % \
                             (port_id, device_profile['label']))
        transformation = ports[port_id].get(transformation_id)
        if transformation is None:
            raise ValueError('Transformation id %d does not exist in port %d' %\
                             (transformation_id, port_id))
        if intf_id is None:
            continue

        intf = transformation.get(intf_id)
        if intf is None:
            raise ValueError('Interface id %d does not exist in transformation %d '
                             'of port %d' % (intf_id, transformation_id, port_id))
        if intf['state'] != 'active':
            raise ValueError('Cannot use inactive interface %d in transformation %d'
                             ' of port %d' % (intf_id, transformation_id, port_id))

        if intf.get('speed') is None:
            raise ValueError('Interface %d transformation %d port %d has no speed'%\
                             (intf_id, transformation_id, port_id))

    # Check that interface counts match logical port count
    logical_port_count = sum(
        sum(pg['count'] for pg in panel['port_groups'])
        for panel in logical_device['panels']
    )

    physical_port_count = sum(
        1 if intf_id is not None else
        sum(1 if intf['state'] == 'active' else 0
            for intf in six.itervalues(ports[port_id][transformation_id]))
        for port_id, transformation_id, intf_id in dp_usage
    )

    if logical_port_count != physical_port_count:
        raise ValueError('Logical port count %d != physical port count %d' % \
                         (logical_port_count, physical_port_count))

    # Check that at most one transformation used per port
    port_transforms = {}
    for port_id, transformation_id, _ in dp_usage:
        existing = port_transforms.get(port_id)
        if existing is not None and existing != transformation_id:
            raise ValueError('Port %d transformation conflict: %d != in use %d' %
                             (port_id, transformation_id, existing))
        port_transforms[port_id] = transformation_id

    def logical_ports():
        for panel_id, panel in enumerate(logical_device['panels'], 1):
            start_index = panel['port_indexing']['start_index']
            port_index = 0
            for pg in panel['port_groups']:
                for _ in range(pg['count']):
                    yield (panel_id, start_index + port_index,
                           pg['speed'], pg['roles'])
                    port_index += 1

    # Generate imap interfaces keyed by (port_id, intf_id) for sorting by position
    interfaces = {}
    ld_ports = logical_ports()
    for port_id, transformation_id, intf_id in dp_usage:
        if intf_id is not None:
            intfs = [ports[port_id][transformation_id][intf_id]]
        else:
            intfs = [intf for intf in
                     six.itervalues(ports[port_id][transformation_id])
                     if intf['state'] == 'active']
        for intf in intfs:
            ld_panel_id, ld_port_id, speed, roles = next(ld_ports)
            iid = intf['interface_id']
            if speed != intf['speed']:
                raise ValueError('Port %d transformation %d interface %d speed %s '
                                 '!= logical panel %d port %d speed %s' % \
                                 (port_id, transformation_id, iid,
                                  format_speed(intf['speed']), ld_panel_id,
                                  ld_port_id, format_speed(speed)))

            interfaces[(port_id, iid)] = {
                'name': intf['name'],
                'state': intf['state'],
                'speed': copy.deepcopy(intf['speed']),
                'param': copy.deepcopy(intf['setting']),
                'roles': copy.deepcopy(roles),
                'mapping': [port_id, transformation_id, iid,
                            ld_panel_id, ld_port_id],
            }

    def make_unused(intf, port_id, transformation_id):
        return {
            'name': intf['name'],
            'state': intf['state'],
            'speed': copy.deepcopy(intf['speed']) if intf.get('speed') else None,
            'param': copy.deepcopy(intf['setting']),
            'roles': ['unused'],
            'mapping': [port_id, transformation_id, intf['interface_id'], None, None]
        }

    # Add unused interfaces (including inactive interfaces) for used ports
    for port_id, transformation_id in six.iteritems(port_transforms):
        for intf_id, intf in six.iteritems(ports[port_id][transformation_id]):
            key = (port_id, intf_id)
            if key not in interfaces:
                interfaces[key] = make_unused(intf, port_id, transformation_id)

    def get_unused_port_transformation(port_id):
        """If there are no inter-port usability constraints, we choose the default
        transformation for unused ports. Some devices have constraints on some
        ports state depending on how other ports in the system are being used.
        In Mellanox 2700, if odd number ports are broken down into 10G or 25G
        port speed, the even number ports have to be explicitly disabled. So
        if we are chosing odd number ports in IM, we need to choose the
        transformation for next even number port which disables the port.

        We can make this a plugin architecture based on (model, os) if we
        need to express inter-port usability constraints for more vendor os
        and hw models.
        """
        #Arista model DCS-7050QX-32S either can have hardware port-group 1
        #select Et5/1-4 or hardware port-group 1 select Et1-4, default
        #port-group1 select Et5/1-4 Here at below code if port-group 1-4 is
        #not used then we will pick default port 5.
        if device_profile['selector']['model'] == "DCS-7050QX-32S":
            if port_id <= 4 or (port_id == 5 and \
                    any(p in port_transforms for p in range(1, 5))):
                return None
        if device_profile['selector']['os'] == 'Cumulus' and \
            device_profile['selector']['model'] == 'MSN2700' and \
            port_id % 2 == 0 and \
            port_id-1 in port_transforms and \
            ports[port_id-1][port_transforms[port_id-1]][1]['speed']['value'] \
                in [10, 25]:
            transformation = find(lambda t: all(intf['state'] == 'inactive' \
                for intf in t['interfaces']), port['transformations'])
        else:
            transformation = find(lambda t: t['is_default'], port['transformations'])
        assert transformation, "Could not find a transformation for unused port: " \
                "os %s model %s port_id %d " % (device_profile['selector']['os'],
                                                device_profile['selector']['model'],
                                                port_id)
        return transformation

    # TODO(michael): parameterize transformation for unused ports
    # Add unused interfaces from unused ports (taking default transformation for now
    # which is the behavior of old port map generators)

    for port_id in ports:
        if port_id in port_transforms:
            continue
        port = find(lambda p: p['port_id'] == port_id, device_profile['ports'])  # pylint: disable=cell-var-from-loop
        transformation = get_unused_port_transformation(port_id)
        if transformation is None:
            continue
        for intf in transformation['interfaces']:
            interfaces[(port_id, intf['interface_id'])] = \
                make_unused(intf, port_id, transformation['transformation_id'])

    return {
        'device_profile_id': device_profile['id'],
        'logical_device_id': logical_device['id'],
        'label': label or '%s__%s' % (device_profile['id'],
                                      logical_device['id']),
        'id': id or '%s__%s' % (device_profile['id'],
                                logical_device['id']),
        'interfaces': [
            gen_interface(position, **interfaces[k])
            for position, k in enumerate(sorted(interfaces), 1)
        ]
    }
