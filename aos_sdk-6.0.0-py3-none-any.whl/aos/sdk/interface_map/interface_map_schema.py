# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

""" This module captures the schema definitions for the interface map which
can be resused across modules

All schema is defined using the Python package lollipop 1.1.5
which can further be used for serialization/deserialization,
validation etc. in consumer modules.
"""

import aos.sdk.schema as s

interface_setting_schema = s.Dict({'param': s.String(
    description='Indicates interface interface setting parameters')})


def validates_first_three_entries_are_always_non_none(data):
    errors = s.ValidationErrorBuilder()
    for ele in data[:3]:
        if ele is None:
            errors.add_error('mapping',
                             'The first three entries of mapping '
                             'field need to be integers')
    errors.raise_errors()


interface_schema = s.Dict({
    'name': s.String(validate=s.Length(min=1), description='Interface name'),
    'roles': s.List(s.String(), validate=s.Length(min=1),
                    description='Roles the interface can participate in'),
    'position': s.Integer(
        description='1-based index that corresponds to an absolute position of a '
                    'logical port irrespective of a panel it belongs to'),
    'state': s.Enum(['active', 'inactive'],
                    description='Is the interface active or inactive'),
    'speed': s.Optional(s.Speed, description='Interface speed'),
    'setting': interface_setting_schema,
    'mapping': s.List(s.Optional(s.Integer()),
                      validate=[
                          s.Length(exact=5),
                          validates_first_three_entries_are_always_non_none],
                      description='This list of 5 integers represent which '
                      '(port ID, transformation ID and interface ID) in the '
                      'device profile and which '
                      '(panel ID, port ID) in the logical device '
                      'is this interface coming from')})

interface_map_fields = {
    'device_profile_id': s.String(validate=s.Length(min=1),
                                  description='The ID of the Device Profile '
                                  'which this interface map is built from'),
    'logical_device_id': s.String(validate=s.Length(min=1),
                                  description='The ID of the logical device '
                                  'this interface map is built from'),
    'label': s.String(validate=s.Length(min=1, max=64), description='Human '
                      'friendly name for the Interface Map as read on UI'),
    'interfaces': s.List(interface_schema, validate=s.Length(min=1),
                         description='List of interfaces available as part of '
                         'this interface map')}

interface_map_schema = s.Object(interface_map_fields)

device_profile_digest = s.Dict({
    'label': s.String(
        validate=s.Length(min=1, max=64), description='Label of device profile.'),
    'id': s.String(validate=s.Length(min=1))})

logical_device_digest = s.Dict({
    'label': s.String(
        validate=s.Length(min=1), description='Label of logical device.'),
    'id': s.String(validate=s.Length(min=1))})

interface_map_digest = {
    'device_profile': device_profile_digest,
    'logical_device': logical_device_digest,
    'label': s.String(
        validate=s.Length(min=1, max=64),
        description='Label of interface map digest.'
    )}
