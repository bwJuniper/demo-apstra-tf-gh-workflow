# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


"""Library functions for working with interface map assignments in blueprint"""

import json
import copy
import logging
from functools import partial

from aos.sdk.graph import is_in
from aos.sdk.collection_utils import get_only_item
from aos.sdk.generator import gen_id, gen_device_profile_node, gen_interface_map_node
import aos.sdk.schema as s
from aos.sdk.logical_device import logical_devices_match
from aos.sdk.facade import ResourceNotFoundError
import six

LOGGER = logging.getLogger(__name__)


def get_interface_map_assignments_by_roles(graph, roles):
    """Returns interface map assignments assuming that the graph is semantically
       consistent. There should be only one interface map per system.
    """
    assignments = {}
    for system in graph.get_nodes('system', role=is_in(roles)):
        interface_map = get_only_item(graph.traverse(system).out('interface_map')
                                      .target())
        assignments[system.id] = interface_map.id if interface_map else None
    return assignments


SUPPORTED_SYSTEM_ROLES = ['spine', 'superspine', 'leaf',
                          'access', 'generic']

get_interface_map_assignments = partial(get_interface_map_assignments_by_roles,
                                        roles=SUPPORTED_SYSTEM_ROLES)


def get_logical_devices(blueprint, ld_nodes=None):
    if ld_nodes is None:
        ld_nodes = blueprint.get_nodes(type='logical_device')

    return {
        node.id: json.loads(node.json)
        for node in ld_nodes
    }


def import_default_interface_maps(blueprint, aos_library, ld_nodes=None):
    """Creates interface map and device profile nodes in graph.

    :param ld_nodes: if not None, interface maps only for the given logical
        device nodes will be imported
    """

    ims = []
    device_profiles = {}
    logical_devices = get_logical_devices(blueprint, ld_nodes)
    for im in aos_library.interface_maps.list():
        ld = aos_library.logical_devices.get(im['logical_device_id'])
        if not ld:
            LOGGER.error('Interface map "%s" missing logical device "%s"',
                         im['label'], im['logical_device_id'])
            continue

        device_profile = aos_library.device_profiles.get(im['device_profile_id'])
        if not device_profile:
            LOGGER.error('Interface map "%s" missing device profile "%s"',
                         im['label'], im['device_profile_id'])
            continue
        if device_profile['reference_design_capabilities']['datacenter'] ==\
                'disabled':
            LOGGER.error('Interface map "%s" device profile "%s" is disabled for '
                         '\'Datacenter\'', im['label'], im['device_profile_id'])
            continue

        matching_ld_nodes = \
            [
                ld_node_id
                for ld_node_id in logical_devices
                if logical_devices_match(ld, logical_devices[ld_node_id])
            ]
        if matching_ld_nodes:
            im1 = copy.deepcopy(im)
            ims.append((im1, matching_ld_nodes))
            device_profiles[device_profile['id']] = device_profile

    device_profile_nodes = {
        dp['id']: blueprint.get_nodes('device_profile',
                                      device_profile_id=dp['id']).first or \
            gen_device_profile_node(blueprint, dp)
        for dp in six.itervalues(device_profiles)
    }

    for im, ld_node_ids in ims:
        gen_interface_map_node(blueprint, im, ld_node_ids,
                               device_profile_nodes[im['device_profile_id']])


def import_interface_map(blueprint, aos_library, interface_map):
    """
        Args:
            blueprint   sdk.graph.Graph instance
            aos_library sdk.aos_library.AosLibraryBase instance
            interface_map   dict representation of IM

        Returns:
            Graph node of type 'interface_map'
    """
    interface_map = copy.deepcopy(interface_map)
    im_id = interface_map.get('id')
    if im_id is None:
        im_id = gen_id()
        while blueprint.get_node(im_id) is not None:
            im_id = gen_id()
        interface_map['id'] = im_id
    elif blueprint.get_node(im_id) is not None:
        raise s.ValidationError(
            {'id': 'Blueprint already has interface map with this id'})

    logical_device = aos_library.logical_devices.get(
        interface_map['logical_device_id'])
    if not logical_device:
        raise s.ValidationError({
            'logical_device_id': 'Logical device not found in global catalog'
        })

    device_profile = aos_library.device_profiles.get(
        interface_map['device_profile_id'])
    if not device_profile:
        raise s.ValidationError({
            'device_profile_id': 'Device profile not found in global catalog'
        })
    if device_profile['reference_design_capabilities']['datacenter'] == 'disabled':
        raise s.ValidationError({
            'device_profile_id': 'Device profile {} is disabled for \'Datacenter\' '
                                 'reference designs'.format(device_profile['id'])
        })

    dp_node = blueprint.get_nodes('device_profile',
                                  device_profile_id=device_profile['id']).first
    if not dp_node:
        dp_node = gen_device_profile_node(blueprint, device_profile)

    logical_devices = get_logical_devices(blueprint)
    matching_ld_nodes = \
        [
            ld_node_id
            for ld_node_id in logical_devices
            if logical_devices_match(logical_device, logical_devices[ld_node_id])
        ]

    if not matching_ld_nodes:
        raise s.ValidationError({
            'logical_device_id': 'No logical device in blueprint is compatible ' +
                                 'with this interface map.'
        })

    return gen_interface_map_node(blueprint, interface_map, matching_ld_nodes,
                                  dp_node)


def del_interface_map(blueprint, im_node_id):
    node = blueprint.get_node(im_node_id)
    if node is None:
        raise ResourceNotFoundError('No node with id %s' % im_node_id)

    if node.type != 'interface_map':
        raise s.ValidationError('Invalid node type %s - expected "interface_map"' \
                                 % node.type)

    systems_using_im = [
        (system.id, system.label)
        for system in blueprint.traverse(node).in_('interface_map').source('system')
    ]

    if systems_using_im:
        raise s.ValidationError('Cannot delete interface map. Used by systems: %s' \
                                % ' '.join(['%s (%s)' % (label, node_id)
                                            for node_id, label in systems_using_im
                                           ]))
    dp_nodes = list(blueprint.traverse(node).out('device_profile') \
                                            .target('device_profile'))
    blueprint.del_node(node)
    for dp_node in dp_nodes:    #Delete orphaned nodes after deleting im
        if not blueprint.traverse(dp_node).in_().first and \
                                not blueprint.traverse(dp_node).out().first:
            blueprint.del_node(dp_node)
