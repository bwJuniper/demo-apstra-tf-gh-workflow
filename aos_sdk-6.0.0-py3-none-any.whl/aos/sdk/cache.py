# Copyright 2021-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import absolute_import

import copy
import functools
import itertools
import types
import weakref

import lru
import six
from six.moves import collections_abc


__all__ = (
    'DEFAULT_CACHE_SIZE',
    'DONT_CACHE',
    'CACHE_MISS',
    'Cache',
    'CallableCache',
    'hashkey',
    'cached',
    'cachedmethod',
)

# a default capacity of LRU cache if no parameters are given. please
# specify your own capacity where applicable. If size of LRU cache is
# smaller then frequent rotation of elements can lead to a huge number
# of misses.
DEFAULT_CACHE_SIZE = 128
# a default indicator about cache lookup miss.
CACHE_MISS = object()
# a dummy caching value which means that cache interaction has to be
# skipped and function should be called directly.
# this can be returned from both function and a hash key function.
DONT_CACHE = object()


def hashkey(*args, **kwargs):
    '''Returns a datastructure that is hasheable and can be used
    as a key for dict or set.

    A key is _typed_, a type of elements matters.
    E.g hashkey(3, 1) != hashkey(3.0, True)
    '''
    return (
        tuple(_hashitem(arg) for arg in args),
        tuple(itertools.chain(
            (k, _hashitem(v)) for k, v in sorted(six.iteritems(kwargs))
        ))
    )


def _hashitem(arg):
    '''Hashes a single value. If value is composite, then it
    recursively traverses it
    '''
    try:
        hash(arg)
        return type(arg), arg
    except TypeError:
        pass

    if isinstance(arg, dict):
        return type(arg), tuple(
            itertools.chain(
                (k, _hashitem(v)) for k, v in sorted(six.iteritems(arg))
            )
        )

    if isinstance(arg, (list, tuple)):
        return type(arg), tuple(_hashitem(item) for item in arg)

    if isinstance(arg, (set, frozenset)):
        return type(arg), tuple(_hashitem(item) for item in sorted(arg))

    return type(arg), id(arg)


class CacheInfo(object):
    '''Different statistics on cache.'''

    def __init__(self, lru_cache):
        self.hits, self.misses = lru_cache.get_stats()
        self.length = len(lru_cache)
        self.capacity = lru_cache.get_size()

    def __repr__(self):
        return (
            '<{0.__class__.__name__}('
            'hits={0.hits} '
            'misses={0.misses} '
            'length={0.length} '
            'capacity={0.capacity} '
            'accesses={0.accesses} '
            'hit_ratio={0.hit_ratio} '
            'free_ratio={0.free_ratio})>'
        ).format(self)

    @property
    def accesses(self):
        '''A number of attempts to get a value from a cache.'''
        return self.hits + self.misses

    @property
    def hit_ratio(self):
        '''A ratio of successful lookups to all lookups.'''
        return float(self.hits) / self.accesses if self.accesses else 0.0

    @property
    def free_ratio(self):
        '''A ratio of spare space within a cache.'''
        return float(self.length) / self.capacity


class Cache(collections_abc.MutableMapping):
    '''A default cache implementation.

    This is a tiny layer around lru.LRU with a bare minimum of
    method. There is no intention to support full mapping interface.
    '''

    def __init__(self, size=DEFAULT_CACHE_SIZE):
        self._cache = lru.LRU(size)

    def _instance(self):
        return self._cache

    def __getitem__(self, key):
        return self._instance()[key]

    def __setitem__(self, key, value):
        self._instance()[key] = value

    def __delitem__(self, key):
        self._instance().pop(key, None)

    def __len__(self):
        return len(self._instance())

    def __iter__(self):
        return iter(self._instance())

    def get(self, key, default=CACHE_MISS):  # pylint: disable=useless-super-delegation
        return super(Cache, self).get(key, default)

    def clear(self):
        self._instance().clear()

    def get_stats(self):
        return CacheInfo(self._instance())


class CallableCache(Cache):

    def __init__(self, func, key=hashkey, size=DEFAULT_CACHE_SIZE):
        super(CallableCache, self).__init__(size)
        self._func = func
        self._keyfunc = key
        functools.update_wrapper(self, func, updated=())

    def __getattr__(self, key):
        return getattr(self.__getattribute__('_func'), key)

    def __call__(self, *args, **kwargs):
        cache_key = self._keyfunc(*args, **kwargs)
        if cache_key is DONT_CACHE:
            return self._func(*args, **kwargs)

        cache = self._instance()
        cached_value = cache.get(cache_key, CACHE_MISS)
        if cached_value is CACHE_MISS:
            cached_value = self._func(*args, **kwargs)
            if cached_value is not DONT_CACHE:
                cache[cache_key] = cached_value

        return cached_value


class _CachedMethodCache(CallableCache):
    '''This is a cache that works as a callable and can be
    bound to an object.

    This is required if you have a method and want to get
    its get_info and clear methods.

        class TestClass(object):

            @cachedmethod()
            def method(self):
                return 1

        a = TestClass()
        a.method.clear()

    So, if you want to call a methods own methods and want
    a bound function, you need an object with a get descriptor
    because metaclass type binds only functions.
    '''
    # a registry that keeps a mapping between objects
    # and its bound _CachedMethodCache.
    REGISTRY = weakref.WeakKeyDictionary()

    def __init__(self, func, key, cache_getter):
        super(_CachedMethodCache, self).__init__(
            func,
            # since we rebound this callable, then __call__
            # has a following signature:
            #
            # __call__(self, caller, *args, **kwargs)
            #
            # instead of expected. this decorator strips a first argument.
            lambda caller, *args, **kwargs: key(*args, **kwargs)
        )
        self._cache_getter = cache_getter
        self._caller = None
        # we do not need to have our own cache instance here because
        # a real instance will be taken from a cache_getter. We
        # also cannot get an instance now because we rely on a late
        # binding that will take its place during exeuction of __get__
        # descriptor.
        del self._cache

    def __get__(self, instance, owner=None):
        # this descriptor is required because default metaclass does
        # not bind callbables to objects if these callbables are not
        # functions.
        if instance is None:
            return None

        if instance not in self.REGISTRY:
            self_copy = copy.copy(self)
            self_copy._caller = weakref.ref(instance)
            self.REGISTRY[instance] = types.MethodType(self_copy, instance)

        return self.REGISTRY[instance]

    def _instance(self):
        # pylint: disable=not-callable
        return self._cache_getter(self._caller())


def cached(maxsize=DEFAULT_CACHE_SIZE, key=hashkey):
    '''Cached is a decorator for functions (not for methods)
    It has a similar meaning and purpose as @functools.lru_cache
    from Python 3.

    @param maxsize: a maxsize of the cache. If cache is provided,
        then this parameter is ignored.
    @param key: a function, that returns a hasheable structure
        based on given *args and **kwargs
    @param cache: a cache to use. If cache is None (default),
        then it will be created.
    '''
    def decorator(func):
        return CallableCache(func, key, maxsize)

    return decorator


def cachedmethod(maxsize=DEFAULT_CACHE_SIZE, key=hashkey):
    '''Cachedmethod is a decorator for methods (not for functions)
    It has a similar meaning and purpose as @functools.lru_cache
    from Python 3.

    We have separate @cached and @cachedmethod because we do not want to
    store references to an object itself: this immediately mean circular
    reference.

    @param maxsize: a maxsize of the cache. If cache is provided,
        then this parameter is ignored.
    @param key: a function, that returns a hasheable structure
        based on given *args and **kwargs
    @param cache: a cache to use. If cache is None (default),
        then it will be created.
    '''
    caches = weakref.WeakKeyDictionary()

    def cache_getter(caller):
        if caller is None:
            return lru.LRU(maxsize)

        value = caches.get(caller, CACHE_MISS)
        if value is CACHE_MISS:
            value = caches[caller] = lru.LRU(maxsize)

        return value

    def decorator(func):
        return _CachedMethodCache(func, key, cache_getter)

    return decorator
