# Copyright 2021-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

r"""
This module contains useful tools to instrument applications.

Modules that use it should create instances of the nested instrument like below:

    instrument = instrument.nested(source=__name__)

this way any events that are created using this instrument will automatically
contain an indication of where these events are coming from.

Three basic methods constitute main instrumentation API: begin, checkpoint and end.
There are corresponding events emitted when any of these methods are called. Also,
there are some shortcuts to simplify the usage and optimize for widespread scenarios.

    with instrument.it('activity_name'):
        run_something()

Conceptually there are two main objects that instrument is working with:
Activity and Event. Activity is some process stretched in time that we would like to
track. It is started with begin() and finished with end(). In the middle of Activity
a checkpoint() can be made tracking some significant milestone within the Activity.
Event is what instrument emits as the result of begin/checkpoint/end invocation
and contains the details about tracked Activities. There is a special activity that
spans during process lifetime and allows to emit checkpoints against it at any time
using any instrument -- it could be useful in tracking important application lifetime
events/processes that are occurring in the different modules. See example below.

    instrument.checkpoint(instrument.LIFETIME, 'mounts completed')

Instruments are forming a tree structure. Any instrument can define context
properties. Resulting events that will be emitted will contain all the properties
specified by the used instrument or any of the parent instances with child/nested
instrument overriding the parent ones in case of usage of the same properties.
This way in order to add a property to all the events it's enough to add such
property on the root instrument level.

Context properties are either some value or a callable. Usage of a callable allows
to hook up some important metric calculation value of which is only known at the time
of execution.

The simplest approach on consuming the instrumentation data is to use
LoggingSubscriber shipped with this module. In this scenario instrumentation data is
simply emitted as INFO log messages with a predefined prefix and JSON as events
encoding scheme. These messages and can be easily grep-ed for analysis, for example
(assuming you are in the directory with all the logs written in the file systems and
creating "instrumentation.json" in the parent directory):

    grep -rohP "(?<=\[INSTRUMENTATION\] ).+" . > ../instrumentation.jsonl
"""

from __future__ import absolute_import
from __future__ import division

import json
import logging
import time
from contextlib import contextmanager
from functools import wraps
from uuid import uuid4

import psutil
import six

# pylint: disable=redefined-outer-name, redefined-builtin, invalid-name

LOGGER = logging.getLogger(__name__)
_process = psutil.Process()


class Event(object):
    def __init__(self, type, properties):
        self.type = type
        self.properties = properties


class ActivityInfo(object):
    def __init__(self, id, name, started_at, properties):
        self.id = id
        self.name = name
        self.started_at = started_at
        self.last_checkpoint_at = None
        self.properties = properties


def failsafe(fn):
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        # pylint: disable=broad-except
        except Exception as err:
            LOGGER.warning(
                'error collecting instrumentation inside %s: %s',
                fn.__name__, err, exc_info=True)
    return wrapper


class Instrument(object):
    # activity ID corresponding to the lifetime of the application, it's started when
    # this module is being imported and allows "checkpointing" at any time
    # instrument.checkpoint(instrument.LIFETIME, 'mounts completed')
    LIFETIME = 'lifetime'

    def __init__(self, parent=None, **properties):
        self._parent = parent
        self._properties = properties  # context that will be added to each event
        self._activities = dict()  # activity_id -> ActivityInfo
        self.subscribers = set()
        self.enabled = True

    def nested(self, **properties):
        return Instrument(parent=self, **properties)

    def is_effectively_enabled(self):
        # instrumentation is enabled if it's not disabled all the way to the root
        # so that if root is disabled, everything is disabled
        if not self.enabled:
            return False
        if self._parent:
            return self._parent.is_effectively_enabled()
        return True

    @contextmanager
    def it(self, name, **properties):
        activity_id = self.begin(name, **properties)
        try:
            yield activity_id
        except Exception as exception:
            self.end(
                activity_id,
                exception_type=type(exception).__name__,
                exception=str(exception),
            )
            raise  # re-raise exception
        else:  # no exception
            # do not add any exception related properties to be less wordy
            self.end(activity_id)

    def wrap(self, name=None, **properties):
        """ Wraps entire function adding instrumentation """

        def wrapper(func):
            @wraps(func)
            def wrapped(*args, **kwargs):
                with self.it(name or func.__name__, **properties):
                    return func(*args, **kwargs)
            return wrapped
        return wrapper

    def _fetch_activity(self, activity_id, remove=False):
        # looking not only at its own activities allows to checkpoint the activity
        # started by parent instrument
        if activity_id in self._activities:
            if remove:
                return self._activities.pop(activity_id)
            else:
                return self._activities[activity_id]

        if self._parent:
            return self._parent._fetch_activity(activity_id, remove)

        return None

    @failsafe
    def begin(self, activity_name, activity_id=None, **properties):
        if not self.is_effectively_enabled():
            return None

        activity_id = activity_id or uuid4().hex

        if activity_id in self._activities:
            LOGGER.warning('overwriting already existing activity "%s"', activity_id)

        now = time.time()

        self._activities[activity_id] = ActivityInfo(
            activity_id, activity_name, now, properties.copy())

        properties.update(
            timestamp=now,
            activity_id=activity_id,
            activity_name=activity_name)

        self._emit('begin', properties)

        return activity_id

    def _create_props(self, activity, now, properties):
        # extra supplied props take precedence over what is specified in the
        # activity already
        properties = dict(
            activity.properties,
            **properties)

        # default properties overriding the user ones if user uses special names
        # like "activity_id" so that correct structure/semantic is preserved
        properties.update(
            timestamp=now,
            activity_id=activity.id,
            activity_name=activity.name,
            started_at=activity.started_at,
            elapsed_sec=now - activity.started_at,
            elapsed_since_last_checkpoint_sec=now - (
                activity.last_checkpoint_at or activity.started_at))

        return properties

    @failsafe
    def checkpoint(self, activity_id, checkpoint_name, **properties):
        if not self.is_effectively_enabled():
            return

        activity = self._fetch_activity(activity_id, remove=False)

        if activity is None:
            LOGGER.warning('unable to find activity with ID "%s"', activity_id)
            return

        now = time.time()
        properties = self._create_props(activity, now, properties)
        properties['checkpoint'] = checkpoint_name
        activity.last_checkpoint_at = now

        self._emit('checkpoint', properties)

    @failsafe
    def end(self, activity_id, **properties):
        if not self.is_effectively_enabled():
            return

        activity = self._fetch_activity(activity_id, remove=True)

        if activity is None:
            LOGGER.warning('unable to find activity with ID "%s"', activity_id)
            return

        now = time.time()
        properties = self._create_props(activity, now, properties)

        self._emit('end', properties)

    def subscribe(self, subscriber):
        self.subscribers.add(subscriber)

    def unsubscribe(self, subscriber):
        self.subscribers.discard(subscriber)

    def _enrich_properties(self, event_properties):
        """ Enriches event properties will all the global context up to the root """
        for k, v in six.iteritems(self._properties):
            # do not evaluate/override already present property, so values defined
            # in the child/nested instrument take precedence over the parent(s)
            if k in event_properties:
                continue
            if callable(v):
                v = v()
            event_properties[k] = v

        if self._parent:
            self._parent._enrich_properties(event_properties)

    def _emit(self, event_type, event_properties):
        # process.oneshot() optimizes performance in cases we get repeated
        # information about the same process (e.g. CPU user and system times)
        with _process.oneshot():
            self._enrich_properties(event_properties)
            event = Event(event_type, event_properties)
            self._notify_subscribers(event)

    def _notify_subscribers(self, event):
        """ Notifies subscribers about new event up to the root """
        for subscriber in self.subscribers:
            subscriber.on_event(event)

        if self._parent:
            self._parent._notify_subscribers(event)

    def update_properties(self, **props):
        self._properties.update(props)

    def remove_properties(self, keys):
        for key in keys:
            self._properties.pop(key, None)

    def with_memory_stats(self, enabled=True):
        # memory_info() costs about 0.03-0.1 ms per call
        if enabled:
            self.update_properties(
                mem_rss=lambda: _process.memory_info().rss,
                mem_shared=lambda: _process.memory_info().shared,
            )
        else:
            self.remove_properties(['mem_rss', 'mem_shared'])

    def with_extended_memory_stats(self, enabled=True):
        if enabled:
            # note that memory_full_info call is quite expensive (!) and takes 3-5 ms
            # per call, so when not required can be avoided to decrease performance
            # impact
            self.update_properties(
                mem_uss=lambda: _process.memory_full_info().uss
            )
        else:
            self.remove_properties(['mem_uss'])

    def with_cpu_stats(self, enabled=True):
        # getting cpu_times takes about 0.05-0.15 ms per call
        if enabled:
            self.update_properties(
                cpu_user=lambda: _process.cpu_times().user,
                cpu_system=lambda: _process.cpu_times().system
            )
        else:
            self.remove_properties(['cpu_user', 'cpu_system'])


class LoggingSubscriber(object):
    def __init__(self, logger=None):
        self.logger = logger or LOGGER

    def on_event(self, event):
        self.logger.info(
            '[INSTRUMENTATION] %s',
            json.dumps(dict(
                event.properties,
                event_type=event.type)))


instrument = Instrument()  # root instrument
instrument.begin(instrument.LIFETIME, activity_id=instrument.LIFETIME)
