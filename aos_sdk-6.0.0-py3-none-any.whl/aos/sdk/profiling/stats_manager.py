# Copyright 2021-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


class NoopStatsManager(object):
    def create_namespace(self, *path):
        return self

    def add_entry(self, data):
        return

    def get_stats(self):
        return {}

    def is_enabled(self):
        return False

