# Copyright 2022-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# The MIT License (MIT)
#
# Copyright (c) 2017 Maxim Kulkin
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from __future__ import annotations

import json
import logging
import re
import typing as t
import urllib.parse

import requests

if t.TYPE_CHECKING:
    import typing_extensions as te

    from aos.sdk import typing as tt


T = t.TypeVar('T')
TApi = t.TypeVar('TApi', bound='Api')  # pylint: disable=invalid-name


class ClientError(Exception):
    status_code: tt.HTTPStatusCode
    text: str

    def __init__(self, status_code: tt.HTTPStatusCode, text: str) -> None:
        if not text:
            message = f'Status code {status_code}'
        else:
            message = f'{text} (status code {status_code})'
        super().__init__(message)
        self.status_code = status_code
        self.text = text


class Response(t.NamedTuple):
    status_code: tt.HTTPStatusCode
    headers: tt.HTTPHeaders
    text: str

    @property
    def content(self) -> bytes:
        return self.text.encode()

    def json(self) -> tt.JSON:
        return json.loads(self.text)


PARAM_RE: t.Final[re.Pattern] = re.compile(r'^/(?:[^{]+/)*\{(.+)\}$')


class ApiNamespace(t.Generic[TApi]):
    path: tt.UrlPath
    param: str | None
    klass: type[TApi]

    def __init__(self, path: tt.UrlPath, klass: type[TApi]) -> None:
        self.path = path
        m = PARAM_RE.match(path)
        self.param = m.group(1) if m else None
        self.klass = klass

    @t.overload
    def __get__(self, obj: None, objtype: type[Client]) -> te.Self: ...

    @t.overload
    def __get__(self, obj: Client, objtype: type[Client]) -> TApi: ...

    def __get__(
        self,
        obj: None | Client,
        objtype: None | type[Client] = None
    ) -> te.Self | TApi:
        if obj is None:
            return self
        if self.param:
            raise AttributeError(
                f'Parameter "{self.param}" of "{self.klass.__name__}" not specified'
            )
        return self.klass(obj._client, obj._url + self.path)


class DummyTransport:
    """
    Transport that just prints executed requests
    """
    def request(
        self,
        url: tt.Url,
        method: t.Optional[tt.HTTPMethod] = None,
        headers: t.Optional[tt.HTTPHeaders] = None,
        data: t.Optional[tt.JSON] = None,
        **kwargs: te.Unpack[tt.RequestsRequestKwargs],
    ) -> tt.HTTPResponse:
        if data is not None:
            print(f'{method} {url} data={json.dumps(data)}')
        else:
            print(f'{method} {url}')

        return Response(200, {}, '')


class HttpTransport:
    """
    HTTP transport. Use base_url to specifying URL prefix (e.g. host/port)
    """
    _base_url: tt.Url
    _session: requests.Session

    def __init__(self, base_url: tt.Url) -> None:
        self._base_url = base_url
        self._session = requests.Session()

    def request(
        self,
        url: tt.Url,
        method: t.Optional[tt.HTTPMethod] = None,
        headers: t.Optional[tt.HTTPHeaders] = None,
        data: t.Optional[tt.JSON] = None,
        **kwargs: te.Unpack[tt.RequestsRequestKwargs],
    ) -> tt.HTTPResponse:
        request = requests.Request(
            url=self._base_url + url, method=method or 'GET',
            headers=headers or {},
            data=data,
            **kwargs
        )

        return self._session.send(self._session.prepare_request(request))


class Client:
    """
    Top level API client object. Holds reference to transport and base url.
    Has cleanup API to allow resources to register cleanup callbacks.
    """
    _transport: tt.HTTPTransportProto
    _url: tt.Url
    _cleanup: list[tuple[tt.Url, tt.HTTPClientCleanup]]
    _client: Client  # ???

    logger: logging.Logger = logging.getLogger(f'{__module__}.Client')

    def __init__(
        self,
        transport: tt.HTTPTransportProto,
        url: tt.Url = ''
    ) -> None:
        """
        Args:
            transport  Instance HttpSession
            url        API URL to access a specific resource
        """
        self._transport = transport
        self._url = url
        self._cleanup = []

        self._client = self

    def __repr__(self) -> str:
        return f'<{self.__class__.__name__} {self._url}>'

    def add_cleanup(self, url: tt.UrlPath, func: tt.HTTPClientCleanup) -> None:
        """Add cleanup callback associated with given URL"""
        self._cleanup.append((url, func))

    def remove_cleanup(self, url: tt.UrlPath) -> None:
        """Remove cleanup callbacks associated with given URL"""
        self._cleanup = [(url1, func) for (url1, func) in self._cleanup
                         if url1 != url and not url1.startswith(f'{url}/')]

    def cleanup(self) -> None:
        """Execute all cleanup callbacks"""
        for _, func in self._cleanup:
            func()
        self._cleanup = []

    def raw_request(
        self,
        url: tt.Url,
        method: t.Optional[tt.HTTPMethod] = None,
        headers: t.Optional[tt.HTTPHeaders] = None,
        data: t.Optional[tt.JSON] = None,
        encode_data: tt.JSONEncode = json.dumps,
        content_type: tt.HTTPMimeType = 'application/json',
        **kwargs: te.Unpack[tt.RequestsRequestKwargs],
    ) -> tt.HTTPResponse:
        """
        Send HTTP request through configured transport and return Response object

        Args:
            url     The URL to be appended to the base url of this client
            method  HTTP method - defaults to GET if data is None, POST otherwise
            headers Headers that are passed to the configured transport (see
                    content_type for more details)
            data    Data payload to be passed to configured transport; by default,
                    no data is passed
            encode_data     A function that returns the encoded form of data to be
                            passed to the configured transport; By default, any
                            provided data is encoded with json.dumps().
                            If encoded_data is None, then data is untouched.
                            This is useful for cases where the application performs
                            its own encoding, even for JSON data.
           content_type     Value for the HTTP Header 'Content-Type'. Defaults to
                            'application/json'.

           Any remaining keyword arguments are passed as is to the configured
           transport.
        """
        if method is None:
            method = 'GET' if data is None else 'POST'

        url = self._url + url
        if data is not None and encode_data is not None:
            data = encode_data(data)

        new_headers = dict(headers or {})
        new_headers['Content-Type'] = content_type

        self._log_request(url, method=method, headers=new_headers, data=data)

        response = self._transport.request(
            url=url, method=method, headers=new_headers, data=data, **kwargs
        )

        self._log_response(response)

        return response

    def request(
        self,
        url: tt.Url,
        method: t.Optional[tt.HTTPMethod] = None,
        headers: t.Optional[tt.HTTPHeaders] = None,
        data: t.Optional[tt.JSON] = None,
        **kwargs: te.Unpack[tt.RequestsRequestKwargs],
    ) -> tt.JSON:
        """Send HTTP request and return JSON response data"""
        response = self.raw_request(
            url, method=method, headers=headers, data=data, **kwargs
        )

        if response.status_code not in range(200, 299):
            raise ClientError(response.status_code, response.text)

        if response.content:
            return response.json()

        return None

    # compatibility with Api
    def _raw_request(self, *args, **kwargs):
        return super().raw_request(*args, **kwargs)

    def _request(self, *args, **kwargs):
        return super().request(*args, **kwargs)

    def _log_request(
        self,
        url: tt.Url,
        method: tt.HTTPMethod,
        headers: tt.HTTPHeaders,
        data: tt.JSON,
    ) -> None:
        """Log request"""

        if not self.logger.isEnabledFor(logging.DEBUG):
            return

        s = f'{method} request to {url}'
        if headers:
            s += f' headers={headers!r}'
        if data:
            s += f' body={data}'

        self.logger.debug('Sending %s', s)

    def _log_response(self, response: tt.HTTPResponse) -> None:
        """Log response"""

        if not self.logger.isEnabledFor(logging.DEBUG):
            return

        s = f'code={response.status_code}'
        if response.headers:
            s += f' headers={response.headers!r}'
        if response.text:
            s += f' body={response.text}'

        self.logger.debug('Got response %s', s)


class ApiMeta(type):
    def __new__(
        mcs,
        name: str,
        bases: tuple[type],
        attrs: dict[str, t.Any]
    ) -> type:
        params = {attr_name: attr_value
                  for attr_name, attr_value in attrs.items()
                  if isinstance(attr_value, ApiNamespace) and attr_value.param}

        if len(params) > 1:
            raise ValueError('Multiple param APIs are not supported')
        elif len(params) == 1:
            param_api = next(iter(params.values()))

            def getitem(self, param_value: str) -> Api:
                return param_api.klass(
                    self._client,
                    f'{self._url}/{urllib.parse.quote(param_value)}',
                )

            attrs['__getitem__'] = getitem

        return super().__new__(mcs, name, bases, attrs)


class Api(metaclass=ApiMeta):
    """
    Base class for all HTTP APIs. Maintains a client and base url.
    """
    _client: Client
    _url: tt.Url

    if t.TYPE_CHECKING:
        class TRawRequestKwargs(tt.RequestsRequestKwargs, total=False):
            method: tt.HTTPMethod
            headers: tt.HTTPHeaders
            data: tt.JSON

    def __init__(self, client: Client, url: tt.Url, **kwargs):
        """
        :param client: An instance of Client to use.
        :param url: URL segment
        """
        self._client = client
        self._url = url
        for k, v in kwargs.items():
            setattr(self, k, v)

    def _raw_request(
        self,
        url: t.Optional[tt.Url] = None,
        **kwargs: te.Unpack[TRawRequestKwargs],
    ) -> tt.HTTPResponse:
        return self._client.raw_request(self._url + (url or ''), **kwargs)

    def _request(
        self,
        url: t.Optional[tt.Url] = None,
        **kwargs: te.Unpack[TRawRequestKwargs],
    ) -> tt.JSON:
        return self._client.request(self._url + (url or ''), **kwargs)

    def __repr__(self) -> str:
        return f'<{self.__class__.__name__} {self._url}>'


def api(path: str) -> t.Callable[[type[TApi]], ApiNamespace[TApi]]:
    """
    Returns property that instantiates and returns specified Api class instance
    passing it client and suburl, derived from self url and given path.

    :param path: (string) URI path relative to parent resource
    :param klass: (Api) Api class to instantiate
    :return: Property descriptor
    """
    def wrapper(klass: type[TApi]) -> ApiNamespace[TApi]:
        if not issubclass(klass, Api):
            klass = type(klass.__name__, (klass, Api), {})
        return ApiNamespace(path, klass)

    return wrapper


class RestResource(Api):
    if t.TYPE_CHECKING:
        class TReadKwargs(tt.RequestsRequestKwargs):
            headers: tt.HTTPHeaders
            data: tt.JSON

        class TWriteKwargs(tt.RequestsRequestKwargs):
            headers: tt.HTTPHeaders


    def get(self, **kwargs: te.Unpack[RestResource.TReadKwargs]) -> tt.JSON:
        try:
            return self._request(method='GET', **kwargs)
        except ClientError as ce:
            if ce.status_code != 404:
                raise ce
            return None

    def update(
        self,
        data: tt.JSON,
        **kwargs: te.Unpack[RestResource.TWriteKwargs],
    ) -> tt.JSON:
        return self._request(method='PUT', data=data, **kwargs)

    def delete(self, **kwargs: te.Unpack[RestResource.TReadKwargs]) -> None:
        try:
            self._request(method='DELETE', **kwargs)
        except ClientError as ce:
            if ce.status_code != 404:
                raise ce

        self._client.remove_cleanup(self._url)


class RestResources(Api):
    """
    REST resources API implementing access to collection of resources.
    Inner class "Resource" defines API for accessing particular resource.

    Example:

        users = RestResources(client, '/users')
        users.list() # => [{'id': '1', 'name': 'John'}, ... ]
        users.create({'name': 'Jane'}) # => {'id': '2'}

        users['2'].get() # => {'id': '2', 'name': 'Jane'}
        users['2'].update({'name': 'Jane Doe'})
        users['2'].delete()

    Uses Client's Cleanup API to register created resources for cleanup.
    """
    def list(self, **kwargs: te.Unpack[RestResource.TReadKwargs]) -> tt.JSON:
        return self._request(method='GET', **kwargs)

    def create(
        self,
        data: tt.JSON,
        **kwargs: te.Unpack[RestResource.TWriteKwargs],
    ) -> tt.JSON:
        result = self._request(method='POST', data=data, **kwargs)
        if isinstance(result, dict) and 'id' in result:
            # pylint: disable=unsubscriptable-object
            resource_api = self[result['id']]  # type: ignore[index]
            self._client.add_cleanup(resource_api._url, resource_api.delete)
        return result

    @api('/{resource_id}')
    class Resource(RestResource):
        pass

def resources(
    path: str,
    klass: type[RestResources] = RestResources,
    **kwargs
) -> ApiNamespace[RestResources]:
    """Convenience shortcut for defining REST resources API

    Example:

        class Client(http_test_client.Client):
            users = resources('/users')

    """
    return api(path, **kwargs)(RestResources)
