# Copyright 2024-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula
# pylint: disable=duplicate-bases,invalid-name,redefined-builtin
'''
Various type definitions
'''

from __future__ import annotations

import typing as t
import collections.abc
import http.cookiejar

import requests
import typing_extensions as te

T_co = t.TypeVar('T_co', covariant=True)

Url: te.TypeAlias = str
UrlPath: te.TypeAlias = Url | str
HostName: te.TypeAlias = str
UserName: te.TypeAlias = str
Password: te.TypeAlias = str

Timeout: te.TypeAlias = int | float
ISOTimestamp: te.TypeAlias = str

JSON: te.TypeAlias = (
    None | int | float | bool | str | list['JSON'] | dict[t.Hashable, 'JSON']
)
JSONEncode: te.TypeAlias = t.Callable[[JSON], str]
JSONDict: te.TypeAlias = dict[str, JSON]

HTTPProtocol: te.TypeAlias = t.Literal['http', 'https']
HTTPMethod = te.Literal[
    'GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'
]
HTTPHeaderKey: te.TypeAlias = str
HTTPHeaderValue: te.TypeAlias = str
HTTPHeaders: te.TypeAlias = collections.abc.Mapping[
    HTTPHeaderKey, HTTPHeaderValue
]
HTTPStatusCode: te.TypeAlias = int
HTTPMimeType: te.TypeAlias = str
HTTPQueryStringParamKey: te.TypeAlias = str
HTTPQueryStringParamValue: te.TypeAlias = str
HTTPClientCleanup: te.TypeAlias = t.Callable[[], None]

BlueprintType: te.TypeAlias = t.Literal['config', 'staging', 'deploy']
BlueprintDigest: te.TypeAlias = t.AnyStr
BlueprintVersion: te.TypeAlias = int

GraphNodeId: te.TypeAlias = str
GraphNodeType: te.TypeAlias = str
GraphRelationshipId: te.TypeAlias = str
GraphRelationshipType: te.TypeAlias = str

SourceVersions: te.TypeAlias = collections.abc.Mapping[
    BlueprintType, BlueprintVersion
]

PortSpeedValue: te.TypeAlias = int
PortSpeedUnit: te.TypeAlias = t.Literal['K', 'M', 'G']


class PortSpeed(t.TypedDict):
    value: PortSpeedValue
    unit: PortSpeedUnit


IPv4Address: te.TypeAlias = str
IPv6Address: te.TypeAlias = str
IPAddress = IPv4Address | IPv6Address
IPv4Network: te.TypeAlias = str
IPv6Network: te.TypeAlias = str
IPNetwork = IPv4Network | IPv6Network
PortNo: te.TypeAlias = int
ASN: te.TypeAlias = str
NetworkProtocol: te.TypeAlias = t.Literal['tcp', 'udp']
SyslogFacility: te.TypeAlias = t.Literal[
    'kern',
    'user',
    'mail',
    'daemon',
    'auth',
    'syslog',
    'lpr',
    'news',
    'uucp',
    'cron',
    'authpriv',
    'ftp',
    'ntp',
    'security',
    'console',
    'solaris-cron',
    'local0',
    'local1',
    'local2',
    'local3',
    'local4',
    'local5',
    'local6',
    'local7',
]

Tag: te.TypeAlias = str
Timezone: te.TypeAlias = str
RailIndex: te.TypeAlias = int

RefDesignCaps: te.TypeAlias = t.Literal['disabled', 'full_support']
RefDesign: te.TypeAlias = t.Literal['two_stage_l3clos', 'freeform']
FabricConnectivityDesign: te.TypeAlias = t.Literal[
    'l3collapsed', 'l3clos', 'rail_collapsed']
LagMode: te.TypeAlias = t.Literal['lacp_active', 'lacp_passive', 'static_lag']
LagAttachmentType: te.TypeAlias = t.Literal['singleAttached', 'dualAttached']
RedundancyProtocol: te.TypeAlias = t.Literal['mlag', 'esi']
ConnectivityType: te.TypeAlias = t.Literal['l2', 'l3', 'l3_bond', 'bond']
ManagementLevel: te.TypeAlias = t.Literal[
    'unmanaged',
    'telemetry_only',
    'full_control'
]
RoutingImportPolicyType: te.TypeAlias = t.Literal[
    'default_only',
    'all',
    'extra_only'
]
SecurityZoneType: te.TypeAlias = t.Literal['evpn', 'l3_fabric']
JunosEvpnIrbMode: te.TypeAlias = t.Literal['asymmetric', 'symmetric']
JunosEvpnRoutingInstanceType: te.TypeAlias = t.Literal['default', 'vlan_aware']
EnabledDisabled: te.TypeAlias = t.Literal['enabled', 'disabled']
LinkIpv4Ipv6: te.TypeAlias = t.Literal['ipv4', 'ipv4_ipv6']
LinkIpv4Ipv6All: te.TypeAlias = LinkIpv4Ipv6 | t.Literal['ipv6']
ValidationSeverity: te.TypeAlias = t.Literal['error', 'warning', 'no_warning']
Dot1xPolicyAuthMode: te.TypeAlias = t.Literal['multi_host', 'single_host']
Dot1xPolicyPortControl: te.TypeAlias = t.Literal[
    'auto',
    'force_authorized',
    'force_unauthorized'
]
PrefixListEntryAction: te.TypeAlias = t.Literal['permit', 'deny']
LinkRole: te.TypeAlias = t.Literal[
    'spine_leaf', 'leaf_l2_server', 'leaf_l3_server',
    'leaf_pair_l2_server', 'leaf_pair_access_pair',
    'leaf_peer_link', 'leaf_l3_peer_link', 'access_l3_peer_link',
    'to_external_router', 'spine_superspine',
    'leaf_access', 'access_server', 'leaf_pair_access', 'to_generic',
    'leaf_leaf'
]
SystemRole: te.TypeAlias = t.Literal[
    'spine', 'leaf', 'superspine', 'l2_server', 'l3_server',
    'external_router', 'remote_gateway', 'access', 'generic'
]
InterfaceType: te.TypeAlias = t.Literal[
    'ip',
    'loopback',
    'ethernet',
    'svi',
    'port_channel',
    'logical_vtep',
    'anycast_vtep',
    'unicast_vtep',
    'global_anycast_vtep',
    'subinterface',
]
VnEndpointTagType: te.TypeAlias = t.Literal['vlan_tagged', 'untagged']
IpEndpointType: te.TypeAlias = t.Literal['vip', 'internal', 'external']


LBPolicyDLBMode: te.TypeAlias = t.Literal['per_packet', 'flowlet']
LBPolicyGLBMode: te.TypeAlias = t.Literal[
    'helper_only', 'load_balancer_only']
LBPolicyMode: te.TypeAlias = t.Literal['dlb', 'disabled']
LBPolicyFlowsetTableSize: te.TypeAlias = t.Literal[
    256, 512, 1024, 2048, 4096, 8192, 16384, 32768,
]
LBPolicyPolicyType: te.TypeAlias = t.Literal['user_defined', 'default']


# TODO(eromashenko): placeholder for TACC entities, in the future we might want to
#  generate stubs from TACC code
TacType: te.TypeAlias = t.Any
# DEVICE_FACTS_SCHEMA
DeviceInfo: te.TypeAlias = dict[str, dict[str, str] | str | int]


class RequestsHook(t.Protocol):
    def __call__(
        self, r: requests.Response, *args, **kwargs
    ) -> requests.Response: ...


RequestsRequestQueryParams: te.TypeAlias = (
    dict[HTTPQueryStringParamKey, HTTPQueryStringParamValue]
        | list[tuple[HTTPQueryStringParamKey, HTTPQueryStringParamValue]]
        | str
)


# https://requests.readthedocs.io/en/latest/api/#requests.Session.request
class RequestsRequestKwargs(t.TypedDict, total=False):
    params: RequestsRequestQueryParams
    json: JSON
    cookies: dict | http.cookiejar.CookieJar
    files: dict[str, t.IO]
    auth: (
        tuple[UserName, Password]
        | t.Callable[[requests.Request], requests.Request]
    )
    hooks: dict[str, RequestsHook | list[RequestsHook]]


class HTTPResponse(t.Protocol):

    @property
    def status_code(self) -> HTTPStatusCode: ...

    @property
    def headers(self) -> HTTPHeaders: ...

    @property
    def text(self) -> str: ...

    @property
    def content(self) -> bytes: ...

    def json(self) -> JSON: ...


class HTTPTransportProto(t.Protocol):

    def request(
        self,
        url: Url,
        method: t.Optional[HTTPMethod] = None,
        headers: t.Optional[HTTPHeaders] = None,
        data: t.Optional[JSON] = None,
        **kwargs: te.Unpack[RequestsRequestKwargs],
    ) -> HTTPResponse: ...


class GraphNode(t.Hashable, t.Protocol):
    @property
    def obj_type(self) -> str: ...
    @property
    def id(self) -> str: ...
    @property
    def properties(self) -> dict[str, t.Any]: ...
    @property
    def type(self) -> str: ...

    def __copy__(self) -> GraphNode: ...
    def __deepcopy__(self, memo: t.Optional[dict]) -> GraphNode: ...
    def __getattr__(self, name: str) -> t.Any: ...
    def __eq__(self, other: t.Any) -> bool: ...
    def __ne__(self, other: t.Any) -> bool: ...
    def __lt__(self, other: t.Any) -> bool: ...
    def __hash__(self) -> int: ...
    def __repr__(self) -> str: ...


class GraphRelationship(t.Hashable, t.Protocol):
    @property
    def obj_type(self) -> str: ...
    @property
    def id(self) -> str: ...
    @property
    def source_id(self) -> str: ...
    @property
    def target_id(self) -> str: ...
    @property
    def properties(self) -> dict[str, t.Any]: ...
    @property
    def type(self) -> str: ...

    def __copy__(self) -> GraphRelationship: ...
    def __deepcopy__(self, memo: t.Optional[dict]) -> GraphRelationship: ...
    def __getattr__(self, name: str) -> t.Any: ...
    def __eq__(self, other: t.Any) -> bool: ...
    def __ne__(self, other: t.Any) -> bool: ...
    def __lt__(self, other: t.Any) -> bool: ...
    def __hash__(self) -> int: ...
    def __repr__(self) -> str: ...


class DumpedGraphNode(t.TypedDict):
    type: str
    id: str


class DumpedGraphRelationship(t.TypedDict):
    type: str
    source_id: str
    target_id: str


class OnNodeCallback(t.Protocol):
    @t.overload
    def __call__(self,
                 graph: Graph | UpdateGraph,
                 old_node: None,
                 new_node: GraphNode) -> None: ...
    @t.overload
    def __call__(self,
                 graph: Graph | UpdateGraph,
                 old_node: GraphNode,
                 new_node: None) -> None: ...
    @t.overload
    def __call__(self,
                 graph: Graph | UpdateGraph,
                 old_node: GraphNode,
                 new_node: GraphNode) -> None: ...


class OnRelationshipCallback(t.Protocol):
    @t.overload
    def __call__(self,
                 graph: Graph | UpdateGraph,
                 old_rel: None,
                 new_rel: GraphRelationship) -> None: ...

    @t.overload
    def __call__(self,
                 graph: Graph | UpdateGraph,
                 old_rel: GraphRelationship,
                 new_rel: None) -> None: ...

    @t.overload
    def __call__(self,
                 graph: Graph | UpdateGraph,
                 old_rel: GraphRelationship,
                 new_rel: GraphRelationship) -> None: ...


class OnGraphCallback(t.Protocol):
    def __call__(self, graph: Graph | UpdateGraph) -> None: ...


class GraphObserver(t.Protocol):
    on_node: OnNodeCallback
    on_relationship: OnRelationshipCallback
    on_graph: OnGraphCallback


class GraphBaseIterator(t.Protocol[T_co]):

    @property
    def _graph(self) -> Graph | UpdateGraph: ...

    @property
    def _depleted(self) -> bool: ...

    def __iter__(self) -> t.Iterator[T_co]: ...

    @property
    def first(self) -> T_co | None: ...

    @property
    def one(self) -> T_co: ...

    @property
    def one_or_none(self) -> T_co | None: ...

    @property
    def count(self) -> int: ...


class GraphNodeIterator(GraphBaseIterator, t.Protocol):

    @property
    def _node_iter(self) -> t.Iterable[GraphNode]: ...

    def out(
        self,
        type: t.Optional[GraphRelationshipType | PropertyMatcher] = None,
        **kwargs: t.Any,
    ) -> GraphOutRelationshipIterator: ...

    def in_(
        self,
        type: t.Optional[GraphRelationshipType | PropertyMatcher] = None,
        **kwargs: t.Any,
    ) -> GraphInRelationshipIterator: ...

    def where(
        self,
        predicate: t.Callable[[GraphNode], bool]
    ) -> GraphNodeIterator: ...


class GraphRelationshipIterator(GraphBaseIterator, t.Protocol):

    @property
    def _relationship_iter(self) -> t.Iterable[GraphRelationship]: ...

    def source(
        self,
        type: t.Optional[GraphNodeType | PropertyMatcher] = None,
        **kwargs
    ) -> GraphNodeIterator: ...

    def target(
        self,
        type: t.Optional[GraphNodeType | PropertyMatcher] = None,
        **kwargs
    ) -> GraphNodeIterator: ...

    def where(
        self,
        predicate: t.Callable[[GraphRelationship], bool]
    ) -> GraphRelationshipIterator: ...


class GraphOutRelationshipIterator(GraphRelationshipIterator, t.Protocol):

    def node(
        self,
        type: t.Optional[GraphNodeType | PropertyMatcher] = None,
        **kwargs
    ) -> GraphNodeIterator: ...


class GraphInRelationshipIterator(GraphRelationshipIterator, t.Protocol):

    def node(
        self,
        type: t.Optional[GraphNodeType | PropertyMatcher] = None,
        **kwargs
    ) -> GraphNodeIterator: ...


class NodeSchema(t.Protocol):
    @property
    def indexes(self) -> t.Optional[list[list[str]]]: ...

    @property
    def properties(self) -> dict[str, t.Any]: ...

    @property
    def type(self) -> str: ...

    @property
    def validators(self) -> t.Iterable[t.Callable[[dict], None]]: ...

    def __contains__(self, name: str) -> bool: ...

    def __getitem__(self, name: str) -> t.Any: ...

    def __repr__(self) -> str: ...

    def load(self, data: dict, partial: bool = False) -> JSONDict: ...

    def dump(self, node: GraphNode, ensure_defaults: bool = False) -> JSON: ...

    def validate(
            self, data: dict[str, t.Any], raw: bool = False
    ) -> t.Optional[list | dict]: ...


class RelationshipSchema(t.Protocol):
    @property
    def properties(self) -> dict[str, t.Any]: ...

    @property
    def source_type(self) -> str: ...

    @property
    def target_type(self) -> str: ...

    @property
    def sticky(self) -> bool: ...

    @property
    def validators(self) -> t.Iterable[t.Callable[[dict], None]]: ...

    @property
    def type(self) -> str: ...

    def __contains__(self, name: str) -> bool: ...

    def __getitem__(self, name: str) -> t.Any: ...

    def __repr__(self) -> str: ...

    def load(self, data: dict, partial: bool = False) -> JSONDict: ...

    def dump(self, node: GraphNode, ensure_defaults: bool = False) -> JSON: ...

    def validate(
            self, data: dict[str, t.Any], raw: bool = False
    ) -> t.Optional[list | dict]: ...


class Schema(t.Protocol):
    nodes: dict[str, NodeSchema]
    relationships: list[RelationshipSchema]

    def get_node_schema(self, node_type: str) -> NodeSchema: ...

    def get_relationship_schema(
            self,
            type: str,
            source_node_type: str,
            target_node_type: str
    ) -> RelationshipSchema: ...

    @classmethod
    def validate(cls) -> None: ...


class PropertyMatcher(t.Protocol):
    @property
    def type(self) -> str: ...
    @property
    def value(self) -> t.Any: ...

    def __call__(self, value: t.Any) -> bool: ...

    def __hash__(self) -> int: ...

    def __eq__(self, other: t.Any) -> bool: ...

    def __ne__(self, other: t.Any) -> bool: ...

    def __repr__(self) -> str: ...

    def __deepcopy__(self, memo: t.Optional[dict]) -> PropertyMatcher: ...


class Graph(t.Protocol):
    @property
    def id(self) -> str: ...

    @property
    def schema(self) -> Schema: ...

    @property
    def version(self) -> BlueprintVersion: ...

    @property
    def source_versions(self) -> SourceVersions: ...

    @property
    def node_count(self) -> int: ...

    @property
    def relationship_count(self) -> int: ...

    def is_committed(self) -> bool: ...

    def commit(
        self,
        version: t.Optional[BlueprintVersion] = ...,
        source_versions: t.Optional[SourceVersions] = ...,
    ) -> None: ...

    def add_node(
        self, type: GraphNodeType, id: t.Optional[GraphNodeId] = ..., **data
    ) -> GraphNode: ...

    def add_relationship(
        self,
        type: GraphRelationshipType,
        source: GraphNode | GraphNodeId,
        target: GraphNode | GraphNodeId,
        id: t.Optional[GraphRelationshipId] = ...,
        **data,
    ) -> GraphRelationship: ...

    def set_node(
            self, node_id: GraphNode | GraphNodeId, **data
    ) -> GraphNode: ...

    def set_relationship(
        self, relationship_id: GraphRelationship | GraphRelationshipId, **data
    ) -> GraphNode: ...

    def del_node(self, node_id: GraphNode | GraphNodeId) -> None: ...

    def del_relationship(
            self,
            relationship_id: GraphRelationship | GraphRelationshipId
    ) -> None: ...

    def get_node(
            self, node_id: GraphNode | GraphNodeId

    ) -> GraphNode | None: ...

    def get_nodes(
        self,
        type: t.Optional[GraphNodeType | PropertyMatcher] = ...,
        id: t.Optional[GraphNodeId | GraphNode | PropertyMatcher] = ...,
        **kwargs,
    ) -> GraphNodeIterator: ...

    def get_relationship(
            self, relationship_id: GraphRelationship | GraphRelationshipId
    ) -> GraphRelationship | None: ...

    def get_relationships(
        self,
        type: t.Optional[GraphRelationshipType | PropertyMatcher] = ...,
        source_id: t.Optional[GraphNodeId | GraphNode | PropertyMatcher] = ...,
        target_id: t.Optional[GraphNodeId | GraphNode | PropertyMatcher] = ...,
        id: t.Optional[
            GraphRelationshipId | GraphRelationship | PropertyMatcher
            ] = ...,
        **kwargs
    ) -> GraphRelationshipIterator: ...

    def get_tags(
            self, node: GraphNode | GraphNodeId
    ) -> set[str]: ...

    def traverse(
        self,
        nodes: t.Optional[
            GraphNode | t.Iterable[GraphNode]] = None,
        node_type: t.Optional[GraphNodeType | PropertyMatcher] = None,
    ) -> GraphNodeIterator: ...

    def add_observer(
            self,
            observer: GraphObserver
    ) -> None: ...

    def remove_observer(
            self,
            observer: GraphObserver
    ) -> None: ...

    def json(self) -> JSON: ...
    def compact_json(self) -> JSON: ...


class UpdateGraph(t.Protocol):
    @property
    def id(self) -> str: ...

    @property
    def schema(self) -> Schema: ...

    @property
    def version(self) -> BlueprintVersion: ...

    @property
    def source_versions(self) -> SourceVersions: ...

    def is_dirty(self) -> bool: ...

    def is_committed(self) -> bool: ...

    def get_node(self, node_id: GraphNode | GraphNodeId
                 ) -> t.Optional[GraphNode]: ...

    def get_nodes(self, type: t.Optional[GraphNodeType] = None,
                  id: t.Optional[GraphNode | GraphNodeId] = None,
                  **kwargs: t.Any,
                  ) -> GraphNodeIterator: ...

    def get_relationship(self, rel_id: GraphRelationship | GraphRelationshipId
                         ) -> t.Optional[GraphRelationship]: ...

    def get_relationships(
            self,
            type: t.Optional[GraphRelationshipType] = None,
            source_id: t.Optional[GraphNode | GraphNodeId] = None,
            target_id: t.Optional[GraphNode | GraphNodeId] = None,
            id: t.Optional[GraphRelationship | GraphRelationshipId] = None,
            **kwargs: t.Any,
    ) -> GraphRelationshipIterator: ...

    def get_tags(self, node: GraphNode | GraphNodeId) -> set[str]: ...

    def traverse(self,
                 nodes: t.Optional[t.Iterable[GraphNode] | GraphNode] = None,
                 node_type: t.Optional[str] = None
                 ) -> GraphNodeIterator: ...
