"""
Copyright 2022-present, Apstra, Inc. All rights reserved.

This source code is licensed under End User License Agreement found in the
LICENSE file at http://apstra.com/eula
"""

from __future__ import absolute_import
from __future__ import division

import contextlib
import errno
import functools
import os
import os.path
import sys

import six


text_and_binary_types = (six.binary_type,) + six.string_types

# Python3 has no long, only ints. But for TACC compatibility that
# treats ints and longs differently it worth to have this class.
LongType = long if six.PY2 else int  # pylint: disable=undefined-variable

py2_json_module = 'json'

if six.PY2:
    try:
        import simplejson
    except ImportError:
        pass
    else:
        del simplejson
        py2_json_module = 'simplejson'


six.add_move(six.MovedModule('mock', 'mock', 'unittest.mock'))
six.add_move(six.MovedModule('mox', 'mox', 'mox3.mox'))
six.add_move(six.MovedModule('json', py2_json_module, 'json'))
six.add_move(six.MovedAttribute(
    'process_time',
    'time', 'time',
    'clock', 'process_time'))
six.add_move(six.MovedAttribute(
    'open_with_encoding',
    'codecs', 'builtins',
    'open'))
six.add_move(six.MovedAttribute(
    'LooseVersion',
    'distutils.version', 'looseversion',
    'LooseVersion', 'LooseVersion2'))


@contextlib.contextmanager
def open_with_flags(path, flags):
    # TODO(Sergey Arkhipov)
    # The goal and purpose of this function is to support migration to Python3
    # It looks generic but it was created to support a simple usecase: an
    # abscence of 'x' flag in builtin.open. This flag corresponds to having of
    # os.O_EXCL in open(3) syscall.
    #
    # This flag is supported in Python3 but ignored in Python2. So, if we want
    # to have a feature parity, this small wrapper is required. But once
    # Python3 migration is completed, we can safely drop it.
    fd = os.open(path, flags)

    mode = 'r'
    if flags & os.O_WRONLY:
        mode = 'a' if flags & os.O_APPEND else 'w'
    elif flags & os.O_RDWR:
        mode = 'w+' if flags & os.O_TRUNC else 'r+'

    try:
        fileobj = os.fdopen(fd, mode + 'b', 0)
    except Exception:
        os.close(fd)
        raise

    with contextlib.closing(fileobj) as obj:
        yield obj


if six.PY2:
    def load_module(module_name, path):
        # pylint: disable=deprecated-module
        import imp

        info = imp.find_module(module_name, [path])
        module = imp.load_module(module_name, *info)

        return module
else:
    def load_module(module_name, path):
        import importlib.util  # pylint: disable=no-name-in-module

        module_path = os.path.join(path, module_name)
        if os.path.isfile(module_path + ".py"):
            module_path = module_path + ".py"
        else:
            module_path = os.path.join(module_path, "__init__.py")

        spec = importlib.util.spec_from_file_location(module_name, module_path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)

        return module


def os_makedirs_exist_ok_is_true(*args, **kwargs):
    """
    Adding support exist_ok=True to os.makedirs for python2
    """
    if six.PY3:
        # pylint: disable=unexpected-keyword-arg
        os.makedirs(*args, exist_ok=True, **kwargs)
    else:
        try:
            os.makedirs(*args, **kwargs)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise


def wrap_loads_unicode_to_str(loads_func):
    if six.PY3:
        return loads_func

    def deunicode(k):
        if isinstance(k, text_and_binary_types):
            return six.ensure_str(k)
        return k

    return functools.partial(
        loads_func,
        object_pairs_hook=lambda kvs: {
            deunicode(k): deunicode(v)
            for k, v in kvs
        })


from six.moves import json


json_loads_str = wrap_loads_unicode_to_str(json.loads)
json_load_str = wrap_loads_unicode_to_str(json.load)


# Python3 does not support compare two dicts directly during sorting. Thus
# adapt the dict comparison rule from python2
class ComparableDict(dict):
    def __lt__(self, other):
        def min_diff_key(d1, d2):
            diff_keys = [k for k in d1 if k not in d2 or d1[k] != d2[k]]
            return min(diff_keys)
        if len(self) != len(other):
            return len(self) < len(other)
        try:
            key1 = min_diff_key(self, other)
            key2 = min_diff_key(other, self)
        except ValueError:
            # No difference when all the key and values are the same
            return False
        except TypeError as e:
            raise TypeError('Not supporting keys with different types: %s' % str(e))
        if key1 != key2:
            return key1 < key2
        return self[key1] < other[key2]


def make_comparable(obj):
    if isinstance(obj, dict):
        for key in obj:
            obj[key] = make_comparable(obj[key])
        obj = ComparableDict(obj)
    elif isinstance(obj, list):
        for i, item in enumerate(obj):
            obj[i] = make_comparable(item)
    return obj
