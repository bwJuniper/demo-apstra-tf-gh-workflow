# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""
    - Imports all the required imports from lollipop.
    - Defines AOS specific basic types like Dict, String etc.
"""

__all__ = [
    # types
    'Any', 'String', 'Number', 'Integer', 'Float', 'Boolean', 'List',
    'Dict', 'Object', 'DateTime', 'Optional', 'Tuple',
    'DumpOnly', 'LoadOnly', 'OneOf', 'Transform', 'Type',
    'Constant', 'Modifier', 'MISSING', 'validated_type', 'Enum', 'Speed',
    # fields
    'Field', 'AttributeField', 'IndexField', 'FunctionField', 'MethodField',
    # validation error
    'ValidationError', 'ValidationErrorBuilder',
    # validators
    'Validator', 'Predicate', 'Range', 'Length', 'Regexp', 'AnyOf', 'NoneOf',
    'Unique',
    # type registry
    'TypeRegistry',
    # utils
    'DictWithDefault', 'OpenStruct', 'to_snake_case', 'to_camel_case', 'is_mapping',
    # custom types
    'StringBoolean', 'StringNumber', 'StringInteger', 'StringFloat', 'LoadOnlyApi',
    # hints
    'dict_value_hint',
]


# Import types for re-export.
from lollipop.types import (
    Any as _Any,
    AttributeField,
    Boolean,
    Constant,
    DateTime,
    Dict as _Dict,
    DumpOnly,
    Field,
    Float,
    FunctionField,
    IndexField,
    Integer,
    List,
    LoadOnly,
    MethodField,
    MISSING,
    Modifier,
    Number,
    Object as _Object,
    OneOf,
    Optional,
    String as _String,
    Transform,
    Tuple,
    Type,
    validated_type,
)
from lollipop.errors import ValidationError, ValidationErrorBuilder
from lollipop.validators import Validator, Predicate, Range, Length, Regexp, \
    AnyOf, NoneOf, Unique
from lollipop.type_registry import TypeRegistry
from lollipop.utils import DictWithDefault, OpenStruct, to_snake_case, \
    to_camel_case, is_mapping
import six
from six.moves import collections_abc
import socket


def validate_ipv4_address(address):
    try:
        socket.inet_pton(socket.AF_INET, address)
    except socket.error as err:
        six.raise_from(
            ValidationError('Invalid IP address %s' % address),
            err)


def is_ipv4_address(address_string):
    try:
        validate_ipv4_address(str(address_string))
    except ValidationError:
        return False
    return True


def validate_ipv6_address(address):
    try:
        socket.inet_pton(socket.AF_INET6, address)
    except socket.error as exc:
        six.raise_from(
            ValidationError('Invalid IPv6 address %s' % address),
            exc)


def is_ipv6_address(address_string):
    try:
        validate_ipv6_address(str(address_string))
    except ValidationError:
        return False
    return True


class Any(_Any):
    def load(self, *args, **kwargs):
        value = super(Any, self).load(*args, **kwargs)
        if value is None or value is MISSING:
            return value
        if six.PY2 and isinstance(value, six.text_type):
            value = value.encode('utf-8')
        return value


class String(_String):
    def load(self, *args, **kwargs):
        value = super(String, self).load(*args, **kwargs)
        return six.ensure_str(value)

    def dump(self, value, *args, **kwargs):
        if six.PY2 and isinstance(value, six.text_type):
            value = value.encode('utf-8')
        return super(String, self).dump(value, *args, **kwargs)


class Object(_Object):
    def __init__(self, *args, **kwargs):
        """

        :rtype: object
        """
        constructor = kwargs.pop('constructor', dict)
        super(Object, self).__init__(*args, constructor=constructor, **kwargs)


class Dict(_Dict):
    def __init__(self, values, key_type=None, default_value=None, *args, **kwargs):
        if not isinstance(values, collections_abc.Mapping):
            if default_value is not None:
                raise ValueError('Invalid combination of values and default value')
            values = DictWithDefault({}, values)
        elif default_value is not None:
            values = DictWithDefault(values, default_value)

        super(Dict, self).__init__(
            values, key_type=key_type or String(), *args, **kwargs
        )


class Enum(String):
    def __init__(self, choices, *args, **kwargs):
        error = kwargs.pop('error', 'Invalid choice {data}')
        super(Enum, self).__init__(*args, **kwargs)
        self.validators.append(AnyOf(choices, error=error))


Speed = Dict({'value': Integer(description='scalar multiplier for '
                                           'the speed of the interface'),
              'unit': String(validate=AnyOf(["", "M", "G"]),
                             description='Indicates if \'value\' is in '
                                         'units of Gbps or Mbps')})


class StringBoolean(Type):
    choices = ['true', 'True', 'false', 'False']
    default_error_messages = {
        'invalid_value': 'Value should be one of %s' % choices,
        'invalid_type': 'Invalid value type',
    }

    def load(self, data, *args, **kwargs):
        if data is MISSING or data is None:
            self._fail('required')
        if data not in self.choices:
            self._fail('invalid_value')

        val = (data.lower() == 'true')
        return super(StringBoolean, self).load(val, *args, **kwargs)

    def dump(self, value, *args, **kwargs):
        if value is MISSING or value is None:
            self._fail('required')

        if not isinstance(value, bool):
            self._fail('invalid_type', data=value)

        return super(StringBoolean, self).dump(
            'true' if value else 'false', *args, **kwargs)


class StringNumber(Number):
    def load(self, data, *args, **kwargs):
        if isinstance(data, str):
            data = self._normalize(data)

        return super(StringNumber, self).load(data, *args, **kwargs)


class StringInteger(StringNumber):
    num_type = int
    default_error_messages = {
        'invalid': 'Value should be integer'
    }


class StringFloat(StringNumber):
    num_type = float
    default_error_messages = {
        'invalid': 'Value should be float'
    }


class SparseOptional(Optional):
    pass


# FIXME: fix this in the docs generation by skipping MISSING values as this
#  should not be a burden of the schema
class LoadOnlyApi(LoadOnly):
    # Dump value for LoadOnly is MISSING (MissingType()), which can not be serialized
    # for docs generation
    def dump(self, *args, **kwargs):
        return None


def dict_value_hint(key, incorrect_type=None):
    def hinter(data):
        if isinstance(data, dict):
            return data.get(key)
        return incorrect_type

    return hinter
