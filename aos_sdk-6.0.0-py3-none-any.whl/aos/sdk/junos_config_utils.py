# Copyright 2021-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import re
from collections import deque


def weed_prefix(key):
    """
    Formats Junos configuration which contains replace: statements
    so that they are not present in the output. This helps in converting the Junos
    configuration to set commands in the convert_to_set_commands function.
    :param: key: str - unformatted configuration
        examples:
            replace: forward-delay 30;

    :return: str - formatted configuration
        examples:
            forward-delay 30;
    """
    # Check if the string starts with 'replace:'
    if key.startswith('replace:'):
        # Remove only 'replace:' from the key
        return re.sub(r'^replace:\s*', '', key)

    return key


# Don't delete this function, it's used by the tests.
def weed_comments(conf):
    # Strip ## lines
    conf = re.sub(r'\s*##.*', '', conf, flags=re.MULTILINE).strip()
    # Strip /* <annotation> */ lines
    conf = re.sub(r'\s*/\*.*\*/', '', conf, flags=re.MULTILINE).strip()
    return conf

# pylint: disable=deprecated-lambda
def parse_junos_config(conf):
    """ Junos config parser: Takes a Junos configuration string and
    returns a deep structure representing it. Any operand (e.g. "no-traps;")
    is a dict key (e.g. 'no-traps') with value True, any nested structure is
    a dict key (e.g. 'chassis') with a dict representing the nested structure
    as the value.
    """

    # Splits a Junos configuration string into tokens. We can presently detect
    # special symbols ({, }, [, ], ;), quoted strings, and words. Whitespaces,
    # newlines and comments (starting with # or /*) are ignored.
    def tokenize(s):
        tokens = deque()
        while s := s.lstrip():
            previous_s = s
            if s[0] in ('{', '}', '[', ']', ';'):
                tokens.append(s[0])
                s = s[1:]
            elif m := re.match(r'^("(?:\\.|[^"\\])*")', s):
                tokens.append(m.group(1))
                s = s[len(m.group(1)):]
            elif s[0] == '#':
                s = re.sub(r'^#.*$', '', s, flags=re.MULTILINE)
            elif s[0:2] == '/*':
                s = re.sub(r'^/\*.*?\*/', '', s, flags=re.DOTALL)
            elif m := re.match(r'^([^{}[\];\s]+)', s):
                tokens.append(m.group(1))
                s = s[len(m.group(1)):]
            else:
                raise RuntimeError(f'Not sure how to parse [{s}]')
            if s == previous_s:
                raise RuntimeError(f'Infinite loop detected: {s}')
        ## print(f"tokens: {tokens}\ns: {s}")
        return tokens

    tokens = tokenize(conf)

    # Very rudimentary descend mechanism to walk the tokens array and return the
    # final deep structure representing the config string.
    def descend(tokens):
        def deep_update(to_dict, from_dict):
            for k, v in from_dict.items():
                if isinstance(v, list):
                    to_dict[k] = to_dict.get(k, []) + v
                elif isinstance(v, dict):
                    if isinstance(to_dict.get(k), bool):
                        to_dict[k] = dict()
                    to_dict[k] = deep_update(to_dict.get(k, {}), v)
                elif isinstance(v, bool):
                    to_dict[k] = v
                else:
                    raise RuntimeError('Value must be one of boolean, list, '
                                       'and dictionary.')
            return to_dict

        ret = {}
        current_key = ''
        while tokens:
            token = tokens.popleft()
            if token == '{':
                if current_key in ret:
                    deep_update(ret[current_key], descend(tokens))
                else:
                    ret[current_key] = descend(tokens)
                current_key = ''
            elif token == '}':
                return ret
            elif token == '[':
                ret[current_key] = descend_array(tokens)
                current_key = ''
            elif token == ';':
                if current_key:
                    ret[current_key] = True
                current_key = ''
            else:
                current_key = current_key + ' ' + token if current_key else token
        return ret

    def descend_array(tokens):
        ret = []
        while tokens:
            token = tokens.popleft()
            if token == ']':
                return ret
            if token == ';':
                continue
            ret.append(token)

    return descend(tokens)


def generate_junos_config(d, indent='', ts=4):
    conf = ''
    for k in d:
        if isinstance(d[k], list):
            array_indent = ts*' ' + indent
            conf = conf + indent + k + \
                " [\n" + array_indent + ("\n"+array_indent).join(d[k]) +\
                "\n" + indent + "]\n"
        elif d[k] is True:
            conf = conf + indent + k + ";\n"
        else:
            conf = conf + \
                   indent + k + \
                   ' {\n' + generate_junos_config(d[k], indent + ts*' ', ts=ts) \
                   + indent + '}' + "\n"
    return conf


def ensure_data(o):
    return parse_junos_config(o) if isinstance(o, str) else o


def convert_to_set_commands(data_or_conf):
    data = ensure_data(data_or_conf)
    def get_set_commands(d, prefix=''):
        ret = []
        if isinstance(d, list):
            ret.append('set ' + prefix + '[ ' + ' '.join(d) + ' ]')
        else:
            for k in d:
                if d[k] is True:
                    if not k.startswith('delete:'):
                        ret.append('set ' + prefix + weed_prefix(k))
                else:
                    ret.extend(
                        get_set_commands(
                            d[k], prefix + weed_prefix(k) + ' '
                        )
                    )
        return ret
    return get_set_commands(data)


def junos_config_contains(fragment, data_or_conf):
    data = ensure_data(data_or_conf)
    set_commands = convert_to_set_commands(fragment)
    return all(is_set_command_present(c, data) for c in set_commands)


def is_set_command_present(cmd, data_or_conf):
    data = ensure_data(data_or_conf)
    tokens = re.split(r'\s+', cmd.strip())
    operand = tokens.pop(0)
    assert operand in ('set', 'delete')
    search_term = ''
    while tokens:
        search_term = search_term + ' ' + tokens.pop(0) if search_term else\
            tokens.pop(0)
        if search_term in data:
            if data[search_term] is True:
                return True
            data = data.get(search_term)
            search_term = ''
    return False
