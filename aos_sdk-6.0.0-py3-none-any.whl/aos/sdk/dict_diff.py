# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""Utility to generate diff between two dictionaries
"""
import copy

class DictDiff(object):
    """Class to generate diff of two dicts. The structure of diff_dict is:

    'old': old dictionary
    'new': new dictionary
    'added' : (key, value) from the new_dict which was not present in old_dict
    'removed' : (key, value) in the old_dict which is not present in new_dict
    'changed': key : { 'old' : old_value,
                       'new' : new_value } for keys which are present in both
                       old_dict and new_dict.
    """

    def __init__(self, new_dict=None, old_dict=None):
        if not new_dict:
            new_dict = dict({})
        if not old_dict:
            old_dict = dict({})
        self.diff_dict = dict({})
        self.diff_dict['added'] = dict({})
        self.diff_dict['removed'] = dict({})
        self.diff_dict['changed'] = dict({})
        self.diff_dict['old'] = old_dict
        self.diff_dict['new'] = new_dict
        self.calculate_diff(old_dict, new_dict)

    def empty_diff(self):
        """Return True if both the dictionaries are identical."""
        return self.diff_dict['added'] == dict({}) and \
            self.diff_dict['removed'] == dict({}) and \
               self.diff_dict['changed'] == dict({})

    def calculate_diff(self, old, new, path=None):
        """Calculate diff of old and new dictionaries.
        Args:
            old: old dictionary
            new: new dictionary
            path: common path of keys between old and new from the start.

            For ex. if old is {a : { b : { c : {d:e} } } }
                       new is {a : { b : { c : {d:f} } } }
                    to begin with, and right now are at key c in finding the
                    diff, then path is [a, b].
        """
        # Defend against nested keys which may or may not be in both old
        # and new which can cause KeyErrors or TypeErrors, such as:
        # old = {"foo": {"bar": "baz"}}
        # new = {"foo": None}
        old = old or {}
        new = new or {}
        if not path:
            path = []
        for key in old:
            if key not in new:
                removed = self.diff_dict['removed']
                for entry in path:
                    removed = removed.setdefault(entry, dict({}))
                removed[key] = copy.deepcopy(old[key])
        for key in new:
            if key not in old:
                added = self.diff_dict['added']
                for entry in path:
                    added = added.setdefault(entry, dict({}))
                added[key] = copy.deepcopy(new[key])
                continue
            if old[key] != new[key]:
                if isinstance(new[key], dict):
                    path.append(key)
                    self.calculate_diff(old[key], new[key], path)
                    path.pop()
                else:
                    changed = self.diff_dict['changed']
                    for entry in path:
                        changed = changed.setdefault(entry, dict({}))
                    changed[key] = {'old' : copy.deepcopy(old[key]),
                                    'new' : copy.deepcopy(new[key])}
