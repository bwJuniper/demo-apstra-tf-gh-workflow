# Copyright 2023-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""
This module contains FIPS related helpers.

Allows to create paramiko SSHClient that will not be using non FIPS approved
cryptography under the AOS FIPS environment.

Note that SDK has no dependency on the paramiko, so all the paramiko imports
are dynamic (not module import time) and made only if requested by the code.
"""

import os
import logging


LOGGER = logging.getLogger(__name__)


def is_fips_environment():
    return os.environ.get('AOS_FIPS_MODE', 'no') in ['1', 'yes', 'true']


class ParamikoTweaks(object):
    FIPS_ALGORITHMS = {
        'ciphers': [
            'aes128-ctr',
            'aes192-ctr',
            'aes256-ctr',
            'aes128-cbc',
            'aes192-cbc',
            'aes256-cbc',
            # TODO(michael): Add aes128-gcm@openssh.com and aes256-gcm@openssh.com
            # when support is added to paramiko
        ],
        'macs': [
            'hmac-sha2-256',
            'hmac-sha2-512',
            # TODO(michael): Re-enable these hash algorithms after Terrapin
            # vulnerability is considered resolved
            #'hmac-sha2-256-etm@openssh.com',
            #'hmac-sha2-512-etm@openssh.com',
        ],
        'kex': [
            'ecdh-sha2-nistp256',
            'ecdh-sha2-nistp384',
            'ecdh-sha2-nistp521',
            'diffie-hellman-group14-sha256',
            'diffie-hellman-group-exchange-sha256',
        ],
        'pubkeys': [
            'ecdsa-sha2-nistp256',
            'ecdsa-sha2-nistp384',
            'ecdsa-sha2-nistp521',
            'rsa-sha2-256',
            'rsa-sha2-512',
        ],
        'keys': [
            'ecdsa-sha2-nistp256',
            'ecdsa-sha2-nistp384',
            'ecdsa-sha2-nistp521',
            'rsa-sha2-256',
            'rsa-sha2-512',
        ],
    }

    NON_FIPS_ALGORITHMS = {
        'ciphers': [
            'aes128-ctr',
            'aes192-ctr',
            'aes256-ctr',
            'aes128-cbc',
            'aes192-cbc',
            'aes256-cbc',
            # TODO(michael): Add aes128-gcm@openssh.com and aes256-gcm@openssh.com
            # when support is added to paramiko
        ],
        'macs': [
            'hmac-sha2-256',
            'hmac-sha2-512',
            # TODO(michael): Re-enable these hash algorithms after Terrapin
            # vulnerability is considered resolved
            #'hmac-sha2-256-etm@openssh.com',
            #'hmac-sha2-512-etm@openssh.com',
        ],
    }

    _disabled_algorithms = None
    _disabled_algorithms_non_fips = None

    @staticmethod
    def _get_disabled_algorithms(algorithm_overrides):
        import paramiko

        all_algorithms = {
            'ciphers': paramiko.Transport._preferred_ciphers,
            'macs': paramiko.Transport._preferred_macs,
            'kex': paramiko.Transport._preferred_kex,
            'pubkeys': paramiko.Transport._preferred_pubkeys,
            'keys': paramiko.Transport._preferred_keys,
        }

        disabled_algorithms = {}

        for key, algs in all_algorithms.items():
            if key in algorithm_overrides:
                disabled_algorithms[key] = list(
                    set(algs) - set(algorithm_overrides[key]))

        return disabled_algorithms

    @staticmethod
    def _get_disabled_algorithms_fips():
        LOGGER.info(
            'generating set of disabled algorithms for FIPS Paramiko SSH Client...')
        disabled_algorithms = ParamikoTweaks._get_disabled_algorithms(
            ParamikoTweaks.FIPS_ALGORITHMS
        )

        LOGGER.info('FIPS Paramiko disabled algorithms: %s', disabled_algorithms)

        return disabled_algorithms

    @staticmethod
    def _get_disabled_algorithms_non_fips():
        LOGGER.info(
            'generating set of disabled algorithms for non-FIPS Paramiko '
            'SSH Client...')
        disabled_algorithms = ParamikoTweaks._get_disabled_algorithms(
            ParamikoTweaks.NON_FIPS_ALGORITHMS
        )

        LOGGER.info('Non-FIPS Paramiko disabled algorithms: %s', disabled_algorithms)

        return disabled_algorithms

    @staticmethod
    def get_disabled_algorithms():
        if not is_fips_environment():
            if ParamikoTweaks._disabled_algorithms_non_fips is None:
                ParamikoTweaks._disabled_algorithms_non_fips = \
                    ParamikoTweaks._get_disabled_algorithms_non_fips()
            return ParamikoTweaks._disabled_algorithms_non_fips

        if ParamikoTweaks._disabled_algorithms is None:
            ParamikoTweaks._disabled_algorithms = \
                ParamikoTweaks._get_disabled_algorithms_fips()

        return ParamikoTweaks._disabled_algorithms


_fips_aware_ssh_client_class = None


def _create_fips_aware_ssh_client_class():
    import paramiko

    class FipsAwareSSHClient(paramiko.SSHClient):
        def connect(self, *args, **kwargs):
            disabled_algorithms = dict(kwargs.get('disabled_algorithms', {}))
            extra_disabled_algorithms = ParamikoTweaks.get_disabled_algorithms()
            for key, algs in extra_disabled_algorithms.items():
                disabled_algorithms[key] = list(
                    set(disabled_algorithms.get(key, [])).union(algs)
                )

            kwargs['disabled_algorithms'] = disabled_algorithms

            super(FipsAwareSSHClient, self).connect(*args, **kwargs)

    return FipsAwareSSHClient


def create_fips_aware_ssh_client():
    # pylint: disable=global-statement
    global _fips_aware_ssh_client_class

    if _fips_aware_ssh_client_class is None:
        _fips_aware_ssh_client_class = _create_fips_aware_ssh_client_class()

    assert _fips_aware_ssh_client_class

    return _fips_aware_ssh_client_class()
