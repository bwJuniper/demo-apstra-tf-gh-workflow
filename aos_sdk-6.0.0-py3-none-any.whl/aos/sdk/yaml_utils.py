# Copyright 2022-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""
Facilitates data conversion from/to YAML format.

Python2/3 compatibility note: The result of the YAML conversion is textual type
(as opposed to the binary type) on both Python versions. Textual type is represented
by "unicode" type in Python2 and by "str" in the Python3. Deserialization function
will accept both textual type (preferably) and binary type (assumed UTF-8 encoding).
This is mostly done to reduce integration friction.
"""

import six

import yaml
import yaml.parser
import yaml.representer
import yaml.scanner


class YamlError(Exception):
    def __init__(self, message, *args):
        super(YamlError, self).__init__(message, *args)
        self.message = message


class YamlSerializationError(YamlError):
    pass


class YamlDeserializationError(YamlError):
    def __init__(self, message, mark=None):
        super(YamlDeserializationError, self).__init__(message)
        self.mark = mark


def to_yaml(data):
    """
    Returns YAML (text) representation of the data.
    """

    try:
        return yaml.safe_dump(
            data,
            allow_unicode=True,
            explicit_end=False,
            explicit_start=False,
            encoding=None,  # prevent automatic encoding
            default_flow_style=False,  # always use "block style" for collections
        )
    except yaml.representer.RepresenterError as e:
        error = 'Unable to serialize data to YAML'
        six.raise_from(YamlSerializationError(error, *e.args), e)


def from_yaml(yaml_text):
    """
    Deserializes YAML text into the Python simple objects.

    When YAML text is represented by the binary type it is decoded with
    UTF-8 encoding.

    Raises ValueError when non textual type is passed in.
    """

    if yaml_text is None:
        raise ValueError('YAML text was None')

    yaml_text = six.ensure_text(yaml_text, 'utf-8')

    try:
        data = yaml.safe_load(
            yaml_text,
        )
        return data
    except yaml.parser.ParserError as e:
        error = 'Unable to read YAML string: %s' % e.problem
        six.raise_from(YamlDeserializationError(error, e.problem_mark), e)
    except yaml.scanner.ScannerError as e:
        error = 'Unable to read YAML string: %s' % e.problem
        six.raise_from(YamlDeserializationError(error, e.problem_mark), e)
