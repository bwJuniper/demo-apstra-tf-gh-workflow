# Copyright 2022-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


def get_not_none(value, alt_value=''):
    return value if value is not None else alt_value


def get_label_or_id(node_or_props):
    if not node_or_props:
        return ''
    return get_not_none(getattr(node_or_props, 'label', None), node_or_props.id)
