# Copyright 2024-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=invalid-name

from __future__ import annotations

from aos.sdk.client import (
    Client as BaseClient,
    Api,
    RestResource,
    RestResources,
    api,
)


def _get_facade_schema(name: str, value: str) -> str:
    '''Helper for type annotations generation.

    :param name: name of the facade method
    :param value: attribute of the facade method which holds schema

    :return: reference to arg schema in form of a magic annotation
    '''
    return f'''
    _MAGIC.facade_method_schema[
        aos.reference_design.extension.tenants.facade.Facade,
        {name},
        {value}
    ]
    '''


class Client(BaseClient):
    '''This client has a set of methods to access blueprints with
    reference designs that have active tenants extension.

    .. code-block:: python

        from aos.sdk.client import Client as BaseClient
        from aos.sdk.reference_design.extension.tenants.client import Client

        class MyClient(Client, BaseClient):
            pass
    '''

    @api('/blueprints')
    class blueprints(Api):

        @api('/{blueprint_id}')
        class resource(Api):

            @api('/tenants')
            class tenants(
                RestResources,
                list__=_get_facade_schema('get_tenants', 'result'),
                create__data=_get_facade_schema('create_tenant', 'arg'),
                create__=_get_facade_schema('create_tenant', 'result'),
            ):
                '''Manage tenants specific to blueprint.
                '''

                @api('/{tenant_id}')
                class resource(
                    RestResource,
                    get__=_get_facade_schema('get_tenant', 'result'),
                    update__data=_get_facade_schema('update_tenant_assignment',
                                                    'arg'),
                ):
                    '''Manage specific tenant of a blueprint.
                    '''
