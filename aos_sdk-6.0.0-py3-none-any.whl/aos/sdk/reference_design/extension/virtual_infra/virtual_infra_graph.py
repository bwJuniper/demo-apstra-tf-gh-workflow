#!/usr/bin/python
# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from aos.sdk.collection_utils import get_only_item
import logging
LOGGER = logging.getLogger(__name__)


class VirtualInfraGraph(object):
    def __init__(self, graph):
        self.graph = graph
        self._virtual_infra_node = None
        self._track = False
        self._vm_ids = set()
        self._hv_ids = set()
        self._vnet_ids = set()
        self._port_channel_policy_ids = set()
        self._link_discovery_policy_ids = set()

    @property
    def virtual_infra_node(self):
        assert self._virtual_infra_node
        return self._virtual_infra_node

    @virtual_infra_node.setter
    def virtual_infra_node(self, value):
        self._virtual_infra_node = value

    def stop_tracking(self):
        self._track = False
        self._vm_ids.clear()
        self._hv_ids.clear()
        self._vnet_ids.clear()
        self._port_channel_policy_ids.clear()
        self._link_discovery_policy_ids.clear()

    def start_tracking(self):
        # cannot ignore double calls to tracking, as each call to start_tracking
        # is meant to only track updates from that point on..
        assert not self._track
        self._track = True

    @property
    def vm_ids(self):
        assert self._track
        return self._vm_ids

    @property
    def hv_ids(self):
        assert self._track
        return self._hv_ids

    @property
    def vnet_ids(self):
        assert self._track
        return self._vnet_ids

    @property
    def port_channel_policy_ids(self):
        assert self._track
        return self._port_channel_policy_ids

    @property
    def link_discovery_policy_ids(self):
        assert self._track
        return self._link_discovery_policy_ids

    def ensure_singleton_relationship(self, rel_type, source, target, **properties):
        assert source and target, str(locals())
        existing_target = get_only_item(self.graph.traverse(
            nodes=source).out(rel_type).target(target.type))
        if existing_target and existing_target != target:
            self.ensure_no_relationship(rel_type, source, existing_target)
        self.ensure_relationship(rel_type, source, target, **properties)

    def ensure_singleton_reverse_relationship(
            self, rel_type, source, target, **properties):
        '''
        For situation like: hypervisor -> hosts -> vm
        We all know that the hosts relationship is 1 to many. And this is
        defined in the schema. However, thinking from reverse order, 1 vm can only
        be hosted by 1 hypervisor. For this example, given source as vm,
        and target as hypervisor, this method ensures the 1-1 relationship. We
        first find the existing hypervisor the vm is hosted on, if it's obsolete,
        we remove old relation and create one for new hypervisor.
        '''
        assert source and target, str(locals())
        existing_source = get_only_item(self.graph.traverse(
            nodes=target).in_(rel_type).source(source.type))
        if existing_source and existing_source != source:
            self.ensure_no_relationship(rel_type, existing_source, target)
        self.ensure_relationship(rel_type, source, target, **properties)

    def ensure_relationship(self, rel_type, source_id, target_id, **properties):
        rel = self.graph.get_relationships(
            type=rel_type, source_id=source_id, target_id=target_id).first
        if not rel:
            rel = self.graph.add_relationship(
                rel_type, source_id, target_id, **properties)
            LOGGER.info("relation %s added", rel)
        return rel

    def ensure_no_relationship(self, rel_type, source_id, target_id):
        rel = self.graph.get_relationships(
            type=rel_type, source_id=source_id, target_id=target_id).first
        if rel:
            self.graph.del_relationship(rel)
            LOGGER.info("relation %s removed", rel)

    def get_vm(self, vm_id):
        return self.graph.get_nodes('vm', vm_id=vm_id).first

    def ensure_vm(self, vm_id, **properties):
        vm_node = self.get_vm(vm_id)
        if not vm_node:
            vm_node = self.graph.add_node('vm', vm_id=vm_id, **properties)
            LOGGER.info("vm %s, %s added", vm_node.id, vm_node)
        else:
            vm_node = self.graph.set_node(vm_node, **properties)

        self.ensure_relationship('part_of', vm_node, self.virtual_infra_node)

        if self._track:
            self._vm_ids.add(vm_id)

        return vm_node

    def get_hypervisor(self, hypervisor_id):
        return self.graph.get_nodes('hypervisor', hypervisor_id=hypervisor_id).first

    def get_hypervisor_with_vm(self, vm_node):
        return get_only_item(self.graph.traverse(
            nodes=vm_node).in_('hosts').source('hypervisor'))

    def ensure_hypervisor(self, hypervisor_id, **properties):
        hv_node = self.get_hypervisor(hypervisor_id)
        if not hv_node:
            hv_node = self.graph.add_node(
                'hypervisor', hypervisor_id=hypervisor_id, **properties)
            LOGGER.info("hypervisor %s, %s added", hv_node.id, hv_node)
        else:
            hv_node = self.graph.set_node(hv_node, **properties)

        self.ensure_relationship('part_of', hv_node, self.virtual_infra_node)

        if self._track:
            self._hv_ids.add(hypervisor_id)

        return hv_node

    def get_vnet(self, vnet_id):
        return self.graph.get_nodes('vnet', vnet_id=vnet_id).first

    def get_vnet_with_vnic(self, vnic_node):
        return get_only_item(self.graph.traverse(
            nodes=vnic_node).out('part_of').target('vnet'))

    def ensure_vnet(self, vnet_id, **properties):
        vnet_node = self.get_vnet(vnet_id)
        if not vnet_node:
            vnet_node = self.graph.add_node(
                'vnet', vnet_id=vnet_id, **properties)
            LOGGER.info("vnet %s, %s added", vnet_node.id, vnet_node)
        else:
            vnet_node = self.graph.set_node(vnet_node, **properties)

        self.ensure_relationship('part_of', vnet_node, self.virtual_infra_node)

        if self._track:
            self._vnet_ids.add(vnet_id)

        return vnet_node

    def get_pnic(self, mac_address):
        return self.graph.get_nodes('pnic', mac_address=mac_address).first

    def ensure_pnic(self, mac_address, hypervisor_node, **properties):
        pnic_node = self.get_pnic(mac_address)
        if not pnic_node:
            pnic_node = self.graph.add_node(
                'pnic', mac_address=mac_address, **properties)
            LOGGER.info("pnic %s, %s added", pnic_node.id, pnic_node)
        else:
            pnic_node = self.graph.set_node(pnic_node, **properties)

        self.ensure_relationship('part_of', pnic_node, self.virtual_infra_node)
        self.ensure_relationship('has', hypervisor_node, pnic_node)

        # pnic_nodes are not tracked since they are not considered top level objects

        return pnic_node

    def get_vnic(self, mac_address, host_node):
        return get_only_item(self.graph.traverse(
            host_node).out('has').target('vnic', mac_address=mac_address))

    def ensure_vnic(self, mac_address, host_node, **properties):
        vnic_node = self.get_vnic(mac_address, host_node)
        if not vnic_node:
            vnic_node = self.graph.add_node(
                'vnic', mac_address=mac_address, **properties)
            LOGGER.info("vnic %s, %s added", vnic_node.id, vnic_node)
        else:
            vnic_node = self.graph.set_node(vnic_node, **properties)

        self.ensure_relationship('part_of', vnic_node, self.virtual_infra_node)
        self.ensure_relationship('has', host_node, vnic_node)

        # vnic_nodes are not tracked since they are not considered top level objects

        return vnic_node

    def get_port_channel(self, port_channel_id, hypervisor_node):
        return (
            self.graph.traverse(nodes=hypervisor_node)
            .out('has')
            .node('port_channel', port_channel_id=port_channel_id)
        ).first

    def ensure_port_channel(self, port_channel_id, hypervisor_node):
        port_channel_node = self.get_port_channel(port_channel_id, hypervisor_node)
        if not port_channel_node:
            port_channel_node = self.graph.add_node(
                'port_channel', port_channel_id=port_channel_id)
            LOGGER.info(
                "port_channel %s, %s added", port_channel_node.id, port_channel_node)

        self.ensure_relationship('has', hypervisor_node, port_channel_node)

        return port_channel_node

    def get_port_channel_policy(self, policy_id):
        return self.graph.get_nodes('port_channel_policy', policy_id=policy_id).first

    def ensure_port_channel_policy(self, policy_id, **properties):
        policy_node = self.get_port_channel_policy(policy_id)
        if not policy_node:
            policy_node = self.graph.add_node(
                'port_channel_policy', policy_id=policy_id, **properties)
            LOGGER.info(
                "port_channel_policy %s, %s added", policy_node.id, policy_node)

            self.ensure_relationship('part_of', policy_node, self.virtual_infra_node)
        else:
            policy_node = self.graph.set_node(policy_node, **properties)
            LOGGER.debug(
                "port_channel_policy %s, %s updated", policy_node.id, policy_node)

        if self._track:
            self._port_channel_policy_ids.add(policy_id)

        return policy_node

    def get_link_discovery_policy(self, policy_id):
        return self.graph.get_nodes(
            'link_discovery_policy', policy_id=policy_id).first

    def ensure_link_discovery_policy(self, policy_id, **properties):
        policy_node = self.get_link_discovery_policy(policy_id)
        if not policy_node:
            policy_node = self.graph.add_node(
                'link_discovery_policy', policy_id=policy_id, **properties)
            LOGGER.info(
                "link_discovery_policy %s, %s added", policy_node.id, policy_node)

            self.ensure_relationship(
                'part_of', policy_node, self.virtual_infra_node)
        else:
            policy_node = self.graph.set_node(policy_node, **properties)
            LOGGER.debug(
                "link_discovery_policy %s, %s updated", policy_node.id, policy_node)

        if self._track:
            self._link_discovery_policy_ids.add(policy_id)

        return policy_node

    def ensure_no_link_discovery_policy(self, policy_id):
        policy_node = self.get_link_discovery_policy(policy_id)
        if not policy_node:
            return

        LOGGER.info(
            "link_discovery_policy %s, %s removed", policy_node.id, policy_node)
        self.graph.del_node(policy_node)

    def ensure_virtual_infra_node(self, infra_type, system_id, management_ip):
        virtual_infra_info_node = self.graph.get_nodes('virtual_infra_info').first
        if not virtual_infra_info_node:
            virtual_infra_info_node = self.graph.add_node(
                'virtual_infra_info', infra_type=infra_type,
                management_ip=management_ip, system_id=system_id)
        self.virtual_infra_node = virtual_infra_info_node
