#!/usr/bin/python
# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import absolute_import
from __future__ import division

from aos.sdk import schema as s


def validate_vnet(vnet):
    errors = s.ValidationErrorBuilder()
    vn_type = vnet.get('vn_type', 'vlan')
    if vn_type == 'vlan' and not vnet.get('vlans') and vnet.get('vlan') is None:
        errors.add_error('vlan(s)', 'Value is required')
    if vn_type == 'overlay' and vnet.get('vni') is None:
        errors.add_error('vni', 'Value is required')
    errors.raise_errors()


class Schema(s.Schema):
    nodes = {
        'virtual_infra': {
            # nsxt is maintained to support backward compatibility with old
            #  graph schema. Use nsx instead of nsxt.
            'infra_type': s.Enum(['vcenter', 'nsxt', 'nutanix', 'nsx']),
            'system_id': s.SystemId(),
            'agent_id': s.String(
                description='ID of a system agent, we store agent_id solely for '
                            'performance reasons, so we can efficiently lookup '
                            'agent config to enrich GET facade APIs with '
                            'additional user-friendly context such as virtual '
                            'infra manager address.',
            )
        },
        'vnet_remediation_policy': {
            'vn_type': s.VnetRemediationPolicyVnetType(),
        },
        'hypervisor': s.NodeSchema('hypervisor', {
            'hypervisor_id': s.String(),
            'label': s.Optional(s.String()),
            'hostname': s.Optional(s.String()),
            'version': s.Optional(s.String()),
            'nsx_enabled' : s.Optional(s.Boolean()),
        }, indexes=[('hypervisor_id', 'label')]),
        'vm': s.NodeSchema('vm', {
            'vm_id': s.String(),
            'label': s.Optional(s.String()),
            'ip': s.Optional(s.IpAddressOrEmpty())
        }, indexes=[('vm_id', 'label')]),
        'pnic': s.NodeSchema('pnic', {
            'mac_address': s.MacAddress(),
            'switch_id': s.String(),
            'label': s.Optional(s.String()),
            'pnic_tag': s.String(),
            'neighbor_name': s.Optional(
                s.String(),
                description='The neighbor hostname reported from LLDP on the'
                            ' hypervisor'
            ),
            'neighbor_intf': s.Optional(
                s.String(),
                description='The neighbor interface reported from LLDP on the'
                            ' hypervisor'
            ),
            # TODO(chiahui): make mtu mandatory after adding vcenter mtu collection
            'mtu': s.Optional(s.Integer()),
            'nsx_uplink_name': s.Optional(s.List(s.String(
                description='Uplink port names used by NSX-T'))),
        }, indexes=[('pnic_tag',)]),
        'vnic': {
            'mac_address': s.MacAddress(),
            'label': s.Optional(s.String()),
            'ipv4_addr': s.Optional(s.IpAddressOrEmpty()),
            'traffic_types':
                s.Optional(s.List(s.Enum([
                    'fault_tolerance_logging',
                    'management',
                    'vmotion',
                    'sds',
                    'sds_witness',
                    'provisioning',
                    'replication',
                    'replication_nfc',
                    'overlay',
                    'vlan',
                ]))),
            'mtu': s.Optional(s.Integer()),
        },
        'vnet': s.NodeSchema('vnet', {
            'ipv4_subnet': s.Optional(s.IpNetworkAddress()),
            'label': s.Optional(s.String()),
            'vnet_id': s.String(),
            'vni': s.Optional(
                s.Integer(),
                description='vni for overlay vn_type. This field is required'
                            ' for overlay vn_type'),
            'vlan': s.Optional(
                s.Integer(),
                description='vlan for vlan vn_type. Deprecated by vlans'),
            'vlans': s.Optional(
                s.List(s.Integer()),
                load_default=list,
                description='list of vlans for vlan vn_type. This field is required'
                            ' for vlan vn_type'),
            'vn_type': s.Optional(s.Enum(['vlan', 'overlay']),
                                  load_default='vlan'),
            'switch_label': s.Optional(s.String(),
                                       description='Label of virtual switch this '
                                                   'virtual network is part of, '
                                                   ' in cases such a concept exists'
                                                   'in the target virtual infra '
                                                   'manager'),
            'switch_id': s.Optional(s.String(),
                                    description='Unique id of the host switch this '
                                                'virtual network is part of'),
            'transport_zone_id': s.Optional(s.String(
                description='Transport zone to be associated with a NSX portgroup')),
            'logical_switch_id': s.Optional(s.String(
                description='Logical switch UUID, which is used by NSX portgroup')),
            }, indexes=[('vnet_id', 'label')], validate=validate_vnet),
        'port_channel_policy': {
            'policy_id': s.Optional(s.String(),
                                    description='Internal identity known to '
                                                'collectors and opaque to AOS.'
                                                'Typically this is a unique '
                                                'identifier in the virtual infra'
                                                'manager external system'),
            'label': s.Optional(s.String()),
            'mode': s.Enum(['active', 'passive']),
            'hashing_algorithm': s.Enum(
                ['destIp',
                 'destIpTcpUdpPort',
                 'destIpVlan',
                 'destIpTcpUdpPortVlan',
                 'destMac',
                 'destTcpUdpPort',
                 'srcIp',
                 'srcIpTcpUdpPort',
                 'srcIpVlan',
                 'srcIpTcpUdpPortVlan',
                 'srcMac',
                 'srcTcpUdpPort',
                 'srcDestIp',
                 'srcDestIpTcpUdpPort',
                 'srcDestIpVlan',
                 'srcDestIpTcpUdpPortVlan',
                 'srcDestMac',
                 'srcDestTcpUdpPort',
                 'srcPortId',
                 'vlan',
                 'srcDestMacIpPort'])
        },
        'port_channel': {
            'label': s.Optional(s.String()),
            'port_channel_id': s.String(),
        },
        'link_discovery_policy': {
            'policy_id': s.Optional(
                s.String(),
                description='Internal identity known to collectors and opaque to '
                            'AOS. Typically this is a unique identifier in the'
                            ' virtual infra manager external system'),
            'label': s.Optional(s.String()),
            'protocol': s.Optional(s.Enum(['lldp', 'cdp'])),
            'operation': s.Optional(s.Enum(['advertise', 'listen', 'both'])),
        },
        'virtual_infra_info': {
            # nsxt is maintained to support backward compatibility with old
            # graph schema. Use nsx instead of nsxt.
            'infra_type': s.Enum(['vcenter', 'nsxt', 'nutanix', 'nsx']),
            'system_id': s.String(),
            'management_ip': s.String(),
        },
    }

    relationships = [
        s.RelationshipSchema(
            type='hosts',
            source_type='hypervisor',
            target_type='vm',
            sticky=False,  # To properly support vmotion
        ),
        s.RelationshipSchema(
            type='has',
            source_type='hypervisor',
            target_type='pnic',
            sticky=True
        ),
        s.RelationshipSchema(
            type='has',
            source_type='hypervisor',
            target_type='vnic',
            sticky=True
        ),
        s.RelationshipSchema(
            type='has',
            source_type='hypervisor',
            target_type='port_channel',
            sticky=True
        ),
        s.RelationshipSchema(
            type='has',
            source_type='vm',
            target_type='vnic',
            sticky=True
        ),
        s.RelationshipSchema(
            type='policy',
            source_type='virtual_infra',
            target_type='vnet_remediation_policy'
        ),
        # This is a one-to-one relationship that must exist for every
        # vnet_remediation_policy. When vlan is selected in the policy, we still
        # have relation to default security zone
        # TODO shanshan Add 1-1 validation
        {
            'source': 'vnet_remediation_policy',
            'type': 'security_zone',
            'target': 'security_zone'
        },
        {
            'source': 'vnic',
            'type': 'part_of',
            'target': 'vnet',
        },
        {
            'source': 'pnic',
            'type': 'carries',
            'target': 'vnet',
        },
        {
            'source': 'pnic',
            'type': 'policy',
            'target': 'link_discovery_policy',
        },
        {
            'source': 'hypervisor',
            'type': 'is_realized_by',
            'target': 'system',
        },
        {
            'source': 'pnic',
            'type': 'is_realized_by',
            'target': 'interface',
        },
        {
            'source': 'port_channel',
            'type': 'is_realized_by',
            'target': 'interface',
        },
        {
            'source': 'port_channel',
            'type': 'composed_of',
            'target': 'pnic'
        },
        {
            'source': 'port_channel',
            'type': 'policy',
            'target': 'port_channel_policy'
        },
        {
            'source': 'vm',
            'type': 'part_of',
            'target': 'virtual_infra_info',
        },
        {
            'source': 'hypervisor',
            'type': 'part_of',
            'target': 'virtual_infra_info',
        },
        {
            'source': 'pnic',
            'type': 'part_of',
            'target': 'virtual_infra_info',
        },
        {
            'source': 'vnic',
            'type': 'part_of',
            'target': 'virtual_infra_info',
        },
        {
            'source': 'vnet',
            'type': 'part_of',
            'target': 'virtual_infra_info',
        },
        {
            'source': 'port_channel_policy',
            'type': 'part_of',
            'target': 'virtual_infra_info',
        },
        {
            'source': 'link_discovery_policy',
            'type': 'part_of',
            'target': 'virtual_infra_info',
        },
        {
            'source': 'virtual_infra_info',
            'type': 'bound_to',
            'target': 'virtual_infra_info',
        },
    ]
