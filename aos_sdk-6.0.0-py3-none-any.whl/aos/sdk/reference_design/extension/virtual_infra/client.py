# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula
# pylint: disable=invalid-name

from __future__ import annotations

import typing as t

from aos.sdk.client import Client as _Client, Api, api, RestResource, RestResources

if t.TYPE_CHECKING:
    import typing_extensions as te

    from aos.sdk import typing as tt

    _MAGIC: t.Any
    aos: t.Any


def _fc_schema(name: str, value: str) -> str:
    '''Helper for type annotations generation.

    :param name: name of the facade method
    :param value: attribute of the facade method which holds schema

    :return: reference to arg schema in form of a magic annotation
    '''
    return f"""
    _MAGIC.facade_method_schema[
        aos.reference_design.extension.virtual_infra.facade.Facade,
        {name},
        {value}
    ]
    """


class Client(_Client):
    @api('/blueprints')
    class blueprints(Api):
        @api('/{blueprint_id}')
        class resource(Api):
            @api('/virtual_infra')
            class virtual_infra(
                RestResources,
                list__=_fc_schema('list_virtual_infra', 'result'),
                create__data=_fc_schema('add_virtual_infra', 'arg'),
                create__=_fc_schema('add_virtual_infra', 'result'),
                __list='''
                    Get all virtual infra nodes.
                ''',
                __create='''
                    Add virtual infra node to the blueprint.

                    :param data: configuration of the new virtual infra node
                '''
            ):
                @api('/{resource_id}')
                class resource(
                    RestResource,
                    patch__data=_fc_schema('patch_virtual_infra', 'arg'),
                    patch__=_fc_schema('patch_virtual_infra', 'result'),
                    get__=_fc_schema('get_virtual_infra', 'result'),
                    __patch='''
                        Update virtual infra.

                        :param data: new configuration of the virtual infra
                    ''',
                    __get='''
                        Get virtual infra node info.
                    ''',
                    __delete='''
                        Remove virtual infra node from blueprint.
                    '''
                ):
                    pass

                @api('/query')
                class query(Api):
                    @api('/vm')
                    class vm(Api):
                        def post(
                            self,
                            data: _MAGIC.facade_method_schema[
                                # pylint: disable=line-too-long
                                'aos.reference_design.extension.virtual_infra.facade.Facade',
                                'query_virtual_infra_vm',
                                'arg'
                            ],
                            **kwargs: te.Unpack[RestResource.TWriteKwargs]
                        ) -> _MAGIC.facade_method_schema[
                            # pylint: disable=line-too-long
                            'aos.reference_design.extension.virtual_infra.facade.Facade',
                            'query_virtual_infra_vm',
                            'result']:
                            """ Return VM info.

                            :param data: name of the VM
                            """
                            return self._request(
                                method='POST',
                                data=data,
                                **kwargs
                            )

                @api('/vnet')
                class vnet(Api):
                    @api('/{vnet}')
                    class resource(Api):
                        def get(
                            self,
                            params: t.Optional[dict[str, tt.JSON]] = None,
                            **kwargs: te.Unpack[RestResource.TReadKwargs],
                        ) -> _MAGIC.facade_method_schema[
                            # pylint: disable=line-too-long
                            'aos.reference_design.extension.virtual_infra.facade.Facade',
                            'query_virtual_infra_vnet',
                            'result']:
                            """ Return VNET info.

                            :param params: VNET label
                            """
                            if params is None:
                                params = {}
                            self._request(
                                params=dict({'type': 'operation'}, **params),
                                **kwargs)

                def resolve_virtual_infra_vlan_match_anomalies(
                    self,
                    data: _MAGIC.facade_method_schema[
                        # pylint: disable=line-too-long
                        'aos.reference_design.extension.virtual_infra.facade.Facade',
                        'resolve_vlan_probe_anomalies',
                        'arg'
                    ],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs]
                ) -> tt.JSON:
                    """ Update blueprint virtual network config to resolve anomalies.

                    :param data: probe id and stage name
                    """
                    return self._request(
                        url='/predefined_probes/virtual_infra_vlan_match'
                            '/anomaly_resolver',
                        method='POST',
                        data=data,
                        **kwargs
                    )
