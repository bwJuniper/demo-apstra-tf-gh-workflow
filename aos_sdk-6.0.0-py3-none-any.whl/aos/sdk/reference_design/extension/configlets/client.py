# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula
# pylint: disable=invalid-name,line-too-long

from __future__ import annotations

from aos.sdk.client import Client as _Client, Api, api, resources


def _pset_schema(name: str) -> str:
    return f"_MAGIC.lollipop_type[aos.scotch.blueprints.property_sets.{name}]"


def _cfg_schema(name: str) -> str:
    return f"_MAGIC.lollipop_type[aos.scotch.schemas.configlet_schema.{name}]"


class Client(_Client):
    '''This client has a set of methods to access blueprints with
    reference designs that have active configlets extension.

    .. code-block:: python

        from aos.sdk.client import Client as BaseClient
        from aos.sdk.reference_design.extension.configlets.client import Client as ExtClient

        class MyClient(ExtClient, BaseClient):
            pass
    '''

    @api('/blueprints')
    class blueprints(Api):
        @api('/{blueprint_id}')
        class resource(Api):
            property_sets = resources(
                '/property-sets',
                with_options=True,
                get_schema=_pset_schema('DETAILED_PROPERTY_SET'),
                collection_schema=_pset_schema('LIST_PROPERTY_SET'),
                post_schema=_pset_schema('CREATE_PROPERTY_SET'),
                put_schema=_pset_schema('UPDATE_PROPERTY_SET'),
                patch_schema=_pset_schema('PATCH_PROPERTY_SET'),
                collection_doc='''
                    Manage property sets, specific to blueprints.
                ''',
                resource_doc='''
                    Manage property set of a blueprint.
                '''
            )
            configlets = resources(
                '/configlets',
                with_options=True,
                get_schema=_cfg_schema('CONFIGLET_SCHEMA'),
                collection_schema=_cfg_schema('LIST_CONFIGLET_SCHEMA'),
                post_schema=_cfg_schema('CONFIGLET_SCHEMA'),
                put_schema=_cfg_schema('CONFIGLET_SCHEMA'),
                collection_doc='''
                    Manage configlets, specific to blueprints.
                ''',
                resource_doc='''
                    Manage configlet of a blueprint.
                '''
            )
