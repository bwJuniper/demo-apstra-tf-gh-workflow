# Copyright 2024-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=invalid-name,line-too-long

from __future__ import annotations

import typing as t

from aos.sdk.client import (
    Client as BaseClient,
    Api,
    api,
)


if t.TYPE_CHECKING:
    import typing_extensions as te

    from aos.sdk import typing as tt
    from aos.sdk.client import RestResource

    _MAGIC: t.Any
    aos: t.Any


class Client(BaseClient):
    '''This client has a set of methods to access blueprints with
    reference designs that have active preferences extension.

    .. code-block:: python

        from aos.sdk.client import Client as BaseClient
        from aos.sdk.reference_design.extension.preferences.client import Client

        class MyClient(Client, BaseClient):
            pass
    '''

    @api('/blueprints')
    class blueprints(Api):

        @api('/{blueprint_id}')
        class resource(Api):

            @api('/preferences')
            class preferences(Api):
                def update(
                    self,
                    data: _MAGIC.lollipop_type[
                        'aos.reference_design.extension.preferences.preferences.PREFERENCES_SCHEMA'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs]
                ) -> tt.JSON:
                    """ Update user-specific preferences.

                    Updates user-specific blueprint preferences. These preferences
                    are used by the UI to indicate metadata such as topology
                    diagrams or User preferences.

                    This API is not intended to be user-facing and is used only by
                    UI code.

                    :param data: new preferences
                    """
                    return self._request(method='PUT', data=data, **kwargs)

                def get(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> _MAGIC.lollipop_type[
                    'aos.reference_design.extension.preferences.preferences.PREFERENCES_SCHEMA']:
                    """ Get user preferences.

                    Returns user-specific preferences for the blueprint.
                    """
                    return t.cast(
                        dict,
                        self._request(method='GET', **kwargs)
                    )['preferences']

            @api('/experience')
            class experience(Api):
                @api('/web')
                class web(Api):
                    @api('/preferences')
                    class preferences(Api):
                        def get(
                                self,
                                **kwargs: te.Unpack[RestResource.TReadKwargs],
                        ) -> _MAGIC.lollipop_type[
                            'aos.reference_design.extension.preferences.experience.PREFERENCES_CACHE_SCHEMA']:
                            """ Returns user-specific preferences for the blueprint.
                            """
                            # uses "values" instead of "items" as others because
                            # preferences is a single node and response does not
                            # contain a list of resources, but values from that
                            # single preferences node
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['values']

