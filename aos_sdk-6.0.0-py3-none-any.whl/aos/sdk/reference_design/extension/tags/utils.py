# Copyright 2020-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import annotations

from collections import defaultdict
from itertools import chain
import six
import typing as t

from aos.sdk.graph import Node, is_node
import aos.sdk.graph.query as graph_query
import aos.sdk.graph.matchers as m

if t.TYPE_CHECKING:
    from aos.sdk.types import ValidationErrorBuilder
    from aos.sdk import typing as tt

    _MAGIC: t.Any
    aos: t.Any


def assign_tags(graph: tt.Graph, node: tt.GraphNode,
                tags: list[tt.GraphNode]) -> None:
    """Assign tags to the node

    For each tag create relationship from that tag to specified node.
    Target node and tags can be passed as IDs and as graph node instances as well.
    This function is not idempotent and unconditionally creates tag relationships
    for each provided tags to the node. So, the calling code must prevent
    calling this function for already existing relationships, otherwise
    it will result in duplication of relationships.
    """
    for tag in tags:
        graph.add_relationship('tag', tag, node)


def update_tags_assignment(graph: tt.Graph, node: tt.GraphNode,
                           tags: list[tt.GraphNode] | list[tt.GraphNodeId]) -> None:
    """Update the node tags

    For each tag ID in 'tags' check if relationship to node exists and
    create one otherwise. Also remove relationships to node from tags
    which are not in 'tags' argument.
    """
    tag_ids = [t.cast(Node, tag).id if is_node(tag) else
               t.cast(str, tag) for tag in tags]

    assigned_tags = {rel.source_id: rel for rel in
                     graph.get_relationships('tag', target_id=node)}

    for tag_id, rel in six.iteritems(assigned_tags):
        if tag_id not in tag_ids:
            graph.del_relationship(rel)

    for tag_id in tag_ids:
        if tag_id not in assigned_tags:
            graph.add_relationship('tag', tag_id, node)


def get_assigned_tags_ids(graph: tt.Graph,
                          node: tt.GraphNode) -> list[tt.GraphNodeId]:
    """Get list of IDs of tags that are assigned to node

    If tag assigned to node multiple times, which is invalid graph state, result
    will contain duplicates, which is useful for testing purposes.
    """
    return list(rel.source_id for rel in
                graph.get_relationships('tag', target_id=node))


def get_assigned_tags_labels(graph: tt.Graph,
                             node: tt.GraphNode) -> list[str]:
    """Get list of tag labels that are assigned to node"""

    return sorted([
        tag_node.label for tag_node in graph.traverse(
            node if is_node(node) else graph.get_node(node)).in_('tag').node('tag')])


def get_assigned_tags_ids_and_labels(graph: tt.Graph,
                                     node: tt.GraphNode) -> dict[str, list[str]]:
    """ Gets assigned tag IDS and labels for a given node

    :param (Graph) graph: Graph to traverse for tags
    :param (Node) node: Node ID to obtain tags from
    :return (dict): Dictionary containing sorted list of assigned tag IDs and tag
        labels in the format:
        {
            'assigned_tag_ids': [<tag_ids>, ...],
            'tags': [<tag_labels>, ...],
        }

        Tag ID and tag label list will be empty if none are assigned.
        assigned_tag_ids are sorted based on their according label.

    """
    _node = node if is_node(node) else graph.get_node(node)
    tags = list(sorted(graph.traverse(_node).in_('tag').node('tag'),
                       key=lambda t: t.label))
    return {
        'assigned_tag_ids': [t.id for t in tags],
        'tags': [t.label for t in tags],
    }


def get_assigned_tags_labels_batch(
        graph: tt.Graph, node_type: tt.GraphNodeType,
        node_ids: list[tt.GraphNodeId]
) -> dict[tt.GraphNodeId, list[str]]:
    """ Batch-optimized version that allows to retrieve all tags labels assigned to
    specific nodes of the same type.

    Returned dictionary will support indexing by node IDs for which there are no
    tags found returning empty list for these cases.
    """
    tag_rel_map = _get_assigned_tags_batch(graph, node_type, node_ids)
    tags_map = {
        tag.id: tag.label for tag in graph.get_nodes(
            'tag',
            id=m.is_in(set(chain.from_iterable(six.itervalues(tag_rel_map))))
        )
    }

    result = defaultdict(lambda: [])  # type: dict[tt.GraphNodeId, list[str]]
    result.update({
        node_id: sorted([tags_map[tag_id] for tag_id in tag_rel_map[node_id]])
        for node_id in tag_rel_map})
    return result


def get_assigned_tags_ids_and_labels_batch(
        graph: tt.Graph, node_type: tt.GraphNodeType,
        node_ids: list[tt.GraphNodeId]
) -> dict[tt.GraphNodeId, dict[str, list[str]]]:
    """ Batch-optimized version that allows to retrieve all tags IDS and labels
        assigned to specific nodes of the same type. If some node ID does not
        correspond to a specified node type it will not be included into the result
        map.

        :param (Graph) graph: Graph to traverse
        :param (str) node_type: Node type to obtain tags from
        :param (iterable) node_ids: Node IDs to obtain tag IDs from
        :return (dict): A defaultdict that will return sorted tags in the format:

        {
            node_id: {
                'assigned_tag_ids': [<tag_ids>, ...],
                'tags': [<tag_labels>, ...],
            },
        }

        The response will generate node IDs and empty lists for nodes
        that do not have tags to make it easier for downstream API to avoid
        complexity of sorting, defensive dictionary traversal, etc.

        assigned_tag_ids are sorted based on their according label.
    """

    # node_id -> [tag_ids]
    tag_rel_map = _get_assigned_tags_batch(graph, node_type, node_ids)
    # tag_id -> tag_label
    tags_map = {
        tag.id: tag.label for tag in graph.get_nodes(
            'tag',
            id=m.is_in(set(chain.from_iterable(six.itervalues(tag_rel_map))))
        )
    }
    # Using defaultdict reduces burden of downstream code from having to be
    # defensive on dict key lookups.
    resp = defaultdict(
        lambda: dict(assigned_tag_ids=[], tags=[])
    )  # type: dict[tt.GraphNodeId, dict[str, list[str]]]
    resp.update({
        node_id: {
            'tags': sorted([tags_map[t] for t in tag_ids]),
            'assigned_tag_ids': sorted(tag_ids, key=lambda i: tags_map[i]),
        }
        for node_id, tag_ids in six.iteritems(tag_rel_map)
    })
    return resp


def get_assigned_tags_ids_batch(
        graph: tt.Graph, node_type: tt.GraphNodeType,
        node_ids: list[tt.GraphNodeId]
) -> dict[tt.GraphNodeId, list[tt.GraphNodeId]]:
    """Batch-optimized version that allows to retrieve all tag labels
    assigned to specific nodes of the same type. If some node ID does
    not correspond to a specified node type, it will not be included
    into the result map.

    :param graph: An instance of the graph.
    :param node_type: A type of the node IDs correspond to.
    :type node_type: str
    :param node_ids: IDs for the node to resolve tags for.
    :type node_ids: iterable
    :return: a map of node_id -> list_of_tag_ids
    """
    return dict(_get_assigned_tags_batch(graph, node_type, node_ids))


def _get_assigned_tags_batch(
        graph: tt.Graph, node_type: tt.GraphNodeType,
        node_ids: list[tt.GraphNodeId]
) -> dict[tt.GraphNodeId, list[tt.GraphNodeId]]:
    nodes = graph.get_nodes(node_type, id=m.is_in(set(node_ids)))

    tag_rel_map = defaultdict(list)
    for tag_rel in graph.traverse(nodes).in_('tag'):
        tag_rel_map[tag_rel.target_id].append(tag_rel.source_id)

    return tag_rel_map


def get_or_add_tags_by_labels(graph: tt.Graph,
                              labels: list[str]) -> list[tt.GraphNodeId]:
    """Get tags from graph for each specified label

    Create new tag if there is no tag in graph with specified lowercased label.
    """
    tag_ids = []
    for label in labels:
        lowercased = label.lower()
        tag = graph.get_nodes('tag', lowercased=lowercased).one_or_none
        if not tag:
            tag = graph.add_node('tag', label=label, lowercased=lowercased)
        tag_ids.append(tag.id)

    return tag_ids


def validate_ambiguous_labels_for_new_tag(
        tag_sets: dict[str, list[str]],
        check_tag_existence_fn: t.Callable[[str], bool],
        errors: ValidationErrorBuilder
) -> None:
    """Validate that labels for new tags have the same case

    Args:
        tag_sets: dict which keys are paths for validation error addressing
                  and values are lists of tag labels.
        check_tag_existence_fn: function that receives lowercased label
                                and returns bool
        errors: an instance of ValidationErrorBuilder
    """
    lowercased_to_original = defaultdict(set)
    label_to_tag_path = defaultdict(list)
    for path, tag_set in six.iteritems(tag_sets):
        for tag_idx, tag_label in enumerate(tag_set):
            lowercased_to_original[tag_label.lower()].add(tag_label)
            label_to_tag_path[tag_label].append('%s.%s' % (path, tag_idx))

    for lowercased, original_labels in six.iteritems(lowercased_to_original):
        if len(original_labels) > 1:
            if not check_tag_existence_fn(lowercased):
                for original_label in original_labels:
                    for path in label_to_tag_path[original_label]:
                        errors.add_error(path, 'Ambiguous label for a new tag')


def validate_ambiguous_labels_for_new_tag_in_graph(
        graph: tt.Graph,
        tag_sets: dict[str, list[str]],
        errors: ValidationErrorBuilder
) -> None:
    """Validate that labels for new tags in graph have the same case

    Args:
        tag_sets: dict which keys are paths for validation error addressing
                  and values are lists of tag labels.
        errors: an instance of ValidationErrorBuilder
    """
    validate_ambiguous_labels_for_new_tag(
        tag_sets,
        lambda lowercased: bool(graph.get_nodes('tag', lowercased=lowercased).first),
        errors)


def collect_rack_type_tag_assignments(
        rack_type: _MAGIC.lollipop_type[
            'aos.scotch.schemas.rack_type.RACK_TYPE_SCHEMA'
        ]
) -> dict[str, list[str]]:
    """Collect paths of systems and links with at least one tag assigned

    Return map of paths (relative to rack type) to list of assigned tag labels
    """
    result = {}
    for system_type in ['leafs', 'generic_systems', 'access_switches']:
        for system_idx, system in enumerate(rack_type.get(system_type, [])):
            if system.get('tags'):
                result['%s.%s.tags' % (system_type, system_idx)] = system['tags']
            if system.get('links'):
                for link_idx, link in enumerate(system['links']):
                    if link.get('tags'):
                        result['%s.%s.links.%s.tags' % (
                            system_type, system_idx, link_idx
                        )] = link.get('tags', [])
    return result


def get_or_generate_rack_type_tag_definitions(
        rack_type: _MAGIC.lollipop_type[
            'aos.scotch.schemas.rack_type.RACK_TYPE_SCHEMA'
        ],
        global_tags: t.Optional[list[dict[str, str]]] = None
) -> dict[str, list[dict[str, str]]]:
    """Get definition object and its path for each tag used in rack type

    Return dict which values are tags defined in rack_type['tags'] plus generated
    definitions for tags assigned just by label (without definition in
    rack_type['tags']). Keys of returned dict are relative to rack type
    paths where tag is defined. In a case of referencing tag by just label,
    path point to rack type system/link this tag assigned to.
    In a case of referencing global catalog tag by label, its definition
    will be returned with path pointing to rack type system/link this
    tag assigned to.
    """
    lowercased_to_rack_type_tag = {}
    lowercased_to_global_tag = {}

    path_to_tag = defaultdict(list)
    tag_definitions = rack_type.get('tags', [])
    for tag_definition in tag_definitions:
        lowercased_to_rack_type_tag[tag_definition['label'].lower()] = tag_definition
        path_to_tag['tags'].append(tag_definition)

    for global_tag in global_tags or []:
        label = global_tag['label']
        lowercased = label.lower()
        lowercased_to_global_tag[lowercased] = global_tag

    for path, tag_set in six.iteritems(collect_rack_type_tag_assignments(rack_type)):
        for label in tag_set:
            lowercased = label.lower()
            if lowercased not in lowercased_to_rack_type_tag:
                if lowercased in lowercased_to_global_tag:
                    path_to_tag[path].append(lowercased_to_global_tag[lowercased])
                else:
                    path_to_tag[path].append({'label': label})

    return path_to_tag


class ConflictingTagSpellingError(Exception):
    pass


def format_list(array: t.Iterable) -> str:
    return ', '.join(f'"{item}"' for item in array)


def validate_tag_uniqueness(all_graph_tags: dict[str, tt.GraphNode],
                            request: list[str]) -> None:
    parsed_request = defaultdict(list)
    for tag_label in request:
        parsed_request[tag_label.lower()].append(tag_label)

    conflicting_request_tags = set()
    for tags in parsed_request.values():
        if len(tags) > 1:
            conflicting_request_tags.update(tags)

    if conflicting_request_tags:
        flattened_list = format_list(
            sorted(conflicting_request_tags, key=lambda x: (x.lower(), x))
        )
        raise ConflictingTagSpellingError(
            f'The following tags are not unique in the request: '
            f'{flattened_list}.'
        )

    request_forms = []
    graph_forms = []
    for tag_label in sorted(request, key=lambda x: (x.lower(), x)):
        existing_tag = all_graph_tags.get(tag_label.lower())
        if existing_tag is not None and tag_label != existing_tag.label:
            request_forms.append(tag_label)
            graph_forms.append(existing_tag.label)

    if request_forms:
        assert len(request_forms) == len(graph_forms)
        raise ConflictingTagSpellingError(
            f'The tags [{format_list(request_forms)}] are '
            f'already present in the blueprint with another '
            f'spelling: [{format_list(graph_forms)}].')


def reset_tags_for_node(graph: tt.Graph, node_id: tt.GraphNodeId,
                        tag_labels: list[str]) -> None:
    all_graph_tags = {
        tag.lowercased: tag
        for tag in graph.get_nodes('tag')
    }

    validate_tag_uniqueness(all_graph_tags, tag_labels)

    assigned_tags = {
        path['tag'].label: path['rel']
        for path in graph_query.iterate(
                graph,
                graph_query.node(id=node_id)
                .in_('tag', name='rel')
                .node('tag', name='tag')
        )
    }

    tag_labels = list(set(tag_labels))
    for tag_label, rel in assigned_tags.items():
        if tag_label not in tag_labels:
            graph.del_relationship(rel)

    for tag_label in tag_labels:
        if tag_label not in assigned_tags:
            existing_tag = all_graph_tags.get(tag_label.lower())
            tag_id = (
                graph.add_node(
                    'tag', label=tag_label, lowercased=tag_label.lower()
                ).id
                if existing_tag is None
                else existing_tag.id
            )
            graph.add_relationship('tag', tag_id, node_id)
