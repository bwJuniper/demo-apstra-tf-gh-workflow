# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=invalid-name

from __future__ import annotations

import typing as t

from aos.sdk.client import (
    Api,
    Client as BaseClient,
    RestResource,
    RestResources,
    api,
)

if t.TYPE_CHECKING:
    import typing_extensions as te
    from aos.sdk import typing as tt

    aos: t.Any
    _MAGIC: t.Any


def _get_facade_method_schema(name: str, value: str) -> str:
    '''Helper for type annotations generation.

    :param name: name of the facade method
    :param value: attribute of the facade method which holds schema

    :return: reference to arg schema in form of a magic annotation
    '''
    return f'''
    _MAGIC.facade_method_schema[
        aos.reference_design.extension.tags.facade.Facade,
        {name},
        {value}
    ]
    '''


class Client(BaseClient):

    @api('/blueprints')
    class blueprints(Api):

        @api('/{blueprint_id}')
        class resource(Api):

            @api('/tags')
            class tags(
                RestResources,
                list__=_get_facade_method_schema('get_tags', 'result'),
                create__data=_get_facade_method_schema('create_tag', 'arg'),
                create__=_get_facade_method_schema('create_tag', 'result'),
                __create='''
                    Create a new tag.

                    :param data: configuration of the new tag
                ''',
                __list='''
                    Get all tags.
                ''',
            ):

                def create_batch(
                        self,
                        tags: _MAGIC.lollipop_type[
                            'aos.scotch.schemas.tag.POST_TAG_LIST_SCHEMA'
                        ],
                        **kwargs: te.Unpack[RestResource.TWriteKwargs]
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.extension.tags.facade.Facade',
                    'create_tags',
                    'result'
                ]:
                    """ Create multiple tags.

                    Creates only those tags which don't exist and always succeeds.

                    :param tags: configuration of the new tags
                    """
                    data = {
                        'tags': tags,
                    }
                    return self._request(
                        '-batch-create',
                        method='POST',
                        data=data,
                        **kwargs
                    )

                @api('/{tag_id}')
                class resource(
                    RestResource,
                    get__=_get_facade_method_schema('get_tag', 'result'),
                    update__data=_get_facade_method_schema('update_tag', 'arg'),
                    __get='''
                        Get tag.

                        Gets a tag by ID.
                    ''',
                    __update='''
                        Update tag.

                        Updates an existing tag.

                        :param data: new configuration of the tag
                    ''',
                    __delete='''
                        Delete tag.

                        Deletes an existing tag.
                    ''',
                ):
                    pass

            def tagging(
                    self,
                    nodes: list[tt.GraphNodeId],
                    add: t.Optional[list[str]] = None,
                    remove: t.Optional[list[str]] = None,
                    **kw: te.Unpack[RestResource.TWriteKwargs]
            ) -> tt.JSON:
                """ Tagging / Untagging nodes.

                Batch API for tagging and untagging graph nodes.

                :param nodes: List of graph node IDs to be used to tag and untag
                    tag nodes specified in ``add`` and ``remove`` properties
                    respectively.
                :param add: List of tag labels to be added to ``nodes``
                :param remove: List of tag labels to be removed from ``nodes``
                """
                data = {
                    'nodes': nodes,
                    'add': add,
                    'remove': remove,
                }

                return self._request(
                    url='/tagging',
                    method='POST',
                    data=data,
                    **kw
                )
