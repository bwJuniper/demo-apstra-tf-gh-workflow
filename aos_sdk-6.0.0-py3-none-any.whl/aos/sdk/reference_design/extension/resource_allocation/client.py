# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula
# pylint: disable=invalid-name,line-too-long

from __future__ import annotations

import typing as t

from aos.sdk.client import Client as _Client, Api, api, RestResource

if t.TYPE_CHECKING:
    import typing_extensions as te

    from aos.sdk import typing as tt


class Client(_Client):
    @api('/blueprints')
    class blueprints(Api):
        @api('/{blueprint_id}')
        class resource(Api):
            @api('/resource_groups')
            class resource_groups(Api):
                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.extension.resource_allocation.facade.Facade',
                    'get_resource_groups',
                    'result']:
                    """ Get resource groups.

                    Returns resource allocation groups for a given blueprint.
                    """
                    return self._request(**kwargs)['items']

                def patch(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.extension.resource_allocation.facade.Facade',
                        'patch_resource_groups',
                        'arg'
                    ],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> tt.JSON:
                    """ Patch resource groups.

                    Creates or updates resource allocation groups with resource
                    type, group name and pool IDs.

                    Example:
                    .. code-block:: python
                           data = {
                               'resource_groups': [{
                                   'resource_type': 'asn',
                                   'group_name': 'spine_asns',
                                   'pool_ids':  ['pool1', 'pool2']
                               }, {
                                   'resource_type': 'asn',
                                   'group_name': 'leaf_asns',
                                   'pool_ids':  ['pool1', 'pool2']
                               }, ... ]
                           }

                    :param data: new configuration for resource groups
                    """
                    return self._request(method='PATCH', data=data, **kwargs)

                @api('/{resource_type}')
                class resource_type(Api):
                    @api('/{group_name}')
                    class group(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResource.TReadKwargs]
                        ) -> _MAGIC.facade_method_schema[
                            'aos.reference_design.extension.resource_allocation.facade.Facade',
                            'get_resource_group',
                            'result']:
                            """ Get resource group by resource_type and group_name.

                            Get resource allocation group with given name and
                            resource type.
                            """
                            return self._request(**kwargs)

                        def update(
                            self,
                            data: _MAGIC.facade_method_schema[
                                'aos.reference_design.extension.resource_allocation.facade.Facade',
                                'update_resource_group',
                                'arg'
                            ],
                            **kwargs: te.Unpack[RestResource.TWriteKwargs],
                        ) -> tt.JSON:
                            """ Update resource allocation group with given name and
                            resource type.

                            :param data: new configuration of the resource group
                            """
                            return self._request(method='PUT', data=data, **kwargs)
