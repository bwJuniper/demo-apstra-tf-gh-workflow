# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import annotations

import typing as t

from aos.sdk.graph import is_node
from aos.sdk.graph import query as q

if t.TYPE_CHECKING:
    import aos.sdk.typing as tt


def get_top_level_policies(blueprint: tt.Graph,
                           policy: tt.GraphNode) -> list[tt.GraphNode | None]:
    policy_id = policy.id if is_node(policy) else policy
    used = set()
    top_level_policy_ids = []

    def dfs(node_id):
        used.add(node_id)

        node_has_parent = False
        for sub_relation in ['ep_subpolicy', 'ep_first_subpolicy',
                             'ep_second_subpolicy']:

            for parent_rel in blueprint.get_relationships(sub_relation,
                                                          target_id=node_id):
                node_has_parent = True
                parent_id = parent_rel.source_id
                if parent_id in used:
                    continue
                dfs(parent_id)

        if not node_has_parent:
            top_level_policy_ids.append(node_id)

    dfs(policy_id)

    return [blueprint.get_node(top_level_policy_id)
            for top_level_policy_id in top_level_policy_ids]


def is_top_level_policy(graph: tt.Graph, endpoint_policy: tt.GraphNode) -> bool:
    # make sure the policy is not a subpolicy of another policy
    parent_query = (
        q.match(
            q.node('ep_endpoint_policy', id=endpoint_policy.id, name='policy'),
            q.optional(
                q.node(name='policy')
                .in_(type=q.is_in([
                    'ep_subpolicy',
                    'ep_first_subpolicy',
                    'ep_second_subpolicy'
                ]))
                .node('ep_endpoint_policy', name='parent')
            ),
        )
    )
    paths = list(q.iterate(graph, parent_query))
    return len(paths) == 1 and paths[0]['parent'] is None
