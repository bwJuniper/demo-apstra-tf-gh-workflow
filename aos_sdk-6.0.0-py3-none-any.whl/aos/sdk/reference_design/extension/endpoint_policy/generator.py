# Copyright 2024-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""Utility methods to generate Connectivity Template payloads accepted by API"""

from __future__ import annotations

from collections import defaultdict
import typing as t

from aos.sdk.generator_helpers import gen_id

POLICY_NOT_FOUND_INITIAL = 'Policy with id "{}" was not found in initial payload'
POLICY_NOT_FOUND_EXTENSION = 'Policy with id "{}" was not found in extension payload'
POLICY_DOES_NOT_SUPPORT_EXTENSION = ('Policy with type "{}" does not support '
                                     'extension')


def wrap_policies(
    payload: list[_MAGIC.facade_method_schema['aos.reference_design.extension.endpoint_policy.facade.Facade', 'obj_policy_import', 'arg']] |  # pylint: disable=line-too-long
             _MAGIC.facade_method_schema['aos.reference_design.extension.endpoint_policy.facade.Facade', 'obj_policy_import', 'arg']  # pylint: disable=line-too-long
) -> dict[str, _MAGIC.facade_method_schema[
    'aos.reference_design.extension.endpoint_policy.facade.Facade',
    'obj_policy_import', 'arg']]:
    """Wraps payload in API-acceptable format for '/obj-policy-import'

    Note that this function should be called before issuing calls to
    obj_policy_import

    Functions in this module create payloads for CT generation. These payloads are
    not accepted by API, because obj_policy_import schema requires policies to be
    in a dict under "policies" keyword. This function does exactly it.

    Other functions do not return payloads with "policies" keyword for ease of
    data manipulation.
    """
    if 'policies' in payload:
        return payload
    return {'policies': payload}


def create_self_sufficient_ct_with_one_primitive(
    policy_type_name: str,
    policy_label: str,
    policy_attributes: dict[str, t.Any]
) -> list[_MAGIC.lollipop_type[('aos.reference_design.extension.endpoint_policy'
                                '.endpoint_policies.POLICY_IMPORT_EXPORT_SCHEMA')]]:
    """ Create payload of connectivity template with one primitive displayed in UI

    High level helper which returns a payload sufficient to create a connectivity
    template with one primitive, which will be correctly displayed in the UI.
    Should be wrapped with wrap_policies.
    """
    batch_ct, primitive_ct, pipeline_ct = create_ct_with_one_primitive(
        policy_type_name, policy_label, policy_attributes)
    batch_ct.update(dict(visible=True, user_data='{"isSausage":true}'))

    return [batch_ct, primitive_ct, pipeline_ct]


def create_ct_with_one_primitive(
    policy_type_name: str,
    policy_label: str,
    policy_attributes: dict[str, t.Any]
) -> list[_MAGIC.lollipop_type[('aos.reference_design.extension.endpoint_policy'
                                '.endpoint_policies.POLICY_IMPORT_EXPORT_SCHEMA')]]:
    """ Create payload of connectivity template with one primitive

    High level helper which returns a payload sufficient to create a connectivity
    template with one primitive, which will be correctly displayed in the UI.
    Should be wrapped with wrap_policies.
    """
    primitive_ct = create_ct(policy_type_name, policy_label, policy_attributes)
    pipeline_ct = create_pipeline_ct(policy_label+' (pipeline)', primitive_ct['id'])
    batch_ct = create_batch_ct(policy_label, [pipeline_ct['id']])
    return [batch_ct, primitive_ct, pipeline_ct]


def create_ct(
    policy_type_name: str,
    policy_label: str,
    policy_attributes: dict[str, t.Any],
    visible: bool = False,
    **overrides
) -> _MAGIC.lollipop_type[('aos.reference_design.extension.endpoint_policy'
                           '.endpoint_policies.POLICY_IMPORT_EXPORT_SCHEMA')]:
    """ Create payload of connectivity template

    Low level helper which returns a payload for a single policy which can later be
    combined with other polices to build a complex Connectivity Template
    """
    policy_id = gen_id()
    payload =  {
        'id': policy_id,
        'label': policy_label,
        'description': '',
        'policy_type_name': policy_type_name,
        'attributes': policy_attributes,
        'visible': visible,  # should be True for top-level batch
        'tags': []
    }
    payload.update(**overrides)
    return payload


def create_batch_ct(
    policy_label: str, subpolicy_ids: list[str] | str, **overrides
) -> _MAGIC.lollipop_type[('aos.reference_design.extension.endpoint_policy'
                           '.endpoint_policies.POLICY_IMPORT_EXPORT_SCHEMA')]:
    """ Create payload of batch policy

    Low level helper which returns a payload for a batch policy which can later be
    combined with other polices to build a complex Connectivity Template.
    Batch policy can have arbitrary number of subpolicies, which considered to be
    independent.
    """
    if not isinstance(subpolicy_ids, list):
        subpolicy_ids = [subpolicy_ids]
    return create_ct(
        'batch', policy_label, {'subpolicies': subpolicy_ids}, **overrides)


# Note that "resolver" attribute is always None as it's ignored by the framework
def create_pipeline_ct(
    policy_label: str,
    first_subpolicy_id: str,
    second_subpolicy_id: t.Optional[str] = None,
    **overrides
) -> _MAGIC.lollipop_type[('aos.reference_design.extension.endpoint_policy'
                           '.endpoint_policies.POLICY_IMPORT_EXPORT_SCHEMA')]:
    """ Create payload of pipeline policy

    Low level helper which returns a payload for a pipeline policy which can later be
    combined with other polices to build a complex Connectivity Template.
    Pipeline policy can have two subpolicies, where the input of second subpolicy
    is the output of the first subpolicy
    """
    return create_ct(
        'pipeline', policy_label,
        {'first_subpolicy': first_subpolicy_id,
         'second_subpolicy': second_subpolicy_id,
         'resolver': None},
        **overrides)


def extend_policy(
    initial_payload: list[_MAGIC.lollipop_type['aos.reference_design.extension.endpoint_policy.endpoint_policies.POLICY_IMPORT_EXPORT_SCHEMA']],  # pylint: disable=line-too-long
    policy_id: str,
    extension_policy_id: str,
    extension: list[_MAGIC.lollipop_type['aos.reference_design.extension.endpoint_policy.endpoint_policies.POLICY_IMPORT_EXPORT_SCHEMA']],  # pylint: disable=line-too-long
    policy_type: str = 'batch'
) -> _MAGIC.lollipop_type[('aos.reference_design.extension.endpoint_policy'
                           '.endpoint_policies.POLICY_IMPORT_EXPORT_SCHEMA')]:
    """ Extend policies payload with more policies

    This a low level function which allows building arbitrary connectivity templates.

    This function takes two independent connectivity template payloads and unites
    them depending on the type of the policy being extended.
    Payloads are represented as plain lists of policies, to merge them into one
    bigger policy these lists should be united. But in order to create a holistic
    CT, extension policy should be added either as independent subpolicy for batch
    or as second subpolicy for pipeline.
    Thus, policy_id represents the policy from initial_payload being extended (should
    be either batch or pipeline), extension_policy_id represents the root-policy of
    template from extension that is being added.
    """
    # Extended policy most likely to be at the end of the payload
    for idx in range(len(initial_payload) - 1, -1, -1):
        ct = initial_payload[idx]
        if ct['id'] == policy_id and ct['policy_type_name'] == policy_type:
            extended_policy = ct
            break
    else:
        raise RuntimeError(POLICY_NOT_FOUND_INITIAL.format(policy_id))

    for ct in extension:
        if ct['id'] == extension_policy_id:
            break
    else:
        raise RuntimeError(POLICY_NOT_FOUND_EXTENSION.format(extension_policy_id))

    if policy_type == 'batch':
        extended_policy['attributes']['subpolicies'].append(extension_policy_id)
    elif policy_type == 'pipeline':
        extended_policy['attributes']['second_subpolicy'] = extension_policy_id
    else:
        raise ValueError(POLICY_DOES_NOT_SUPPORT_EXTENSION.format(policy_type))

    return initial_payload + extension


def extend_batch(
    initial_payload: list[_MAGIC.lollipop_type['aos.reference_design.extension.endpoint_policy.endpoint_policies.POLICY_IMPORT_EXPORT_SCHEMA']],  # pylint: disable=line-too-long
    batch_id: str,
    subpolicy_id: str,
    extension: list[_MAGIC.lollipop_type['aos.reference_design.extension.endpoint_policy.endpoint_policies.POLICY_IMPORT_EXPORT_SCHEMA']]  # pylint: disable=line-too-long
) -> list[_MAGIC.lollipop_type[('aos.reference_design.extension.endpoint_policy'
                                '.endpoint_policies.POLICY_IMPORT_EXPORT_SCHEMA')]]:
    """ Extend batch policy """
    return extend_policy(initial_payload, batch_id, subpolicy_id, extension)


def extend_pipeline(
    initial_payload: list[_MAGIC.lollipop_type['aos.reference_design.extension.endpoint_policy.endpoint_policies.POLICY_IMPORT_EXPORT_SCHEMA']],  # pylint: disable=line-too-long,
    pipeline_id: str,
    second_policy_id: str,
    extension: list[_MAGIC.lollipop_type['aos.reference_design.extension.endpoint_policy.endpoint_policies.POLICY_IMPORT_EXPORT_SCHEMA']],  # pylint: disable=line-too-long
) -> list[_MAGIC.lollipop_type[('aos.reference_design.extension.endpoint_policy'
                                '.endpoint_policies.POLICY_IMPORT_EXPORT_SCHEMA')]]:
    """ Extend pipeline policy """
    return extend_policy(initial_payload, pipeline_id, second_policy_id, extension,
                         policy_type='pipeline')


def create_ct_with_hierarchy(
    policies: list[dict[str, t.Any]],
    ct_name: str
) -> list[_MAGIC.lollipop_type[('aos.reference_design.extension.endpoint_policy'
                                '.endpoint_policies.POLICY_IMPORT_EXPORT_SCHEMA')]]:
    r""" Create payload of connectivity template with arbitrary structure

    Middle level helper which returns a payload sufficient to create a connectivity
    template, which will be correctly displayed in the UI.
    Should be wrapped with wrap_policies.

    Each policy from policies should follow the following format:
    {
        'policy_type_name': <str>,
        'label': <str>,
        'attributes': <dict[str, Any]>,
        'subpolicies': <list[<another_policy>, ...]>
    }

    Example for two_stage_l3clos design:
    [
      {
        'policy_type_name': 'AttachLogicalLink',
        'label': 'l3_logical_link_sz1 (1)',
        'attributes': {'vlan_id': 0, 'security_zone': <sz1_id>},
        'subpolicies': [
          {
            'policy_type_name': 'AttachBgpOverSubinterfacesOrSvi',
            'label': 'bgp_to_generic_sz1 (2)',
            'attributes': {},
            'subpolicies': [
              {
                'policy_type_name': 'AttachExistingRoutingPolicy',
                'label': 'routing_policy_to_generic_sz1 (3)',
                'attributes': {}
              },
            ]
          },
          {
            'policy_type_name': 'AttachStaticRoute',
            'label': 'static_route_to_generic_sz1 (4)',
            'attributes': {}
          },
        ]
      },
      {
        'policy_type_name': 'AttachLogicalLink',
        'label': 'l3_logical_link_sz2 (5)',
        'attributes': {'vlan_id': 0, 'security_zone': <sz2_id>},
        'subpolicies': [
          {
            'policy_type_name': 'AttachBgpOverSubinterfacesOrSvi',
            'label': 'bgp_to_generic_sz2 (6)',
            'attributes': {}
          },
        ]
      },
    ]

    After adding extra policies the snippet above will be modified to the
    following tree:
                              batch1
                            /        \
                   pipeline1          pipeline2
                     /   \              /   \
                  (1)   batch2       (5)   batch3
                       /      \              |
               pipeline3    pipeline4     pipeline5
               /    \           |            |
            (2)     batch4     (4)          (6)
                     |
                  pipeline6
                    |
                   (3)

    """

    # For ease of implementation add a fake node
    top_level_policy = {'subpolicies': policies,
                        'policy_type_name': None, 'label': '', 'attributes': None}
    # ... then get rid of its policies, only real subpolicies left
    payload = _create_policy_with_subpolicies(top_level_policy)[3:]
    # ... with a modification for first batch which is a top-most batch in result
    # to correctly display it in UI
    payload[0].update(dict(visible=True, user_data='{"isSausage":true}',
                           label=ct_name))
    return payload


# NOTE: there is a room for performance improvements due to list copying around
#  extend_batch and extend_pipeline.
def _create_policy_with_subpolicies(
    policy: dict[str, t.Any]
) -> list[_MAGIC.lollipop_type[('aos.reference_design.extension.endpoint_policy'
                                '.endpoint_policies.POLICY_IMPORT_EXPORT_SCHEMA')]]:
    """ Recursively creates policy payloads
    """
    batch, primitive, pipeline = create_ct_with_one_primitive(
        policy['policy_type_name'], policy['label'], policy['attributes'])
    payload = [batch, primitive, pipeline]

    shared_sub_batch_id = None
    for subpolicy in policy.get('subpolicies', []):
        sub_payload = _create_policy_with_subpolicies(subpolicy)
        if shared_sub_batch_id:
            # Batch CTs for all subpolicies except the first one are dropped
            payload = extend_batch(payload, shared_sub_batch_id,
                                   sub_payload[2]['id'], sub_payload[1:])
        else:
            shared_sub_batch_id = sub_payload[0]['id']
            payload = extend_pipeline(payload, pipeline['id'], shared_sub_batch_id,
                                      sub_payload)

    return payload


def create_apply_unapply_ct(
    policy_id: str,
    app_point_apply_ids: list[str] | str | None,
    app_point_unapply_ids: list[str] | str | None,
) -> _MAGIC.facade_method_schema[
    'aos.reference_design.extension.endpoint_policy.Facade',
    'apply_endpoint_policy', 'arg']:
    """ Create payload for '/application-points', 'PATCH'

    Generates a payload which can be used to apply or unapply application points
    for a selected policy.
    """
    if not isinstance(app_point_apply_ids, list):
        app_point_apply_ids = [app_point_apply_ids] if app_point_apply_ids else []

    if not isinstance(app_point_unapply_ids, list):
        app_point_unapply_ids = ([app_point_unapply_ids] if app_point_unapply_ids
                                 else [])

    application_points = [
        {'node_id': node_id, 'used': True} for node_id in app_point_apply_ids]
    application_points.extend(
        {'node_id': node_id, 'used': False} for node_id in app_point_unapply_ids)

    return {
        'policy_id': policy_id,
        'application_points': application_points
    }


def create_apply_ct(
    policy_id: str,
    app_point_ids: list[str]
) -> _MAGIC.facade_method_schema[
    'aos.reference_design.extension.endpoint_policy.Facade',
    'apply_endpoint_policy', 'arg']:
    """ Create payload for '/application-points', 'PATCH'

    Generates a payload which can be directly used to apply a policy to specific
    application points.
    """
    return create_apply_unapply_ct(policy_id, app_point_ids, [])


def create_unapply_ct(
    policy_id: str,
    app_point_ids: list[str]
) -> _MAGIC.facade_method_schema[
    'aos.reference_design.extension.endpoint_policy.Facade',
    'apply_endpoint_policy', 'arg']:
    """ Create payload for '/application-points', 'PATCH'

    Generates a payload which can be directly used to unapply a policy from specific
    application points.
    """
    return create_apply_unapply_ct(policy_id, [], app_point_ids)


class ApplyUnapplyDTO(t.TypedDict):
    policy_id: str
    apply: list[str]
    unapply: list[str]


def gen_apply_unapply(
    policy_id: str,
    app_point_ids_apply: t.Optional[list[str]] = None,
    app_point_ids_unapply: t.Optional[list[str]] = None
) -> ApplyUnapplyDTO:
    """ Helper function to make argument list for create_batch_apply_unapply_ct """
    return {'policy_id': policy_id,
            'apply': app_point_ids_apply or [],
            'unapply': app_point_ids_unapply or []}


def create_batch_apply_unapply_ct(
    *policies_with_app_points: ApplyUnapplyDTO
) -> _MAGIC.facade_method_schema[
    'aos.reference_design.extension.endpoint_policy.Facade',
    'batch_apply_endpoint_policy', 'arg']:
    """ Create payload for /obj-policy-batch-apply, 'PATCH'

    Generates a payload which can be directly used to apply a number of policies to
    or unapply a number of policies from application points.

    Can be called as following:
    payload = g.create_batch_apply_unapply_ct(
        g.gen_apply_unapply('p1_id', ['app1'], ['app2']),
        g.gen_apply_unapply('p2_id', ['app3', 'appX'], [])
    )
    """

    app_point_to_policies = defaultdict(list)
    for policy_with_app_points in policies_with_app_points:
        policy_id = policy_with_app_points['policy_id']

        for app_point in policy_with_app_points['apply']:
            app_point_to_policies[app_point].append({'policy': policy_id,
                                                     'used': True})

        for app_point in policy_with_app_points['unapply']:
            app_point_to_policies[app_point].append({'policy': policy_id,
                                                     'used': False})

    return {'application_points': [
        {'id': app_point, 'policies': policies}
        for app_point, policies in app_point_to_policies.items()
    ]}
