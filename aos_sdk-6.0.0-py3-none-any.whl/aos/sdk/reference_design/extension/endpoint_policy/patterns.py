# Copyright 2021-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import annotations

import typing as t

from aos.sdk.graph.query import node

if t.TYPE_CHECKING:
    from aos.sdk.graph.query.dsl import PathQueryBuilder


def nested_application_points(
        endpoint_policy: str = 'endpoint_policy',
        application_point: str = 'application_point'
) -> PathQueryBuilder:
    return (node('ep_endpoint_policy', name=endpoint_policy)
            .in_('ep_nested')
            .node('ep_application_instance')
            .out('ep_affected_by')
            .node('ep_group')
            .in_('ep_member_of')
            .node('interface', name=application_point))
