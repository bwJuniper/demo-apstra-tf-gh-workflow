# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=invalid-name, line-too-long
# mypy: disable-error-code="name-defined"

from __future__ import annotations

import typing as t

from aos.sdk.client import (
    Api,
    Client as _Client,
    RestResources,
    api
)

if t.TYPE_CHECKING:
    import typing_extensions as te

    from aos.sdk.client import RestResource

    _MAGIC: t.Any
    aos: t.Any


def _get_facade_method_schema(name: str, value: str) -> str:
    """Helper function for type annotations generation.

    :param name: name of the facade method
    :param value: attribute of the facade method which holds schema

    :return: reference to arg schema in form of a magic annotation
    """
    return f'''
    _MAGIC.facade_method_schema[
        'aos.reference_design.extension.endpoint_policy.facade.Facade',
        {name},
        {value}
    ]
    '''


class Client(_Client):
    @api('/blueprints')
    class blueprints(Api):
        @api('/{blueprint_id}')
        class resource(Api):

            @api('/policy-types')
            class policy_types(Api):
                def get(
                    self, **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type[
                    'aos.scotch.schemas.endpoint_policies.POLICY_TYPES_SCHEMA',
                ]:
                    """Get available connectivity templates types.

                    List of connectivity template types valid for the given
                    blueprint.
                    """
                    return self._request(**kwargs)['policy_types']

            @api('/endpoint-policies')
            class endpoint_policies(
                RestResources,
                create__data=_get_facade_method_schema('create_endpoint_policy',
                                                       'arg'),
                create__=_get_facade_method_schema('create_endpoint_policy',
                                                   'result'),
            ):
                def list(
                    self, **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> list[_MAGIC.lollipop_type[
                    'aos.scotch.schemas.endpoint_policies.ENDPOINT_POLICY_FACADE_SCHEMA',
                ]]:
                    """Get connectivity templates.

                    List of all connectivity templates in the given blueprint.
                    """
                    return self._request(**kwargs)['endpoint_policies']

                @api('/{policy_id}')
                class resource(Api):
                    def get(
                        self, **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> _MAGIC.lollipop_type[
                        'aos.scotch.schemas.endpoint_policies.ENDPOINT_POLICY_FACADE_SCHEMA'
                    ]:
                        """Get connectivity template.

                        Get connectivity template from blueprint by ID.
                        """
                        response = self._request(method='GET',**kwargs)
                        if response is None:
                            return None
                        return response['endpoint_policy']

                    def patch(
                        self,
                        data: _MAGIC.facade_method_schema[
                            'aos.reference_design.extension.endpoint_policy.facade.Facade',
                            'mutate_endpoint_policy',
                            'arg'
                        ],
                        **kwargs: te.Unpack[RestResource.TWriteKwargs]
                    ) -> _MAGIC.facade_method_schema[
                        'aos.reference_design.extension.endpoint_policy.facade.Facade',
                        'mutate_endpoint_policy',
                        'result'
                    ]:
                        """Update connectivity template.

                        :param data: Update existing connectivity template with
                            provided attributes.
                        """
                        return self._request(method='PATCH', data=data, **kwargs)

                    def delete(self, **kwargs: te.Unpack[RestResource.TReadKwargs]):
                        """Delete connectivity template.

                        Delete existing connectivity template by provided ID.
                        """
                        return self._request(method='DELETE', **kwargs)

                    @api('/application-points')
                    class application_points(Api):
                        def get(
                            self, **kwargs: te.Unpack[RestResource.TReadKwargs]
                        ) -> _MAGIC.facade_method_schema[
                            'aos.reference_design.extension.endpoint_policy.facade.Facade',
                            'get_application_points',
                            'result'
                        ]:
                            """Get application endpoints.

                            Return possible application endpoints for given
                            connectivity template.
                            """
                            return self._request(**kwargs)

                        def patch(
                            self,
                            data: _MAGIC.facade_method_schema[
                                'aos.reference_design.extension.endpoint_policy.facade.Facade',
                                'apply_endpoint_policy',
                                'arg'
                            ],
                            **kwargs: te.Unpack[RestResource.TWriteKwargs]
                        ) -> _MAGIC.facade_method_schema[
                            'aos.reference_design.extension.endpoint_policy.facade.Facade',
                            'apply_endpoint_policy',
                            'result'
                        ]:
                            """Update application endpoints.

                            :param data: Update assignments of application endpoints
                                for given connectivity template.
                            """
                            return self._request(method='PATCH', data=data, **kwargs)

            @api('/obj-policy-application-points')
            class obj_policy_application_points(Api):
                def post(
                    self,
                    # Dynamic schema depending on the output of
                    # /obj-policy-locations-schema
                    data: t.Optional[dict[str, str | int]] = None,
                    **kwargs: te.Unpack[RestResource.TWriteKwargs]
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.extension.endpoint_policy.facade.Facade',
                    'obj_policy_application_points',
                    'result'
                ]:
                    """Return possible application endpoints for connectivity
                    templates.

                    Usage example:

                    .. code-block:: python

                        api = Client(...)
                        bp_id = 'id_of_blueprint'
                        api.blueprints[bp_id].obj_policy_application_points.post(
                            data={'policy': policy_id,
                                  'type': 'config',
                                  'rack': 'rack1',
                                  'leaf': 'L[a-z]*4',
                                  'rack_tags': 'main-racks',
                                  'leaf_tags': 'tag2'})

                    :param data: Parameters for filtering. For detailed information
                        about supported filter keys see REST API Explorer.
                    """
                    if data is None:
                        data = {}
                    return self._request(method='POST', data=data, **kwargs)

                # DEPRECATED in 4.2.1.
                def get(self, **kwargs):
                    """Deprecated.
                    """
                    return self._request(**kwargs)

            @api('/obj-policy-batch-apply')
            class obj_policy_batch_apply(Api):
                def patch(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.extension.endpoint_policy.facade.Facade',
                        'batch_apply_endpoint_policy',
                        'arg'
                    ],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs]
                ):
                    """Update assignment of connectivity templates.

                    :param data: Update assignments of application endpoints. Should
                        be jsonable (i.e. correctly treated by
                        :py:func:`json.encode`)
                    """
                    return self._request(method='PATCH', data=data, **kwargs)

            @api('/obj-policy-locations-schema')
            class obj_policy_locations_schema(Api):
                def get(
                    self, **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type[
                    'aos.scotch.schemas.endpoint_policies.OBJ_POLICY_LOCATIONS_SCHEMA'
                ]:
                    """Return list of node types available for application endpoints
                    tree.
                    """
                    return self._request(**kwargs)['locations']

            @api('/obj-policy-export')
            class obj_policy_export(Api):
                def list(
                    self, **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> list[_MAGIC.lollipop_type[
                    'aos.reference_design.extension.endpoint_policy.endpoint_policies.POLICY_IMPORT_EXPORT_SCHEMA'
                ]]:
                    """Export connectivity templates.

                    Return JSON representation of all connectivity templates in the
                    blueprint.
                    """
                    return self._request(method='GET', **kwargs)['policies']

                @api('/{policy_id}')
                class resource(Api):
                    def get(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> list[_MAGIC.lollipop_type[
                        'aos.reference_design.extension.endpoint_policy.endpoint_policies.POLICY_IMPORT_EXPORT_SCHEMA'
                    ]]:
                        """Export given connectivity template.

                        Return JSON representation of given connectivity template.
                        """
                        return self._request(method='GET', **kwargs)['policies']

            @api('/obj-policy-import')
            class obj_policy_import(Api):
                def put(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.extension.endpoint_policy.facade.Facade',
                        'obj_policy_import',
                        'arg'
                    ],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs]
                ):
                    """Import connectivity templates.

                    :param data: Connectivity templates to be imported.
                    """
                    return self._request(method='PUT', data=data, **kwargs)

            @api('/obj-policy-batch-delete')
            class obj_policy_batch_delete(Api):
                def post(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.extension.endpoint_policy.facade.Facade',
                        'batch_delete_endpoint_policy',
                        'arg'
                    ],
                    **kwargs: te.Union[RestResource.TWriteKwargs]
                ):
                    """Delete batch of connectivity templates.

                    Accepts only IDs of top level (parent) nodes of connectivity
                    templates. All provided connectivity templates should be
                    unassigned before deletion.
                    """
                    return self._request(method='POST', data=data, **kwargs)

            @api('/obj-policy-search')
            class obj_policy_search(Api):
                def post(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.extension.endpoint_policy.facade.Facade',
                        'obj_policy_search',
                        'arg'
                    ],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs]
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.extension.endpoint_policy.facade.Facade',
                    'obj_policy_search',
                    'result'
                ]:
                    """Search connectivity templates.

                    :param data: Search filter for connectivity templates.
                    """
                    return self._request(method='POST', data=data, **kwargs)
