# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import annotations

from .client import Client
from aos.sdk.reference_design.extension import (
    configlets,
    endpoint_policy,
    preferences,
    resource_allocation,
    tags,
    tenants,
    virtual_infra,
)

NAME = 'two_stage_l3clos'
EXTENSIONS = [
    configlets,
    endpoint_policy,
    preferences,
    resource_allocation,
    tags,
    tenants,
    virtual_infra,
]
