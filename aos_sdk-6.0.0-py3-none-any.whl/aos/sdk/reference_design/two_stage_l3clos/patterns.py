
# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""Central place to house common patterns in current reference design graph"""

from aos.sdk.graph import is_node
from aos.sdk.graph.query import optional
from aos.sdk.reference_design.two_stage_l3clos.search import node_id
from aos.sdk.builder import match
from aos.sdk.graph.query import node
import aos.sdk.graph.query as m


def systems_in_rack(rack, system='device', system_type='system',
                    system_filters=None):
    rack_id = node_id(rack)
    system_filters = system_filters or {}

    return (node('rack', id=rack_id)
            .in_('part_of_rack')
            .node(system_type, name=system, **system_filters))


def leafs_in_rack(rack, system='device'):
    return systems_in_rack(rack, system, system_filters={'role': 'leaf'})


def access_switches_in_rack(rack, system='device'):
    return systems_in_rack(rack, system, system_filters={'role': 'access'})


def leafs_and_access_switches_in_rack(rack, system='device'):
    return systems_in_rack(rack, system,
                           system_filters={'role': m.is_in(['leaf', 'access'])})


def redundancy_groups_in_rack(rack, redundancy_group='redundancy_group'):
    return systems_in_rack(rack, redundancy_group, 'redundancy_group')


def rails_in_rack(rack='rack', rail='rail', rack_filters=None, rail_filters=None):
    rack_filters = rack_filters or {}
    rail_filters = rail_filters or {}
    return (
        node('rack', name=rack, **rack_filters)
        .in_('part_of_rack')
        .node('rail', name=rail, **rail_filters)
    )


def switches_in_rail(switch='switch', rail='rail', switch_filters=None,
                     rail_filters=None):
    switch_filters = switch_filters or {}
    rail_filters = rail_filters or {}
    return (
        node('rail', name=rail, **rail_filters)
        .out('hosted_by')
        .node('system', name=switch, **switch_filters)
    )


def links_in_rail(rail='rail', link='link', rail_filters=None, link_filters=None):
    rail_filters = rail_filters or {}
    link_filters = link_filters or {}
    return (
        node('rail', name=rail, **rail_filters)
        .out('composed_of')
        .node('link', name=link, **link_filters)
    )


def servers_in_rack(rack, system='device'):
    # This query is often used as part of complex queries.
    # The servers in the rack may be reached via different leafs or access switches.
    # At the same time it is crucial to have deterministic behaviour,
    # so auxiliary nodes like 'leaf', 'access', 'interface' and 'link'
    # are intentionally not named in the query, as we are interested
    # in rack and server nodes only. This is also a reason why systems_in_rack is not
    # used
    if is_node(rack):
        rack = rack.id
    return match(node('rack', id=rack)
                 .in_('part_of_rack')
                 .node('system', role=m.is_in(['leaf', 'access']))
                 .out('hosted_interfaces')
                 .node('interface', if_type=m.is_in(['ip', 'ethernet']))
                 .out('link')
                 .node('link')
                 .in_('link')
                 .node('interface')
                 .in_('hosted_interfaces')
                 .node('system', name=system, system_type='server', external=False)
                ).distinct([system])


def external_generic_connected_to_leafs_in_rack(rack, switch='switch',
                                                external_generic='external_generic'):
    if is_node(rack):
        rack = rack.id

    return match(leafs_in_rack(rack, system=switch),
                 linked_systems(
                     system1=switch, system2=external_generic,
                     system2_filters={'role': 'generic', 'external': True}
                 )).distinct([switch, external_generic])


def systems_with_logical_device(system='device', logical_device='logical_device',
                                system_filters=None, ld_filters=None):
    system_filters = system_filters or {}
    ld_filters = ld_filters or {}
    return (
        node('system', name=system, **system_filters)
        .out('logical_device')
        .node('logical_device', name=logical_device, **ld_filters)
    )


def linked_systems(system1=None, system2=None,
                   interface1='interface1', interface2='interface2',
                   link=None, system1_type='system',
                   link_filters=None,
                   interface1_filters=None, interface2_filters=None,
                   system1_filters=None, system2_filters=None,
                   system2_type='system'):

    system1_filters = system1_filters or {}
    system2_filters = system2_filters or {}
    interface1_filters = interface1_filters or {}
    interface2_filters = interface2_filters or {}
    link_filters = link_filters or {}
    return (
        node(type=system1_type, name=system1, **system1_filters)
        .out('hosted_interfaces', name='system1_hosted_interfaces')
        .node('interface', name=interface1, **interface1_filters)
        .out('link')
        .node('link', name=link, **link_filters)
        .in_('link')
        .node('interface', name=interface2, **interface2_filters)
        .in_('hosted_interfaces', name='system2_hosted_interfaces')
        .node(type=system2_type, name=system2, **system2_filters)
        .ensure_different(interface1, interface2)
    )


def switch_systems(switch_id=None, switch_role='leaf', switch='leaf',
                   system_role='generic', system='server', system_type='server',
                   link='link'):
    """Return match query for linked systems to switches."""
    return match(
        connected_physical_interfaces(device=switch, remote_device=system,
                                      link=link),
        node('system', name=switch, role=switch_role, id=switch_id),
        node('system', name=system, system_type=system_type, role=system_role)
    )


def switch_systems_with_optional_rails(
        switch_id=None, switch_role='leaf', switch='leaf', system_role='generic',
        system='server', system_type='server', rail='rail', link='link'):
    """ Return match query for linked systems to switches. Also contains Rail nodes
    if exist."""
    return match(
        switch_systems(
            switch_id=switch_id, switch_role=switch_role, switch=switch,
            system_role=system_role, system=system, system_type=system_type,
            link=link,
        ),
        optional(links_in_rail(rail=rail, link=link)),
    )


def system_interface_map_and_device_profile(system='system',
                                            interface_map='interface_map',
                                            interface_map_rel=None,
                                            device_profile='device_profile',
                                            device_profile_rel=None,
                                            system_filters=None):
    system_filters = system_filters or {}
    return (
        node('system', name=system, **system_filters)
        .out('interface_map', name=interface_map_rel)
        .node('interface_map', name=interface_map)
        .out('device_profile', name=device_profile_rel)
        .node('device_profile', name=device_profile)
    )


def connected_physical_interfaces(device='device', remote_device='remote_device',
                                  if_types=None, link='link', **filters):
    '''Return path query for linked physical interfaces. Named nodes are device,
    interface, link, remote_interface and remote_device.
    '''
    if_types = if_types if if_types else ['ip', 'ethernet']
    return match(
        linked_systems(system1=device, system2=remote_device,
                       interface1='interface', interface2='remote_interface',
                       link=link, **filters),
        node('interface', name='interface', if_type=m.is_in(if_types)),
    )


def connected_interfaces(link='link', intf1='intf1', intf2='intf2',
                         link_filters=None):
    link_filters = link_filters or {}
    return (
        node('interface', name=intf1)
        .out('link')
        .node('link', name=link, **link_filters)
        .in_('link')
        .node('interface', name=intf2)
        .ensure_different(intf1, intf2)
    )


def connected_port_channels_with_aggregate_link(
        device='device', remote_device='remote_device',
        aggregate_link='aggregate_link',
        system_filters=None, remote_system_filters=None,
        link_filters=None):
    '''Return path query for port-channels with an aggregate link between them.
    Named nodes are device, interface (representing port-channel),
    aggregate_link (overridable), remote_interface and remote_device.
    '''
    system_filters = system_filters or {}
    remote_system_filters = remote_system_filters or {}
    link_filters = link_filters or {}
    return (
        node('system', name=device, **system_filters)
        .out('hosted_interfaces')
        .node('interface', name='interface', if_type='port_channel')
        .out('link')
        .node('link', name=aggregate_link, link_type='aggregate_link',
              **link_filters)
        .in_('link')
        .node('interface', name='remote_interface', if_type='port_channel')
        .in_('hosted_interfaces')
        .node('system', name=remote_device, **remote_system_filters)
        .ensure_different('interface', 'remote_interface')
    )


def system_with_interface_via_sz_instance(system='system', interface='interface'):
    return (
        node('system', name=system)
        .out('hosted_sz_instances')
        .node('sz_instance')
        .out('member_interfaces')
        .node('interface', name=interface)
    )


def connected_subinterfaces(interface='interface',
                            remote_interface='remote_interface',
                            link='link',
                            link_filters=None):
    link_filters = link_filters or {}
    return (
        node('interface', if_type='subinterface', name=interface)
        .out('link')
        .node('link', name=link, **link_filters)
        .in_('link')
        .node('interface', if_type='subinterface', name=remote_interface)
        .ensure_different(interface, remote_interface)
    )


def links_with_subinterfaces_with_systems(system='system', interface='interface',
                                          subinterface='subinterface', link='link',
                                          system_filters=None, link_filters=None):
    system_filters = system_filters or {}
    link_filters = link_filters or {}
    return (
        node('link', name=link, **link_filters)
        .in_('link')
        .node('interface', if_type='subinterface', name=subinterface)
        .in_('composed_of')
        .node('interface', if_type=m.is_in(
            ['ethernet', 'port_channel']), name=interface)
        .in_('hosted_interfaces')
        .node('system', name=system, **system_filters)
    )


def protocol_session_configuration(protocol_session='protocol_session',
                                   protocol_endpoint='protocol_endpoint',
                                   peer='peer',
                                   session_filters=None,
                                   endpoint_filters=None,
                                   peer_filters=None):
    session_filters = session_filters or {}
    endpoint_filters = endpoint_filters or {}
    peer_filters = peer_filters or {}
    return (
        node('protocol_session', name=protocol_session, **session_filters)
        .out('instantiates')
        .node('protocol_endpoint', name=protocol_endpoint, **endpoint_filters)
        .out('layered_over')
        .node(name=peer, **peer_filters)
    )


def protocol_session_configuration_with_system(peer_type_or_if_type=None,
                                               device='device'):
    assert peer_type_or_if_type in ['ip_endpoint', 'subinterface', 'loopback', 'svi']

    if peer_type_or_if_type == 'ip_endpoint':
        return (protocol_session_configuration(peer_filters={'type': 'ip_endpoint'})
                .in_('hosted_ip_endpoints')
                .node('system', name=device))
    else:
        protocol_sessions_pattern = protocol_session_configuration(
            peer_filters={'type': 'interface', 'if_type': peer_type_or_if_type})
        if peer_type_or_if_type == 'subinterface':
            return (protocol_sessions_pattern
                    .in_('composed_of')
                    .node('interface')
                    .in_('hosted_interfaces')
                    .node('system', name=device))
        elif peer_type_or_if_type == 'loopback':
            return (protocol_sessions_pattern
                    .in_('hosted_interfaces')
                    .node('system', name=device))
        elif peer_type_or_if_type == 'svi':
            return (protocol_sessions_pattern
                    .out('member_of_vn_instance')
                    .node('vn_instance', name='vn_instance')
                    .in_('hosted_vn_instances')
                    .node('system', name=device))


def linked_protocol_session_peers(
        protocol_session='protocol_session',
        protocol_endpoint='protocol_endpoint',
        remote_protocol_endpoint='remote_protocol_endpoint',
        peer='peer',
        remote_peer='remote_peer',
        session_filters=None,
        endpoint_filters=None,
        remote_endpoint_filters=None,
        peer_filters=None,
        remote_peer_filters=None):
    session_filters = session_filters or {}
    endpoint_filters = endpoint_filters or {}
    remote_endpoint_filters = remote_endpoint_filters or {}
    peer_filters = peer_filters or {}
    remote_peer_filters = remote_peer_filters or {}

    default_peer_types_matcher = m.is_in([
        'interface', 'ip_endpoint'
    ])

    peer_filters.setdefault('type', default_peer_types_matcher)
    remote_peer_filters.setdefault('type', default_peer_types_matcher)

    return (
        node(name=peer, **peer_filters)
        .in_('layered_over')
        .node('protocol_endpoint', name=protocol_endpoint, **endpoint_filters)
        .in_('instantiates')
        .node('protocol_session', name=protocol_session, **session_filters)
        .out('instantiates')
        .node('protocol_endpoint', name=remote_protocol_endpoint,
              **remote_endpoint_filters)
        .out('layered_over')
        .node(name=remote_peer, **remote_peer_filters)
        .ensure_different(peer, remote_peer)
    )


def interface_to_protocol_endpoint(interface='interface',
                                   protocol_endpoint='protocol_endpoint'):
    return (
        node('interface', name=interface)
        .in_('layered_over')
        .node('protocol_endpoint', name=protocol_endpoint)
    )


def protocol_endpoint_with_routing_policy(protocol_endpoint='protocol_endpoint',
                                          routing_policy='routing_policy',
                                          routing_policy_filters=None):
    routing_policy_filters = routing_policy_filters or {}
    return (
        node('protocol_endpoint', name=protocol_endpoint)
        .out('policy')
        .node('routing_policy', name=routing_policy, **routing_policy_filters)
    )


def connected_subinterface_and_svi(subinterface='subinterface',
                                   interface='interface',
                                   svi='svi',
                                   virtual_network='vn',
                                   vn_endpoint='vn_endpoint',
                                   vn_instance='vn_instance',
                                   subinterface_filters=None,
                                   interface_filters=None,
                                   svi_filters=None,
                                   vn_filters=None,
                                   vn_endpoint_filters=None,
                                   vn_instance_filters=None):
    subinterface_filters = subinterface_filters or {}
    interface_filters = interface_filters or {}
    svi_filters = svi_filters or {}
    vn_filters = vn_filters or {}
    vn_endpoint_filters = vn_endpoint_filters or {}
    vn_instance_filters = vn_instance_filters or {}
    return (
        node('interface', name=subinterface, **subinterface_filters)
        .in_('composed_of')
        .node('interface', name=interface, **interface_filters)
        .out('hosted_vn_endpoints')
        .node('vn_endpoint', name=vn_endpoint, **vn_endpoint_filters)
        .in_('member_endpoints')
        .node('virtual_network', name=virtual_network, **vn_filters)
        .out('instantiated_by')
        .node('vn_instance', name=vn_instance, **vn_instance_filters)
        .out('member_interfaces')
        .node('interface', name=svi, **svi_filters)
    )


def connected_port_channels(
        device='device', remote_device='remote_device',
        named_child_link='child_link', device_filters=None,
        remote_device_filters=None, named_child_link_filters=None,
        interface_filters=None, remote_interface_filters=None):
    """Return path query for port-channels with a connected child interface.
    Named nodes are device, interface (representing port-channel), child_interface,
    child_link (overridable), remote_child_interface, remote_interface
    (port-channel) and remote_device.
    """
    # For port-channels we always use child interface link to reach neighbor as that
    # must always exist. Port-channel on member leaf itself has no link in case of
    # mlag connection
    device_filters = device_filters or {}
    remote_device_filters = remote_device_filters or {}
    named_child_link_filters = named_child_link_filters or {}
    interface_filters = interface_filters or {}
    remote_interface_filters = remote_interface_filters or {}
    return (
        node('system', name=device, **device_filters)
        .out('hosted_interfaces')
        .node('interface', name='interface', if_type='port_channel',
              **interface_filters)
        .out('composed_of')
        .node('interface', name='child_interface')
        .out('link')
        .node('link', name=named_child_link, **named_child_link_filters)
        .in_('link')
        .node('interface', name='remote_child_interface')
        .where(lambda child_interface, remote_child_interface: \
               child_interface != remote_child_interface)
        .in_('composed_of')
        .node('interface', name='remote_interface', if_type='port_channel',
              **remote_interface_filters)
        .in_('hosted_interfaces')
        .node('system', name=remote_device, **remote_device_filters)
    )


def connected_port_channels_with_optional_redundancy_group(
        device='device', remote_device='remote_device',
        named_child_link='child_link', named_link='link'):
    """Return path query for port-channels and faced redundancy group if it exists.

    Named nodes are device, interface (representing port-channel), child_interface,
    child_link, remote_child_interface, remote_interface (port-channel),
    remote_device and redundancy_group with its link and port channel
    interface if it exists.
    """
    return match(
        connected_port_channels(device, remote_device, named_child_link),
        optional(node('interface', name='interface')
                 .out('link')
                 .node('link', name=named_link)
                 .in_('link')
                 .node('interface', name='remote_rg_interface')
                 .in_('hosted_interfaces')
                 .node('redundancy_group', name='redundancy_group'))
    )


def spine_superspine_links(spine='spine', superspine='superspine',
                           spine_intf='spine_interface',
                           superspine_intf='superspine_interface',
                           link='link', spine_filters=None,
                           superspine_filters=None):
    system1_filters = {'role': 'spine'}
    system2_filters = {'role': 'superspine'}
    if spine_filters:
        system1_filters.update(spine_filters)
    if superspine_filters:
        system2_filters.update(superspine_filters)

    return linked_systems(
        system1=spine,
        system1_filters=system1_filters,
        interface1=spine_intf,
        link=link,
        interface2=superspine_intf,
        system2=superspine,
        system2_filters=system2_filters
    )


def border_systems_for_security_zones(security_zone_id=None,
                                      security_zone_name='sz',
                                      system_name='system',
                                      system_roles=('leaf',)):
    # type: (str, str, str, Tuple[str]) -> Tuple[MultiPathQueryBuilder]
    """Return query for border systems for specified routing zones."""
    return (
        match(
            sz_to_iface,
            interface_to_protocol_endpoint(interface='iface'),
        ) for sz_to_iface in (
            security_zones_to_system_loopbacks(
                security_zone=security_zone_name,
                security_zone_filters=dict(id=security_zone_id),
                system=system_name,
                system_filters=dict(role=m.is_in(system_roles)),
                loopback='iface',
            ),
            match(*security_zones_to_subinterfaces(
                security_zone=security_zone_name,
                sz_filters=dict(id=security_zone_id),
                system=system_name,
                system_filters=dict(role=m.is_in(system_roles)),
                subinterface='iface',
            )),
            security_zones_to_svis(
                security_zone=security_zone_name,
                sz_filters=dict(id=security_zone_id),
                system=system_name,
                system_filters=dict(role=m.is_in(system_roles)),
                svi='iface',
            ),
        )
    )


def rg_port_channels(device='device', interface='interface',
                     rg_interface='rg_interface',
                     redundancy_group='redundancy_group',
                     device_filters=None, interface_filters=None,
                     rg_interface_filters=None, redundancy_group_filters=None,
                     rg_type=None):
    """Return path query for port channels on systems that are MLAG enabled. These
    port-channels extend across leafs and sometimes known as "virtual port channels".
    Named nodes are device, interface, rg_interface, redundancy_group."""
    device_filters = device_filters or {}
    interface_filters = interface_filters or {}
    rg_interface_filters = rg_interface_filters or {}
    redundancy_group_filters = redundancy_group_filters or {}

    if rg_type == 'mlag':
        rg_interface_filters.update({'po_control_protocol': 'mlag'})
        redundancy_group_filters.update({'rg_type': 'mlag'})
    elif rg_type == 'esi':
        rg_interface_filters.update({'po_control_protocol': 'evpn'})
        redundancy_group_filters.update({'rg_type': 'esi'})

    return (
        node('system', name=device, **device_filters)
        .out('hosted_interfaces')
        .node('interface', name=interface, if_type='port_channel',
              **interface_filters)
        .in_('composed_of')
        .node('interface', name=rg_interface, if_type='port_channel',
              **rg_interface_filters)
        .in_('hosted_interfaces')
        .node('redundancy_group', name=redundancy_group, **redundancy_group_filters)
        .out('composed_of_systems')
        .node('system', name=device, **device_filters)
    )


def rg_port_channel_with_link(device='device', peer_device='peer_device',
                              rg_interface='rg_interface',
                              peer_interface='peer_interface',
                              aggregate_link='aggregate_link',
                              peer_device_type='system', device_filters=None,
                              peer_device_filters=None,
                              rg_type=None):
    device_filters = device_filters or {}
    peer_device_filters = peer_device_filters or {}
    return match(
        rg_port_channels(device=device, device_filters=device_filters,
                         rg_interface=rg_interface, rg_type=rg_type),
        node('interface', name=rg_interface)
        .out('link')
        .node('link', name=aggregate_link, link_type='aggregate_link')
        .in_('link')
        .node('interface', name=peer_interface, if_type='port_channel')
        .ensure_different(rg_interface, peer_interface)
        .in_('hosted_interfaces')
        .node(peer_device_type, name=peer_device, **peer_device_filters)
    )


def rg_port_channel_with_link_reversed(device='device', peer_device='peer_device',
                                       aggregate_link='aggregate_link',
                                       peer_system_filters=None,
                                       peer_interface_filters=None,
                                       link_filters=None):
    # Same as rg_port_channel_with_link(..), but is more efficient when a peer from
    # the other side of mlag pair is known
    peer_system_filters = peer_system_filters or {}
    peer_interface_filters = peer_interface_filters or {}
    link_filters = link_filters or {}
    return match(
        node('system', name=peer_device, **peer_system_filters)
        .out('hosted_interfaces')
        .node('interface', name='peer_interface', if_type='port_channel',
              **peer_interface_filters)
        .out('link')
        .node('link', name=aggregate_link, link_type='aggregate_link',
              **link_filters)
        .in_('link')
        .node('interface', name='rg_interface')
        .ensure_different('rg_interface', 'peer_interface'),
        rg_port_channels(device=device)
    )


def access_switch_port_channels_to_redundancy_group(
        device='device', remote_name='redundancy_group',
        aggregate_link='aggregate_link', system_filters=None):
    system_filters = system_filters or {}
    return (
        node('system', role='access', name=device, **system_filters)
        .out('hosted_interfaces')
        .node('interface', name='interface', if_type='port_channel')
        .out('link')
        .node('link', name=aggregate_link, link_type='aggregate_link')
        .in_('link')
        .node('interface', name='remote_interface', if_type='port_channel')
        .in_('hosted_interfaces')
        .node('redundancy_group', name=remote_name)
    )


def access_switch_esi_port_channels_to_redundancy_group(
        device='device', remote_name='redundancy_group',
        aggregate_link='aggregate_link', system_filters=None):
    system_filters = system_filters or {}
    return (
        node('system', role='access', name=device, **system_filters)
        .out('hosted_interfaces')
        .node('interface', if_type='port_channel')
        .in_('composed_of')
        .node('interface', name='interface', if_type='port_channel')
        .out('link')
        .node('link', name=aggregate_link, link_type='aggregate_link',
              role='leaf_pair_access_pair')
        .in_('link')
        .node('interface', name='remote_interface', if_type='port_channel')
        .in_('hosted_interfaces')
        .node('redundancy_group', name=remote_name)
        .ensure_different('interface', 'remote_interface')
    )


def rg_port_channels_with_server_link(device='device', peer_device='peer_device',
                                      aggregate_link='aggregate_link'):
    return match(
        rg_port_channel_with_link(device=device, peer_device=peer_device,
                                  aggregate_link=aggregate_link),
        node('system', name=peer_device, system_type='server')
    )


def rg_port_channels_with_server_or_access_switch_link(
        device='device', peer_device='peer_device', aggregate_link='aggregate_link',
        rg_type=None):
    return match(
        rg_port_channel_with_link(device=device, peer_device=peer_device,
                                  aggregate_link=aggregate_link, rg_type=rg_type),
        node('system', name=peer_device, role=m.is_in(['generic', 'access']))
    )


def two_redundancy_group_port_channels_with_link(
        device='device', peer_device='peer_device', aggregate_link='aggregate_link'):
    return match(
        rg_port_channel_with_link(device=device,
                                  peer_device_type='redundancy_group',
                                  peer_device='peer_redundancy_group',
                                  aggregate_link=aggregate_link,
                                  device_filters={'role': 'leaf'}),
        rg_port_channels(peer_device, 'peer_device_interface',
                         'peer_interface',
                         'peer_redundancy_group',
                         device_filters={'role': 'access'}),
    )


def ethernet_aggregate_links(ethernet_link='ethernet_link', ethernet_link_id=None,
                             aggregate_link='aggregate_link',
                             aggregate_link_id=None):
    return match(
        node('link', name=ethernet_link, link_type='ethernet', id=ethernet_link_id)
        .in_('link')
        .node('interface')
        .in_('composed_of')
        .node('interface', if_type='port_channel')
        .out('link')
        .node('link', name=aggregate_link, link_type='aggregate_link',
              id=aggregate_link_id)
    ).distinct([ethernet_link])


def ethernet_aggregate_links_leaf_access_esi(
        ethernet_link='ethernet_link', ethernet_link_id=None,
        aggregate_link='aggregate_link', aggregate_link_id=None
):
    return match(
        node('link', name=ethernet_link, link_type='ethernet', id=ethernet_link_id)
        .in_('link')
        .node('interface')
        .in_('composed_of')
        .node('interface', if_type='port_channel')
        .in_('composed_of')
        .node('interface', if_type='port_channel', po_control_protocol='evpn')
        .out('link')
        .node('link', name=aggregate_link, link_type='aggregate_link',
              role='leaf_pair_access_pair',
              id=aggregate_link_id)
    ).distinct([ethernet_link])


def paired_systems_in_mlag_domain(
        system1='system1', system2='system2', redundancy_group='redundancy_group',
        domain='domain'):
    '''Return path query for mlag connected devices, query includes domain
    and redundancy group'''
    return (
        node('system', name=system1)
        .out('part_of_redundancy_group')
        .node('redundancy_group', name=redundancy_group)
        .in_('composed_of_redundancy_group')
        .node('domain', name=domain, domain_type='mlag', domain_id=m.not_none())
        .out('composed_of_redundancy_group')
        .node(name=redundancy_group)
        .out('composed_of_systems')
        .node('system', name=system2)
        .ensure_different(system1, system2)
    )


def systems_within_redundancy_group(local_device='local_device',
                                    peer_device='peer_device',
                                    redundancy_group='redundancy_group',
                                    rg_type=None,
                                    role=None):
    role = role or m.is_in(['leaf', 'access'])
    rg_type = rg_type or m.is_in(['mlag', 'esi'])
    return (
        node('system', name=local_device, role=role)
        .out('part_of_redundancy_group')
        .node('redundancy_group', name=redundancy_group, rg_type=rg_type)
        .out('composed_of_systems')
        .node('system', name=peer_device, role=role)
        .ensure_different(local_device, peer_device)
    )


def systems_with_asn_and_loopback_interface(
        system='device', domain='domain', loopback='loopback', system_filters=None):
    """Base line for 'systems_with_asn_and_loopback_<ip-version>' methods.

    Returns
      Path query for systems that are part of autonomous system domain with
      an assigned asn and a loopback interface.
      Named nodes are domain, device, loopback.
    """

    system_filters = system_filters or {}

    return (
        node('domain', name=domain, domain_type='autonomous_system',
             domain_id=m.not_none())
        .out('composed_of_systems')
        .node('system', name=system, **system_filters)
        .out('hosted_interfaces')
        .node('interface', name=loopback, if_type='loopback')
    )

def systems_with_asn_and_loopback_ipv4(
        system='device', domain='domain', loopback='loopback', system_filters=None):
    """
    Returns:
      Graph query for systems that are part of autonomous system domain with
      an assigned asn and a loopback interface with an assigned ipv4 address.
      Named nodes are domain, device, loopback.
    """
    return match(
        systems_with_asn_and_loopback_interface(
            system, domain, loopback, system_filters),
        node('interface', name=loopback, ipv4_addr=m.not_none())
    )

def systems_with_asn_and_loopback_ipv6(
        system='device', domain='domain', loopback='loopback', system_filters=None):
    """
    Returns:
      Graph query for systems that are part of autonomous system domain with
      an assigned asn and a loopback interface with an assigned ipv6 address.
      Named nodes are domain, device, loopback.
    """
    return match(
        systems_with_asn_and_loopback_interface(
            system, domain, loopback, system_filters),
        node('interface', name=loopback, ipv6_addr=m.not_none())
    )

def systems_with_vtep_interface(device='device', interface='interface',
                                if_type='logical_vtep'):
    '''Return path query for systems that have at-least one vtep interface'''
    return (
        node('system', name=device)
        .out('hosted_interfaces')
        .node('interface', name=interface, if_type=if_type,
              ipv4_addr=m.not_none())
    )


def vn_with_instantiating_systems(
        device='device', virtual_network='virtual_network'):
    '''Return path query for virtual networks and the systems it is hosted on.'''
    return (
        node('virtual_network', name=virtual_network)
        .out('instantiated_by')
        .node('vn_instance', name='vn_instance')
        .in_('hosted_vn_instances')
        .node('system', name=device, role=m.is_in(['leaf', 'access']))
    )


def systems_with_loopback_interface(device='device', loopback='loopback',
                                    system_filters=None):
    """
    Returns:
      Path query for systems that have a loopback interface.
      Named nodes are device, loopback.
    """
    system_filters = system_filters or {}
    return (
        node('system', name=device, **system_filters)
        .out('hosted_interfaces')
        .node('interface', name=loopback, if_type='loopback')
    )


def systems_with_subinterface(system='system', subinterface='subinterface',
                              interface=None, system_filters=None):
    """
    Returns:
      Path query for systems that have a subinterface.
      Named nodes are system, subinterface.
    """
    system_filters = system_filters or {}
    return (
        node('system', name=system, **system_filters)
        .out('hosted_interfaces')
        .node('interface', name=interface,
              if_type=m.is_in(('ethernet', 'port_channel')))
        .out('composed_of')
        .node('interface', name=subinterface, if_type='subinterface')
    )


def logical_link_between_systems(device='device', remote_device='remote_device',
                                 subinterface='subinterface',
                                 remote_subinterface='remote_subinterface',
                                 interface=None,
                                 remote_interface=None,
                                 system1_filters=None,
                                 system2_filters=None,
                                 link_filters=None):
    system1_filters = system1_filters or {}
    system2_filters = system2_filters or {}

    return match(
        systems_with_subinterface(device,
                                  subinterface=subinterface,
                                  interface=interface,
                                  system_filters=system1_filters),
        connected_subinterfaces(subinterface, remote_subinterface,
                                link_filters=link_filters),
        systems_with_subinterface(remote_device,
                                  subinterface=remote_subinterface,
                                  interface=remote_interface,
                                  system_filters=system2_filters)
    )


def systems_with_svi(system='system', svi='svi',
                     vn_instance='vn_instance', system_filters=None):
    """
    Returns:
      Path query for systems that have a svi.
      Named nodes are system, session_interface.
    """
    system_filters = system_filters or {}
    return (
        node('system', name=system, **system_filters)
        .out('hosted_vn_instances')
        .node('vn_instance', name=vn_instance)
        .out('member_interfaces')
        .node('interface', name=svi, if_type='svi')
    )


def systems_with_loopback_ipv4(device='device', loopback='loopback'):
    """
    Returns:
      Path query for systems that have a loopback interface with
      an assigned address. Named nodes are device, loopback.
    """
    return match(
        systems_with_loopback_interface(device=device, loopback=loopback),
        node('interface', name=loopback, ipv4_addr=m.not_none())
    )

def systems_with_loopback_ipv6(device='device', loopback='loopback'):
    """
    Returns:
      Path query for systems that have a loopback interface with
      an assigned ipv6 address. Named nodes are device, loopback.
    """
    return match(
        systems_with_loopback_interface(device=device, loopback=loopback),
        node('interface', name=loopback, ipv6_addr=m.not_none())
    )

def systems_with_domain(system='device', domain='domain', system_filters=None):
    '''Return path query for systems that are part of autonomous system domain.
    Named nodes are domain, device'''

    system_filters = system_filters or {}

    return (
        node('domain', name=domain, domain_type='autonomous_system')
        .out('composed_of_systems')
        .node('system', name=system, **system_filters)
    )

def systems_with_asn(system='device', domain='domain', system_filters=None,
                     allow_empty_domain_id=False):
    '''Return path query for systems that are part of autonomous system domain with
    an assigned asn.
    Named nodes are domain, device'''

    if allow_empty_domain_id:
        domain_filters = {}
    else:
        domain_filters = {'domain_id': m.not_none()}
    return match(
        systems_with_domain(system, domain, system_filters),
        node('domain', name=domain, **domain_filters)
    )

def connected_bgp_peers(system_filters=None, remote_system_filters=None):
    """ Get connected BGP Peers between interface IPs

    Returns:
      List of path queries for systems with assigned ASN numbers,
      physically connected through interfaces.
      Named nodes are device, interface, link, remote_interface, remote_device,
      domain, remote_domain.
    """
    return [
        connected_physical_interfaces(),
        # Using additional node() queries instead of lambdas for better performance
        node(name='interface', protocols='ebgp'),
        node(name='remote_interface', protocols='ebgp'),
        systems_with_asn(system_filters=system_filters),
        systems_with_asn('remote_device', 'remote_domain',
                         system_filters=remote_system_filters)
    ]

def bgp_peers_using_v4_link_ips(system_filters=None, remote_system_filters=None):
    """
    Returns:
      List of path queries for systems with assigned ASN numbers, that are
      physically connected through ipv4 interfaces having bgp related protocols.
      Named nodes are device, interface, link, remote_interface, remote_device,
      domain, remote_domain.
    """
    return connected_bgp_peers() + [
        node(name='interface', ipv4_addr=m.not_none(), if_type='ip'),
        node(name='remote_interface', ipv4_addr=m.not_none(), if_type='ip')
    ]

def bgp_peers_using_v6_link_ips(system_filters=None, remote_system_filters=None):
    """
    Returns:
      List of path queries for systems with assigned ASN numbers, that are
      physically connected through ipv6 interfaces having bgp related protocols.
      Named nodes are device, interface, link, remote_interface, remote_device,
      domain, remote_domain.
    """
    return connected_bgp_peers() + [
        node(name='interface', ipv6_addr=m.not_none(), if_type='ip'),
        node(name='remote_interface', ipv6_addr=m.not_none(), if_type='ip')
    ]


def bgp_peers_using_v4_loopback_ips(system_filters=None,
                                    remote_system_filters=None,
                                    loopback_filters=None,
                                    remote_loopback_filters=None,
                                    link_filters=None):
    """
    Returns:
      List of path queries for systems with assigned ASN numbers, that are
      physically connected to external routers and have ipv4 loopback ip.
      Named nodes are device, interface, link, remote_interface, remote_device,
      domain, remote_domain, loopback, remote_loopback.
    """
    loopback_filters = loopback_filters or {}
    remote_loopback_filters = remote_loopback_filters or {}
    return [
        connected_physical_interfaces(link_filters=link_filters),
        node(name='interface', ipv4_addr=m.not_none()),
        node(name='remote_interface', ipv4_addr=m.not_none()),
        systems_with_asn_and_loopback_ipv4(system_filters=system_filters),
        node(name='loopback', **loopback_filters),
        systems_with_asn_and_loopback_ipv4(
            'remote_device', 'remote_domain', 'remote_loopback',
            system_filters=remote_system_filters),
        node(name='remote_loopback', **remote_loopback_filters),
    ]

def bgp_peers_using_v6_loopback_ips(system_filters=None,
                                    remote_system_filters=None,
                                    loopback_filters=None,
                                    remote_loopback_filters=None):
    """
    Returns:
      List of path queries for systems with assigned ASN numbers, that are
      physically connected to external routers and have ipv6 loopback ip.
      Named nodes are device, interface, link, remote_interface, remote_device,
      domain, remote_domain, loopback, remote_loopback.
    """
    loopback_filters = loopback_filters or {}
    remote_loopback_filters = remote_loopback_filters or {}
    return [
        connected_physical_interfaces(),
        node(name='interface', ipv6_addr=m.not_none()),
        node(name='remote_interface', ipv6_addr=m.not_none()),
        systems_with_asn_and_loopback_ipv6(system_filters=system_filters),
        node(name='loopback', **loopback_filters),
        systems_with_asn_and_loopback_ipv6(
            'remote_device', 'remote_domain', 'remote_loopback',
            system_filters=remote_system_filters),
        node(name='remote_loopback', **remote_loopback_filters),
    ]

def bgp_generic_peers_within_mlag_domain():
    """
    Base line for 'bgp_peers_using_<version>_ips_within_mlag_domain' methods.

    Returns:
      List of path queries for systems within a mlag domain.
    """
    return paired_systems_in_mlag_domain_with_peer_vlan() + [
        connected_port_channels(device='local_device', remote_device='peer_device'),
        systems_with_asn(system='local_device', domain='local_asn'),
        systems_with_asn(system='peer_device', domain='peer_asn'),
        node(name='child_interface', if_type='ethernet'),
        node(name='remote_child_interface', if_type='ethernet'),
        # TODO JP: Bellatrix: Signal MLAG BGP sessions using protocol node, and not
        # ebgp if_protocol , but until then, we have to disambiguate
        # other vn_instances that may not be related to mlag to prevent them from
        # establishing bgp peer relationships in config or expectations.
        node(name='local_svi', protocols='ebgp'),
        node(name='peer_svi', protocols='ebgp')
    ]


def policy_with_security_rule(policy='policy', security_rule='rule'):
    ''' Return path query for security rules attached to policy
    '''
    return (
        node('policy', policy_type='security', name=policy)
        .out('has_rule')
        .node('security_rule', name=security_rule)
    )


def systems_with_vn_instance(virtual_network, system):
    '''Return path query for systems with hosted_vn_instance
       to the virtual_network
    '''
    return (
        node('virtual_network', name=virtual_network, ipv4_subnet=m.not_none())
        .out('instantiated_by')
        .node('vn_instance')
        .in_('hosted_vn_instances')
        .node('system', name=system)
    )


def hosted_virtual_networks(
        device='device', system_filters=None, virtual_network='virtual_network',
        vn_filters=None, security_zone='sz', sz_filters=None
):
    '''Return path query for hosted virtual network instances and their associated
       routing zone. Named nodes are device, vn_instance, virtual_network, and sz'''
    system_filters = system_filters or {}
    vn_filters = vn_filters or {}
    sz_filters = sz_filters or {}
    return (
        node('system', name=device, **system_filters)
        .out('hosted_vn_instances')
        .node('vn_instance', name='vn_instance')
        .out('instantiates')
        .node('virtual_network', name=virtual_network, **vn_filters)
        .in_('member_vns')
        .node('security_zone', name=security_zone, **sz_filters)
    )

def hosted_virtual_networks_with_svi(device='device'):
    '''Return path query for hosted virtual network instances with svi.
    Named nodes are device, vn_instance, virtual_network and svi'''
    return [
        hosted_virtual_networks(device=device, vn_filters={'vn_id': m.not_none()}),
        node('vn_instance', name='vn_instance')
        .out('member_interfaces')
        .node('interface', name='svi')
        .where(lambda vn_instance, svi:
               (vn_instance.ipv4_enabled and svi.ipv4_addr)
               or
               (vn_instance.ipv6_enabled and (
                   svi.ipv6_addr or svi.ipv6_addr_type == 'link_local')))
    ]


def paired_systems_in_mlag_domain_with_peer_vlan(local_device='local_device',
                                                 peer_device='peer_device'):
    '''Return path query for mlag connected devices, query includes
    and redundancy group'''
    return [
        paired_systems_in_mlag_domain(system1=local_device, system2=peer_device),
        node(name='domain')
        .out('composed_of_interfaces')
        .node('interface', name='local_svi', if_type='svi')
        .out('member_of_vn_instance')
        .node('vn_instance', name='local_vn_instance')
        .in_('hosted_vn_instances')
        .node(name=local_device),
        node(name='domain')
        .out('composed_of_interfaces')
        .node('interface', name='peer_svi', if_type='svi')
        .out('member_of_vn_instance')
        .node('vn_instance', name='peer_vn_instance')
        .in_('hosted_vn_instances')
        .node(name=peer_device),
        node(name='local_vn_instance')
        .out('instantiates')
        .node('virtual_network', name='virtual_network')
    ]


def bgp_evpn_fabric_peers_for_leaf(system_filters=None, remote_system_filters=None):
    '''Return list of path queries for systems with assigned ASN numbers, that are
    leaf-to-spine connections, that have loopback IP addresses
    Named nodes are device, loopback, link, remote_device, remote_loopback, domain,
    remote_domain
    Loopback and remote loopback need to have IPV4 addresses for EVPN overlay.
    Node named loopback is the leaf loopback - it must be in the loopback in the
    default routing zone
    '''
    system_filters = system_filters or {}
    remote_system_filters = remote_system_filters or {}
    system_filters['role'] = 'leaf'
    remote_system_filters['role'] = 'spine'
    return match(
        *bgp_peers_using_v4_loopback_ips(
            system_filters=system_filters,
            remote_system_filters=remote_system_filters,
            loopback_filters={'loopback_id': 0}
        )
    )


def bgp_evpn_fabric_leaf_leaf_peers(system_filters=None, remote_system_filters=None):
    '''Return list of path queries for systems with assigned ASN numbers, that are
    leaf-to-leaf connections (L3Collapsed), that have loopback IP addresses
    Named nodes are device, loopback, link, remote_device, remote_loopback, domain,
    remote_domain
    Loopback and remote loopback need to have IPV4 addresses for EVPN overlay.
    Node named remote_loopback is the leaf loopback - it must be the loopback
    in the default routing zone
    '''
    system_filters = system_filters or {}
    remote_system_filters = remote_system_filters or {}
    system_filters['role'] = 'leaf'
    remote_system_filters['role'] = 'leaf'
    return match(
        *bgp_peers_using_v4_loopback_ips(
            system_filters=system_filters,
            remote_system_filters=remote_system_filters,
            loopback_filters={'loopback_id': 0},
            remote_loopback_filters={'loopback_id': 0},
            link_filters={'role': 'leaf_leaf'}
        )
    )

def bgp_evpn_fabric_access_access_peers(system_filters=None,
                                        remote_system_filters=None):
    '''Return list of path queries for systems with assigned ASN numbers, that are
    access-to-access connections (access esi), that have loopback IP addresses
    Named nodes are device, loopback, link, remote_device, remote_loopback, domain,
    remote_domain
    Loopback and remote loopback need to have IPV4 addresses for EVPN overlay.
    Node named remote_loopback is the leaf loopback - it must be the loopback
    in the default routing zone
    '''
    system_filters = system_filters or {}
    remote_system_filters = remote_system_filters or {}
    system_filters['role'] = 'access'
    remote_system_filters['role'] = 'access'
    return match(
        *bgp_access_peers_using_v4_loopback_ips(
            system_filters=system_filters,
            remote_system_filters=remote_system_filters,
            loopback_filters={'loopback_id': 0},
            remote_loopback_filters={'loopback_id': 0},
            link_filters={'role': 'access_l3_peer_link'}
        )
    )

def bgp_access_peers_using_v4_loopback_ips(system_filters=None,
                                           remote_system_filters=None,
                                           loopback_filters=None,
                                           remote_loopback_filters=None,
                                           link_filters=None):
    """
    Returns:
      List of path queries for systems with assigned ASN numbers, that are
      physically connected  and have ipv4 loopback ip.
      Named nodes are device, interface, link, remote_interface, remote_device,
      domain, remote_domain, loopback, remote_loopback.
    """
    loopback_filters = loopback_filters or {}
    remote_loopback_filters = remote_loopback_filters or {}
    return [
        connected_physical_interfaces(link_filters=link_filters),
        systems_with_asn_and_loopback_ipv4(system_filters=system_filters),
        node(name='loopback', **loopback_filters),
        systems_with_asn_and_loopback_ipv4(
            'remote_device', 'remote_domain', 'remote_loopback',
            system_filters=remote_system_filters),
        node(name='remote_loopback', **remote_loopback_filters),
    ]

def bgp_evpn_fabric_peers_for_spine(system_filters=None, remote_system_filters=None):
    '''Return list of path queries for systems with assigned ASN numbers, that are
    spine-to-leaf connections, that have loopback IP addresses
    Named nodes are device, loopback, link, remote_device, remote_loopback, domain,
    remote_domain
    Loopback and remote loopback need to have IPV4 addresses for EVPN overlay.
    Node named remote_loopback is the leaf loopback - it must be the loopback
    in the default routing zone
    '''
    system_filters = system_filters or {}
    remote_system_filters = remote_system_filters or {}
    system_filters['role'] = 'spine'
    remote_system_filters['role'] = 'leaf'
    return match(
        *bgp_peers_using_v4_loopback_ips(
            system_filters=system_filters,
            remote_system_filters=remote_system_filters,
            remote_loopback_filters={'loopback_id': 0}
        )
    )


def bgp_evpn_fabric_peers_spine_to_superspine(
        system_filters=None, remote_system_filters=None
):
    '''Return list of path queries for systems with assigned ASN numbers, that are
    spine-to-superspine connections, that have loopback IP addresses
    Named nodes are device, loopback, link, remote_device, remote_loopback, domain,
    remote_domain
    Loopback and remote loopback need to have IPV4 addresses for EVPN overlay.
    Node named remote_loopback is the superspine loopback - loopback ID 0
    is in the default routing zone (VRF)
    '''
    system_filters = system_filters or {}
    remote_system_filters = remote_system_filters or {}
    system_filters['role'] = 'spine'
    remote_system_filters['role'] = 'superspine'
    return match(
        *bgp_peers_using_v4_loopback_ips(
            system_filters=system_filters,
            remote_system_filters=remote_system_filters,
            loopback_filters={'loopback_id': 0},
            remote_loopback_filters={'loopback_id': 0}
        )
    )


def bgp_evpn_fabric_peers_superspine_to_spine(
        system_filters=None, remote_system_filters=None
):
    '''Return list of path queries for systems with assigned ASN numbers, that are
    superspine-to-spine connections, that have loopback IP addresses
    Named nodes are device, loopback, link, remote_device, remote_loopback, domain,
    remote_domain
    Loopback and remote loopback need to have IPV4 addresses for EVPN overlay.
    Node named remote_loopback is the spine loopback - loopback ID 0
    is in the default routing zone (VRF)
    '''
    system_filters = system_filters or {}
    remote_system_filters = remote_system_filters or {}
    system_filters['role'] = 'superspine'
    remote_system_filters['role'] = 'spine'
    return match(
        *bgp_peers_using_v4_loopback_ips(
            system_filters=system_filters,
            remote_system_filters=remote_system_filters,
            loopback_filters={'loopback_id': 0},
            remote_loopback_filters={'loopback_id': 0}
        )
    )


def remote_gateway_to_local_gateways(
        local_gw='local_gw', remote_gw='remote_gw', loopback='loopback',
        remote_loopback='remote_loopback', protocol='protocol',
        local_gw_filters=None, remote_gw_filters=None, protocol_filters=None,
        loopback_filters=None, remote_loopback_filters=None,
):
    local_gw_filters = local_gw_filters or {}
    remote_gw_filters = remote_gw_filters or {}
    loopback_filters = loopback_filters or {}
    protocol_filters = protocol_filters or {}
    remote_loopback_filters = remote_loopback_filters or {}
    return match(
        node('system', role='remote_gateway', name=remote_gw,
             **remote_gw_filters)
        .out('hosted_interfaces')
        .node('interface', if_type='loopback', name=remote_loopback,
              **remote_loopback_filters)
        .out('protocol')
        .node('protocol', name=protocol, routing='bgp', **protocol_filters)
        .in_('protocol')
        .node('interface', if_type='loopback', name=loopback, loopback_id=0,
              **loopback_filters)
        .in_('hosted_interfaces')
        .node('system', name=local_gw, **local_gw_filters)
    ).ensure_different(local_gw, remote_gw)


def fabric_peers_of_remote_gateways(
        local_gw='local_gw', remote_gw='remote_gw', loopback='loopback',
        remote_loopback='remote_loopback', remote_domain='remote_domain',
        protocol='protocol'
):
    return match(
        remote_gateway_to_local_gateways(
            local_gw=local_gw, remote_gw=remote_gw, loopback=loopback,
            remote_loopback=remote_loopback, protocol=protocol
        ),
        systems_with_asn(system=remote_gw, domain=remote_domain)
    )


def security_zones_to_systems(security_zone='sz', sz_instance='sz_inst',
                              system='system', sz_filters=None, system_filters=None,
                              sz_instance_filters=None):
    '''Return a path query for routing zone and system associations via
       sz_instance. By default matching nodes are named sz, sz_inst and
       system.
    '''
    system_filters = system_filters or {}
    sz_filters = sz_filters or {}
    sz_instance_filters = sz_instance_filters or {}
    role = system_filters.pop('role', None) or \
           m.is_in(['leaf', 'spine', 'superspine', 'access'])
    return (
        node('security_zone', name=security_zone, **sz_filters)
        .out('instantiated_by')
        .node('sz_instance', name=sz_instance, **sz_instance_filters)
        .in_('hosted_sz_instances')
        .node('system', name=system, role=role, **system_filters)
    )

def security_zones_to_routing_policies(security_zone='sz',
                                       routing_policy='policy',
                                       security_zone_filters=None,
                                       routing_policy_filters=None):
    security_zone_filters = security_zone_filters or {}
    routing_policy_filters = routing_policy_filters or {}
    return match(
        node('security_zone', name=security_zone, **security_zone_filters)
        .out('policy')
        .node('routing_policy', name=routing_policy, **routing_policy_filters)
    )

def security_zones_with_routing_and_rt_policies(
        security_zone='sz', routing_policy='policy',
        route_target_policy='rt_policy', security_zone_filters=None):
    security_zone_filters = security_zone_filters or {}
    return match(
        node('security_zone', name=security_zone, **security_zone_filters),
        optional(
            node(name=security_zone)
            .out('policy')
            .node('routing_policy', name=routing_policy)
        ),
        optional(
            node(name=security_zone)
            .out('route_target_policy')
            .node('route_target_policy', name=route_target_policy)
        )
    )

def virtual_networks_with_rt_policies(
        virtual_network='vn',
        route_target_policy='rt_policy',
        virtual_network_filters=None,
        route_target_policy_filters=None,
):
    virtual_network_filters = virtual_network_filters or {}
    route_target_policy_filters = route_target_policy_filters or {}
    return match(
        node('virtual_network', name=virtual_network,
             **virtual_network_filters)
        .out('route_target_policy')
        .node('route_target_policy', name=route_target_policy,
              **route_target_policy_filters)
    )


def security_zones_to_system_loopbacks(security_zone='sz', loopback='interface',
                                       system='system', sz_instance='sz_inst',
                                       security_zone_filters=None,
                                       loopback_filters=None,
                                       system_filters=None,
                                       sz_instance_filters=None):
    security_zone_filters = security_zone_filters or {}
    system_filters = system_filters or {}
    sz_instance_filters = sz_instance_filters or {}
    loopback_filters = loopback_filters or {}
    return match(
        node('security_zone', name=security_zone, **security_zone_filters)
        .out('instantiated_by')
        .node('sz_instance', name=sz_instance, **sz_instance_filters)
        .out('member_interfaces')
        .node('interface', if_type='loopback', name=loopback, **loopback_filters)
        .in_('hosted_interfaces')
        .node('system', name=system, **system_filters)
    )


def security_zones_to_virtual_networks(
        security_zone='sz', virtual_network='vn',
        security_zone_filters=None, virtual_network_filters=None,
):
    security_zone_filters = security_zone_filters or {}
    virtual_network_filters = virtual_network_filters or {}
    return (
        node('security_zone', name=security_zone, **security_zone_filters)
        .out('member_vns')
        .node('virtual_network', name=virtual_network, **virtual_network_filters)
    )


def tenants_to_virtual_networks(virtual_network='vn', security_zone=None,
                                virtual_network_filters=None,
                                security_zone_filters=None):
    security_zone_filters = security_zone_filters or {}
    virtual_network_filters = virtual_network_filters or {}
    return (
        node('tenant', name='tenant')
        .in_('tenant')
        .node('security_zone', name=security_zone, **security_zone_filters)
        .out('member_vns')
        .node('virtual_network', name=virtual_network, **virtual_network_filters)
    )


def security_zones_to_subinterfaces(security_zone='sz', sz_instance='sz_inst',
                                    system='system', sz_filters=None,
                                    interface='interface',
                                    subinterface='subinterface',
                                    system_filters=None,
                                    subinterface_filters=None,
                                    sz_instance_filters=None):
    """ Returns path query for a system routing zone and all of its instantiated
        subinterface->interface patterns. """
    sz_filters = sz_filters or {}
    system_filters = system_filters or {}
    subinterface_filters = subinterface_filters or {}
    return (
        security_zones_to_systems(security_zone=security_zone,
                                  system=system, sz_instance=sz_instance,
                                  sz_filters=sz_filters,
                                  system_filters=system_filters,
                                  sz_instance_filters=sz_instance_filters),
        node('sz_instance', name=sz_instance)
        .out('member_interfaces')
        .node('interface', name=subinterface, if_type='subinterface',
              **subinterface_filters)
        .in_('composed_of')
        .node('interface', name=interface)
    )


def security_zones_to_svis(security_zone='sz',
                           system='system', sz_filters=None,
                           virtual_network='vnet',
                           vn_instance='vni',
                           svi='svi',
                           system_filters=None):
    """ Returns path query for a system routing zone and all of its svi interfaces
    """
    sz_filters = sz_filters or {}
    system_filters = system_filters or {}
    return match(
        node('security_zone', name=security_zone, **sz_filters)
        .out('member_vns')
        .node('virtual_network', name=virtual_network)
        .out('instantiated_by')
        .node('vn_instance', name=vn_instance)
        .out('member_interfaces')
        .node('interface', if_type='svi', name=svi),
        node(name=vn_instance)
        .in_('hosted_vn_instances')
        .node('system', name=system, **system_filters)
    )


def security_zone_subinterface_peers(security_zone='sz', sz_instance='sz_inst',
                                     system='system',
                                     interface='interface',
                                     subinterface='subinterface',
                                     remote_subinterface='remote_subinterface',
                                     remote_interface='remote_interface',
                                     remote_system='remote_system',
                                     sz_filters=None,
                                     sz_instance_filters=None,
                                     system_filters=None,
                                     remote_system_filters=None,
                                     link_filters=None):
    """ Returns system <-> subinterface <-> remote_subinterface <-> remote_system
        peers.  Cannot use security_zones_to_subinterfaces twice because external
        routers do not have routing zone instances.

        Named nodes are system, sz, sz_inst, interface, subinterface, link,
        remote_subinterface, remote_interface, remote_system
    """

    sz_filters = sz_filters if sz_filters else {}
    system_filters = system_filters if system_filters else {}
    link_filters = link_filters if link_filters else {}

    remote_system_filters = remote_system_filters if remote_system_filters else {}

    return (
        match(*security_zones_to_subinterfaces(
            system=system,
            security_zone=security_zone,
            sz_instance=sz_instance,
            interface=interface,
            subinterface=subinterface,
            sz_filters=sz_filters,
            sz_instance_filters=sz_instance_filters,
            system_filters=system_filters)),
        connected_subinterfaces(interface=subinterface,
                                remote_interface=remote_subinterface,
                                link_filters=link_filters)
        .node('interface', name=remote_subinterface)
        .in_('composed_of')
        .node('interface', name=remote_interface)
        .in_('hosted_interfaces')
        .node('system', name=remote_system, **remote_system_filters)
    )


def security_zone_subinterface_l3_peers(
        security_zone='sz',
        sz_instance='sz_inst',
        system='system',
        interface='interface',
        subinterface='subinterface',
        remote_subinterface='remote_subinterface',
        remote_interface='remote_interface',
        remote_system='remote_system',
        remote_sz_instance='remote_sz_inst',
        sz_instance_state='active',
        sz_filters=None,
        system_filters=None,
        remote_system_filters=None,
        link_filters=None):
    sz_filters = sz_filters or {}
    system_filters = system_filters or {}
    link_filters = link_filters or {}

    remote_system_filters = remote_system_filters or {}

    return (
        connected_subinterfaces(interface=subinterface,
                                remote_interface=remote_subinterface,
                                link_filters=link_filters)
        .node('interface', name=remote_subinterface)
        .in_('composed_of')
        .node('interface', name=remote_interface)
        .in_('hosted_interfaces')
        .node('system', name=remote_system, **remote_system_filters),
        match(*security_zones_to_subinterfaces(
            system=system,
            security_zone=security_zone,
            sz_instance=sz_instance,
            interface=interface,
            subinterface=subinterface,
            sz_instance_filters={'state': sz_instance_state},
            sz_filters=sz_filters,
            system_filters=system_filters)),
        match(*security_zones_to_subinterfaces(
            system=remote_system,
            security_zone=security_zone,
            sz_instance=remote_sz_instance,
            interface=remote_interface,
            subinterface=remote_subinterface,
            sz_instance_filters={'state': sz_instance_state},
            sz_filters=sz_filters,
            system_filters=remote_system_filters)),
    )


def subinterfaces_with_sz_instances(subinterface='subinterface',
                                    sz_instance='sz_inst',
                                    sz_instance_state='active',
                                    **subinterface_filters):
    return (
        node('interface', if_type='subinterface', name=subinterface,
             **subinterface_filters)
        .in_('member_interfaces')
        .node('sz_instance', name=sz_instance, state=sz_instance_state)
    )


def virtual_networks_with_security_zones(security_zone='sz', virtual_network='vn'):
    """Return match for virtual networks with optional routing zones."""
    sz_to_vn = security_zones_to_virtual_networks(
        security_zone=security_zone, virtual_network=virtual_network)
    return match(
        node('virtual_network', name=virtual_network),
        optional(sz_to_vn),
    )

def loopbacks_in_security_zones(loopback='loopback',
                                sz_inst='sz_inst',
                                security_zone='sz'):
    return match(
        node('interface', name=loopback, if_type='loopback', ipv4_addr=m.not_none())
        .in_('member_interfaces')
        .node('sz_instance', name=sz_inst)
        .in_('instantiated_by')
        .node('security_zone', name=security_zone)
    )

def security_zone_logical_bgp_peers(
        system='device', remote_system='remote_device',
        domain='domain', remote_domain='remote_domain',
        security_zone='sz', sz_instance='sz_inst',
        interface='interface',
        subinterface='subinterface', remote_subinterface='remote_subinterface',
        remote_interface='remote_interface',
        sz_filters=None,
        system_filters=None, remote_system_filters=None):
    """
    Returns connected peers, logically linked via subinterfaces.
    The subinterface belongs to routing zone,
    remote_subinterface is not associated with any routing zone.
    Peer devices both have an ASN assigned.

    Named nodes are system, sz, sz_inst,
    interface, subinterface, link, remote_subinterface, remote_interface,
    remote_system, domain, remote_domain
    """
    return match(
        systems_with_asn(system=system, domain=domain,
                         system_filters=system_filters),
        systems_with_asn(system=remote_system, domain=remote_domain,
                         system_filters=remote_system_filters),
        *security_zone_subinterface_peers(
            system=system, remote_system=remote_system,
            security_zone=security_zone, sz_instance=sz_instance,
            interface=interface,
            subinterface=subinterface, remote_subinterface=remote_subinterface,
            remote_interface=remote_interface,
            sz_filters=sz_filters,
            system_filters=system_filters,
            remote_system_filters=remote_system_filters)
    )


def active_enforcement_points(
        fabric_session_attachment_type=None,
        system='system',
        security_zone='sz',
        security_zone_filters=None,
        protocol_session='protocol_session',
        generic_session_attachment_type=None,
        generic='remote_system',
        enforcement_point_type=None,
        enforcement_point_id=None,
        enforcement_point='enforcement_point',
        generic_impl_type=None,
):
    """
    :param fabric_session_attachment_type: type ('interface', 'loopback') of
           fabric-side protocol session peer.
    :param system: name of the fabric-side system node, hosting protocol session
           peer.
    :param security_zone: name of the routing zone node the protocol session is set
           for.
    :param security_zone_filters: additional filters to identify routing zone
    :param protocol_session: name of the protocol session node.
    :param generic_session_attachment_type: type ('non-loopback', 'loopback') of
           generic-side protocol session peer.
    :param generic: name of the generic-side system node, hosting protocol session
           peer.
    :param enforcement_point_type: if_type ('svi', 'subinterface') of enforcement
           point interface.
    :param enforcement_point_id: id of the enforcement point node.
    :param enforcement_point: name of the enforcement point node.
    :param generic_impl_type: type ('vip', 'subinterface') of generic-side node used
           to find enforcement point.

    :return: path query for active enforcement points by provided arguments.

    Possible 8 cases are:

    fabric_session_attachment_type='interface'
    generic_session_attachment_type=not used
    enforcement_point_type=('svi', 'subinterface')
    generic_impl_type=not used

    fabric_session_attachment_type='loopback'
    generic_session_attachment_type='non-loopback'
    enforcement_point_type='svi'
    generic_impl_type=('vip', 'subinterface')

    fabric_session_attachment_type='loopback'
    generic_session_attachment_type='non-loopback'
    enforcement_point_type='subinterface'
    generic_impl_type='subinterface'

    fabric_session_attachment_type='loopback'
    generic_session_attachment_type='loopback'
    enforcement_point_type='svi'
    generic_impl_type=('vip', 'subinterface')

    fabric_session_attachment_type='loopback'
    generic_session_attachment_type='loopback'
    enforcement_point_type='subinterface'
    generic_impl_type='subinterface'
    """
    assert fabric_session_attachment_type in ('interface', 'loopback'), \
        fabric_session_attachment_type
    assert enforcement_point_type in ('svi', 'subinterface'), \
        enforcement_point_type

    if fabric_session_attachment_type == 'interface':
        if enforcement_point_type == 'svi':
            return match(
                system_protocol_sessions(
                    system_impl_type='svi',
                    system=system,
                    security_zone=security_zone,
                    security_zone_filters=security_zone_filters,
                    bgp_source=enforcement_point,
                    protocol_session=protocol_session,
                ),
                node('interface', name=enforcement_point, id=enforcement_point_id)
            )
        else:
            return match(
                system_protocol_sessions(
                    system_impl_type='interface',
                    system=system,
                    security_zone=security_zone,
                    security_zone_filters=security_zone_filters,
                    bgp_source=enforcement_point,
                    protocol_session=protocol_session,
                ),
                node('interface', name=enforcement_point, id=enforcement_point_id,
                     if_type='subinterface')
            )

    assert generic_session_attachment_type in ('non-loopback', 'loopback'), \
        generic_session_attachment_type
    assert generic_impl_type in ('vip', 'subinterface'), generic_impl_type

    generic_impl_node = (
        ('floating_ip' if generic_impl_type == 'vip' else 'interface')
        if generic_session_attachment_type == 'loopback' else 'bgp_destination'
    )

    if enforcement_point_type == 'svi':
        hosted_vn_with_svi = match(
            hosted_virtual_networks(device=system, virtual_network='vn',
                                    security_zone=security_zone),
            node('interface', if_type='svi', name=enforcement_point)
            .out('member_of_vn_instance')
            .node('vn_instance', name='vn_instance')
        )

        if generic_impl_type == 'vip':
            enf_point_pattern = match(
                hosted_vn_with_svi,
                node('virtual_network', name='vn')
                .in_('member_of')
                .node('ip_endpoint', name=generic_impl_node),
            )
        else:
            enf_point_pattern = match(
                hosted_vn_with_svi,
                node('virtual_network', name='vn')
                .out('member_interfaces')
                .node('interface', if_type='subinterface', name=generic_impl_node),
            )
    else:
        assert generic_impl_type == 'subinterface', generic_impl_type

        enf_point_pattern = match(
            connected_subinterfaces(
                interface=generic_impl_node, remote_interface=enforcement_point,
                link_filters={'role': 'to_generic'}
            ),
            node('interface', name=enforcement_point)
            .in_('member_interfaces')
            .node('sz_instance', name='sz_instance')
        )

    if generic_session_attachment_type == 'loopback':
        if generic_impl_type == 'vip':
            enf_point_pattern = match(
                enf_point_pattern,
                node('system', name=generic)
                .out('hosted_ip_endpoints')
                .node('ip_endpoint', name='floating_ip')
            )
        else:
            enf_point_pattern = match(
                enf_point_pattern,
                node('system', name=generic)
                .out('hosted_interfaces')
                .node('interface')
                .out('composed_of')
                .node('interface', if_type='subinterface', name='interface')
            )

    # System-side peer is loopback
    fabric_side_protocol_session_pattern = match(
        system_protocol_sessions(
            system_impl_type='interface',
            system=system,
            security_zone=security_zone,
            security_zone_filters=security_zone_filters,
            protocol_session=protocol_session,
        ),
        node('interface', name='bgp_source', if_type='loopback')
    )

    return match(
        fabric_side_protocol_session_pattern,
        generic_protocol_sessions(
            generic_impl_type=generic_session_attachment_type
            if generic_session_attachment_type == 'loopback' else generic_impl_type,
            system=generic,
            protocol_session=protocol_session,
            protocol_endpoint='generic_protocol_endpoint'
        ),
        enf_point_pattern,
        node('interface', name=enforcement_point, id=enforcement_point_id)
    )


def linked_security_rules(rel_type, rule1='rule1', rule2='rule2',
                          rel_name='rel', **rel_props):
    return (node('security_rule', name=rule1)
            .out(type=rel_type, name=rel_name, **rel_props)
            .node('security_rule', name=rule2))


def linked_policy_security_rules(rel_types, rel='rel', policy1='policy1',
                                 rule1='rule1', policy2='policy2', rule2='rule2',
                                 **props):
    return match(node('policy', name=policy1, **props)
                 .out('has_rule')
                 .node('security_rule', name=rule1)
                 .out(type=m.is_in(rel_types), name=rel)
                 .node('security_rule', name=rule2)
                 .in_('has_rule')
                 .node('policy', name=policy2))


def linked_policies_security_rules(rel_type,
                                   policy1='policy1',
                                   rule1='rule1', rule1_id=None,
                                   policy2='policy2',
                                   rule2='rule2', rule2_id=None,
                                   rel_name='rel', **rel_props):
    return match(node('policy', name=policy1)
                 .out('has_rule')
                 .node('security_rule', name=rule1, id=node_id(rule1_id))
                 .out(type=rel_type, name=rel_name, **rel_props)
                 .node('security_rule', name=rule2, id=node_id(rule2_id))
                 .in_('has_rule')
                 .node('policy', name=policy2))


def vn_endpoint_and_subinterface_on_same_link(
        system_subinterface='subinterface',
        system_subinterface_filters=None,
        system_interface='interface',
        system_interface_filters=None,
        remote_interface='remote_interface',
        vn_endpoint='vn_endpoint'):
    system_subinterface_filters = system_subinterface_filters or {}
    system_interface_filters = system_interface_filters or {}
    return (node('interface', name=system_subinterface, if_type='subinterface',
                 **system_subinterface_filters)
            .in_('composed_of')
            .node('interface', name=system_interface,
                  **system_interface_filters)
            .out('link')
            .node('link')
            .in_('link')
            .node('interface', name=remote_interface)
            .out('hosted_vn_endpoints')
            .node('vn_endpoint', name=vn_endpoint)
            # make sure we walk the link to the other side
            .ensure_different(system_interface, remote_interface))


def generic_system_bgp_callbacks(intf_type=None):
    if intf_type == 'subinterface':
        intf_pattern = match(
            *security_zone_subinterface_peers(
                subinterface='bgp_source',
                interface='parent_interface',
                remote_subinterface='bgp_destination',
                remote_interface='remote_parent_interface',
            ))
    else:
        raise ValueError('Invalid intf_type - %s not handled' % intf_type)

    base_pattern = match(
        linked_protocol_session_peers(
            peer='bgp_source',
            remote_peer='bgp_destination',
            session_filters={'routing': 'bgp'}
        ),
        node('system', name='remote_system', role='generic'),
        systems_with_asn(
            system='remote_system', domain='remote_domain',
            allow_empty_domain_id=True),
    )
    return match(
        base_pattern,
        intf_pattern,
    )


def static_routes_with_network_node(network='network',
                                    next_hop='next_hop',
                                    static_route='static_route',
                                    system='system',
                                    security_zone='sz',
                                    system_filters=None,
                                    security_zone_filters=None):
    """ Composes a pattern match for static route rendering in AOS, in which
        the static route destination is pointing to graph nodes (not strings)

    Named return nodes are:
        network: Static route destination node, containing IPv4/IPV6 address to
            route to.
        next_hop: node containing next hop IPv4/IPv6 address of destination node
        static_route: static_route node, holding network and ip_version
        system: system performing static routing
        sz: security_zone associated to the source_interface

    :return (MultiPathQueryBuilder): AOS Graph query builder for use in pattern
        matching
    """
    system_filters = system_filters or {}
    security_zone_filters = security_zone_filters or {}
    return match(
        node('system', name=system, **system_filters)
        .out('static_route')
        .node('static_route', name=static_route)
        .out('next_hop')
        .node(name=next_hop, type=m.is_in(['interface', 'ip_endpoint'])),

        node('security_zone', name=security_zone, **security_zone_filters)
        .out('static_route')
        .node('static_route', name=static_route, network=m.is_none())
        .out('network')
        .node('interface', name=network),
    )


def static_routes_with_network_string(
        next_hop='next_hop',
        static_route='static_route',
        system='system',
        security_zone='sz',
        system_filters=None,
        security_zone_filters=None):
    """ Composes a pattern match for static route rendering in AOS for user-defined
        static routes, in which the network is a string from within the
        static_route node instead of a separate ip_endpoint or interface node.

    Named return nodes are:
        next_hop: node containing next hop IPv4/IPv6 address of destination node
        static_route: static_route node, holding ip_version
        system: system performing static routing
        sz: security_zone associated to the source_interface
        network: Node containing Prefix destination for the static route

    :return (MultiPathQueryBuilder): AOS Graph query builder for use in pattern
        matching
    """
    system_filters = system_filters or {}
    security_zone_filters = security_zone_filters or {}
    return match(
        node('system', name=system, **system_filters)
        .out('static_route')
        .node('static_route', name=static_route, network=m.not_none())
        .out('next_hop')
        .node(name=next_hop, type=m.is_in(['interface', 'ip_endpoint'])),

        node('static_route', name=static_route)
        .in_('static_route')
        .node('security_zone', name=security_zone, **security_zone_filters)
    )


def generic_protocol_sessions(
        generic_impl_type=None,
        domain='remote_domain',
        system='remote_system',
        system_filters=None,
        bgp_destination='bgp_destination',
        bgp_destination_filters=None,
        protocol_endpoint='protocol_endpoint',
        protocol_endpoint_filters=None,
        protocol_session='protocol_session',
        protocol_session_filters=None,
        with_asn=True,
):
    # pylint: disable=anomalous-backslash-in-string
    """
    loopback                                       subinterface
    ---------                                      --------
    [domain]                                       [domain]
      | composed_of_systems                           | composed_of_systems
    [system role='generic']                        [system role='generic']
      |  hosted_interfaces                           | hosted_interfaces
    ['bgp_destination' interface                     |
     if_type='loopback']                            [interface]
      | layered_over                                  | composed_of
    [protocol_endpoint]                            ['bgp_destination' interface
      |                                             if_type='subinterface']
      | instantiates                                  | layered_over
    [protocol_session]                             [protocol_endpoint]
                                                      | instantiates
                                                   [protocol_session]

    vip
    ---
    [domain]
      | composed_of_systems
    [system role='generic']
      | hosted_ip_endpoints
    ['bgp_destination' ip_endpoint]
      | layered_over
    [protocol_endpoint]
      | instantiates
    [protocol_session]
    """
    system_filters = system_filters or {}
    bgp_destination_filters = bgp_destination_filters or {}
    protocol_endpoint_filters = protocol_endpoint_filters or {}
    if generic_impl_type == 'loopback':
        intf_pattern = match(
            node('system', role='generic', name=system, **system_filters)
            .out('hosted_interfaces')
            .node('interface', if_type='loopback', name=bgp_destination),
        )
    elif generic_impl_type == 'subinterface':
        intf_pattern = match(
            node('system', role='generic', name=system, **system_filters)
            .out('hosted_interfaces')
            .node('interface')
            .out('composed_of')
            .node('interface', if_type='subinterface', name=bgp_destination),
        )
    # When a system role='generic' and external=True, there is no traversable
    # relationship to a vn_endpoint. The ip_endpoint is associated directly to the
    # external system, which may or may not be attached by a physical link.
    elif generic_impl_type == 'vip':
        intf_pattern = match(
            node('system', role='generic', name=system, **system_filters)
            .out('hosted_ip_endpoints')
            .node('ip_endpoint', name=bgp_destination),
        )

    else:
        raise ValueError('Invalid generic_impl_type %s' % generic_impl_type)

    if with_asn:
        pattern = match(
            systems_with_asn(
                system=system,
                domain=domain,
                system_filters=system_filters,
                allow_empty_domain_id=True,
            ),
            intf_pattern,
            protocol_session_configuration(
                protocol_session=protocol_session,
                session_filters=protocol_session_filters,
                protocol_endpoint=protocol_endpoint,
                endpoint_filters=protocol_endpoint_filters,
                peer=bgp_destination,
                peer_filters=bgp_destination_filters,
            )
        )
    else:
        pattern = match(
            intf_pattern,
            protocol_session_configuration(
                protocol_session=protocol_session,
                session_filters=protocol_session_filters,
                protocol_endpoint=protocol_endpoint,
                endpoint_filters=protocol_endpoint_filters,
                peer=bgp_destination,
                peer_filters=bgp_destination_filters,
            )
        )
    return pattern


def system_protocol_sessions(system_impl_type=None,
                             system='system',
                             system_filters=None,
                             security_zone='sz',
                             security_zone_filters=None,
                             bgp_source='bgp_source',
                             bgp_source_filters=None,
                             protocol_session='protocol_session',
                             protocol_session_filters=None,
                             protocol_endpoint='protocol_endpoint',
                             protocol_endpoint_filters=None,
                             domain='domain',
                             with_asn=True):
    # pylint: disable=anomalous-backslash-in-string
    """
       impl_type='svi'                impl_type='interface'
       -------------------------      ----------------------
       [domain]  [security_zone]      [domain]
          |cmp_o_s    |member_vns        |composed_of_systems
       [system]  [virtual_network]    [system]  [security_zone]
          |hstd_vn_i /instantiated_by    |        /instantiated_by
       [vn_instance]                  [sz_instance]
          |member_interfaces             |hosted_sz_instances
       [interface if_type='svi']      [interface if_type=subinterface, loopback]
          |layered_over                  |layered_over
       [protocol_endpoint]            [protocol_endpoint]
          |instantiates                  |instantiates
       [protocol_session]             [protocol_session]

    """
    system_filters = system_filters or {}
    security_zone_filters = security_zone_filters or {}
    protocol_session_filters = protocol_session_filters or {}
    protocol_endpoint_filters = protocol_endpoint_filters or {}
    bgp_source_filters = bgp_source_filters or {}
    if system_impl_type == 'interface':
        sz_intf_pattern = match(
            node('system', name=system,
                 role=m.is_in(['leaf', 'spine', 'superspine']),
                 **system_filters)
            .out('hosted_sz_instances')
            .node('sz_instance', name='sz_instance')
            .out('member_interfaces')
            .node('interface', if_type=m.is_in(['subinterface', 'loopback']),
                  name=bgp_source, **bgp_source_filters),
            node('security_zone', name=security_zone, **security_zone_filters)
            .out('instantiated_by')
            .node('sz_instance', name='sz_instance')
        )
    elif system_impl_type == 'svi':
        sz_intf_pattern = match(
            node('system', name=system, role='leaf', **system_filters)
            .out('hosted_vn_instances')
            .node('vn_instance', name='vn_instance')
            .out('instantiates')
            .node('virtual_network')
            .in_('member_vns')
            .node('security_zone', name=security_zone, **security_zone_filters),

            node('interface', if_type='svi', name=bgp_source, **bgp_source_filters)
            .out('member_of_vn_instance')
            .node('vn_instance', name='vn_instance')
        )
    else:
        raise ValueError('Unrecognized impl_type %s' % system_impl_type)
    if with_asn:
        pattern = match(
            protocol_session_configuration(
                peer=bgp_source,
                protocol_session=protocol_session,
                protocol_endpoint=protocol_endpoint,
                session_filters=protocol_session_filters,
                endpoint_filters=protocol_endpoint_filters,
            ),
            sz_intf_pattern,
            systems_with_domain(system=system, domain=domain),

        )
    else:
        pattern = match(
            protocol_session_configuration(
                peer=bgp_source,
                protocol_session=protocol_session,
                protocol_endpoint=protocol_endpoint,
                session_filters=protocol_session_filters,
                endpoint_filters=protocol_endpoint_filters,
            ),
            sz_intf_pattern
        )
    return pattern


def evpn_interconnect_virtual_networks(
        evpn_interconnect_group='evpn_interconnect_group',
        evpn_interconnect_group_filters=None,
        evpn_interconnect_vn='evpn_interconnect_vn',
        evpn_interconnect_vn_filters=None,
        virtual_network='virtual_network',
        virtual_network_filters=None,
        vn_type='vxlan',
):
    evpn_interconnect_group_filters = evpn_interconnect_group_filters or {}
    evpn_interconnect_vn_filters = evpn_interconnect_vn_filters or {}
    virtual_network_filters = virtual_network_filters or {}
    return match(
        node('evpn_interconnect_group', name=evpn_interconnect_group,
             **evpn_interconnect_group_filters)
        .out('evpn_interconnect_vn', name=evpn_interconnect_vn,
             **evpn_interconnect_vn_filters)
        .node('virtual_network', name=virtual_network, vn_type=vn_type,
              **virtual_network_filters)
    )


def evpn_interconnect_security_zones(
        evpn_interconnect_group='evpn_interconnect_group',
        evpn_interconnect_group_filters=None,
        evpn_interconnect_l3='evpn_interconnect_l3',
        evpn_interconnect_l3_filters=None,
        evpn_interconnect_l3_rel=None,
        security_zone='security_zone',
        security_zone_filters=None,
        evpn_interconnect_sz_rel=None,
        routing_policy='routing_policy',
        routing_policy_filters=None,
        evpn_interconnect_sz_policy_rel=None,
):
    """
                      [evpn_interconnect_group]
                               |evpn_interconnect_l3
                      [evpn_interconnect_l3]
      evpn_interconnect_sz|            |evpn_interconnect_sz_policy
                 [security_zone]   [routing_policy]
    """
    evpn_interconnect_group_filters = evpn_interconnect_group_filters or {}
    security_zone_filters = security_zone_filters or {}
    routing_policy_filters = routing_policy_filters or {}
    evpn_interconnect_l3_filters = evpn_interconnect_l3_filters or {}

    return match(
        node('evpn_interconnect_group', name=evpn_interconnect_group,
             **evpn_interconnect_group_filters)
        .out('evpn_interconnect_l3', name=evpn_interconnect_l3_rel)
        .node('evpn_interconnect_l3', name=evpn_interconnect_l3,
              **evpn_interconnect_l3_filters)
        .in_('evpn_interconnect_sz', name=evpn_interconnect_sz_rel)
        .node('security_zone', name=security_zone, sz_type='evpn',
              **security_zone_filters),
        node('evpn_interconnect_l3', name=evpn_interconnect_l3)
        .out('evpn_interconnect_sz_policy', name=evpn_interconnect_sz_policy_rel)
        .node('routing_policy', name=routing_policy,
              **routing_policy_filters)
    )


def evpn_interconnect_remote_gateways(
        remote_gw='remote_gw',
        remote_gw_filters=None,
        evpn_interconnect_group='evpn_interconnect_group',
        evpn_interconnect_group_filters=None,
        evpn_interconnect_peer=None,
        evpn_interconnect_peer_filters=None,
):
    remote_gw_filters = remote_gw_filters or {}
    evpn_interconnect_group_filters = evpn_interconnect_group_filters or {}
    evpn_interconnect_peer_filters = evpn_interconnect_peer_filters or {}

    return match(
        node('system', role='remote_gateway', name=remote_gw,
             **remote_gw_filters)
        .in_('evpn_interconnect_peer', name=evpn_interconnect_peer,
             **evpn_interconnect_peer_filters)
        .node('evpn_interconnect_group', name=evpn_interconnect_group,
              **evpn_interconnect_group_filters)

    )

def load_balancing_policies(
    load_balancing_policy='load_balancing_policy',
    load_balancing_policy_filters=None,
):
    load_balancing_policy_filters = load_balancing_policy_filters or {}
    return match(
        node('load_balancing_policy', name=load_balancing_policy,
             **load_balancing_policy_filters)
    )

def load_balancing_policies_with_systems(
    load_balancing_policy='load_balancing_policy',
    load_balancing_policy_filters=None,
    load_balancing_policy_rel=None,
    system='system',
    system_filters=None
):
    load_balancing_policy_filters = load_balancing_policy_filters or {}
    system_filters = system_filters or {}
    return match(
        node('load_balancing_policy', name=load_balancing_policy,
             **load_balancing_policy_filters)
        .out('load_balancing_policy', name=load_balancing_policy_rel)
        .node('system', name=system,
              **system_filters)
    )
