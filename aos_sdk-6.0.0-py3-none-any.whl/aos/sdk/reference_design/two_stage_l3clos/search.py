# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""Utility methods to find info in two_stage_l3clos blueprints"""

from __future__ import annotations

import json
from functools import partial
import typing as t

from aos.sdk.graph import is_node, is_in, ne, _or, is_none, eq, not_none
from aos.sdk.graph.query import match, node as qnode, iterate

if t.TYPE_CHECKING:
    import typing_extensions as te
    import aos.sdk.typing as tt

    GraphNodeOrId: te.TypeAlias = tt.GraphNode | tt.GraphNodeId

    _MAGIC: t.Any
    aos: t.Any


class RouterInfo(t.NamedTuple):
    label: str
    asn: int | None  # asn integer
    # ip including the prefix. Ex: '10.0.0.10/32'
    loopback_ip: tt.IPv4Address | None
    # ipv6 including the prefix. Ex: 'a05:10::10/64'
    loopback_ipv6: tt.IPv6Address | None


def _node(blueprint: tt.Graph, node: GraphNodeOrId) -> tt.GraphNode | None:
    if not is_node(node):
        return blueprint.get_node(node)
    return node


def _has_gai_index(blueprint: tt.Graph, index_name: str) -> bool:
    gai = getattr(blueprint, 'gai', None)
    return t.cast(bool, gai and index_name in gai)


def _iterate(
    blueprint: tt.Graph,
    *args,
    **kwargs
) -> t.Iterator[dict[str, tt.GraphNode]]:
    if getattr(blueprint, 'is_cpp_graph', False):
        # A stand alone sdk package cannot import from non sdk code in leblon.
        # If the blueprint is a cpp graph variant, then the leblon code base is
        # available for import. Hence, the import is specified inside the specific
        # condition.
        from aos.grappa.query import iterate as cpp_iterate
        iterate_fn = cpp_iterate
    else:
        iterate_fn = iterate
    return iterate_fn(blueprint, *args, **kwargs)


def node_id(node: GraphNodeOrId | None) -> tt.GraphNodeId | None:
    _id = node.id if is_node(node) else node
    if t.TYPE_CHECKING:
        return t.cast(tt.GraphNodeId, _id)
    return _id


def has_node(blueprint: tt.Graph, node: GraphNodeOrId) -> bool:
    node = node.id if is_node(node) else node
    return blueprint.get_node(node) is not None


def get_router_nodes(blueprint: tt.Graph) -> tt.GraphNodeIterator:
    return blueprint.get_nodes('system', role='generic', external=True)


def get_fabric_nodes(blueprint: tt.Graph) -> tt.GraphNodeIterator:
    return blueprint.get_nodes('system', role=is_in(['spine', 'leaf', 'superspine']))


def get_plane_superspines(
    blueprint: tt.Graph,
    superspine_plane: GraphNodeOrId
) -> tt.GraphNodeIterator:
    '''
    Find superspines that are associated to the given superspine plane in the
    blueprint
    '''
    return (
        blueprint.traverse(_node(blueprint, superspine_plane))
        .in_('part_of_superspine_plane')
        .source('system', role='superspine')
    )


def get_leaf_nodes(blueprint: tt.Graph) -> tt.GraphNodeIterator:
    return blueprint.get_nodes('system', role='leaf')


def get_access_switch_nodes(blueprint: tt.Graph) -> tt.GraphNodeIterator:
    return blueprint.get_nodes('system', role='access')


def get_spine_nodes(blueprint: tt.Graph) -> tt.GraphNodeIterator:
    return blueprint.get_nodes('system', role='spine')


def get_superspine_nodes(blueprint: tt.Graph) -> tt.GraphNodeIterator:
    return blueprint.get_nodes('system', role='superspine')


def get_server_nodes(blueprint: tt.Graph) -> tt.GraphNodeIterator:
    return blueprint.get_nodes('system', role='generic', external=False)


def get_metadata_node(blueprint: tt.Graph) -> tt.GraphNode | None:
    return blueprint.get_nodes('metadata').first


def get_single_leafs(blueprint: tt.Graph) -> list[tt.GraphNode]:
    '''Return leafs that are not part of redundancy group'''
    return [
        leaf
        for leaf in blueprint.get_nodes('system', role='leaf')
        if not get_system_redundancy_group(blueprint, leaf)
    ]


def get_single_switches(
    blueprint: tt.Graph,
    **system_filter: te.Unpack[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.two_stage_l3clos.schema.SYSTEM_SCHEMA'
    ]]
) -> list[tt.GraphNode]:
    return [path['system'] for path in _iterate(
        blueprint,
        qnode('system', name='system', role=is_in(('leaf', 'access')),
              **system_filter)
        .having(qnode('system', name='system')
                .out('part_of_redundancy_group')
                .node('redundancy_group'), at_most=0))]


def get_all_switches(blueprint: tt.Graph) -> list[tt.GraphNode]:
    return list(blueprint.get_nodes('system', role=is_in(('leaf', 'access'))))


def get_redundancy_groups(
    blueprint: tt.Graph,
    member_role: t.Optional[tt.SystemRole | tt.PropertyMatcher] = None
) -> list[tt.GraphNode]:
    if member_role is None:
        return list(blueprint.get_nodes('redundancy_group'))
    return [path['rg'] for path in _iterate(
        blueprint,
        qnode('redundancy_group', name='rg')
        .having(qnode('redundancy_group', name='rg')
                .in_('part_of_redundancy_group')
                .node('system', role=member_role), at_least=1))]


def get_redundancy_groups_in_rack(
    blueprint: tt.Graph,
    rack_id: GraphNodeOrId,
    member_role: t.Optional[tt.SystemRole | tt.PropertyMatcher] = None,
) -> list[tt.GraphNode]:
    query = (
        qnode('redundancy_group', name='rg')
        .out('part_of_rack')
        .node('rack', id=node_id(rack_id))
        .having(qnode('redundancy_group', name='rg')
                .in_('part_of_redundancy_group')
                .node('system', role=member_role or not_none()), at_least=1))

    return [path['rg'] for path in _iterate(blueprint, query)]


def get_leaf_pairs(blueprint: tt.Graph) -> list[tt.GraphNode]:
    return get_redundancy_groups(blueprint, 'leaf')


def get_access_pairs(blueprint: tt.Graph) -> list[tt.GraphNode]:
    return get_redundancy_groups(blueprint, 'access')


def get_first_leaf_pair(blueprint: tt.Graph) -> tt.GraphNode | None:
    leaf_pairs = get_leaf_pairs(blueprint)
    return leaf_pairs[0] if leaf_pairs else None


def get_first_access_pair(blueprint: tt.Graph) -> tt.GraphNode | None:
    access_pairs = get_access_pairs(blueprint)
    return access_pairs[0] if access_pairs else None


def get_system_asn_node(
    blueprint: tt.Graph,
    system: GraphNodeOrId
) -> tt.GraphNode | None:
    system_ = _node(blueprint, system)
    return (blueprint.traverse(system_)
            .in_('composed_of_systems')
            .source('domain', domain_type='autonomous_system')
            .first)


def get_domain_by_system(
    blueprint: tt.Graph,
    system: GraphNodeOrId
) -> tt.GraphNode | None:
    system_node = _node(blueprint, system)
    return blueprint.traverse(system_node).in_(
        'composed_of_systems').node('domain').one_or_none


def get_generic_system_by_domain(
    blueprint: tt.Graph,
    domain: GraphNodeOrId
) -> tt.GraphNode | None:
    domain_node = _node(blueprint, domain)
    if domain_node is None:
        return None
    return (blueprint.traverse(domain_node).out('composed_of_systems')
            .target(type='system', role='generic').first)


def get_fabric_asn_nodes(blueprint: tt.Graph) -> list[tt.GraphNode]:
    return [
        path['domain'] for path in _iterate(
            blueprint,
            qnode('system', role=is_in({'leaf', 'spine', 'superspine'}))
            .in_('composed_of_systems')
            .node('domain', name='domain', domain_type='autonomous_system')
        )
    ]


def get_system_logical_device_node(
    blueprint: tt.Graph,
    system: GraphNodeOrId
) -> tt.GraphNode | None:
    system_ = _node(blueprint, system)
    return (blueprint.traverse(system_)
            .out('logical_device')
            .target('logical_device')
            .first)


def get_system_interface_map(
    blueprint: tt.Graph,
    system: GraphNodeOrId
) -> tt.GraphNode | None:
    system_ = _node(blueprint, system)
    return (blueprint.traverse(system_)
            .out('interface_map')
            .target('interface_map')
            .first)


def get_system_device_profile(
    blueprint: tt.Graph,
    system: GraphNodeOrId
) -> tt.GraphNode | None:
    if _has_gai_index(blueprint, 'get_system_device_profile'):
        gai = blueprint.gai  # type: ignore[attr-defined]
        return gai.get_system_device_profile.get_node(system)

    system_ = _node(blueprint, system)
    return (blueprint.traverse(system_)
            .out('interface_map')
            .target('interface_map')
            .out('device_profile')
            .target('device_profile')
            .first)


# an optimized version to find out the device profile ID w/o actual
# node retrieval because get_node for the device_profile is quite slow for the
# CPP graph stack due to JSON decoding and schema load on each invocation
def get_system_device_profile_id(
    blueprint: tt.Graph,
    system: GraphNodeOrId
) -> tt.GraphNodeId | None:
    if _has_gai_index(blueprint, 'get_system_device_profile'):
        gai = blueprint.gai  # type: ignore[attr-defined]
        node = gai.get_system_device_profile.get_node(system)
        if node is not None:
            return node.id

    system_ = _node(blueprint, system)
    if system is None:
        return None
    dp_rel = (blueprint.traverse(system_)
              .out('interface_map')
              .target('interface_map')
              .out('device_profile')
              .one_or_none)

    if dp_rel is None:
        return None

    return dp_rel.target_id


def get_logical_device_interface_maps(
    blueprint: tt.Graph,
    logical_device: GraphNodeOrId
) -> tt.GraphNodeIterator:
    logical_device_ = _node(blueprint, logical_device)
    return (blueprint.traverse(logical_device_)
            .in_('logical_device')
            .node('interface_map'))


def get_system_redundancy_group(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    **rg_properties: te.Unpack[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.two_stage_l3clos.schema.REDUNDANCY_GROUP_SCHEMA'
    ]]
) -> tt.GraphNode | None:
    system_ = _node(blueprint, system)
    return (blueprint.traverse(system_)
            .out('part_of_redundancy_group')
            .target('redundancy_group', **rg_properties)
            .first)


# TODO(elena): This function is almost identical to get_composed_systems, consider
#  merging them
def get_systems_by_redundancy_group(
    blueprint: tt.Graph,
    rg: GraphNodeOrId,
    **system_filters: te.Unpack[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.two_stage_l3clos.schema.SYSTEM_SCHEMA'
    ]]
) -> list[tt.GraphNode]:
    return [
        path['system'] for path in _iterate(
            blueprint, (
                qnode('redundancy_group', id=node_id(rg))
                .out('composed_of_systems')
                .node('system', name='system', **system_filters)
            )
        )
    ]


def get_systems_by_vtep(
    blueprint: tt.Graph,
    vtep: GraphNodeOrId
) -> list[tt.GraphNode]:
    if _has_gai_index(blueprint, 'get_systems_by_vtep'):
        gai = blueprint.gai  # type: ignore[attr-defined]
        return gai.get_systems_by_vtep.get_nodes(vtep)
    else:
        vtep_ = _node(blueprint, vtep)
        return list(blueprint.traverse(vtep_)
                    .in_('hosted_interfaces')
                    .source('system'))


def get_vtep_by_system(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    vtep_type: str | tt.PropertyMatcher,
) -> tt.GraphNode | None:
    system_ = _node(blueprint, system)
    if system_ is None:
        return None
    return (blueprint.traverse(system_)
            .out('hosted_interfaces')
            .target('interface', if_type=vtep_type)
            .first)


def get_system_virtual_networks(
    blueprint: tt.Graph,
    system: GraphNodeOrId
) -> tt.GraphNodeIterator:
    system_ = _node(blueprint, system)
    return (blueprint.traverse(system_)
            .out('hosted_vn_instances')
            .target('vn_instance')
            .out('instantiates')
            .target('virtual_network'))


def get_system_hosting_interface(
    blueprint: tt.Graph,
    interface: GraphNodeOrId,
    system_type: str | tt.PropertyMatcher = 'system'
) -> tt.GraphNode | None:
    interface_ = _node(blueprint, interface)
    return (blueprint.traverse(interface_)
            .in_('hosted_interfaces')
            .source(type=system_type)
            .first)


def get_virtual_network_by_system_and_vlan_id(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    vlan_id: int
) -> tt.GraphNode | None:
    system_ = _node(blueprint, system)
    return (blueprint.traverse(system_)
            .out('hosted_vn_instances')
            .node('vn_instance')
            .out('instantiates')
            .node('virtual_network', vn_type='vlan', vn_id=str(vlan_id))
            .first)


def get_virtual_network_by_redundancy_group_and_vlan_id(
    blueprint: tt.Graph,
    rg: GraphNodeOrId,
    vlan_id: int | tt.PropertyMatcher,
) -> tt.GraphNode | None:
    rg_ = _node(blueprint, rg)
    return (blueprint.traverse(rg_)
            .out('composed_of_systems')
            .node('system')
            .out('hosted_vn_instances')
            .node('vn_instance', vlan_id=vlan_id)
            .out('instantiates')
            .node('virtual_network')
            .first)


def get_loopback_interface(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    **loopback_properties: te.Unpack[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.two_stage_l3clos.schema.INTERFACE_SCHEMA'
    ]]
) -> tt.GraphNode | None:
    system_ = _node(blueprint, system)
    return (blueprint.traverse(system_)
            .out('hosted_interfaces')
            .target('interface', if_type='loopback', **loopback_properties)
            .first)


def get_aggregate_peer_link_for_redundancy_group(
    blueprint: tt.Graph,
    group: GraphNodeOrId
) -> tt.GraphNode | None:
    group_ = _node(blueprint, group)
    return (blueprint.traverse(group_)
            .in_('composed_of_redundancy_group')
            .source('domain')
            .out('composed_of_interfaces')
            .target('interface')
            .out('link')
            .target('link', link_type='aggregate_link')
            .first)


def get_logical_links_for_system_from_security_zone(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    security_zone: GraphNodeOrId
) -> list[tt.GraphNode]:
    system_ = _node(blueprint, system)
    security_zone_ = _node(blueprint, security_zone)
    assert system_ is not None
    assert security_zone_ is not None

    return list(
        path['logical_link']
        for path in _iterate(
            blueprint,
            match(
                qnode('system', id=node_id(system_))
                .out('hosted_interfaces')
                .node('interface', name='interface', if_type='port_channel')
                .out('composed_of')
                .node('interface', if_type='subinterface', name='subinterface'),

                qnode('security_zone', id=node_id(security_zone_))
                .out('instantiated_by')
                .node('sz_instance')
                .out('member_interfaces')
                .node('interface', name='subinterface')
                .out('link')
                .node('link', link_type='logical_link', name='logical_link')
            )
        )
    )


def get_logical_links_by_link(
    blueprint: tt.Graph,
    link: GraphNodeOrId
) -> set[tt.GraphNode]:
    link_ = _node(blueprint, link)
    assert link_ is not None
    return set(blueprint.traverse(link_)
               .in_('link')
               .source('interface')
               .out('composed_of')
               .target('interface', if_type='subinterface')
               .out('link')
               .target('link', link_type='logical_link', label=link_.label))


def get_mlag_port_channel_for_system(
    blueprint: tt.Graph,
    group: GraphNodeOrId,
    system: GraphNodeOrId,
    role: tt.LinkRole | tt.PropertyMatcher = 'leaf_peer_link'
) -> tt.GraphNode:
    group_ = _node(blueprint, group)
    system_ = _node(blueprint, system)
    assert group_ is not None
    assert system_ is not None
    paths = list(iterate(
        blueprint,
        match(
            qnode('redundancy_group', rg_type='mlag', id=group_.id)
            .out('composed_of_systems')
            .node('system', id=system_.id)
            .out('hosted_interfaces')
            .node('interface', if_type='port_channel', name='port_channel')
            .out('link')
            .node('link', name='link', role=role)
        )
    ))
    if len(paths) != 1:
        raise ValueError('LAG paths: Expected 1, got %s: %s' % (
            len(paths), paths
        ))
    return paths[0]['port_channel']


def get_mlag_domain_for_redundancy_group(
    blueprint: tt.Graph,
    group: GraphNodeOrId
) -> tt.GraphNode | None:
    group_ = _node(blueprint, group)
    return (blueprint.traverse(group_)
            .in_('composed_of_redundancy_group')
            .source('domain', domain_type='mlag')
            .first)


def get_mlag_vlan_for_redundancy_group(
    blueprint: tt.Graph,
    group: GraphNodeOrId
) -> tt.GraphNode | None:
    if _has_gai_index(blueprint, 'get_mlag_vlan_for_redundancy_group'):
        gai = blueprint.gai  # type: ignore[attr-defined]
        return gai.get_mlag_vlan_for_redundancy_group.get_node(group)

    group_ = _node(blueprint, group)
    return (blueprint.traverse(group_)
            .in_('composed_of_redundancy_group')
            .source('domain', domain_type='mlag')
            .out('composed_of_interfaces')
            .target('interface', if_type='svi')
            .out('member_of_vn_instance')
            .target('vn_instance')
            .out('instantiates')
            .target('virtual_network')
            .first)


def is_vlan_type_mlag(blueprint: tt.Graph, vn: GraphNodeOrId) -> bool:
    if _has_gai_index(blueprint, 'is_vlan_type_mlag'):
        return vn in blueprint.gai.is_vlan_type_mlag  # type: ignore[attr-defined]

    vn_ = _node(blueprint, vn)
    domain = (blueprint.traverse(vn_)
              .out('instantiated_by')
              .target('vn_instance')
              .out('member_interfaces')
              .target('interface', if_type='svi')
              .in_('composed_of_interfaces')
              .source('domain', domain_type='mlag')
              .first)
    return domain is not None


def is_mlag_vn_instance(blueprint: tt.Graph, vn_inst: GraphNodeOrId) -> bool:
    vn_inst_ = _node(blueprint, vn_inst)
    assert vn_inst_ is not None
    domain = (blueprint.traverse(vn_inst_)
              .out('member_interfaces')
              .target('interface', if_type='svi')
              .in_('composed_of_interfaces')
              .source('domain', domain_type='mlag')
              .first)
    return domain is not None


def get_node_by_label(
    blueprint: tt.Graph,
    node_type: str | tt.PropertyMatcher,
    label: str | tt.PropertyMatcher,
) -> tt.GraphNode | None:
    return blueprint.get_nodes(type=node_type, label=label).first


def get_system_by_label(blueprint: tt.Graph, label: str) -> tt.GraphNode | None:
    return get_node_by_label(blueprint, 'system', label)


def get_physical_interfaces(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    **interface_filters: te.Unpack[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.two_stage_l3clos.schema.INTERFACE_SCHEMA'
    ]]
) -> tt.GraphNodeIterator:
    system_ = _node(blueprint, system)
    interface_filters.update(if_type=is_in(['ethernet', 'ip']))
    return (blueprint.traverse(system_)
            .out('hosted_interfaces')
            .target('interface', **interface_filters))


def get_subinterfaces_from_interface(
    blueprint: tt.Graph,
    intf: GraphNodeOrId,
    subinterface_filters: t.Optional[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.two_stage_l3clos.schema.INTERFACE_SCHEMA'
    ]] = None
) -> tt.GraphNodeIterator | None:
    subinterface_filters = subinterface_filters or {}
    intf_ = _node(blueprint, intf)
    if not intf_:
        return None
    return (
        blueprint.traverse(intf_)
        .out('composed_of')
        .target('interface', if_type='subinterface', **subinterface_filters)
    )

def get_logical_link_between_subinterfaces(
    blueprint: tt.Graph,
    subinterface1: GraphNodeOrId,
    subinterface2: GraphNodeOrId
) -> tt.GraphNode | None:
    subinterface1_ = _node(blueprint, subinterface1)
    subinterface2_ = _node(blueprint, subinterface2)
    assert subinterface1_ is not None
    assert subinterface2_ is not None

    logical_links = list(
        path['logical_link']
        for path in _iterate(
            blueprint,
            match(
                qnode('interface', id=node_id(subinterface1_))
                .out('link')
                .node('link', link_type='logical_link', name='logical_link')
                .in_('link')
                .node('interface', id=node_id(subinterface2_))
            )
        )
    )
    if not logical_links:
        return None
    if len(logical_links) > 1:
        raise ValueError('Too many logical links found between %s and %s: %s' % (
            subinterface1, subinterface2, logical_links
        ))
    return logical_links[0]


def get_interface_hosting_subinterface(
    blueprint: tt.Graph,
    subinterface: GraphNodeOrId
) -> tt.GraphNode | None:
    subinterface_ = _node(blueprint, subinterface)
    return (blueprint.traverse(subinterface_)
            .in_('composed_of')
            .node('interface')
            .first)


def get_interface_by_subinterface(
    blueprint: tt.Graph,
    subinterface: GraphNodeOrId
) -> tt.GraphNode | None:
    subinterface_ = _node(blueprint, subinterface)
    return (
        blueprint.traverse(subinterface_)
        .in_('composed_of')
        .source('interface', if_type='ethernet')
    ).first


def get_physical_link_by_subinterface(
    blueprint: tt.Graph,
    subinterface: GraphNodeOrId
) -> tt.GraphNode | None:
    subinterface_ = _node(blueprint, subinterface)
    assert subinterface_ is not None
    interface = get_interface_by_subinterface(blueprint, subinterface_)
    return (
        blueprint.traverse(interface)
        .out('link')
        .node('link', link_type='ethernet')
    ).first


def get_system_hosting_subinterface(
    blueprint: tt.Graph,
    subinterface: GraphNodeOrId
) -> tt.GraphNode | None:
    subinterface_ = _node(blueprint, subinterface)
    return (blueprint.traverse(subinterface_)
            .in_('composed_of')
            .node('interface')
            .in_('hosted_interfaces')
            .source('system').first)


def get_subinterfaces_from_system(
    blueprint: tt.Graph,
    system: GraphNodeOrId
) -> tt.GraphNodeIterator:
    system_ = _node(blueprint, system)
    return (
        blueprint.traverse(system_)
        .out('hosted_interfaces')
        .target('interface', if_type=is_in(['ethernet', 'ip', 'port_channel']))
        .out('composed_of')
        .target('interface', if_type='subinterface')
    )


def get_subinterfaces_from_system_for_sz(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    security_zone: GraphNodeOrId
) -> list[tt.GraphNode]:
    system_ = _node(blueprint, system)
    security_zone_ = _node(blueprint, security_zone)
    assert system_ is not None
    assert security_zone_ is not None

    return list(
        path['subinterface']
        for path in _iterate(
            blueprint,
            match(
                qnode('system', id=node_id(system_))
                .out('hosted_interfaces')
                .node('interface', name='interface',
                      if_type=is_in(['ethernet', 'ip', 'port_channel']))
                .out('composed_of')
                .node('interface', if_type='subinterface', name='subinterface'),

                qnode('security_zone', id=node_id(security_zone_))
                .out('instantiated_by')
                .node('sz_instance')
                .out('member_interfaces')
                .node('interface', name='subinterface')
            )
        )
    )


def get_subinterfaces_from_systems_by_links(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    link_ids: t.Sequence[tt.GraphNodeId]
) -> list[tt.GraphNode]:
    system_ = _node(blueprint, system)
    assert system_ is not None

    return [
        path['subinterface']
        for path in _iterate(
            blueprint,
            match(
                qnode('system', id=node_id(system_))
                .out('hosted_interfaces')
                .node('interface', name='interface',
                      if_type=is_in(['ethernet', 'ip', 'port_channel']))
                .out('composed_of')
                .node('interface', if_type='subinterface', name='subinterface'),

                qnode(name='interface')
                .out('link')
                .node('link', id=is_in(link_ids))
            )
        )
    ]


def get_subinterface_peer(
    blueprint: tt.Graph,
    subinterface: GraphNodeOrId
) -> list[tt.GraphNode]:
    pattern = match(
        qnode('interface', id=node_id(subinterface), name='subinterface')
        .in_('composed_of')
        .node('interface')
        .out('link')
        .node('link')
        .in_('link')
        .node('interface')
        .out('composed_of')
        .node('interface', if_type='subinterface', name='remote_subinterface')
    ).ensure_different('subinterface', 'remote_subinterface')
    return [path['remote_subinterface'] for path in _iterate(blueprint, pattern)]


def is_interface_part_of_l3_link(
    blueprint: tt.Graph,
    interface: GraphNodeOrId
) -> bool:
    interface_ = _node(blueprint, interface)
    assert interface_ is not None
    subinterfaces = list(
        get_subinterfaces_from_interface(blueprint, interface_) or ()
    )
    return interface_.if_type == 'ethernet' and len(subinterfaces) > 0


def get_loopback_from_system_for_sz(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    security_zone: GraphNodeOrId
) -> list[tt.GraphNode]:
    system_ = _node(blueprint, system)
    security_zone_ = _node(blueprint, security_zone)

    pattern = match(
        qnode('system', id=node_id(system_))
        .out('hosted_interfaces')
        .node('interface', name='interface', if_type='loopback')
        .in_('member_interfaces')
        .node('sz_instance')
        .in_('instantiated_by')
        .node('security_zone', id=node_id(security_zone_))
    )
    return [path['interface'] for path in _iterate(blueprint, pattern)]


def get_interfaces(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    **iface_filters: te.Unpack[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.two_stage_l3clos.schema.INTERFACE_SCHEMA'
    ]]
) -> tt.GraphNodeIterator:
    system_ = _node(blueprint, system)
    return (blueprint.traverse(system_)
            .out('hosted_interfaces')
            .target('interface', **iface_filters))


def get_interface(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    if_name: str | tt.PropertyMatcher,
) -> tt.GraphNode | None:
    return get_interfaces(blueprint, system, if_name=if_name).first


def get_port_channel_interfaces(
    blueprint: tt.Graph,
    system: GraphNodeOrId
) -> tt.GraphNodeIterator:
    return get_interfaces(blueprint, system, if_type='port_channel')


def get_port_channel_by_interface(
    blueprint: tt.Graph,
    intf: GraphNodeOrId
) -> tt.GraphNode | None:
    intf_ = _node(blueprint, intf)
    return (blueprint.traverse(intf_)
            .in_('composed_of')
            .node('interface', if_type='port_channel')
            .first)


def get_port_channel_interfaces_by_control_protocol(
    blueprint: tt.Graph,
    po_control_protocol: t.Literal['mlag', 'evpn'] | tt.PropertyMatcher,
) -> tt.GraphNodeIterator:
    return blueprint.get_nodes('interface', if_type='port_channel',
                               po_control_protocol=po_control_protocol)


def get_toplevel_interfaces(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    if_types: t.Sequence[tt.InterfaceType] = ('ethernet', 'port_channel'),
    system_type: str | tt.PropertyMatcher = 'system',
) -> list[tt.GraphNode]:
    """
    For a given system return a list of its interfaces that are
    not a part of any parent interface.
    By default function returns only l2 (ethernet and port_channel)
    interfaces.
    """
    return list(
        path['interface']
        for path in _iterate(
            blueprint,
            match(
                qnode(system_type, id=node_id(system))
                .out('hosted_interfaces')
                .node('interface', name='interface', if_type=is_in(if_types))
                .having(qnode(name='interface').in_('composed_of'),
                        at_most=0)
            )
        )
    )

def get_toplevel_interface(
    blueprint: tt.Graph,
    interface: GraphNodeOrId
) -> tt.GraphNode | None:
    """
    For a given interface recurrently lookup for parent interfaces and return the top
    one (or initial interface itself if it's not a part of any other interfaces)
    """
    intf_ = _node(blueprint, interface)
    while True:
        parent_interface = (
            blueprint.traverse(intf_)
            .in_('composed_of')
            .source('interface', if_type='port_channel').first
        )
        if parent_interface is None:
            break
        intf_ = parent_interface
    return intf_


def get_systems_attached_to_link(
    blueprint: tt.Graph,
    link: GraphNodeOrId,
    **system_properties: te.Unpack[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.two_stage_l3clos.schema.SYSTEM_SCHEMA'
    ]]
) -> list[tt.GraphNode]:
    link_ = _node(blueprint, link)
    return list(blueprint.traverse(link_)
                .in_('link')
                .source('interface')
                .in_('hosted_interfaces')
                .source('system', **system_properties))


# NOTE: This method could be moved otside of search.py, because it's used only in
# ptests
def get_router_info(
    blueprint: tt.Graph,
    router_node: GraphNodeOrId
) -> RouterInfo:
    asn_node_ = get_system_asn_node(blueprint, router_node)
    loopback_intf_ = get_loopback_interface(blueprint, router_node)
    router_node_ = _node(blueprint, router_node)
    assert router_node_ is not None
    return RouterInfo(
        label=router_node_.label,
        asn=int(asn_node_.domain_id) if asn_node_ else None,
        loopback_ip=loopback_intf_.ipv4_addr if loopback_intf_ else None,
        loopback_ipv6=loopback_intf_.ipv6_addr if loopback_intf_ else None,
    )


def get_router_infos(blueprint: tt.Graph) -> list[RouterInfo]:
    return [
        get_router_info(blueprint, router)
        for router in get_router_nodes(blueprint)
    ]


def get_dhcp_server_ips(blueprint: tt.Graph) -> list[tt.IPAddress]:
    return list({
        dhcp_server
        for dhcp_policy in (
            blueprint.get_nodes('policy', policy_type='dhcp_relay')
            .where(lambda p: p.dhcp_servers)
        )
        for dhcp_server in dhcp_policy.dhcp_servers
    })


def get_neighbors(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    role: t.Optional[tt.SystemRole | tt.PropertyMatcher] = None,
    management_level: t.Optional[tt.ManagementLevel | tt.PropertyMatcher] = None,
    external: bool = False,
    link_properties: t.Optional[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.two_stage_l3clos.schema.LINK_SCHEMA'
    ]] = None,
) -> set[tt.GraphNode]:
    if is_node(system):
        system = system.id

    if t.TYPE_CHECKING:
        system = t.cast(tt.GraphNodeId, system)

    if not external:
        external_ = _or(is_none(), eq(False))
    else:
        external_ = eq(external)

    neighbor_filter: dict[str, str | tt.PropertyMatcher] = {
        'id': ne(system),
        'external': external_
    }
    # The semantics here is
    # 1. if argument is specified, query with the specified argument.
    # 2. if argument is not specified, query without argument.
    if isinstance(role, str):
        neighbor_filter['role'] = eq(role)
    elif role is not None:
        neighbor_filter['role'] = role

    if isinstance(management_level, str):
        neighbor_filter['management_level'] = eq(management_level)
    elif management_level is not None:
        neighbor_filter['management_level'] = management_level

    link_properties = link_properties or {}
    return {
        path['neighbor'] for path in _iterate(blueprint, (
            qnode(type=is_in(['system', 'redundancy_group']), id=system)
            .out('hosted_interfaces')
            .node('interface')
            .out('link')
            .node('link', **link_properties)
            .in_('link')
            .node('interface')
            .in_('hosted_interfaces')
            .node('system', name='neighbor', **neighbor_filter)
        ))
    }


def get_neighbor_interface(
    blueprint: tt.Graph,
    local_intf: GraphNodeOrId
) -> tt.GraphNode | None:
    local_intf_ = _node(blueprint, local_intf)
    assert local_intf_ is not None
    return next((
        path['intf'] for path in _iterate(
            blueprint,
            qnode('interface', id=local_intf_.id)
            .out('link')
            .node('link')
            .in_('link')
            .node('interface', name='intf', id=ne(local_intf_.id))
        )
    ), None)


def get_redundancy_groups_by_vn(
    blueprint: tt.Graph,
    vn: GraphNodeOrId,
    role: t.Optional[tt.SystemRole | tt.PropertyMatcher] = None
) -> list[tt.GraphNode]:
    if role is None and _has_gai_index(blueprint, 'get_redundancy_groups_by_vn'):
        gai = blueprint.gai  # type: ignore[attr-defined]
        return gai.get_redundancy_groups_by_vn.get_nodes(vn)

    vn_ = _node(blueprint, vn)
    return list(blueprint.traverse(vn_)
                .out('instantiated_by')
                .target('vn_instance')
                .in_('hosted_vn_instances')
                .source('system', role=role)
                .out('part_of_redundancy_group')
                .target('redundancy_group'))


def get_vn_instances_by_vn(
    blueprint: tt.Graph,
    vn: GraphNodeOrId
) -> tt.GraphNodeIterator:
    if _has_gai_index(blueprint, 'get_vn_instances_by_vn'):
        gai = blueprint.gai  # type: ignore[attr-defined]
        return gai.get_vn_instances_by_vn.get_nodes(vn)

    vn_ = _node(blueprint, vn)
    return (blueprint.traverse(vn_)
            .out('instantiated_by')
            .target('vn_instance'))


def get_vn_by_vn_instance(
    blueprint: tt.Graph,
    vn_inst: GraphNodeOrId
) -> tt.GraphNode | None:
    vn_inst_ = _node(blueprint, vn_inst)
    return (blueprint.traverse(vn_inst_)
            .out('instantiates')
            .target('virtual_network').first)


def get_svis_by_vn(blueprint: tt.Graph, vn: GraphNodeOrId) -> list[tt.GraphNode]:
    vn_ = _node(blueprint, vn)
    return list(blueprint.traverse(vn_)
                .out('instantiated_by')
                .target('vn_instance')
                .out('member_interfaces')
                .target('interface', if_type='svi'))


def get_svi_by_vn_instance(
    blueprint: tt.Graph,
    vn_inst: GraphNodeOrId
) -> tt.GraphNode | None:
    if _has_gai_index(blueprint, 'get_svi_by_vn_instance'):
        gai = blueprint.gai  # type: ignore[attr-defined]
        return gai.get_svi_by_vn_instance.get_node(vn_inst)

    vn_inst_ = _node(blueprint, vn_inst)
    return (blueprint.traverse(vn_inst_)
            .out('member_interfaces')
            .target('interface', if_type='svi')
            .first)


def get_vn_instance_by_svi(
    blueprint: tt.Graph,
    svi: GraphNodeOrId
) -> tt.GraphNode | None:
    svi_ = _node(blueprint, svi)
    return (blueprint.traverse(svi_)
            .out('member_of_vn_instance')
            .node('vn_instance').first)


def get_vn_by_svi(
    blueprint: tt.Graph,
    svi: GraphNodeOrId
) -> tt.GraphNode | None:
    svi_ = _node(blueprint, svi)
    assert svi_ is not None
    vn_instance = get_vn_instance_by_svi(blueprint, svi_)
    assert vn_instance is not None
    return get_vn_by_vn_instance(blueprint, vn_instance)


def get_system_hosting_svi(
    blueprint: tt.Graph,
    svi: GraphNodeOrId
) -> tt.GraphNode | None:
    svi_ = _node(blueprint, svi)
    return (blueprint.traverse(svi_)
            .out('member_of_vn_instance')
            .target('vn_instance')
            .in_('hosted_vn_instances')
            .source('system').one_or_none)


def get_svi_by_system_and_vn(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    vn: GraphNodeOrId
) -> tt.GraphNode | None:
    system_ = _node(blueprint, system)
    return next(
        (svi for svi in get_svis_by_vn(blueprint, vn)
         if get_system_hosting_svi(blueprint, svi) == system_),
        None
    )


def get_ip_endpoints_for_router(
    blueprint: tt.Graph,
    system: GraphNodeOrId
) -> list[tt.GraphNode]:
    system_ = _node(blueprint, system)
    return list(blueprint.traverse(system_)
                .out('hosted_interfaces')
                .target('interface')
                .out('hosted_vn_endpoints')
                .target('vn_endpoint')
                .in_('member_vn_endpoints')
                .source('ip_endpoint', endpoint_type='vip'))


def remote_gateways_associated_to_system(
    blueprint: tt.Graph,
    system: GraphNodeOrId
) -> tt.GraphNodeIterator:
    system_ = _node(blueprint, system)
    return (blueprint.traverse(system_)
            .out('hosted_interfaces')
            .target('interface', if_type='loopback')
            .out('protocol')
            .target('protocol')
            .in_('protocol')
            .source('interface', if_type='loopback')
            .in_('hosted_interfaces')
            .source('system', role='remote_gateway'))


def systems_associated_to_remote_gateway(
    blueprint: tt.Graph,
    remote_gateway: GraphNodeOrId,
    target_roles: t.Optional[t.Sequence[tt.SystemRole]] = None,
) -> tt.GraphNodeIterator:
    remote_gateway_ = _node(blueprint, remote_gateway)
    assert remote_gateway_ is not None
    assert remote_gateway_.role == 'remote_gateway'
    target_roles = target_roles or ['leaf', 'spine', 'superspine']
    assert isinstance(target_roles, list)
    return (blueprint.traverse(remote_gateway_)
            .out('hosted_interfaces')
            .node('interface', if_type='loopback')
            .out('protocol')
            .node('protocol')
            .in_('protocol')
            .node('interface', if_type='loopback')
            .in_('hosted_interfaces')
            .node('system', role=is_in(target_roles)))


def get_mlag_domain_vns(blueprint: tt.Graph) -> set[tt.GraphNode]:
    """Returns set of virtual network nodes that are used for mlag domain peer
    members"""
    return {
        vn
        for vn in (
            blueprint.traverse(node_type='domain')
            .out('composed_of_interfaces')
            .target('interface', if_type='svi')
            .out('member_of_vn_instance')
            .target('vn_instance')
            .out('instantiates')
            .target('virtual_network')
        )
    }


def get_composed_systems(
    blueprint: tt.Graph,
    group: GraphNodeOrId
) -> list[tt.GraphNode]:
    if _has_gai_index(blueprint, 'get_composed_systems'):
        gai = blueprint.gai  # type: ignore[attr-defined]
        return gai.get_composed_systems.get_nodes(group)
    group_ = _node(blueprint, group)
    return list(blueprint.traverse(group_)
                .out('composed_of_systems')
                .target('system'))


def get_hosted_interface_by_endpoint(
    blueprint: tt.Graph,
    endpoint: GraphNodeOrId
) -> tt.GraphNode | None:
    if _has_gai_index(blueprint, 'get_hosted_interface_by_endpoint'):
        gai = blueprint.gai  # type: ignore[attr-defined]
        return gai.get_hosted_interface_by_endpoint.get_node(endpoint)

    endpoint_ = _node(blueprint, endpoint)
    return (blueprint.traverse(endpoint_)
            .in_('hosted_vn_endpoints')
            .source('interface').first)


def get_hosted_system_by_endpoint(
    blueprint: tt.Graph,
    endpoint: GraphNodeOrId
) -> tt.GraphNode | None:
    endpoint_ = _node(blueprint, endpoint)
    return (blueprint.traverse(endpoint_)
            .in_('hosted_vn_endpoints')
            .source('interface')
            .in_('hosted_interfaces')
            .source('system').first)


def get_systems_hosting_vn_endpoints(
    blueprint: tt.Graph,
    endpoints: t.Sequence[GraphNodeOrId],
) -> set[tt.GraphNode]:
    endpoints_: list[tt.GraphNode] = [
        _node(blueprint, endpoint) for endpoint in endpoints  # type: ignore[misc]
    ]
    if not endpoints_:
        return set()

    return set(
        blueprint.traverse(endpoints_)
        .in_('hosted_vn_endpoints')
        .node('interface')
        .in_('hosted_interfaces')
        .node('system')
    )


def get_vn_endpoints_by_link(
    blueprint: tt.Graph,
    link_id: tt.GraphNodeId | tt.PropertyMatcher,
) -> tt.GraphNodeIterator:
    return (blueprint.get_nodes(id=link_id)
            .in_('link')
            .source('interface')
            .out('hosted_vn_endpoints')
            .target('vn_endpoint'))


def get_systems_hosting_ip_endpoint(
    blueprint: tt.Graph,
    ip_endpoint: GraphNodeOrId
) -> list[tt.GraphNode]:
    ip_endpoint_ = _node(blueprint, ip_endpoint)
    return list(blueprint.traverse(ip_endpoint_)
                .in_('hosted_ip_endpoints')
                .node('system'))


def get_vn_instances_by_system(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
) -> list[tt.GraphNode]:
    if _has_gai_index(blueprint, 'get_vn_instances_by_system'):
        gai = blueprint.gai  # type: ignore[attr-defined]
        return gai.get_vn_instances_by_system.get_nodes(system)

    system_ = _node(blueprint, system)
    return list(blueprint.traverse(system_)
                .out('hosted_vn_instances')
                .target('vn_instance'))


def get_system_by_vn_instance(
    blueprint: tt.Graph,
    vn_inst: GraphNodeOrId,
    role: t.Optional[tt.SystemRole] = None
) -> tt.GraphNode | None:
    if _has_gai_index(blueprint, 'get_system_by_vn_instance'):
        gai = blueprint.gai  # type: ignore[attr-defined]
        return gai.get_system_by_vn_instance.get_node(vn_inst, role)

    vn_inst_ = _node(blueprint, vn_inst)
    return (blueprint.traverse(vn_inst_)
            .in_('hosted_vn_instances')
            .source('system', role=role).first)


def get_vn_instance_by_vn_and_system(
    blueprint: tt.Graph,
    vnet: GraphNodeOrId,
    system: GraphNodeOrId
) -> tt.GraphNode | None:
    vnet_ = _node(blueprint, vnet)
    system_ = _node(blueprint, system)
    assert vnet_ is not None
    assert system_ is not None
    vnet_vn_instances = set(get_vn_instances_by_vn(blueprint, vnet_))
    system_vn_instances = set(get_vn_instances_by_system(blueprint, system_))

    if t.TYPE_CHECKING:
        vnet_vn_instances = t.cast(set[tt.GraphNode], vnet_vn_instances)
        system_vn_instances = t.cast(set[tt.GraphNode], system_vn_instances)

    vn_instances = list(vnet_vn_instances & system_vn_instances)
    assert len(vn_instances) <= 1, \
        'Too many vn_instances for vn %s and system %s' % (vnet, system)
    return vn_instances[0] if vn_instances else None


def get_virtual_network_by_endpoint(
    blueprint: tt.Graph,
    endpoint: GraphNodeOrId
) -> tt.GraphNode | None:
    if _has_gai_index(blueprint, 'get_virtual_network_by_endpoint'):
        gai = blueprint.gai  # type: ignore[attr-defined]
        return gai.get_virtual_network_by_endpoint.get_node(endpoint)

    endpoint_ = _node(blueprint, endpoint)
    if endpoint_ is None:
        return None
    return (blueprint.traverse(endpoint_)
            .out('member_of')
            .target('virtual_network').first)


def get_virtual_network_by_system_and_local_vlan_id(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    vlan_id: int | tt.PropertyMatcher,
) -> tt.GraphNode | None:
    '''Find virtual network under specified blueprint with specified
                vlan that is bound to specified node. '''
    system_ = _node(blueprint, system)
    return blueprint.traverse(system_).out('hosted_vn_instances').node(
        'vn_instance', vlan_id=vlan_id).out('instantiates').node(
            'virtual_network').first


def get_endpoints_hosted_by_interface_by_tag_type(
    blueprint: tt.Graph,
    interface: GraphNodeOrId,
    tag_type: tt.VnEndpointTagType | tt.PropertyMatcher,
) -> list[tt.GraphNode]:
    interface_ = _node(blueprint, interface)
    return list(blueprint.traverse(interface_)
                .out('hosted_vn_endpoints')
                .target('vn_endpoint', tag_type=tag_type))


def get_interface_hosting_vn_endpoint(
    blueprint: tt.Graph,
    vn_endpoint: GraphNodeOrId
) -> tt.GraphNode | None:
    vn_endpoint_ = _node(blueprint, vn_endpoint)
    return (blueprint.traverse(vn_endpoint_)
            .in_('hosted_vn_endpoints')
            .node('interface')
            .first)


def get_endpoints_hosted_by_interface(
    blueprint: tt.Graph,
    interface: GraphNodeOrId,
) -> list[tt.GraphNode]:
    interface_ = _node(blueprint, interface)
    return list(blueprint.traverse(interface_)
                .out('hosted_vn_endpoints')
                .target('vn_endpoint'))


def get_systems_hosting_endpoints_by_vn(
    blueprint: tt.Graph,
    vn: GraphNodeOrId
) -> list[tt.GraphNode]:
    vn_ = _node(blueprint, vn)

    return list(blueprint.traverse(vn_)
                .out('member_endpoints')
                .node('vn_endpoint')
                .in_('hosted_vn_endpoints')
                .node('interface')
                .in_('hosted_interfaces')
                .source('system'))


def get_virtual_network_endpoint_hosted_by_interface(
    blueprint: tt.Graph,
    interface: GraphNodeOrId,
    vnet: GraphNodeOrId,
    tag_type: tt.VnEndpointTagType | tt.PropertyMatcher,
) -> tt.GraphNodeId | None:
    interface_ = _node(blueprint, interface)
    vnet_node_ = _node(blueprint, vnet)
    assert interface_ is not None
    assert vnet_node_ is not None
    query = match(qnode('interface', id=interface_.id, name='server_intf')
                  .out('hosted_vn_endpoints')
                  .node('vn_endpoint', name='vn_endpoint', tag_type=tag_type)
                  .in_('member_endpoints')
                  .node('virtual_network', id=vnet_node_.id,
                        name='virtual_network')).distinct(['vn_endpoint'])
    vn_endpoint = next(_iterate(blueprint, query), {}).get('vn_endpoint')
    if vn_endpoint:
        return vn_endpoint.id
    return None


def get_mlag_interfaces_by_redundancy_group(
    blueprint: tt.Graph,
    group: GraphNodeOrId
) -> list[tt.GraphNode]:
    group_ = _node(blueprint, group)
    return list(blueprint.traverse(group_)
                .out('hosted_interfaces')
                .target('interface'))


def get_redundancy_group_by_mlag_interface(
    blueprint: tt.Graph,
    interface: GraphNodeOrId
) -> tt.GraphNode | None:
    interface_ = _node(blueprint, interface)
    return (blueprint.traverse(interface_)
            .in_('hosted_interfaces')
            .source('redundancy_group').first)


def get_mlag_interface_for_port_channel(
    blueprint: tt.Graph,
    pc_intf: GraphNodeOrId
) -> tt.GraphNode | None:
    pc_intf_ = _node(blueprint, pc_intf)
    return (blueprint.traverse(pc_intf_)
            .in_('composed_of')
            .source('interface', if_type='port_channel').first)


def get_child_interfaces(
    blueprint: tt.Graph,
    intf: GraphNodeOrId,
    if_type: tt.InterfaceType | tt.PropertyMatcher,
) -> tt.GraphNodeIterator:
    intf_ = _node(blueprint, intf)
    return (blueprint.traverse(intf_)
            .out('composed_of')
            .target('interface', if_type=if_type))


def get_port_channels_for_mlag_interface(
    blueprint: tt.Graph,
    mlag_intf: GraphNodeOrId
) -> tt.GraphNodeIterator:
    mlag_intf_ = _node(blueprint, mlag_intf)
    assert mlag_intf_ is not None
    return get_child_interfaces(blueprint, mlag_intf_, 'port_channel')


def get_hosted_virtual_networks_by_system(
    blueprint: tt.Graph,
    system: GraphNodeOrId
) -> list[tt.GraphNode]:
    system_ = _node(blueprint, system)
    return list(blueprint.traverse(system_)
                .out('hosted_vn_instances')
                .target('vn_instance')
                .out('instantiates')
                .target('virtual_network'))


def get_systems_hosting_virtual_network(
    blueprint: tt.Graph,
    vnet: GraphNodeOrId,
    roles: t.Sequence[tt.SystemRole] = ('leaf',),
) -> list[tt.GraphNode]:
    vnet_ = _node(blueprint, vnet)
    return list(blueprint.traverse(vnet_)
                .out('instantiated_by')
                .target('vn_instance')
                .in_('hosted_vn_instances')
                .source('system', role=is_in(roles)))


def get_domains_by_remote_gateway(
    blueprint: tt.Graph,
    remote_gateway_id: tt.GraphNodeId | tt.PropertyMatcher,
) -> tt.GraphNodeIterator:
    return blueprint.get_nodes('system', role='remote_gateway',
                               id=remote_gateway_id) \
                    .in_('composed_of_systems') \
                    .source('domain', domain_type='autonomous_system')


def get_systems_hosting_virtual_networks(
    blueprint: tt.Graph,
    vnet_ids: t.Sequence[tt.GraphNodeId],
    roles: t.Sequence[tt.SystemRole] = ('leaf',),
) -> tt.GraphNodeIterator:
    return blueprint.get_nodes('virtual_network', id=is_in(vnet_ids)) \
                    .out('instantiated_by') \
                    .target('vn_instance') \
                    .in_('hosted_vn_instances') \
                    .source('system', role=is_in(roles))


def get_system_servers(
    blueprint: tt.Graph,
    system: GraphNodeOrId
) -> list[tt.GraphNode]:
    system_ = _node(blueprint, system)
    return list(set(
        blueprint.traverse(system_)
        .out('hosted_interfaces')
        .target('interface').out('link')
        .target('link').in_('link')
        .source('interface').in_('hosted_interfaces')
        .source('system', system_type='server', role='generic')))


def get_system_links(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    link_filters: t.Optional[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.two_stage_l3clos.schema.LINK_SCHEMA'
    ]] = None,
    interface_filters: t.Optional[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.two_stage_l3clos.schema.INTERFACE_SCHEMA'
    ]] = None,
) -> tt.GraphNodeIterator:
    link_filters = link_filters or {}
    interface_filters = interface_filters or {}
    system_ = _node(blueprint, system)
    return (blueprint.traverse(system_)
            .out('hosted_interfaces')
            .target('interface', **interface_filters)
            .out('link')
            .target('link', **link_filters))


def get_switches_by_system(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    switch_role: t.Optional[tt.SystemRole | tt.PropertyMatcher] = None,
) -> t.Iterator[tt.GraphNode]:
    if switch_role is None:
        switch_role = is_in(('leaf', 'access'))
    system_ = _node(blueprint, system)
    assert system_ is not None
    return (path['node'] for path in _iterate(
        blueprint,
        qnode('system', id=system_.id)
        .out('hosted_interfaces')
        .node('interface')
        .out('link')
        .node('link')
        .in_('link')
        .node('interface')
        .in_('hosted_interfaces')
        .node(
            'system',
            name='node',
            system_type='switch',
            id=ne(system_.id),
            role=switch_role)))


def get_switch_by_system(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    switch_role: t.Optional[tt.SystemRole | tt.PropertyMatcher] = None,
) -> tt.GraphNode | None:
    return next(get_switches_by_system(blueprint, system, switch_role), None)


def get_systems_by_switch(
    blueprint: tt.Graph,
    switch: GraphNodeOrId,
    link_filters: t.Optional[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.two_stage_l3clos.schema.LINK_SCHEMA'
    ]] = None,
    system_filters: t.Optional[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.two_stage_l3clos.schema.SYSTEM_SCHEMA'
    ]] = None,
) -> list[tt.GraphNode]:
    link_filters = link_filters or {}
    system_filters = system_filters or {}
    switch_ = _node(blueprint, switch)
    assert switch_ is not None
    system_filters['id'] = ne(switch_.id)

    return [
        path['node'] for path in _iterate(
            blueprint,
            qnode('system', id=switch_.id)
            .out('hosted_interfaces')
            .node('interface')
            .out('link')
            .node('link', name='link', **link_filters)
            .in_('link')
            .node('interface')
            .in_('hosted_interfaces')
            .node('system', name='node', **system_filters)
        )
    ]


def get_virtual_network_endpoints(
    blueprint: tt.Graph,
    vnet: GraphNodeOrId
) -> list[tt.GraphNode]:
    vnet_ = _node(blueprint, vnet)
    return list(blueprint.traverse(vnet_)
                .out('member_endpoints')
                .target('vn_endpoint'))


def get_virtual_network_by_vn_endpoint(
    blueprint: tt.Graph,
    vn_endpoint: GraphNodeOrId
) -> tt.GraphNode | None:
    vn_endpoint_ = _node(blueprint, vn_endpoint)
    return (blueprint.traverse(vn_endpoint_)
            .in_('member_endpoints')
            .source('virtual_network')).first


def get_virtual_network_interfaces(
    blueprint: tt.Graph,
    vnet: GraphNodeOrId
) -> list[tt.GraphNode]:
    vnet_ = _node(blueprint, vnet)
    return list(blueprint.traverse(vnet_)
                .out('member_endpoints')
                .target('vn_endpoint')
                .in_('hosted_vn_endpoints')
                .source('interface'))


def get_virtual_network_from_interface(
    blueprint: tt.Graph,
    interface: GraphNodeOrId
) -> list[tt.GraphNode]:
    interface_ = _node(blueprint, interface)
    return list(blueprint.traverse(interface_)
                .out().target('vn_endpoint')
                .out().target('virtual_network'))


def get_virtual_network_ip_endpoints(
    blueprint: tt.Graph,
    vnet: GraphNodeOrId,
    endpoint_type: tt.IpEndpointType | tt.PropertyMatcher = 'vip'
) -> tt.GraphNodeIterator:
    vnet_ = _node(blueprint, vnet)
    return (blueprint.traverse(vnet_)
            .in_('member_of')
            .source('ip_endpoint', endpoint_type=endpoint_type))


def get_virtual_network_by_ip_endpoint(
    blueprint: tt.Graph,
    ip_endpoint: GraphNodeOrId
) -> tt.GraphNode | None:
    ip_endpoint_ = _node(blueprint, ip_endpoint)
    if ip_endpoint_ is None:
        return None
    return (blueprint.traverse(ip_endpoint_)
            .out('member_of')
            .node('virtual_network')
            .first)


def get_virtual_network_subinterfaces(
    blueprint: tt.Graph,
    vnet: GraphNodeOrId
) -> tt.GraphNodeIterator:
    vnet_ = _node(blueprint, vnet)
    return (blueprint.traverse(vnet_)
            .out('member_interfaces')
            .node('interface', if_type='subinterface'))


def get_vn_endpoints_by_virtual_network_ip_endpoint(
    blueprint: tt.Graph,
    ip_endpoint: GraphNodeOrId
) -> list[tt.GraphNode]:
    ip_endpoint_ = _node(blueprint, ip_endpoint)
    return list(blueprint.traverse(ip_endpoint_)
                .out('member_vn_endpoints')
                .target('vn_endpoint'))


def get_hosting_generics_by_ip_endpoint(
    blueprint: tt.Graph,
    ip_endpoint: GraphNodeOrId
) -> list[tt.GraphNode] | None:
    ip_endpoint_ = _node(blueprint, ip_endpoint)
    if not ip_endpoint_:
        return None
    return list(blueprint.traverse(ip_endpoint_)
                .in_('hosted_ip_endpoints')
                .source('system', role='generic'))


def get_ip_endpoints_by_generic_system(
    blueprint: tt.Graph,
    system: GraphNodeOrId
) -> list[tt.GraphNode]:
    system_ = _node(blueprint, system)
    return list(blueprint.traverse(system_)
                .out('hosted_ip_endpoints')
                .target('ip_endpoint'))


def get_hosted_sz_instances_by_system(
    blueprint: tt.Graph,
    system: GraphNodeOrId
) -> list[tt.GraphNode]:
    system_ = _node(blueprint, system)
    return list(blueprint.traverse(system_)
                .out('hosted_sz_instances')
                .target('sz_instance'))


def get_active_evpn_security_zones(
    blueprint: tt.Graph,
    system: GraphNodeOrId
) -> tt.GraphNodeIterator:
    system_ = _node(blueprint, system)
    return (
        blueprint.traverse(system_)
        .out('hosted_sz_instances')
        .node('sz_instance', state='active')
        .in_('instantiated_by')
        .node('security_zone', sz_type='evpn'))


def get_hosted_sz_instances_by_system_and_sz(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    sz: GraphNodeOrId,
) -> set[tt.GraphNode]:
    system_ = _node(blueprint, system)
    sz_ = _node(blueprint, sz)
    assert system_ is not None
    assert sz_ is not None
    query = (
        qnode('system', id=system_.id)
        .out('hosted_sz_instances')
        .node('sz_instance', name='sz_instance')
        .in_('instantiated_by')
        .node('security_zone', id=sz_.id)
    )
    return {path['sz_instance'] for path in _iterate(blueprint, query)}


def get_virtual_networks_by_security_zone(
    blueprint: tt.Graph,
    security_zone: GraphNodeOrId
) -> list[tt.GraphNode]:
    security_zone_ = _node(blueprint, security_zone)
    return list(blueprint.traverse(security_zone_)
                .out('member_vns')
                .target('virtual_network'))


def get_security_zone_from_virtual_network(
    blueprint: tt.Graph,
    virtual_network: GraphNodeOrId
) -> tt.GraphNode | None:
    virtual_network_ = _node(blueprint, virtual_network)
    return blueprint.traverse(virtual_network_)\
                    .in_('member_vns')\
                    .source('security_zone').first


def get_security_zone_by_ip_endpoint(
    blueprint: tt.Graph,
    ip_endpoint: GraphNodeOrId
) -> tt.GraphNode | None:
    vn = get_virtual_network_by_endpoint(blueprint, ip_endpoint)
    assert vn is not None
    return get_security_zone_from_virtual_network(blueprint, vn)


def get_security_zones_by_application_points(
    blueprint: tt.Graph,
    app_points: t.Iterable[GraphNodeOrId],
) -> set[tt.GraphNode]:
    results: set[tt.GraphNode] = set()

    for app_point in app_points:
        security_zone = get_security_zone_by_application_point(
            blueprint,
            app_point
        )
        if security_zone:
            results.add(security_zone)

    return results


def get_security_zone_by_application_point(
    blueprint: tt.Graph,
    app_point: GraphNodeOrId
) -> tt.GraphNode | None:
    app_point_ = _node(blueprint, app_point)
    assert app_point_ is not None
    app_point_type = (app_point_.endpoint_type
                      if app_point_.type == 'ip_endpoint' else app_point_.type)
    if app_point_type == 'security_zone':
        return app_point_

    if _has_gai_index(blueprint, 'get_security_zone_by_application_point'):
        gai = blueprint.gai  # type: ignore[attr-defined]
        return gai.get_security_zone_by_application_point.get_node(app_point_)

    if app_point_type == 'virtual_network':
        return get_security_zone_from_virtual_network(blueprint, app_point_)
    elif app_point_type == 'internal':
        return get_security_zone_by_ip_endpoint(blueprint, app_point_)

    raise RuntimeError('Application point should be a routing zone, virtual '
                       'network or internal IP endpoint')


def get_loopbacks_from_security_zone(
    blueprint: tt.Graph,
    security_zone: GraphNodeOrId
) -> tt.GraphNodeIterator:
    security_zone_ = _node(blueprint, security_zone)
    return blueprint.traverse(security_zone_)\
                    .out('instantiated_by')\
                    .target('sz_instance')\
                    .out('member_interfaces')\
                    .target('interface', if_type='loopback')


def get_link_by_interface(
    blueprint: tt.Graph,
    interface: GraphNodeOrId
) -> tt.GraphNode | None:
    interface_ = _node(blueprint, interface)
    return blueprint.traverse(interface_).out('link').node('link').one_or_none


def get_security_zone_by_interface(
    blueprint: tt.Graph,
    interface: GraphNodeOrId
) -> tt.GraphNode | None:
    interface_ = _node(blueprint, interface)
    return (blueprint.traverse(interface_)
            .in_('member_interfaces')
            .node('sz_instance')
            .in_('instantiated_by')
            .node('security_zone').first)


def get_default_security_zone(blueprint: tt.Graph) -> tt.GraphNode | None:
    return blueprint.get_nodes('security_zone', sz_type='l3_fabric').first


def get_default_routing_policy(blueprint: tt.Graph) -> tt.GraphNode | None:
    return blueprint.get_nodes(
        'routing_policy', policy_type='default_immutable').one_or_none


def get_security_zones_attached_to_routing_policy(
    blueprint: tt.Graph,
    routing_policy: GraphNodeOrId
) -> tt.GraphNodeIterator:
    routing_policy_ = _node(blueprint, routing_policy)
    return blueprint.traverse(routing_policy_).in_('policy').source('security_zone')

def get_routing_policy_attached_to_security_zone(
    blueprint: tt.Graph,
    security_zone: GraphNodeOrId
) -> tt.GraphNode | None:
    security_zone_ = _node(blueprint, security_zone)
    return (blueprint.traverse(security_zone_)
            .out('policy')
            .target('routing_policy').one_or_none)

def get_security_zone_dhcp_policy(
    blueprint: tt.Graph,
    security_zone: GraphNodeOrId
) -> tt.GraphNode | None:
    security_zone_ = _node(blueprint, security_zone)
    return blueprint.traverse(security_zone_)\
                    .out('policy')\
                    .target('policy', policy_type='dhcp_relay').first


def get_routing_policy_by_application_point(
    blueprint: tt.Graph,
    application_point: GraphNodeOrId
) -> tt.GraphNode | None:
    """returns routing policy directly linked to application point
    :param Node application_point: routing zone or protocol endpoint node
    """
    application_point_ = _node(blueprint, application_point)
    return blueprint.traverse(application_point_)\
                    .out('policy')\
                    .target('routing_policy').one_or_none


def get_security_zone_route_target_policy(
    blueprint: tt.Graph,
    security_zone: GraphNodeOrId
) -> tt.GraphNode | None:
    security_zone_ = _node(blueprint, security_zone)
    return blueprint.traverse(security_zone_)\
                    .out('route_target_policy')\
                    .target('route_target_policy').first


def get_security_zone_tenant(
    blueprint: tt.Graph,
    security_zone: GraphNodeOrId
) -> tt.GraphNode | None:
    security_zone_ = _node(blueprint, security_zone)
    return blueprint.traverse(
        security_zone_).out('tenant').node('tenant').one_or_none


def get_assigned_to_tenant(
    blueprint: tt.Graph,
    tenant: GraphNodeOrId
) -> tt.GraphNodeIterator:
    tenant_ = _node(blueprint, tenant)
    return blueprint.traverse(tenant_).in_('tenant').node()


def get_virtual_network_route_target_policy(
    blueprint: tt.Graph,
    virtual_network: GraphNodeOrId
) -> tt.GraphNode | None:
    virtual_network_ = _node(blueprint, virtual_network)
    return blueprint.traverse(virtual_network_)\
                    .out('route_target_policy')\
                    .target('route_target_policy').first


def get_protocol_endpoints_attached_to_routing_policy(
    blueprint: tt.Graph,
    routing_policy: GraphNodeOrId
) -> tt.GraphNodeIterator:
    routing_policy_ = _node(blueprint, routing_policy)
    return blueprint.traverse(routing_policy_)\
                    .in_('policy')\
                    .source('protocol_endpoint')


def get_protocol_ospf_policy(
    blueprint: tt.Graph,
    protocol: GraphNodeOrId
) -> tt.GraphNode | None:
    protocol_ = _node(blueprint, protocol)
    return blueprint.traverse(protocol_)\
                    .out('ospf_policy')\
                    .target('ospf_policy').first


def get_protocol_ospf_domain(
    blueprint: tt.Graph,
    protocol: GraphNodeOrId
) -> tt.GraphNode | None:
    protocol_ = _node(blueprint, protocol)
    return blueprint.traverse(protocol_)\
                    .in_('ospf_domain')\
                    .source('domain').first


def get_rack_by_switch(
    blueprint: tt.Graph,
    switch: GraphNodeOrId
) -> tt.GraphNode | None:
    switch_ = _node(blueprint, switch)
    return (blueprint.traverse(switch_).out('part_of_rack').node('rack')).first


def get_rack_by_generic(
    blueprint: tt.Graph,
    generic_id: GraphNodeOrId
) -> tt.GraphNode | None:
    generic_ = _node(blueprint, generic_id)
    assert generic_ is not None
    if generic_.external:
        return None
    return (blueprint.traverse(generic_)
            .out('hosted_interfaces')
            .node('interface')
            .out('link')
            .node('link')
            .in_('link')
            .node('interface', if_type=is_in(['ip', 'ethernet']))
            .in_('hosted_interfaces')
            .node('system', role=is_in(['leaf', 'access']))
            .out('part_of_rack')
            .node('rack')).first


def get_pod_by_rack(
    blueprint: tt.Graph,
    rack: GraphNodeOrId
) -> tt.GraphNode | None:
    rack_ = _node(blueprint, rack)
    return (blueprint.traverse(rack_).in_('part_of_rack')
            .node('system', role='leaf').out('part_of_pod')
            .node('pod')).first


def get_leafs_by_rack(
    blueprint: tt.Graph,
    rack: GraphNodeOrId,
    **leaf_filters: te.Unpack[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.two_stage_l3clos.schema.SYSTEM_SCHEMA'
    ]]
) -> tt.GraphNodeIterator:
    return get_switches_by_rack(blueprint, rack, switch_role='leaf', **leaf_filters)


def get_access_switches_by_rack(
    blueprint: tt.Graph,
    rack: GraphNodeOrId,
    **access_filters: te.Unpack[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.two_stage_l3clos.schema.SYSTEM_SCHEMA'
    ]]
) -> tt.GraphNodeIterator:
    return get_switches_by_rack(
        blueprint, rack, switch_role='access', **access_filters)


def get_switches_by_rack(
    blueprint: tt.Graph,
    rack: GraphNodeOrId,
    switch_role: t.Optional[tt.SystemRole | tt.PropertyMatcher] = None,
    **switch_filters: te.Unpack[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.two_stage_l3clos.schema.SYSTEM_SCHEMA'
    ]]
) -> tt.GraphNodeIterator:
    switch_role_ = eq(switch_role) if switch_role else is_in(('access', 'leaf'))
    rack_ = _node(blueprint, rack)
    return (blueprint.traverse(rack_).in_('part_of_rack')
            .node('system', role=switch_role_, **switch_filters))


def get_racks_by_pod(blueprint: tt.Graph, pod: GraphNodeOrId) -> list[tt.GraphNode]:
    pod_ = _node(blueprint, pod)
    assert pod_ is not None
    query = match(qnode('pod', id=pod_.id)
                  .in_('part_of_pod')
                  .node('system')
                  .out('part_of_rack')
                  .node('rack', name='rack')).distinct(['rack'])

    return [path['rack'] for path in _iterate(blueprint, query)]


def get_systems_by_pod(
    blueprint: tt.Graph,
    pod: GraphNodeOrId,
    **system_filters: te.Unpack[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.two_stage_l3clos.schema.SYSTEM_SCHEMA'
    ]]
) -> list[tt.GraphNode]:
    pod_ = _node(blueprint, pod)
    assert pod_ is not None
    query = match(qnode('pod', id=pod_.id)
                  .in_('part_of_pod')
                  .node('system', name='system', **system_filters)
                 ).distinct(['system'])

    return [path['system'] for path in _iterate(blueprint, query)]


def get_pod_by_system(
    blueprint: tt.Graph,
    system: GraphNodeOrId
) -> tt.GraphNode | None:
    system_ = _node(blueprint, system)

    return blueprint.traverse(system_).out('part_of_pod').node('pod').first


def get_servers_by_pod(
    blueprint: tt.Graph,
    pod: GraphNodeOrId
) -> set[tt.GraphNode]:
    pod_ = _node(blueprint, pod)
    assert pod_ is not None

    servers = set()
    for switch in list(get_systems_by_pod(blueprint, pod_,
                                          role=is_in(['leaf', 'access']))):
        for server in get_system_servers(blueprint, switch):
            servers.add(server)
    return servers


def get_all_top_of_rack_nodes(g: tt.Graph) -> list[tt.GraphNode]:
    """
    return a collection of leaf systems (single leafs and redundancy group if mlag)
    """
    bound_to = []
    for leaf in g.get_nodes('system', role='leaf'):
        rg = get_system_redundancy_group(g, leaf)
        if rg:
            if rg not in bound_to:
                bound_to.append(rg)
        else:
            bound_to.append(leaf)
    return bound_to


def get_all_top_of_rack_nodes_in_rack(
    g: tt.Graph,
    rack: GraphNodeOrId
) -> list[tt.GraphNode]:
    rg_or_leaf_ids = set()
    for leaf in get_leafs_by_rack(g, rack):
        rg = get_system_redundancy_group(g, leaf)
        if rg:
            rg_or_leaf_ids.add(rg.id)
        else:
            rg_or_leaf_ids.add(leaf.id)

    rv: list[tt.GraphNode] = []
    for _id in rg_or_leaf_ids:
        if (v := g.get_node(_id)) is not None:
            rv.append(v)

    return rv


def get_neighbor_redundancy_groups(
    g: tt.Graph,
    rg: GraphNodeOrId,
    neighbor_role: tt.SystemRole | tt.PropertyMatcher
) -> set[tt.GraphNode]:
    rg_ = _node(g, rg)
    assert rg_ is not None
    return {
        path['neighbor'] for path in _iterate(g, (
            match(
                qnode('redundancy_group', name='rg', id=rg_.id)
                .out('hosted_interfaces')
                .node('interface')
                .out('link')
                .node('link')
                .in_('link')
                .node('interface')
                .in_('hosted_interfaces')
                .node('redundancy_group', name='neighbor')
                .having(qnode('redundancy_group', name='neighbor')
                        .in_('part_of_redundancy_group')
                        .node('system', role=neighbor_role), at_least=1))
            .ensure_different('rg', 'neighbor')))
    }


def get_policy_application_points(
    blueprint: tt.Graph,
    policy: GraphNodeOrId,
    policy_direction: t.Optional[
        t.Literal['from', 'to'] | tt.PropertyMatcher
    ] = None,
) -> tt.GraphNodeIterator:
    policy_ = _node(blueprint, policy)
    # Any type of node is a valid target,
    # so not specifying node type in the last 'node()' call
    return blueprint.traverse(policy_)\
        .in_('security_policy', policy_direction=policy_direction)\
        .node()


def deep_resolve_application_point(
    blueprint: tt.Graph,
    app_point: GraphNodeOrId
) -> set[tt.GraphNode]:
    """
    Gets all application points. If needed, recursively resolves groups
    till final application points
    """
    app_point_ = _node(blueprint, app_point)
    assert app_point_ is not None
    if app_point_.type != 'group':
        return {app_point_}
    return get_posterity_group_members(blueprint, [app_point_])


def get_posterity_group_members(
    blueprint: tt.Graph,
    start_groups: t.Iterable[GraphNodeOrId],
) -> set[tt.GraphNode]:
    result: set[tt.GraphNode] = set()
    for group in get_posterity(blueprint, start_groups):
        result.update(get_group_members(blueprint, group, member_type=is_in([
            'security_zone', 'ip_endpoint', 'virtual_network', 'interface'
        ])))
    return result


def get_next_security_rule(
    blueprint: tt.Graph,
    sec_rule: GraphNodeOrId,
) -> tt.GraphNode | None:
    sec_rule_ = _node(blueprint, sec_rule)
    return blueprint.traverse(sec_rule_)\
        .out('followed_by')\
        .node('security_rule').first


def get_previous_security_rule(
    blueprint: tt.Graph,
    sec_rule: GraphNodeOrId
) -> tt.GraphNode | None:
    sec_rule_ = _node(blueprint, sec_rule)
    return blueprint.traverse(sec_rule_)\
        .in_('followed_by')\
        .node('security_rule').first


def get_rules_by_policy(
    blueprint: tt.Graph,
    policy: GraphNodeOrId,
    rule_node_type: t.Optional[str | tt.PropertyMatcher] = None,
) -> tt.GraphNodeIterator:
    """
    Return all rules for a given policy
    """
    policy_ = _node(blueprint, policy)
    return blueprint.traverse(policy_).out('has_rule').node(rule_node_type)


def get_policy_by_rule(
    blueprint: tt.Graph,
    rule: GraphNodeOrId,
) -> tt.GraphNode | None:
    rule_ = _node(blueprint, rule)
    return blueprint.traverse(rule_).in_('has_rule').node('policy').first


def get_ordered_security_rules_by_policy(
    blueprint: tt.Graph,
    policy: GraphNodeOrId
) -> list[tt.GraphNode]:
    """
    Returns all security_rules for a given policy as ordered list.

    1. Retrieves unordered list of rules.
    2. Goes backward-depth from each of them using reversed 'followed_by' edges,
       stopping on already visited rules.
    3. Appends the rule to ordered list on exit from backward-depth traversing.
    """
    visited_rules: set[GraphNodeOrId] = set()
    ordered_rules: list[tt.GraphNode] = []

    def dfs(rule: tt.GraphNode | None) -> None:
        if rule is None or rule in visited_rules:
            return
        visited_rules.add(rule)
        dfs(get_previous_security_rule(blueprint, rule))
        ordered_rules.append(rule)

    for rule in get_rules_by_policy(blueprint, policy, 'security_rule'):
        dfs(rule)

    return ordered_rules


def get_routing_zone_constraints_by_group(
    blueprint: tt.Graph,
    group: GraphNodeOrId,
) -> tt.GraphNodeIterator:
    group_ = _node(blueprint, group)
    return blueprint.traverse(group_)\
                    .in_('constraint')\
                    .node('routing_zone_constraint')


def get_constraints_for_rz_constraint(
    blueprint: tt.Graph,
    rz_constraint: GraphNodeOrId,
    rz_constraint_filters: t.Optional[
        _MAGIC.lollipop_type[
            'aos.sdk.reference_design.two_stage_l3clos.schema.SECURITY_ZONE_SCHEMA'
        ] | _MAGIC.lollipop_type[
            'aos.sdk.reference_design.two_stage_l3clos.schema.GROUP_SCHEMA'
        ]
    ] = None
) -> tt.GraphNodeIterator:
    rz_constraint_filters = \
        rz_constraint_filters or {'type': is_in(['security_zone', 'group'])}
    cp_ = _node(blueprint, rz_constraint)
    return blueprint.traverse(cp_).out('constraint').node(**rz_constraint_filters)


def get_ip_endpoints(
    blueprint: tt.Graph,
    endpoint_type: str | tt.PropertyMatcher,
) -> tt.GraphNodeIterator:
    return blueprint.get_nodes('ip_endpoint', endpoint_type=endpoint_type)


def get_ip_endpoints_by_virtual_network(
    blueprint: tt.Graph,
    vn: GraphNodeOrId,
    endpoint_type: t.Optional[tt.IpEndpointType | tt.PropertyMatcher] = None,
) -> tt.GraphNodeIterator:
    vn_ = _node(blueprint, vn)
    return blueprint.traverse(vn_)\
                    .in_('member_of')\
                    .node('ip_endpoint', endpoint_type=endpoint_type)


def get_subinterfaces_by_virtual_network(
    blueprint: tt.Graph,
    vn: GraphNodeOrId
) -> tt.GraphNodeIterator:
    vn_ = _node(blueprint, vn)
    return blueprint.traverse(vn_)\
                    .out('member_interfaces')\
                    .node('interface', if_type='subinterface')


def get_group_members(
    blueprint: tt.Graph,
    group: GraphNodeOrId,
    member_type: t.Optional[str | tt.PropertyMatcher] = None,
) -> tt.GraphNodeIterator:
    # Any relationship of type 'member_of' originates from valid member
    # so not specifying node type
    group_ = _node(blueprint, group)
    return blueprint.traverse(group_).in_('member_of').node(type=member_type)


def get_group_parents(
    blueprint: tt.Graph,
    group: GraphNodeOrId,
    group_type: t.Optional[str | tt.PropertyMatcher] = None,
) -> tt.GraphNodeIterator:
    # Any relationship of type 'member_of' goes to a valid parent
    # so not specifying node type
    group_ = _node(blueprint, group)
    return blueprint.traverse(group_).out('member_of').node(type=group_type)


def get_bound_enforcement_points(
    blueprint: tt.Graph,
    node: GraphNodeOrId
) -> tt.GraphNodeIterator:
    node_ = _node(blueprint, node)
    # Enforcement point can be represented by individual interface or enforcement
    # point group. Any 'bound_to' relationship points to a valid enforcement point,
    # regardless of its node type.
    return blueprint.traverse(node_).out('bound_to').node()


def get_system_by_enforcement_point(
    blueprint: tt.Graph,
    enforcement_point: GraphNodeOrId,
) -> tt.GraphNode | None:
    enforcement_point_ = _node(blueprint, enforcement_point)
    assert enforcement_point_ is not None
    if enforcement_point_.if_type == 'svi':
        return get_system_hosting_svi(blueprint, enforcement_point_)
    else:
        return get_system_hosting_subinterface(blueprint, enforcement_point_)


def get_virtual_network_by_enforcement_point(
    blueprint: tt.Graph,
    enforcement_point: GraphNodeOrId
) -> tt.GraphNode | None:
    enforcement_point_ = _node(blueprint, enforcement_point)
    assert enforcement_point_ is not None
    return blueprint.traverse(enforcement_point_) \
        .out('member_of_vn_instance') \
        .node('vn_instance') \
        .in_('instantiated_by') \
        .node('virtual_network').first


def get_subinterfaces_via_protocol_session(
    blueprint: tt.Graph,
    interface: GraphNodeOrId,
) -> list[tt.GraphNode]:
    interface_ = _node(blueprint, interface)
    assert interface_ is not None
    return list(
        blueprint.traverse(interface_)
        .in_('layered_over')
        .node('protocol_endpoint')
        .in_('instantiates')
        .node('protocol_session')
        .out('instantiates')
        .node('protocol_endpoint')
        .out('layered_over')
        .node('interface', if_type='subinterface')
    )


def get_protocol_session_via_application_point(
    blueprint: tt.Graph,
    application_point: GraphNodeOrId,
) -> tt.GraphNode | None:
    application_point_ = _node(blueprint, application_point)
    assert application_point_ is not None
    return (blueprint.traverse(application_point_)
            .in_('layered_over')
            .source('protocol_endpoint')
            .in_('instantiates')
            .source('protocol_session').one_or_none)

def get_protocol_session_via_application_point_peers(
    blueprint: tt.Graph,
    application_point1: GraphNodeOrId,
    application_point2: GraphNodeOrId,
) -> dict[str, tt.GraphNode] | None:
    application_point1_ = _node(blueprint, application_point1)
    application_point2_ = _node(blueprint, application_point2)

    assert application_point1_ is not None
    assert application_point2_ is not None

    protocol_sessions = list(
        _iterate(blueprint,
                 match(
                     qnode(id=application_point1_.id,
                           type=is_in(['interface', 'ip_endpoint']))
                     .in_('layered_over')
                     .node('protocol_endpoint', name='protocol_endpoint1')
                     .in_('instantiates')
                     .node('protocol_session', name='protocol_session')
                     .out('instantiates')
                     .node('protocol_endpoint', name='protocol_endpoint2')
                     .out('layered_over')
                     .node(id=application_point2_.id,
                           type=is_in(['interface', 'ip_endpoint']))
                 )))
    if len(protocol_sessions) > 1:
        raise ValueError(
            'Too many protocol sessions found: %i between %s and %s: %s' %
            (len(protocol_sessions),
             application_point1_, application_point2_, protocol_sessions))
    if protocol_sessions:
        return protocol_sessions[0]
    return None

def get_protocol_session_by_protocol_endpoint(
    blueprint: tt.Graph,
    protocol_endpoint: GraphNodeOrId,
) -> tt.GraphNode | None:
    if _has_gai_index(blueprint, 'get_protocol_session_by_protocol_endpoint'):
        gai = blueprint.gai  # type: ignore[attr-defined]
        return gai.get_protocol_session_by_protocol_endpoint.get_node(
            protocol_endpoint
        )

    protocol_endpoint_ = _node(blueprint, protocol_endpoint)
    return (blueprint.traverse(protocol_endpoint_)
            .in_('instantiates').node('protocol_session').one)


def get_enabled_assigned_policies(
    blueprint: tt.Graph,
    node: GraphNodeOrId
) -> tt.GraphNodeIterator:
    return get_all_assigned_policies(blueprint, node, enabled=True)


def get_all_assigned_policies(
    blueprint: tt.Graph,
    node: GraphNodeOrId,
    **kwargs: te.Unpack[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.two_stage_l3clos.schema.POLICY_SCHEMA'
    ]]
) -> tt.GraphNodeIterator:
    # make possible to retrieve node assigned policies by some properties
    node_ = _node(blueprint, node)
    return blueprint.traverse(node_).out('security_policy')\
        .target('policy', policy_type='security', **kwargs)


def get_bound_to_nodes(
    blueprint: tt.Graph,
    enforcement_point: GraphNodeOrId
) -> tt.GraphNodeIterator:
    node_ = _node(blueprint, enforcement_point)
    return blueprint.traverse(node_).in_('bound_to').node()


def get_group_hierarchy(
    blueprint: tt.Graph,
    start_groups: t.Iterable[GraphNodeOrId],
    retrieve_fn: t.Callable[
        [tt.Graph, GraphNodeOrId],
        tt.GraphNodeIterator | t.Iterator[tt.GraphNode]
    ],
) -> set[tt.GraphNode]:
    """
    Retrieves all hierarchy of direct or indirect groups for a given group set.
    :param retrieve_fn: Function used to obtain next level of hierarchy.
                        Typically retrieves group parents or children
    """
    visited: set[tt.GraphNode] = set()

    def dfs(group: tt.GraphNode) -> None:
        if group in visited:
            return
        visited.add(group)
        for graph_node in retrieve_fn(blueprint, group):
            dfs(graph_node)

    for group in start_groups:
        group_ = _node(blueprint, group)
        assert group_ is not None
        dfs(group_)

    return visited


def get_ancestry(
    blueprint: tt.Graph,
    start_groups: t.Iterable[GraphNodeOrId],
) -> set[tt.GraphNode]:
    """
    Retrieves all direct or indirect (accessible via a chain
    of other groups) parents for a given group set.
    """
    return get_group_hierarchy(blueprint, start_groups, get_group_parents)


def get_posterity(
    blueprint: tt.Graph,
    start_groups: t.Iterable[GraphNodeOrId],
) -> set[tt.GraphNode]:
    """
    Retrieves all direct or indirect (accessible via a chain
    of other groups) children for a given group set.
    """
    return get_group_hierarchy(blueprint, start_groups,
                               partial(get_group_members, member_type='group'))


def get_system_for_static_route(
    blueprint: tt.Graph,
    static_route: GraphNodeOrId
) -> tt.GraphNode | None:
    """
    :return: system that points to the static route
    """
    static_route_ = _node(blueprint, static_route)
    return (blueprint.traverse(static_route_)
            .in_('static_route').source('system').first)


def get_security_zone_for_static_route(
    blueprint: tt.Graph,
    static_route: GraphNodeOrId,
) -> tt.GraphNode | None:
    """
    :return: associated routing zone for the static route
    """
    static_route_ = _node(blueprint, static_route)
    return (blueprint.traverse(static_route_)
            .in_('static_route').source('security_zone').first)


def get_next_hop_interface_for_static_route(
    blueprint: tt.Graph,
    static_route: GraphNodeOrId,
) -> tt.GraphNode | None:
    """
    :return: next_hop interface node for the static route
    """
    static_route_ = _node(blueprint, static_route)
    return (blueprint.traverse(static_route_)
            .out('next_hop').target('interface').first)


def get_next_hop_ip_endpoint_for_static_route(
    blueprint: tt.Graph,
    static_route: GraphNodeOrId
) -> tt.GraphNode | None:
    """
    :return: next_hop ip_endpoint node for the static route
    """
    static_route_ = _node(blueprint, static_route)
    return (blueprint.traverse(static_route_)
            .out('next_hop').target('ip_endpoint').first)


def get_source_interface_for_static_route(
    blueprint: tt.Graph,
    static_route: GraphNodeOrId,
) -> tt.GraphNode | None:
    """
    :return: source interface node for the static route
    """
    static_route_ = _node(blueprint, static_route)
    return (blueprint.traverse(static_route_)
            .out('source_interface').target('interface').first)


def get_network_interface_for_static_route(
    blueprint: tt.Graph,
    static_route: GraphNodeOrId
) -> tt.GraphNode | None:
    """
    :return: network node for the static route
    """
    static_route_ = _node(blueprint, static_route)
    return (blueprint.traverse(static_route_)
            .out('network').target('interface').first)


def get_peers_by_protocol_session(
    blueprint: tt.Graph,
    node: GraphNodeOrId,
) -> list[tt.GraphNode]:
    node_ = _node(blueprint, node)
    return list(blueprint.traverse(node_).out('instantiates').
                node('protocol_endpoint').out('layered_over').target())


def get_neighbor_protocol_endpoint_by_peer(
    blueprint: tt.Graph,
    protocol_session: GraphNodeOrId,
    peer: GraphNodeOrId,
) -> tt.GraphNode | None:
    """
    :return: Returns neighbor protocol endpoint (a) for given peer and session.
        Useful as protocol_endpoint on one side of the protocol session puts the
        restrictions on the peer on the other side of the protocol session;

        protocol_endpoint (a) <- protocol_session -> protocol_endpoint (b) -> peer
    """
    protocol_session_ = _node(blueprint, protocol_session)
    peer_ = _node(blueprint, peer)

    protocol_endpoints = list(blueprint.traverse(protocol_session_)
                              .out('instantiates').node('protocol_endpoint'))

    # only applicable for two peers protocol sessions (excludes prefix-based ones)
    if len(protocol_endpoints) != 2:
        return None

    for idx, protocol_endpoint in enumerate(protocol_endpoints):
        protocol_endpoint_peer = (blueprint.traverse(protocol_endpoint)
                                  .out('layered_over').node().first)
        if peer_ == protocol_endpoint_peer:
            result_idx = 0 if idx == 1 else 1
            return protocol_endpoints[result_idx]  # returns the other side

    return None


def get_protocol_endpoint_by_peer(
    blueprint: tt.Graph,
    protocol_session: GraphNodeOrId,
    peer: GraphNodeOrId,
) -> tt.GraphNode | None:
    """
        :return: Returns protocol endpoint for given peer and session.
            protocol_session -> protocol_endpoint -> peer
        """
    protocol_session_ = _node(blueprint, protocol_session)
    peer_ = _node(blueprint, peer)

    protocol_endpoints = list(blueprint.traverse(protocol_session_)
                              .out('instantiates').node('protocol_endpoint'))

    for protocol_endpoint in protocol_endpoints:
        protocol_endpoint_peer = (blueprint.traverse(protocol_endpoint)
                                  .out('layered_over').node().first)

        if peer_ == protocol_endpoint_peer:
            return protocol_endpoint

    return None


def get_virtual_network_by_subinterface(
    blueprint: tt.Graph,
    subinterface: GraphNodeOrId,
) -> tt.GraphNode | None:
    subinterface_ = _node(blueprint, subinterface)
    if subinterface_ is None:
        return None
    return (blueprint.traverse(subinterface_)
            .in_('member_interfaces')
            .source('virtual_network')).one_or_none


def get_security_zone_by_subinterface(
    blueprint: tt.Graph,
    subinterface: GraphNodeOrId,
) -> tt.GraphNode | None:
    subinterface_ = _node(blueprint, subinterface)
    if subinterface_ is None:
        return None
    return (blueprint.traverse(subinterface_)
            .in_('member_interfaces')
            .node('sz_instance')
            .in_('instantiated_by')
            .node('security_zone').one)


def get_security_zone_by_logical_link(
    blueprint: tt.Graph,
    link: GraphNodeOrId,
) -> tt.GraphNode | None:
    link_ = _node(blueprint, link)
    for intf in blueprint.traverse(link_).in_('link').node('interface'):
        if sz := get_security_zone_by_interface(blueprint, intf):
            return sz
    return None


def get_interface_by_protocol_endpoint(
    blueprint: tt.Graph,
    protocol_endpoint: GraphNodeOrId,
) -> tt.GraphNode | None:
    protocol_endpoint_ = _node(blueprint, protocol_endpoint)
    return (blueprint.traverse(protocol_endpoint_)
            .out('layered_over')
            .node('interface')).one_or_none


def get_protocol_endpoint_prefix_neighbor(
    blueprint: tt.Graph,
    protocol_endpoint: GraphNodeOrId
) -> tt.GraphNode | None:
    protocol_endpoint_ = _node(blueprint, protocol_endpoint)
    return (blueprint.traverse(protocol_endpoint_)
            .out('prefix_neighbor')
            .target().first)


def get_fabric_policy(blueprint: tt.Graph) -> tt.GraphNode | None:
    return blueprint.get_nodes('fabric_policy').one_or_none


def get_rack_by_rail(blueprint: tt.Graph, rail: GraphNodeOrId) -> tt.GraphNode:
    rail = _node(blueprint, rail)
    return (blueprint.traverse(rail)
            .out('part_of_rack')
            .node('rack')).one


def get_rails_by_rack(
    blueprint: tt.Graph,
    rack: GraphNodeOrId,
    **rail_attrs: te.Unpack[_MAGIC.lollipop_type[
        'aos.reference_design.two_stage_l3clos.rail.RAIL_SCHEMA']]
) -> tt.GraphNodeIterator:
    rack = _node(blueprint, rack)
    return (blueprint.traverse(rack)
            .in_('part_of_rack')
            .node('rail', **rail_attrs))


def get_rails_by_system(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    **rail_attrs: te.Unpack[_MAGIC.lollipop_type[
        'aos.reference_design.two_stage_l3clos.rail.RAIL_SCHEMA']]
) -> tt.GraphNodeIterator:
    system = _node(blueprint, system)
    return (blueprint.traverse(system)
            .in_('hosted_by')
            .node('rail', **rail_attrs))


def get_links_in_rail(
    blueprint: tt.Graph,
    rail: GraphNodeOrId
) -> list[tt.GraphNode]:
    rail = _node(blueprint, rail)
    return list(blueprint.traverse(rail)
                .out('composed_of')
                .node('link'))


def get_system_by_rail(
        blueprint: tt.Graph,
        rail: GraphNodeOrId
) -> tt.GraphNode:
    rail = _node(blueprint, rail)
    return (blueprint.traverse(rail)
            .out('hosted_by')
            .node('system')).one


def get_rail_by_link(
    blueprint: tt.Graph,
    link: GraphNodeOrId
) -> tt.GraphNode | None:
    link = _node(blueprint, link)
    return (blueprint.traverse(link)
            .in_('composed_of')
            .node('rail')).one_or_none


def get_rail_by_generic_system(
    blueprint: tt.Graph,
    generic: GraphNodeOrId
) -> tt.GraphNode | None:
    generic = _node(blueprint, generic)
    return (blueprint.traverse(generic)
            .out('hosted_interfaces')
            .node('interface')
            .out('link')
            .node('link', role='to_generic')
            .in_('composed_of')
            .node('rail')).first


def get_leaf_by_rail(
    blueprint: tt.Graph,
    rail: GraphNodeOrId
) -> tt.GraphNode | None:
    rail = _node(blueprint, rail)
    return (
        blueprint.traverse(rail)
        .out('composed_of')
        .node('link')
        .in_('link')
        .node('interface')
        .in_('hosted_interfaces')
        .node('system', role='leaf')
    ).first


def get_load_balancing_policies(blueprint):
    return list(blueprint.get_nodes('load_balancing_policy'))


def get_load_balancing_policy_for_system(blueprint, system):
    system = _node(blueprint, system)
    load_balancing_policy = (
        blueprint.traverse(system)
        ._in('load_balancing_policy')
        .node('load_balancing_policy')
    ).one_or_none
    return load_balancing_policy


def get_load_balancing_policy_systems(blueprint, load_balancing_policy):
    load_balancing_policy = _node(blueprint, load_balancing_policy)
    return list(
        blueprint.traverse(load_balancing_policy)
        .out('load_balancing_policy')
        .node('system')
    )


def get_fabric_connectivity_design(
        blueprint: tt.Graph
) -> tt.FabricConnectivityDesign | None:
    # All racks in a blueprint must have the same fabric connectivity design
    rack = blueprint.get_nodes('rack').first
    if rack and rack.rack_type_json:
        rack_type_json = json.loads(rack.rack_type_json)
        return rack_type_json['fabric_connectivity_design']
    return None
