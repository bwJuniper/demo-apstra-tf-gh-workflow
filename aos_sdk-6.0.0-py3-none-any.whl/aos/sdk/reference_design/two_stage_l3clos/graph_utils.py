# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from itertools import chain

from aos.sdk.graph.graph import dump_node, dump_relationship
import six


def properties_equal(o1, o2):
    """
    Compares properties of two nodes/relationships which are assumed to be
    of the same type. Skips comparing some "domain" and "metadata" node properties.
    """
    ps1 = o1.properties
    ps2 = o2.properties

    keys = set(chain(six.iterkeys(ps1), six.iterkeys(ps2)))
    if o1.type in ('domain', 'interface', 'protocol_session', 'static_route'):
        keys.discard('ref_count')
    elif o1.type == 'metadata':
        keys = {key for key in keys if key not in ('user', 'user_ip')}

    for k in keys:
        if ps1.get(k) != ps2.get(k):
            return False

    return True


def graphs_equal(g1, g2):
    """
    Compares contents of two graphs with a little bit of reference design twist.
    Graphs are assumed to be of the same reference design.
    """
    g1_nodes = [node for node in g1.get_nodes()]
    g2_nodes = [node for node in g2.get_nodes()]
    g1_rel = [rel for rel in g1.get_relationships()]
    g2_rel = [rel for rel in g2.get_relationships()]
    if len(g1_nodes) != len(g2_nodes) or \
            len(g1_rel) != len(g2_rel):
        return False

    for n1 in g1_nodes:
        n2 = g2.get_node(n1)
        if not n2 or not properties_equal(n1, n2):
            return False

    for r1 in g1_rel:
        r2 = g2.get_relationship(r1)
        if not r2 or not properties_equal(r1, r2):
            return False

    return True


def graphs_diff(g1, g2, dump=False):
    """Compare two graphs and return their diff.

    Returns a two items tuple where the first item is a list of node changes
    and the second item is a list of relationship changes. A change is
    represented as a three items tuple in the following format:

        (<action>, <g1 node>, <g2 node>)

    Where <action> can be one of "added", "updated" and "removed" strings,
    <g1 node> and <g2 node> are corresponding nodes from two graphs. For
    "added" changes, <g1 node> is None, and for "removed" changes, <g2 node>
    is None.

    If dump is set to True, then nodes and relationships are dumped into dicts.
    Otherwise, they are returned as instances of Node and Relationship classes.
    """

    nodes = []
    relationships = []

    for n1 in g1.get_nodes():
        n2 = g2.get_node(n1)
        if n2 is None:
            nodes.append(('removed', n1, None))
        elif not properties_equal(n1, n2):
            nodes.append(('updated', n1, n2))

    for n2 in g2.get_nodes():
        n1 = g1.get_node(n2)
        if n1 is None:
            nodes.append(('added', None, n2))

    for r1 in g1.get_relationships():
        r2 = g2.get_relationship(r1)
        if r2 is None:
            relationships.append(('removed', r1, None))
        elif not properties_equal(r1, r2):
            relationships.append(('updated', r1, r2))

    for r2 in g2.get_relationships():
        r1 = g1.get_relationship(r2)
        if r1 is None:
            relationships.append(('added', None, r2))

    if dump:
        nodes = [(
            action,
            dump_node(n1) if n1 is not None else n1,
            dump_node(n2) if n2 is not None else n2,
        ) for (action, n1, n2) in nodes]
        relationships = [(
            action,
            dump_relationship(r1) if r1 is not None else r1,
            dump_relationship(r2) if r2 is not None else r2,
        ) for (action, r1, r2) in relationships]

    return (nodes, relationships)


def normalize_bgp_result(path):
    # 'bgp_source' and 'bgp_destination' must always be present in path
    # for any peering type.
    assert 'bgp_source' in path, "'bgp_source' not found in 'path'"
    assert 'bgp_destination' in path, "'bgp_destination' not found in 'path'"
    bgp_source = path['bgp_source']
    bgp_destination = path['bgp_destination']

    # 'via_interface' and 'nexthop_interface' are expected only for queries
    # matching only 'loopback' peering type. Their presence in case of interface
    # peering means that entity using ext_connectivity_patterns constructed an
    # incorrect match that can lead to unexpected results.
    error_msg = "Unexpected {} key in path. Is your query correct?"
    if bgp_source.type == 'interface' and bgp_source.if_type != 'loopback':
        assert 'via_interface' not in path, error_msg.format('via_interface')
    if bgp_destination.type == 'interface' and bgp_destination.if_type != 'loopback':
        assert 'nexthop_interface' not in path, error_msg.format('nexthop_interface')

    normalized_path = path.copy()

    if 'via_interface' not in normalized_path:
        normalized_path['via_interface'] = bgp_source
    if 'nexthop_interface' not in normalized_path:
        normalized_path['nexthop_interface'] = bgp_destination

    return normalized_path
