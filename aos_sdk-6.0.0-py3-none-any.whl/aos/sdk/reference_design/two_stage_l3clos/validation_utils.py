# Copyright 2019-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import aos.sdk.schema as s
from aos.sdk.facade import ResourceNotFoundError
from aos.sdk.graph import is_node


# This function should help minimize overhead functions that must differentiate
# between http-type facade api and python libraries.
def validate_node(blueprint, node_type, node):
    """ Helper function for facade and api libraries to allow usage of either a
        node by ID or by node object in function usage.

    Args:
        blueprint (graph): AOS Graph object corresponding to the blueprint
        node_type (string): Node type to search for, eg, 'system' or 'interface'
        node (string, node): The node, by either node ID or Graph.Node type

    Returns:
        (node): Node object corresponding to provided node or node ID

    Raises:
        ValidationError: Raised if the node or node ID is not valid in the blueprint
                         or is an unexpected node type

    Examples:
        Given leaf_node as an AOS Node object (eg low-level API)

        >>> validate_node(blueprint, node_type='system', node=leaf_node)

        Given the node is only known by node ID (eg, http facade api)

        >>> validate_node(blueprint, node_type='system', node='leaf1_node_id')
    """
    # node id or node object wrapper.
    original_node = node
    if not is_node(node):
        node = blueprint.get_nodes(node_type, id=node).first
        if not node:
            raise s.ValidationError(
                'Not a valid %s node object or node id: %s' %
                (node_type, original_node))
    if node.type != node_type:
        raise s.ValidationError(
            'Node %s is an invalid type: (%s != %s)' %
            (original_node, node.type, node_type))
    return node


def validate_sz_id(graph, security_zone_id):
    sz = graph.get_node(security_zone_id)
    if sz is None:
        raise ResourceNotFoundError('Routing zone with given ID does not exist')
    if sz.type != 'security_zone':
        raise s.ValidationError({'security_zone_id': 'Node is not a routing zone'})
    return sz


def validate_sz_with_vn_type(graph, security_zone_id, vn_type):
    sz = validate_sz_id(graph, security_zone_id)

    fabric_policy = graph.get_nodes('fabric_policy').first
    is_evpn = fabric_policy and fabric_policy.overlay_control_protocol == 'evpn'
    if is_evpn and vn_type == 'vxlan' and sz.sz_type == 'l3_fabric':
        raise s.ValidationError({
            'vn_type': 'VXLAN is not allowed in default routing zone '
                       'in EVPN blueprint'})
