# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from aos.sdk import schema as s
from aos.sdk.interface_map.interface_map_schema import interface_map_fields
from aos.sdk.device_profile.device_profile_schema import device_profile_fields
from aos.sdk.types import (
    Dot1xPolicyFields,
    AAAServerFields,
    MAX_VLAN_ID,
    DEFAULT_DUP_MAC_RECOVERY_TIME,
    DEFAULT_SVI_L3_MTU,
    DependentKeys,
)
from operator import itemgetter

# TODO: l2_server/l3_server/external_router roles must be removed but they are
#  still used in upgrades
NODE_ROLES = ['spine', 'leaf', 'superspine', 'l2_server', 'l3_server',
              'external_router', 'remote_gateway', 'access', 'generic']

# TODO: leaf_l2_server, leaf_l3_server, leaf_pair_l2_server, to_external_router,
#  access_server are deprecated and can be removed when they are no longer used in
#  upgrades
# use 'access_server' here rather than 'access_lx_server' given the plan to
# unify system role l2 and l3 servers
LINK_ROLES = ['spine_leaf', 'leaf_l2_server', 'leaf_l3_server',
              'leaf_pair_l2_server', 'leaf_pair_access_pair',
              'leaf_peer_link', 'leaf_l3_peer_link', 'access_l3_peer_link',
              'to_external_router', 'spine_superspine',
              'leaf_access', 'access_server', 'leaf_pair_access', 'to_generic',
              'leaf_leaf']

IF_TYPES = [
    'ip',
    'loopback',
    'ethernet',
    'svi',
    'port_channel',
    # the ip of vtep can be same as loopback0 for platforms defined in
    # PLATFORMS_WITH_VTEP_IP_AS_PRIMARY_LOOPBACK
    'logical_vtep',
    'anycast_vtep',
    'unicast_vtep',
    'global_anycast_vtep',
    'subinterface',
]

PLATFORMS_WITH_VTEP_IP_AS_PRIMARY_LOOPBACK = ['junos']

PROTOCOL_SESSION_IPV4_ADDRESSING_TYPES = ['addressed', 'prefix']

PROTOCOL_SESSION_IPV6_ADDRESSING_TYPES = ['addressed', 'link_local', 'prefix']

PROTOCOL_SESSION_NEIGHBOR_ASN_TYPES = ['static', 'dynamic']
PROTOCOL_SESSION_NEIGHBOR_ASN_TYPES_DISPLAYED = ['Static', 'Dynamic']

ROUTING_TYPES = ['bgp', 'ospf']

OSPF_NETWORK_TYPES = ['point_to_point', 'broadcast']

BGP_PROTOCOL_SESSION_DEPLOY_MODES = ['deploy', 'drain']
SYSTEM_DEPLOY_MODES = ['deploy', 'undeploy', 'ready', 'drain']

DEFAULT_PROTOCOL_SESSION_TTL = 2
DEFAULT_PROTOCOL_SESSION_BFD = False

dp_fields = dict(device_profile_fields)
dp_fields['device_profile_id'] = s.String(validate=s.Length(min=1))


LOAD_BALANCING_POLICY_FIELDS = {
    'mode': s.Enum(
        ['dlb', 'disabled'],
        description="The load balancing policy can be explicitly disabled, or set "
                    "to DLB. When DLB is enabled, additional suboptions are "
                    "available to choose per-packet, reactive DLB, or flowlet mode "
                    "for DLB.  When DLB is enabled, GLB can also be enabled on "
                    "supported TH5 chipset hardware."
    ),
    'label': s.Label(
        description="The load balancing policy label is used to help users "
                    "differentiate one policy vs the other for granular system "
                    "assignment"
    ),
    'dlb_options': s.Optional(s.Dict({
        'dlb_mode': s.Enum(
            ['per_packet', 'flowlet'],
            description="DLB can be configured in multiple load-balancing modes. "
                        "per_packet will add per-packet load balancing. flowlet "
                        "mode renders a non-reactive flowlet load balancing "
                        "strategy. DLB can also operate in reactive mode which "
                        "requires additional configuration for reactive path "
                        "reassignment thresholds."
        ),
        'flowlet_options': s.Optional(s.Dict({
            # set forwarding-options enhanced-hash-key ecmp-dlb flowlet
            # inactivity-interval <inactivity_interval>
            'inactivity_interval': s.Optional(s.Integer(
                validate=[s.Range(min=16, max=4096)],
                description="Configurable value for the flowlet inactivity timer. "
                            "When this timer expires, the flowlet traffic tuple is "
                            "removed from the software and hardware caches and "
                            "freed from allocations. The platform default "
                            "inactivity timer is 256 microseconds. The traffic uses "
                            "the assigned outgoing (egress) interface until the "
                            "flow pauses for longer than the inactivity timer. "
                            "If the outgoing link quality deteriorates gradually, "
                            "the pause within the flow might not exceed the "
                            "configured inactivity timer. In this case, classic "
                            "flowlet mode does not reassign the traffic to a "
                            "different link, so the traffic cannot utilize a "
                            "better-quality link. Reactive path rebalancing "
                            "addresses this limitation by enabling the user to "
                            "move the traffic to a better-quality link even when "
                            "flowlet mode is enabled.  This value is paired"
                            "with the reassignment structure in order to provide "
                            "quality delta and probability thresholds.")),
            # set forwarding-options enhanced-hash-key ecmp-dlb flowlet
            # flowset-table-size <flowset_table_size>
            'flowset_table_size': s.Optional(s.FlowsetTableSize(
                description="Number of flowset (MacroFlow) entries in DLB hash "
                            "bucket. The platform default hash bucket size is 256 "
                            "entries. Values from 256->32768 are supported in "
                            "increasing powers of 2: 256, 512, 1024, 2048, 4096, "
                            "8192, 16384, 32768.")),
            'reassignment': s.Optional(s.Dict({
                # set forwarding-options enhanced-hash-key ecmp-dlb flowlet
                # reassignment quality-delta <quality_delta>
                'quality_delta': s.Integer(validate=[s.Range(min=0, max=8)]),
                # set forwarding-options enhanced-hash-key ecmp-dlb flowlet
                # reassignment prob-threshold <reassign-prob-threshold>
                'probability_threshold': s.Integer(
                    validate=[s.Range(min=0, max=255)]),
            },
                description="Reassignment parameters relate to reactive DLB or "
                            "reactive path rebalancing."
            )),
        })),
        'egress_quantization': s.Optional(s.Dict({
            # set forwarding-options enhanced-hash-key ecmp-dlb
            # egress-quantization min <quantization_min>
            'quantization_min': s.Optional(s.Integer(
                validate=[s.Range(min=1, max=100)],
                description="Minimum port load in percentage (1-100). DLB assigns "
                            "any egress port with a port load falling below this "
                            "minimum to the highest quality band (7)"
            ), load_default=None),
            # set forwarding-options enhanced-hash-key ecmp-dlb
            # egress-quantization max <quantization_max>
            'quantization_max': s.Optional(s.Integer(
                validate=[s.Range(min=1, max=100)],
                description="Maximum port load in percentage (1-100). DLB assigns "
                            "any egress port with a port load above this maximum "
                            "to the lowest quality band (0)."
            ), load_default=None),
            # set forwarding-options enhanced-hash-key ecmp-dlb
            # egress-quantization rate-weightage <weightage>
            'rate_weightage': s.Optional(s.Integer(
                validate=[s.Range(min=1, max=100)],
                description="How much weight DLB puts on the port load metric, or "
                            "amount of traffic, when determining the link quality. "
                            "The range is 0-100, where 100 means that DLB bases "
                            "link quality 100% on the port load."
            ), load_default=None),
        }, validate=DependentKeys(['quantization_min', 'quantization_max']))),
        'glb_options': s.Optional(s.Dict({
            'glb_mode': s.Enum(
                ['helper_only', 'load_balancer_only'],
                description='''\
The global-load-balancing knob can be configured alone or together 
with one of the sub-knobs: helper_only, load_balancer_only. 
Here are the behaviors of the configurations: 

global-load-balancing is configured alone: This means this node works as both 
load-balancer and helper. BGP sends NNHN capability for the route it advertises. 
BGP instructs GLB App to monitor the link qualities of all local links with EBGP 
sessions and flood them to all direct neighbors. GLB App receives link qualities 
from neighboring nodes and use the combine link quality of the next-hops and 
next-next-hops to make load balancing decisions. This is usually configured on 
the spines and super spines of 5-CLOS or 7-CLOS.
This option is not yet supported by Junos.

helper-only is configured: BGP sends NNHN capability for the routes it advertises. 
BGP instructs GLB  App to monitor the link qualities of all local links with EBGP 
sessions and flood them to all direct neighbors. GPB App do not process link 
qualities from neighboring nodes and do not do GLB. This is usually configured 
on the 3-CLOS spines. 

load-balancer-only is configured: BGP does not send NNHN capability for the route 
it advertises. BGP does not instruct GLB App to monitor the link qualities of local 
links either. GLB App only receives link qualities from neighboring nodes and use 
the combined link quality of next-hops and next-next-hops to make load balancing 
decisions. This is usually configured on the leaves (any-CLOS). '''),
            # set forwarding-options global-load-balancing
            # msg-tx-interval <micro-seconds>
            'msg_tx_interval': s.Optional(s.Integer(
                validate=[s.Range(min=5, max=1000)],
                description="GLB app wakes up every msg_tx_interval microseconds "
                            "and transmits GLB messages regardless of whether "
                            "quality info has changed from the previous state or "
                            "not. The platform default value is 10 microseconds."),
                load_default=None),

            # set forwarding-options global-load-balancing
            # monitor-interval <micro-seconds>
            'monitor_interval': s.Optional(s.Integer(
                validate=[s.Range(min=10, max=1000)],
                description="GLB app wakes up every monitor_interval microseconds "
                            "and transmits GLB messages if quality info has changed "
                            "from the previous state. This is independent of the "
                            "msg_tx_interval. The platform default value is 20 "
                            "microseconds."
            ), load_default=None),
            # set forwarding-options global-load-balancing
            # update-interval <micro-seconds>
            'update_interval': s.Optional(s.Integer(
                validate=[s.Range(min=10, max=1000)],
                description="GLB app wakes up every update_interval microseconds "
                            "and updates the remote quality in hardware. The "
                            "platform default value is 20 microseconds."
            ), load_default=None),
        })),
        'sampling_rate': s.Optional(s.Integer(
            validate=[s.Range(min=5953, max=1000000)],
            description="Defines the sampling rate for egress port load on ECMP "
                        "members for updating link quality"
        )),
    })),
    'policy_type': s.Optional(s.Enum(
        ['default', 'user_defined'],
        description=('Policy of "default" type is created during '
                    'blueprint scaffolding and is associated to systems within '
                    'rail-enabled fabrics by default unless an override is '
                    'provided. This policy cannot be deleted. "user_defined" '
                    'policies are created by users and are used to override the '
                    'default policy.'),
    ), load_default='user_defined'),
}

VALIDATION_POLICY_FIELDS = {
    'ip_overlap': s.Object(
        {
            'base_level': s.ValidationSeverityEnum(
                description='Severity of errors raised on overlap of IPs.'
            ),
            'svi': s.Optional(s.ValidationSeverityEnum(
                description=(
                    'Severity of error raised on overlap of SVI IP '
                    'addresses in a virtual network. This handles '
                    'use-cases when duplicated SVI IPs '
                    'must not block blueprint deploy.'
                ),
            )),
            'uncontrolled_generic_loopback': s.Optional(s.ValidationSeverityEnum(
                description=(
                    'Severity for uncontrolled '
                    'generic loopback IP overlaps error.'
                ),
            )),
        },
        allow_extra_fields=False,
        default_field_type=s.IndexField,
    ),
    'route_target_overlap': s.Object(
        {
            'internal': s.ValidationSeverityEnum(
                description=(
                    'Severity of errors raised on overlap of a '
                    'user-defined route-target which is also used '
                    'within a virtual network or routing zone. '
                    'This can be used for a form of full table inter-vrf '
                    'route leaking. This feature is currently marked as '
                    'experimental.'
                ),
            ),
        },
        allow_extra_fields=False,
        default_field_type=s.IndexField,
    ),
    'asn_overlap': s.Object(
        {
            'base_level': s.ValidationSeverityEnum(
                description='Severity of errors raised on overlap of ASNs.'
            ),
        },
        allow_extra_fields=False,
        default_field_type=s.IndexField,
    ),
    'os_version': s.Object(
        {
            'sonic_esi_min_version': s.ValidationSeverityEnum(
                description='Severity of errors for the minimum OS version of '
                            'SONiC ESI support.',
            )
        },
        allow_extra_fields=False,
        default_field_type=s.IndexField,
    ),
    'asic_features': s.Object(
        {
            'subinterfaces': s.ValidationSeverityEnum(
                description='Severity of errors related to vendor and ASIC support '
                            'for presence of subinterfaces on front-panel interfaces'
            ),
            'load_balancing_policy': s.Optional(s.ValidationSeverityEnum(
                description='Severity of errors related to ASIC support '
                            'for load balancing policy capabilities.'),
                load_default='error',
            )
        },
        allow_extra_fields=False,
        default_field_type=s.IndexField,
    ),
    'load_balancing_policy': s.Object(
        {
            'glb_mode': s.ValidationSeverityEnum(
                'Severity of errors related with load balancing policies and '
                'recommended GLB modes based on system role. This also handles '
                'fabric-wide validation which will raise errors if GLB is enabled '
                'on one or more superspines, spines, or leafs, but is missing '
                'from other capable systems.'),
        },
        allow_extra_fields=False,
        default_field_type=s.IndexField,
    ),
    'rail_optimized_design': s.Object(
        {
            'rail_vlan_misconfiguration': s.ValidationSeverityEnum(
                'Severity for the detected absence of single L2 domain for all Leaf '
                'interfaces which are part of the same rail.'),
        },
        allow_extra_fields = False,
        default_field_type = s.IndexField,
    )
}


class RoutingZoneConstraintFields(object):
    label = s.String(validate=[s.Length(min=1)],
                     description='Name of the constraint')
    routing_zones_list_constraint = s.Enum(
        ['allow', 'deny', 'none'],
        description='Mode of associated constraints usage. '
                    '"allow" means that only specified routing zones are allowed, '
                    '"deny" means that specified routing zones are restricted, '
                    '"none" means that the policy does not specify instance '
                    'constraints.')
    max_count_constraint = s.Optional(s.Integer(
        validate=[s.Range(min=0, max=255)],
        description='Maximum number of routing zones linked to an interface. If '
                    'missing, interface has no restriction.',
    ))
    constraints = s.List(s.NodeId(description='List of constraint IDs'),
                         validate=s.Unique())
    constraints_info = s.List(s.Dict({
        'id': s.NodeId(description='ID of the node where constraint is applied'),
        'type': s.Enum(['security_zone', 'security_zones'],
                       description='Where constraint is applied. It\'s either '
                                   'routing zone or a group of routing zones'),
        'label': s.Optional(s.String(description='Name of the constraint'))
    }))


class RoutingPolicyFields(object):
    # Label's max length is 32 - len('RoutesFromExt-') = 18
    RoutingPolicyLabel = s.validated_type(
        s.String, 'RoutingPolicyLabel', validate=[
            s.Length(min=1, max=18),
            s.Regexp('^[a-zA-Z0-9_-]*$',
                     error='Invalid routing policy label. Only ASCII alphanumeric '
                           'characters, underscore and dash are allowed.'),
        ],
    )

    label = RoutingPolicyLabel(description='Routing policy label')
    description = s.Description(description='Routing policy description')
    policy_type = s.Enum(
        ['default_immutable', 'user_defined'],
        description='Policy of "default_immutable" type is created during '
                    'blueprint scaffolding and is associated with '
                    'routing zones by default unless an override is '
                    'provided. Cannot be updated or deleted. "user_defined" '
                    'policies are created by users and are used to override '
                    'the default policy.')
    policy_type_user_defined = s.Enum(
        ['user_defined'],
        description='Only user defined policies can be created via API, '
                    'so the only possible policy type is "user_defined".')
    import_policy = s.Enum(
        ['default_only', 'all', 'extra_only'],
        description='Import policies are specified to import only the default '
                    'route, all routes, or only extra routes, defined under '
                    'extra_import_routes. These options are additive: If '
                    'default-only is defined, extra routes will also be permitted '
                    'in addition to the default route.')
    aggregate_prefixes = s.List(
        s.Ipv6orIpv4NetworkAddress(),
        description='BGP Aggregate routes to be imported into a routing zone (VRF) '
                    'on all border switches. This option can only be set on routing '
                    'policies associated with routing zones, and cannot be set on '
                    'per-protocol session policies. The aggregated routes are '
                    'sent to all external router peers in a routing zone (VRF).')
    extra_import_routes = s.List(
        s.PrefixListEntry,
        description='User defined import routes will be used in addition to any '
                    'routes generated by the import_policy. Prefixes specified here '
                    'are additive to import_policy, unless the import_policy is set '
                    'to extra_only, in which case only these routes will be '
                    'imported.')
    extra_export_routes = s.List(
        s.PrefixListEntry,
        description='User defined export routes will be used in addition to any '
                    'other routes specified in export policies. These policies are '
                    'additive. To advertise only extra routes, unselect all export '
                    'policies, and only the extra policies specified here will be '
                    'advertised.')
    export_policy_loopbacks = s.Boolean(
        description='Exports all loopbacks within a routing zone (VRF) across '
                    'spine, leaf, and generic systems.')
    export_policy_spine_leaf_links = s.Boolean(
        description='Exports all spine-leaf (fabric) links within a VRF. EVPN '
                    'routing zones do not have spine-leaf addressing, so this '
                    'generated list may be empty. For routing zones of type '
                    'virtual_l3_fabric, subinterfaces between spine-leaf will be '
                    'included.')
    export_policy_spine_superspine_links = s.Boolean(
        description='Exports all spine-superspine (fabric) links within the '
                    'default routing zone (VRF).')
    export_policy_l2edge_subnets = s.Boolean(
        description='Exports all virtual networks (VLANs) that have L3 addresses '
                    'within a routing zone (VRF).')
    export_policy_static_routes = s.Boolean(
        description="Exports all subnets in a VRF associated with static routes "
                    "from all fabric systems to external routers associated with "
                    "this routing policy")
    expect_default_ipv4_route = s.Boolean(
        description='Default IPv4 route is expected to be imported via protocol '
                    'session using this policy. Used for rendering route '
                    'expectations.')
    expect_default_ipv6_route = s.Boolean(
        description='Default IPv6 route is expected to be imported via protocol '
                    'session using this policy. Used for rendering route '
                    'expectations.')
    import_export_routes_validate = [s.Unique(
        key=itemgetter('prefix', 'le_mask', 'ge_mask', 'action'))]


class RouteTargetPolicyFields(object):
    import_RTs = s.List(
        s.RouteTarget(),
        validate=[s.Unique(), s.Length(min=1)],
        description='Route targets to be imported into the routing zone'
    )
    export_RTs = s.List(
        s.RouteTarget(),
        validate=[s.Unique(), s.Length(min=1)],
        description='Route targets exported by the routing zone'
    )


class VNPolicyFields(object):
    overlay_control_protocol = s.Enum(
        ['evpn', ],
        description='Control protocol for VXLANs. If None, then no control plane '
                    'is used, and head-end replication in data plane is used '
                    'exclusively for MAC learning. If "evpn", then EPVN control '
                    'protocol run on leafs and spines. Please refer to Apstra '
                    'documentation for matrix of supported fabric control '
                    'protocols vs device vendors / models.')
    # TODO: Since release-4.2.1, we only support values in range 1280-9216. This is
    #  insured in facade due to schema upgrade limitations. Once we drop support for
    #  pre-4.2.1 releases, this field type should be updated to s.Mtu and the facade
    #  validation should be removed.
    external_router_mtu = s.Integer(
        validate=[s.Range(min=68, max=9216)],
        description='Specify fabric-wide external router interface IP MTU. Larger '
                    'MTU may be required to provide EVPN DCI Functionality or to '
                    'support fabric wide Jumbo frame functionality. MTU of 9050 '
                    'recommended for EVPN-DCI. A null (default) value implies '
                    'Apstra will not render a user-overridden MTU.')
    max_fabric_routes = s.Integer(
        validate=[s.Range(min=0, max=2 ** 32 - 1)],
        description='Maximum number of routes to accept between spine and leaf, '
                    'and spine and superspine in the fabric, or between leafs in '
                    'L3 Collapsed blueprints. This includes the default '
                    'VRF. Setting this option may be required in the event of '
                    'leaking EVPN routes from a routing zone into the default '
                    'routing zone (VRF) which could generate a large number of '
                    '/32 and /128 routes. It is suggested that this value is '
                    'effectively unlimited on all blueprints to ensure the network '
                    'stability of spine-leaf bgp sessions and evpn underlay. '
                    'Unlimited is also suggested for non-evpn blueprints '
                    'considering the impact to traffic if spine-leaf sessions go '
                    'offline. An integer between 1-2**32-1 will set a maximum '
                    'limit of routes in BGP config. The value 0 (zero) intends '
                    'the device to never apply a limit to number of fabric '
                    'routes (effectively unlimited).')
    max_external_routes = s.Integer(
        validate=[s.Range(min=0, max=2 ** 32 - 1)],
        description='Maximum number of routes to accept from external routers. '
                    'The default (None) will not render any maximum-route '
                    'commands on BGP sessions, implying that only vendor defaults '
                    'are used. An integer between 1-2**32-1 will set a '
                    'maximum limit of routes in BGP config. The value 0 (zero) '
                    'intends the device to never apply a limit to number of EVPN '
                    'routes (effectively unlimited).It is suggested this value '
                    'is value is effectively unlimited on evpn blueprints, to '
                    'permit the high number of /32 and /128 routes to be '
                    'advertised and received between VRFs in the event an external '
                    'router is providing a form of route leaking functionality.')
    max_mlag_routes = s.Integer(
        validate=[s.Range(min=0, max=2 ** 32 - 1)],
        description='Maximum number of routes to accept across MLAG peer switches. '
                    'The default (None) will not render any maximum-route '
                    'commands on BGP sessions, implying that only vendor defaults '
                    'are used. An integer between 1-2**32-1 will set a maximum '
                    'limit of routes in BGP config. The value 0 (zero) intends '
                    'the device to never apply a limit to number of EVPN routes '
                    '(effectively unlimited). Note: Device vendors typically '
                    'shut down BGP sessions if maximums are exceeded on a '
                    'session. For EVPN blueprints, this should be combined with '
                    'max_evpn_routes to permit routes across the l3 peer link '
                    'which may contain many /32 and /128 from EVPN type-2 routes '
                    'that convert into BGP route advertisements.')
    max_evpn_routes = s.Integer(
        validate=[s.Range(min=0, max=2 ** 32 - 1)],
        description='Maximum number of EVPN routes to accept on an EVPN switch. '
                    'The default (None) will not render any maximum-route '
                    'commands on BGP sessions, implying that only vendor defaults '
                    'are used. An integer between 1-2**32-1 will set a maximum '
                    'limit of routes in BGP config. The value 0 (zero) intends '
                    'the device to never apply a limit to number of EVPN routes '
                    '(effectively unlimited). Note: Device vendors typically '
                    'shut down BGP sessions if maximums are exceeded on a session.')
    default_fabric_evi_route_target = s.Optional(
        s.RouteTarget(),
        validate=[s.Length(min=1)],
        description='Juniper Qfx series only supports vlan-aware models for EPVN,'
                    ' where 1 switching instance is mapped to multiple VLANs, '
                    'this route target is per EVI RT, which must be common across '
                    'the fabric for all switches participating in one EVI. And it '
                    'also must not overlap with any existing EVI (L2VNI) RTs')
    evpn_generate_type5_host_routes = s.Optional(
        s.Enum(['enabled', 'disabled']),
        load_default='disabled',
        description="Default disabled. When enabled all EVPN vteps in the fabric "
                    "will redistribute ARP/IPV6 ND (when possible on NOS type) "
                    "as EVPN type 5 /32 routes in the routing table. Currently, "
                    "this option is only certified for Juniper JunOS. FRR "
                    "(SONiC/Cumulus) does this implicitly and cannot be disabled. "
                    "This setting will be ignored. On Arista and Cisco, no "
                    "configuration is rendered and will result in a blueprint "
                    "warning that it is not supported by Apstra. This value is "
                    "disabled by default, as it generates a very large number of "
                    "routes in the BGP routing table and takes large amounts of "
                    "TCAM allocation space. When these /32 & /128 routes are "
                    "generated, it assists in direct unicast routing to host "
                    "destinations on VNIs that are not stretched to the ingress "
                    "vtep, and avoids a route lookup to a subnet (eg, /24) that "
                    "may be hosted on many leafs. The directed host route "
                    "prevents a double lookup to one of many vteps may hosts "
                    "the /24 and instead routes the destination directly to "
                    "the correct vtep.")
    cumulus_vxlan_arp_suppression = s.Optional(
        s.Enum(['enabled', 'disabled']),
        load_default='enabled',
        description='Default enabled - This specifies whether or not cumulus leafs '
                    'render bridge-arp-nd-suppress as on or off. This option is '
                    'not intended for normal use by customers except in certain '
                    'circumstances, please consult Apstra Support before changing '
                    'this option from enabled to disabled. When this option is '
                    'configured to disabled, all L2 VXLAN kernel interfaces will '
                    'render bridge-arp-nd-suppress-off. The default behavior '
                    'when configured as enabled renders bridge-arp-nd-suppress-on.'
    )
    frr_rd_vlan_offset = s.Optional(
        s.Enum(['enabled', 'disabled']),
        load_default='enabled',
        description="Default enabled for new blueprints. On upgrade, this value "
                    "will default to disabled to prevent disruption. This knob "
                    "is used to increase the 'vlan_id' component of a route "
                    "distinguisher in FRR EVPN VXLAN rendering by 10,000 to avoid "
                    "a race condition between the kernel instantiating kernel vteps "
                    "and FRR immediately reacting to them potentially allocating a "
                    "duplicate <router_id>:<vlan_id>, which is automatically "
                    "assigned from an internal RD ID pool in FRR. When a virtual "
                    "network's VLAN overlaps with the FRR internal RD ID, Zebra "
                    "fails to install the EVPN IMET route correctly into the "
                    "kernel and does not generate Type3 routes to other devices. "
                    "This causes significant traffic disruption in an EVPN network. "
                    "Setting this option to 'enabled' may be disruptive while the "
                    "network reconverges with the new overlap-free design. This "
                    "changes the RD from 192.168.1.1:100 to 192.168.1.1:10100"
    )
    cumulus_bridge_mac_derivation = s.Optional(
        s.Enum(['first_interface', 'mgmt_interface']),
        load_default='mgmt_interface',
        description="Default mgmt_interface for new blueprints. On upgrade, this "
                    "value will default to first_interface to prevent disruption. "
                    "This option specifies the method that cumulus "
                    "bridges use to derive their MAC addresses. The Linux/Cumulus "
                    "default is to derive the MAC address from the first interface "
                    "that joins the bridge. This exposes an issue where the "
                    "spanning-tree bridge ID changes if the first interface is "
                    "removed from the bridge, causing a spanning-tree topology "
                    "change. Modifying this value to 'mgmt_interface' will change "
                    "configuration rendering to use a function to derive the MAC "
                    "from the management interface eth0 instead. This will isolate "
                    "any bridge membership changes from bridge MAC changes and add "
                    "determinism to the STP bridge ID."
    )
    junos_evpn_routing_instance_type = s.Optional(
        s.Enum(['default', 'vlan_aware']),
        load_default='vlan_aware',
        description="Selects Junos EVPN mac-vrf rendering mode. default indicates "
                    "EVPN configuration will be added to the default switch "
                    "instance on junos. vlan_aware will transition junos to a "
                    "single evpn mac-vrf vlan-aware instance named evpn-1, similar "
                    "to Junos EVO config rendering in Apstra."
    )
    junos_evpn_max_nexthop_and_interface_number = s.Optional(
        s.Enum(['enabled', 'disabled']),
        load_default='enabled',
        description="Enables configuring the maximum number of nexthops and "
                    "interface numbers reserved for use in EVPN-VXLAN overlay "
                    "network on Junos leaf devices. Default is set to enabled")
    junos_graceful_restart = s.Optional(
        s.Enum(['enabled', 'disabled']),
        load_default='enabled',
        description="Enables configuring the graceful restart on Junos devices."
                    "Default is set to enabled")
    junos_ex_overlay_ecmp = s.Optional(
        s.Enum(['enabled', 'disabled']),
        load_default='enabled',
        description="Enables configuring the overlay_ecmp on ex devices."
                    "Default is set to enabled")
    junos_evpn_duplicate_mac_recovery_time = s.Optional(
        s.Integer(
            validate=[s.Range(min=5, max=360)],
            description='Configures auto recovery time that the Juniper device '
                        'waits before the duplicate MAC address is unsuppressed.'
        ),
        load_default=DEFAULT_DUP_MAC_RECOVERY_TIME
    )
    default_svi_l3_mtu = s.Mtu(
        description="Default L3 MTU for SVI interfaces."
    )


class SecurityZoneFields(object):
    label = s.String(
        description='Unique user-friendly name of a routing zone.'
                    'Only locally significant on Apstra controller, '
                    'not used in device configurations',
        validate=s.Length(min=1)
    )
    sz_type = s.Enum(
        [
            'l3_fabric',
            'virtual_l3_fabric',
            'evpn',
        ],
        description='Routing zone type determines the interpretation '
                    'of fields like vni_id and vlan_id. '
                    'Default routing zone\'s sz_type is always "l3_fabric".'
                    ' A blueprint cannot have a mix of "virtual_l3_fabric" '
                    'and "evpn" routing zones.'
    )
    vni_id = s.VxlanId(
        description='L3 VNI ID for routing zone with sz_type == "evpn".'
                    'This is always None for sz_type != "evpn".'
    )
    vlan_id = s.VlanId(
        description='Multiple uses. (1) VRF-Lite 802.1q tagging '
                    'in sub-interfaces. VRF-Lite is implemented for fabric '
                    'links in "virtual_l3_fabric" routing zones, '
                    'and external router links of "evpn" routing zones. '
                    '(2) SVI configuration for L3 VNIs in "evpn" '
                    'routing zones. '
                    'With "virtual_l3_fabric" routing zones, vlan_id '
                    'must be unique across all routing zones. '
                    'With "evpn" routing zones, vlan_id must be unique '
                    'across all routing zones and virtual networks.'
    )
    # Constraining VRF name to have same syntax as virtual network label
    # because we render an L2 SVI with name <vrf name> per routing zone.
    # AOS-10660 - routing zone VRF name should be limited at 15 characters
    # due to linux constraint
    vrf_name = s.SecurityZoneName(
        description='Name of the virtual routing and forwarding (VRF) '
                    'instance instantiating the routing zone in systems. '
                    'Value is always "default" for the default '
                    'routing zone. Must be unique across all '
                    'routing zones.',
    )
    vrf_id = s.Integer(
        description='Unique integer ID of VRF',
        validate=[s.Range(min=s.MIN_VRF_ID, max=s.MAX_VRF_ID)],
    )
    l3_mtu = s.Mtu(description='MTU specific to L3 VNI')
    junos_evpn_irb_mode = s.Enum(
        [
            'asymmetric',
            'symmetric',
        ],
        description="Enables Symmetric IRB Routing for EVPN on Junos "
                    "devices. This makes use of an L3 VNI for inter-subnet "
                    "routing which is embedded into EVPN Type2-routes. This "
                    "supports better scaling for networks with large amounts of "
                    "VLANs. The default model is 'asymmetric' indicating "
                    "asymmetric EVPN mode. This option is only applicable to "
                    "security zones of sz_type 'evpn', and otherwise must be "
                    "configured as None",
    )
    vrf_description = s.String(
        description='Additional information/context to the routing zone '
                    'configuration that is also available on the switch itself',
        validate=[
            s.Length(min=1, max=240),
            s.Regexp('^[^"<>\\\\?]*$',
                     error='Invalid description. The following characters are not '
                           'allowed in the device configuration: ", <, >, \\, ?')
        ]
    )


class VirtualNetworkFields(object):
    label = s.VirtualNetworkLabel()
    vn_type = s.Enum(
        ['vlan', 'vxlan', 'external'],
        description='Type of virtual network.\n'
                    '"vlan" - virtual network hosted on a single leaf '
                    'or leaf pair;\n'
                    '"vxlan" - virtual network that can span across leafs '
                    'and racks;\n'
                    '"external" - deprecated'
    )
    vn_id = s.VirtualNetworkId()
    reserved_vlan_id = s.VlanId()
    description = s.VirtualNetworkDescription()
    ipv4_enabled = s.Boolean()
    ipv6_enabled = s.Boolean()
    ipv4_subnet = s.IpNetworkAddressOrPrefix()
    ipv6_subnet = s.Ipv6NetworkAddressOrPrefix()
    virtual_mac = s.MacAddress()
    virtual_gateway_ipv4_enabled = s.Boolean()
    virtual_gateway_ipv6_enabled = s.Boolean()
    virtual_gateway_ipv4 = s.IpAddress()
    virtual_gateway_ipv6 = s.Ipv6Address()
    l3_mtu = s.Mtu()


class ProtocolSessionFields(object):
    routing = s.Enum(ROUTING_TYPES, description='Protocol session routing protocol')
    ipv4_safi = s.Enum(['enabled', 'disabled'],
                       description='Indicates whether IPv4 address family is '
                                   'intended to be routed')
    ipv6_safi = s.Enum(['enabled', 'disabled'],
                       description='Indicates whether IPv6 address family is '
                                   'intended to be routed')
    ttl = s.Integer(
        description='Time to live (number of hops) value allowed for the session. '
                    'When this value is None or 0, no BFD Commands are rendered '
                    'on the device.',
        validate=[s.Range(min=0, max=255)])
    password = s.String(description='Protocol session password')
    mtu_ignore = s.Boolean()
    bfd = s.Boolean(description='Enable single-hop BFD')
    md5_key_id = s.Integer(
        description='Message digest authentication key',
        validate=[s.Range(min=1, max=255)])
    network_type = s.Enum(OSPF_NETWORK_TYPES)


class ProtocolEndpointFields(object):
    session_addressing_ipv4 = s.Enum(
        PROTOCOL_SESSION_IPV4_ADDRESSING_TYPES,
        description='Tells a routing protocol how to render a routing '
                    'session (e.g. a BGP neighbor command).\n'
                    '"addressed" - use the direct IP addresses\n'
                    '"prefix" - permit all peers of a given neighbor '
                    'subnet. Not applicable for OSPF.')
    session_addressing_ipv6 = s.Enum(
        PROTOCOL_SESSION_IPV6_ADDRESSING_TYPES,
        description='Tells a routing protocol how to render a routing '
                    'session (e.g. a BGP neighbor command).\n'
                    '"addressed" - use the direct IP addresses\n'
                    '"link_local" - use link-local and IPv6 '
                    'router-advertisement packets to establish a BGP peer '
                    'without explicit IP addressing. Not applicable for '
                    'OSPF\n'
                    '"prefix" - permit all peers of a given neighbor '
                    'subnet. Not applicable for OSPF.')
    neighbor_asn_type_ipv4 = s.Enum(
        PROTOCOL_SESSION_NEIGHBOR_ASN_TYPES,
        description='Allows to configure a BGP neighbor on an '
                    'interface/prefix/link-local session without '
                    'explicitly knowing the remote AS at config '
                    'rendering time. Cannot be set for OSPF '
                    'sessions.\n'
                    '"static" - the ASN of neighbor or group of '
                    'neighbors is known\n'
                    '"dynamic" - the ASN of neighbor or group of '
                    'neighbors is not known')
    neighbor_asn_type_ipv6 = s.Enum(
        PROTOCOL_SESSION_NEIGHBOR_ASN_TYPES,
        description='Allows to configure a BGP neighbor on an '
                    'interface/prefix/link-local session without '
                    'explicitly knowing the remote AS at config '
                    'rendering time. Cannot be set for OSPF '
                    'sessions.\n'
                    '"static" - the ASN of neighbor or group of '
                    'neighbors is known\n'
                    '"dynamic" - the ASN of neighbor or group of '
                    'neighbors is not known')
    prefix_neighbor_ipv4 = s.StrictIpNetworkAddress(
        description='IPv4 subnet to listen for BGP dynamic neighbors. '
                    'Mutually exclusive with prefix neighbor specified as '
                    'node in the graph. '
                    'Can only be specified if session_addressing_ipv4 is '
                    'set to prefix mode. '
                    'Not applicable for OSPF.')
    prefix_neighbor_ipv6 = s.StrictIpv6NetworkAddress(
        description='IPv6 subnet to listen for BGP dynamic neighbors. '
                    'Mutually exclusive with prefix neighbor specified as '
                    'node in the graph. '
                    'Can only be specified if session_addressing_ipv6 is '
                    'set to prefix mode. '
                    'Not applicable for OSPF.')
    local_asn = s.Asn(
        description='Local ASN for the protocol session. Not applicable for OSPF.')


class SecurityZonePolicyFields(object):
    footprint_optimise = s.Enum(
        ['enabled', 'disabled'],
        description='When enable: routing zones will not be rendered on '
                    'leafs where it is not required, which results in less resource '
                    'consumption. Routing zone will only be rendered for systems '
                    'which have other structures configured on top of routing zone, '
                    'such as virtual networks, protocol sessions, static routes, '
                    'subinterfaces, etc. '
                    'When disabled: routing zones are rendered on every leaf.')


ANTI_AFFINITY_FIELDS = {
    'mode': s.Enum(
        ['disabled', 'enabled_loose', 'enabled_strict'],
        description='Disabled - policy is not enabled in blueprint. Enabled_loose '
                    '- policy is applied, but is not allowed to override '
                    'user-defined cabling. Enabled_strict - the policy completely '
                    'controls the port distribution and can override user-defined '
                    'assignments.',
    ),
    'algorithm': s.Enum(
        ['heuristic'],
        description='The heuristic port assignment algorithm allocates interfaces in'
                    ' a greedy way, satisfying max_links_per_slot, '
                    'max_links_per_port, max_per_system_links_per_slot and '
                    'max_per_system_links_per_port constraints. It guarantees the '
                    'anti-affinity constraint fulfilment, but due to heuristic '
                    'nature may not find a distribution when it exists.'
    ),
    'max_links_per_slot': s.Integer(
        description='Maximal total number of links connected to the ports / '
                    'interfaces of the specific slot regardless of the system '
                    'they are targeted to.',
        validate=s.Range(min=0, max=255),
    ),
    'max_links_per_port': s.Integer(
        description='Maximal total number of links connected to the interfaces of '
                    'the specific port regardless of the system they are targeted '
                    'to.',
        validate=s.Range(min=0, max=255),
    ),
    'max_per_system_links_per_slot': s.Integer(
        description='Restricts the number of links to a certain system connected '
                    'to the ports / interfaces in a specific slot.',
        validate=s.Range(min=0, max=255),
    ),
    'max_per_system_links_per_port': s.Integer(
        description='Restricts the number interfaces on a port used to connect to '
                    'a certain system.',
        validate=s.Range(min=0, max=255),
    ),
}


FABRIC_POLICY_FIELDS = {
    'spine_leaf_links': s.Enum(
        ['ipv4', 'ipv6', 'ipv4_ipv6'],
        description=('Indicates which IPs to allocate for leaf to spine links. '
                     'This property is used to determine '
                     'if IPv6 application support is enabled in the '
                     'blueprint.'),
    ),
    'spine_superspine_links': s.Enum(
        ['ipv4', 'ipv6', 'ipv4_ipv6'],
        description=('Indicates which IPs to allocate for spine to superspine '
                     'links. This property is used to determine '
                     'if IPv6 application support is enabled in the '
                     'blueprint.'),
    ),
    'leaf_loopbacks': s.Enum(
        ['ipv4', 'ipv4_ipv6'],
        description=('Indicates which IPs to allocate for leaf '
                     'loopbacks. This property is used to determine '
                     'if IPv6 application support is enabled in the '
                     'blueprint.'),
    ),
    'spine_loopbacks': s.Enum(
        ['ipv4', 'ipv4_ipv6'],
        description=('Indicates which IPs to allocate for spine '
                     'loopbacks. This property is used to determine '
                     'if IPv6 application support is enabled in the '
                     'blueprint.'),
    ),
    'mlag_svi_subnets': s.Enum(
        ['ipv4', 'ipv4_ipv6'],
        description=('Indicates which IP subnets to allocate for '
                     'MLAG virtual networks in default routing zone.'),
    ),
    'leaf_l3_peer_links': s.Enum(
        ['ipv4', 'ipv4_ipv6'],
        description=('Indicates which IP subnets to allocate for '
                     'leaf L3 peer links in non-default routing zones.'),
    ),
    'esi_mac_msb': s.Integer(
        validate=[s.Range(min=0, max=254)],
        description=('This indicates the value of the most significant '
                     'byte used by Apstra to generate ESI MACs in the '
                     'blueprint. This has to be an even number to ensure '
                     'we dont generate multicast MACs that are best '
                     'avoided for this purpose. Default value is 2. '
                     'Updating this value will result in regeneration of '
                     'all existing ESI MACs.'),
    ),
    # TODO(menc): remove Optional wrapper here
    'fabric_l3_mtu': s.Optional(
        s.Mtu(
            description=('Specifies maximal size (in bytes) of the IP '
                         'packet that can be transmitted by the '
                         'IP Fabric underlay without fragmentation.'),
        ),
    ),
    'anti_affinity': s.Object(
        ANTI_AFFINITY_FIELDS,
        allow_extra_fields=False,
        default_field_type=s.IndexField,
    ),
    'optimise_sz_footprint': s.Enum(
        ['enabled', 'disabled'],
        description=(
            'When enable: routing zones will not be rendered on '
            'leafs where it is not required, which results in less resource '
            'consumption. Routing zone will only be rendered for systems '
            'which have other structures configured on top of routing zone, '
            'such as virtual networks, protocol sessions, static routes, '
            'subinterfaces, etc. '
            'When disabled: routing zones are rendered on every leaf.'),
    ),
    'junos_evpn_routing_instance_type': s.Enum(
        ['default', 'vlan_aware'],
        description=(
            "Selects Junos EVPN mac-vrf rendering mode. default indicates "
            "EVPN configuration will be added to the default switch "
            "instance on junos. vlan_aware will transition junos to a "
            "single evpn mac-vrf vlan-aware instance named evpn-1, similar "
            "to Junos EVO config rendering in Apstra."),
    ),
    'junos_evpn_max_nexthop_and_interface_number': s.Enum(
        ['enabled', 'disabled'],
        description=(
            'Enables configuring the maximum number of nexthops and '
            'interface numbers reserved for use in EVPN-VXLAN overlay '
            'network on Junos leaf devices. Default is set to enabled'),
    ),
    'junos_graceful_restart': s.Enum(
        ['enabled', 'disabled'],
        description=(
            'Enables configuring the graceful restart on Junos devices.'
            'Default is set to enabled'),
    ),
    'junos_ex_overlay_ecmp': s.Enum(
        ['enabled', 'disabled'],
        description=(
            'Enables configuring the overlay_ecmp on ex devices.'
            'Default is set to enabled'),
    ),
    'junos_evpn_duplicate_mac_recovery_time': s.Integer(
        validate=[s.Range(min=5, max=360)],
        description=(
            'Configures auto recovery time that the Juniper device '
            'waits before the duplicate MAC address is unsuppressed.'),
    ),
    # overlay_control_protocol is not used as part of fabric_policy payload in
    # blueprint generation API, but is kept inside templates and ingested into
    # fabric_policy node from there.
    'overlay_control_protocol': s.Optional(s.Enum(
        ['evpn'],
        description='Control protocol for VXLANs. If None, then no control plane '
                    'is used, and head-end replication in data plane is used '
                    'exclusively for MAC learning. If "evpn", then EVPN control '
                    'protocol run on leafs and spines. Please refer to Apstra '
                    'documentation for matrix of supported fabric control '
                    'protocols vs device vendors / models.')),
    # TODO: Since release-4.2.1, we only support values in range 1280-9216. This is
    #  insured in facade due to schema upgrade limitations. Once we drop support for
    #  pre-4.2.1 releases, this field type should be updated to s.Mtu and the facade
    #  validation should be removed.
    'external_router_mtu': s.Optional(s.Integer(
        validate=[s.Range(min=68, max=9216)],
        description='Specify fabric-wide external router interface IP MTU. Larger '
                    'MTU may be required to provide EVPN DCI Functionality or to '
                    'support fabric wide Jumbo frame functionality. MTU of 9050 '
                    'recommended for EVPN-DCI. A null (default) value implies '
                    'Apstra will not render a user-overridden MTU.')),
    'max_fabric_routes': s.Optional(s.Integer(
        validate=[s.Range(min=0, max=2 ** 32 - 1)],
        description='Maximum number of routes to accept between spine and leaf, '
                    'and spine and superspine in the fabric, or between leafs in '
                    'L3 Collapsed blueprints. This includes the default '
                    'VRF. Setting this option may be required in the event of '
                    'leaking EVPN routes from a routing zone into the default '
                    'routing zone (VRF) which could generate a large number of '
                    '/32 and /128 routes. It is suggested that this value is '
                    'effectively unlimited on all blueprints to ensure the network '
                    'stability of spine-leaf bgp sessions and evpn underlay. '
                    'Unlimited is also suggested for non-evpn blueprints '
                    'considering the impact to traffic if spine-leaf sessions go '
                    'offline. An integer between 1-2**32-1 will set a maximum '
                    'limit of routes in BGP config. The value 0 (zero) intends '
                    'the device to never apply a limit to number of fabric '
                    'routes (effectively unlimited).')),
    'max_external_routes': s.Optional(s.Integer(
        validate=[s.Range(min=0, max=2 ** 32 - 1)],
        description='Maximum number of routes to accept from external routers. '
                    'The default (None) will not render any maximum-route '
                    'commands on BGP sessions, implying that only vendor defaults '
                    'are used. An integer between 1-2**32-1 will set a '
                    'maximum limit of routes in BGP config. The value 0 (zero) '
                    'intends the device to never apply a limit to number of EVPN '
                    'routes (effectively unlimited).It is suggested this value '
                    'is value is effectively unlimited on evpn blueprints, to '
                    'permit the high number of /32 and /128 routes to be '
                    'advertised and received between VRFs in the event an external '
                    'router is providing a form of route leaking functionality.')),
    'max_mlag_routes': s.Optional(s.Integer(
        validate=[s.Range(min=0, max=2 ** 32 - 1)],
        description='Maximum number of routes to accept across MLAG peer switches. '
                    'The default (None) will not render any maximum-route '
                    'commands on BGP sessions, implying that only vendor defaults '
                    'are used. An integer between 1-2**32-1 will set a maximum '
                    'limit of routes in BGP config. The value 0 (zero) intends '
                    'the device to never apply a limit to number of EVPN routes '
                    '(effectively unlimited). Note: Device vendors typically '
                    'shut down BGP sessions if maximums are exceeded on a '
                    'session. For EVPN blueprints, this should be combined with '
                    'max_evpn_routes to permit routes across the l3 peer link '
                    'which may contain many /32 and /128 from EVPN type-2 routes '
                    'that convert into BGP route advertisements.')),
    'max_evpn_routes': s.Optional(s.Integer(
        validate=[s.Range(min=0, max=2 ** 32 - 1)],
        description='Maximum number of EVPN routes to accept on an EVPN switch. '
                    'The default (None) will not render any maximum-route '
                    'commands on BGP sessions, implying that only vendor defaults '
                    'are used. An integer between 1-2**32-1 will set a maximum '
                    'limit of routes in BGP config. The value 0 (zero) intends '
                    'the device to never apply a limit to number of EVPN routes '
                    '(effectively unlimited). Note: Device vendors typically '
                    'shut down BGP sessions if maximums are exceeded on a session.'
    )),
    'default_fabric_evi_route_target': s.Optional(
        s.RouteTarget(),
        validate=[s.Length(min=1)],
        description='Juniper Qfx series only supports vlan-aware models for EPVN,'
                    ' where 1 switching instance is mapped to multiple VLANs, '
                    'this route target is per EVI RT, which must be common across '
                    'the fabric for all switches participating in one EVI. And it '
                    'also must not overlap with any existing EVI (L2VNI) RTs.'),
    'evpn_generate_type5_host_routes': s.Optional(s.Enum(
        ['enabled', 'disabled'],
        description='Default disabled. When enabled all EVPN vteps in the fabric '
                    'will redistribute ARP/IPV6 ND (when possible on NOS type) '
                    'as EVPN type 5 /32 routes in the routing table. Currently, '
                    'this option is only certified for Juniper JunOS. FRR '
                    '(SONiC/Cumulus) does this implicitly and cannot be disabled. '
                    'This setting will be ignored. On Arista and Cisco, no '
                    'configuration is rendered and will result in a blueprint '
                    'warning that it is not supported by Apstra. This value is '
                    'disabled by default, as it generates a very large number of '
                    'routes in the BGP routing table and takes large amounts of '
                    'TCAM allocation space. When these /32 & /128 routes are '
                    'generated, it assists in direct unicast routing to host '
                    'destinations on VNIs that are not stretched to the ingress '
                    'vtep, and avoids a route lookup to a subnet (eg, /24) that '
                    'may be hosted on many leafs. The directed host route '
                    'prevents a double lookup to one of many vteps may hosts '
                    'the /24 and instead routes the destination directly to '
                    'the correct vtep.')),
    'frr_rd_vlan_offset': s.Enum(
        ['enabled', 'disabled'],
        description="Default enabled for new blueprints. On upgrade, this value "
                    "will default to disabled to prevent disruption. This knob "
                    "is used to increase the 'vlan_id' component of a route "
                    "distinguisher in FRR EVPN VXLAN rendering by 10,000 to avoid "
                    "a race condition between the kernel instantiating kernel vteps "
                    "and FRR immediately reacting to them potentially allocating a "
                    "duplicate <router_id>:<vlan_id>, which is automatically "
                    "assigned from an internal RD ID pool in FRR. When a virtual "
                    "network's VLAN overlaps with the FRR internal RD ID, Zebra "
                    "fails to install the EVPN IMET route correctly into the "
                    "kernel and does not generate Type3 routes to other devices. "
                    "This causes significant traffic disruption in an EVPN network. "
                    "Setting this option to 'enabled' may be disruptive while the "
                    "network reconverges with the new overlap-free design. This "
                    "changes the RD from 192.168.1.1:100 to 192.168.1.1:10100."),
    'default_svi_l3_mtu': s.Optional(s.Mtu(
        description="Default L3 MTU for SVI interfaces."
    )),
}


DCI_SETTINGS_FIELDS = {
    'esi_mac_msb': FABRIC_POLICY_FIELDS['esi_mac_msb']
}


class StaticRouteFields(object):
    label = s.String(validate=[s.Length(min=1)], description='Static route label')
    system_id = s.NodeId(description='Node ID of system that should have the static '
                                     'route')
    network_node_id = s.NodeId(
        description='Node of type "interface" - indicates the network part of the '
                    'static route is taken from the address on the target interface '
                    'node. "network_node_id" and "network" are mutually exclusive.'
    )
    network = s.Ipv6orIpv4NetworkAddress(
        description='Target network for the static route. "network_node_id" and '
                    '"network" are mutually exclusive.'
    )
    next_hop_id = s.NodeId(description='Next hop interface ID or ip_endpoint ID')
    source_interface_id = s.NodeId(description='Subinterface or SVI on the system '
                                               'to use for reaching the next-hop')
    ip_version = s.Enum(['ipv4', 'ipv6'],
                        description='IP version for the static route')
    security_zone_id = s.NodeId(description='Routing zone ID')


class SubinterfaceFields(object):
    ADDR_TYPE_DESC = ('Property is used ONLY by subinterfaces on generic '
                      'systems and border leafs. This is null for interfaces '
                      'that do not need an address of respective type.')

    SubinterfaceVlanId = s.validated_type(
        s.Integer, 'VlanId', s.Range(
            2, MAX_VLAN_ID,
            error='Vlan ID should be at least {min} and at most {max} '
                  'for subinterfaces'))

    interface_id = s.NodeId(description='Physical interface node ID')
    sz_id = s.NodeId(description='Routing zone node ID')
    vlan_id = SubinterfaceVlanId(description='Subinterface VLAN ID for local VLAN '
                                             'traffic')
    ipv4_addr_type = s.Enum(['numbered'],
                            description=ADDR_TYPE_DESC)
    ipv6_addr_type = s.Enum(['numbered', 'link_local'],
                            description=ADDR_TYPE_DESC)
    ipv4_addr = s.IpNetworkAddress(description='Subinterface IPv4 address')
    ipv6_addr = s.Ipv6NetworkAddress(description='Subinterface IPv6 address')
    l3_mtu = s.Mtu(description='Subinterface L3 MTU value')


POLICY_DIRECTION_DESCRIPTION = 'The direction is used for security policy '\
                               'to define traffic source and destination. '\
                               'The relationship to traffic source '\
                               'is marked with "from" and the relationship '\
                               'to traffic destination - with "to". '\
                               'If policy direction is not specified, '\
                               'the policy is considered non-directional.'

POLICY_ENABLED_DESCRIPTION = 'A flag indicating whether security policy rules ' \
                             'should be used for defining network ACL to control ' \
                             'traffic or not.'

GROUP_TYPE_DESCRIPTION = 'Defines the type of the objects the group contains ' \
                         'directly or via nested groups of the same type. ' \
                         'Internal endpoints are: subnets managed by Apstra, ' \
                         'virtual networks and routing zones. ' \
                         'External endpoints are subnets ' \
                         'not managed by Apstra directly. ' \
                         'Enforcement points are hints for the Apstra ' \
                         'to identify entry points of external traffic. ' \
                         'Enforcement points are represented by SVI interfaces or ' \
                         'by generic-facing subinterfaces on fabric side. ' \
                         'Routing zones can be grouped to simplify ' \
                         'Routing Zone Constraints definition. ' \
                         'It is allowed to recursively include child groups ' \
                         'into the parent group of the same type. ' \
                         'It is forbidden to include objects or groups ' \
                         'of different type into the same group.'

RESOLVED_BY_TYPE = s.Enum(
    ['aos', 'user', 'aos-transitive', 'user-invalid'],
    description='The relationship identifies that a conflict '
                'between two rules has been resolved '
                'manually or automatically and the source rule node '
                'should be rendered before target rule node. '
                'If a rule conflict was automatically resolved by Apstra '
                'using policy knob, the property value is "aos". '
                'If a rule conflict was manually resolved by user, '
                'the property value is "user". '
                'If user sets a precedes relationship between '
                'non-conflicting rules, the value is "user-invalid". '
                'The value "user-invalid" is introduced in the staging graph. '
                'If it is possible to resolve a conflict based on '
                'previously introduced user-defined or aos-generated "precedes" '
                'relationships, then such resolution is called "transitive" '
                'and corresponding "precedes" will have the property '
                'set to "aos-transitive"'
)


class Schema(s.Schema):
    nodes = {
        'system': s.NodeSchema('system', {
            'label': s.Optional(s.String()),
            'system_type': s.Enum(['switch', 'server']),
            'management_level': s.SparseOptional(s.ManagementLevel),
            'external': s.SparseOptional(s.Boolean(
                description='Indicates the position of system related to a rack. '
                            'This field is used only for generic systems to '
                            'identify systems do not belong to any rack.'
            ), load_default=False),
            'role': s.Enum(NODE_ROLES),
            'hostname': s.Optional(s.Hostname()),
            'system_id': s.Optional(s.String()),
            'system_index': s.Optional(s.Integer(
                description=(
                    'A unique integer index for this system node useful for '
                    'rendering device configurations. For now it is used to derive '
                    'the "device ID" component of a BGP community for the system'
                ),
                validate=s.Range(min=s.MIN_SYSTEM_INDEX, max=s.MAX_SYSTEM_INDEX),
            )),
            'deploy_mode': s.Optional(s.Enum(
                SYSTEM_DEPLOY_MODES,
                description='Config deployment mode of the system '
                'deploy: intended service config is applied on the system '
                'ready: system is in sane state and ready for '
                'service config application '
                'drain: system is in maintenance mode and traffic on its links '
                'is drained/being drained')),
            'position_data': s.SparseOptional(s.Dict({
                'region': s.Optional(s.Integer(
                    description='Datacenter region number.',
                    validate=s.Range(min=0),
                ), load_default=s.MISSING),
                'plane': s.Optional(s.Integer(
                    description=(
                        'superspine plane if the system is a superspine'
                        ' or spine plane if it is a spine. -1 represents '
                        'that it is not applicable for this type of system'
                    ),
                    validate=s.Range(min=-1),
                ), load_default=s.MISSING),
                'pod': s.Optional(s.Integer(
                    description=(
                        'pod number of the spine or leaf'
                        ' -1 represents that it is not applicable for'
                        ' this type of system.'
                    ),
                    validate=s.Range(min=-1),
                ), load_default=s.MISSING),
                # Sequence number of the system.
                # This sequence is per each type.
                # e.g: index of spine/superspine in its plane
                'position': s.Optional(s.Integer(
                    description='System sequence number.',
                    validate=s.Range(min=0),
                ), load_default=s.MISSING),
                'rg_position': s.Optional(s.Integer(
                    description='System sequence number in a redundancy group. '
                                'Applicable to leafs and access switches.',
                    validate=s.Range(min=0, max=1),
                ), load_default=s.MISSING)
            })),
            'group_label': s.SparseOptional(s.String(
                description='Group label of systems within a rack. Currently '
                            'used for association of systems with groups in '
                            'rack types.',
                validate=[s.Length(min=1)],
            )),
            'port_channel_id_min': s.Optional(
                s.Integer(validate=s.Range(min=0, max=4096))),
            'port_channel_id_max': s.Optional(
                s.Integer(validate=s.Range(min=0, max=4096))),
            'access_l3_peer_link_port_channel_id_min': s.Optional(
                s.Integer(validate=s.Range(min=0, max=4096))),
            'access_l3_peer_link_port_channel_id_max': s.Optional(
                s.Integer(validate=s.Range(min=0, max=4096))),
        }, indexes=[('role', 'deploy_mode')]),
        'redundancy_group': {
            'label': s.Optional(s.String()),
            # rg_type 'l3' is deprecated since release 2.3.0
            'rg_type': s.Optional(s.Enum(
                [
                    'mlag',
                    'l3',
                    # RGs of type esi represent a dual-leaf rack that's using EVPN
                    # ESI to provide multi-homing to servers.
                    # In future, we will not even create an RG node for this case, as
                    # ESI based redundancy is at the port level and not at the
                    # system-level. Creation of system-wide RG makes it difficult to
                    # support flexible N-way multi-homing natively supported by ESI.
                    # However there is a lot of code/workflow that relies on RG and
                    # we don't want to take up this cost in phase1, especially given
                    # 2-way multi-homing is the most common case
                    'esi',
                ]), load_default='mlag'),
            # rg_id is Optional with load default to facilitate upgrade path from
            # 2.1 blueprints, whose redundancy_group nodes have no rg_id defined.
            # Validator ensures that rg_id is unique in the blueprint.
            'rg_id': s.Optional(
                s.Integer(
                    validate=s.Range(min=1),
                    description='Unique ID for the redundancy group across the '
                                'blueprint. Currently used for rendering unique '
                                'anycast mac address for Cumulus MLAG leaf pairs.'),
                load_default=1),
        },
        'rack': {
            'label': s.Optional(s.String(validate=[s.Length(min=1)])),
            'position': s.Optional(s.Integer(), load_default=1),
            'rack_type_json': s.Optional(
                s.String(validate=[s.Length(min=1)]),
                description=(
                    'Contains corresponding JSON-serialized rack type from '
                    'which this rack node was generated.'
                ),
            ),
            'ip_version': s.Optional(
                s.Enum(
                    ['ipv4', 'ipv6', 'ipv4_ipv6'],
                    description=(
                        'DEPRECATED. IP version to use for server<->leaf links '
                        'addresses. This option is used only for L3 servers.'),
                    ),
                load_default='ipv4'
            ),
        },
        'link': {
            'label': s.Optional(s.String()),
            'link_type': s.Enum([
                'ethernet', 'aggregate_link', 'logical_link'
            ], description='Ethernet links are physical links. Aggregate links '
                           'connect port channels. Logical links connect '
                           'logical interfaces sucha as sub-interfaces.'),
            'role': s.Enum(LINK_ROLES),
            'speed': s.Optional(s.PortSpeed),
            'deploy_mode': s.Optional(
                s.Enum(['deploy', 'drain'],
                       description=\
                       'deploy: is in normal mode of operation '
                       'drain: traffic on the link is '
                       'drained/being drained since attached system'
                       ' is in maintenance mode'),
                load_default='deploy'
            ),
            'group_label': s.SparseOptional(s.String(
                description='Group label of links. Currently used for '
                            'association of server links with link groups in '
                            'rack types.',
                validate=[s.Length(min=1)],
            )),
        },
        'interface': {
            'label': s.Optional(s.String()),
            'if_type': s.Enum(
                IF_TYPES,
                description='Type of interface. '
                            'subinterface: has composed_of relationship with '
                            'parent interface'),
            # NOTE: The empty string hasn't been considered as a valid value
            #       since 4.2.1. The validation on the empty string can be
            #       enforced on the graph schema level once the lowest possible
            #       upgradable release is 4.2.1.
            'if_name': s.Optional(s.String()),
            # Allowed: "!", "#" to ";", "=", "@" to "~".
            # Space is also allowed, except in the start and the end of the string.
            'description': s.Optional(s.String(validate=[s.Length(max=240), \
                s.Regexp(r'\A([!#-;=@-[\]-~]([ !#-;=@-[\]-~]*[!#-;=@-[\]-~])?)?\Z', \
                error='Invalid interface description. Only ASCII characters ' \
                'with codes 32 - 126, except "?", "<", ">" ,\'"\' and \\ are ' \
                'allowed. The description should not start or end with a space.')])),
            'mode': s.Optional(s.Enum(['trunk', 'access'])),
            'operation_state': s.Optional(
                s.Enum(['up', 'deduced_down', 'admin_down'],
                       description='This field represents interface state on the '
                                   'device. It can be explicitly set to "up" or '
                                   '"admin_down" via the API. Physical interfaces, '
                                   'port channels and subinterfaces are set to '
                                   '"deduced_down" by builder in case the interface '
                                   'was not shut down by user, but cannot operate '
                                   'because other interfaces are disabled '
                                   'administratively. E.g. interface will be in '
                                   '"deduced_down" state when its peer is shut '
                                   'down. Another example - when all child '
                                   'interfaces of the port channel are disabled.'),
                load_default='up'
            ),
            'ipv4_addr': s.SparseOptional(s.IpNetworkAddress()),
            'ipv6_addr': s.SparseOptional(s.Ipv6NetworkAddress()),
            'ipv4_enabled': s.SparseOptional(s.Boolean(
                description='Explicitly set to True or False to indicate whether '
                            'ipv4_addr should be allocated or not. '
                            'The default value is None. If set, then validation is '
                            'performed to ensure ipv4_addr is '
                            'allocated(ipv4_enabled == True), or is '
                            'not allocated(ipv4_enabled == False). If None, then '
                            'no such validation is performed. '
                            'For if_type "logical_vtep", "unicast_vtep", '
                            '"anycast_vtep", "global_anycast_vtep", '
                            'this property is set by the builder, based on whether '
                            'the IPv4 address for that VTEP is required on '
                            'the hosting system. User overrides will be cleared '
                            'by the builder if ipv4_enabled=False. '
                            'For all other if_type, there is no special handling '
                            'by builder. User overrides of this property for '
                            'VTEPs will not be honored by the builder '
                            'Since setting this value to a non-None value triggers '
                            'validation, the user is advised against overriding '
                            'this value explicitly.'
            )),
            'ipv6_enabled': s.SparseOptional(s.Boolean(
                description='Explicitly set to True or False to indicate whether '
                            'ipv6_addr should be allocated or not. '
                            'For if_type "loopback", "subinterface", this property '
                            'is set by facade APIs during blueprint creation or '
                            'enabling IPv6 footprint in a blueprint upgraded from '
                            'an older version of Apstra that does not support IPv6 '
                            'applications. '
                            'For if_type "ip", "svi", this property is None '
                            'because ipv6_addr allocation is determined from '
                            'policy or vn_instance nodes. '
                            'For if_type "ethernet", "port_channel", "*_vtep" '
                            'ipv6_addr is not applicable, so '
                            'this property is None as well. '
                            'If set, then validation is performed to ensure '
                            'ipv6_addr is allocated (ipv6_enabled == True) '
                            'or not allocated (ipv6_enabled == False). '
                            'If None, no such validation is performed.'
            )),
            'port_channel_id': s.SparseOptional(s.Integer()),
            'mlag_id': s.SparseOptional(s.Integer()),
            'protocols': s.SparseOptional(s.Enum(['ebgp', 'iccp'])),
            'loopback_id': s.SparseOptional(s.LoopbackId(
                description='For interfaces with if_type != loopback, this field is '
                            'unused - recommend setting to None. '
                            'For interfaces with if_type == loopback, this is used '
                            'to index loopbacks of the system. Loopback '
                            'interface names are generated based on this ID and '
                            'the OS of that system. The value must be unique across '
                            'loopbacks of a system. The value 0 is always assigned '
                            'to the loopback in default routing zone. The value 1 '
                            'is reserved for VTEP. Therefore, loopbacks for '
                            'non-default routing zone and for multicast should '
                            'have indices starting from 2. Loopbacks associated '
                            'with the same routing zone may have same or different '
                            'index, though routing zone facade API strives to '
                            'assign the same index to loopbacks from same SZ.'
            )),
            'lag_mode': s.SparseOptional(s.LagModes),
            'po_control_protocol': s.SparseOptional(s.Enum(
                ['mlag', 'evpn'],
                description=(
                    'This field applies only to top-level port-channels that compose'
                    ' interfaces on multiple systems and indicates the control '
                    'protocol used for synchronizing any needed network state. For '
                    'non-port-channels it is not applicable. For port-channels '
                    'confined to a single system, it is None - because there is no '
                    'control protocol required. Having this field at the interface '
                    'level gives us the maximum flexibility to cover whatever is '
                    'technically possible today'))),
            'evpn_esi_mac': s.SparseOptional(s.MacAddress(
                description=(
                    'This field indicates the MAC address part of the 10 byte EVPN '
                    'Ethernet Segment ID and is only applicable for nodes with '
                    'po_control_protocol="evpn". This must be unique across the '
                    'blueprint. Apstra only supports ESI types 0 '
                    '(used for Junos, EOS) and 3 (used for NXOS). '
                    'For ESI type0, Apstra uses this MAC address '
                    'for the 6 octets after the first type octet and the remaining '
                    '3 octets are zeroed. For type 3, this MAC address is used as '
                    'system MAC and the next 3 octet Logical Discriminator value is '
                    'derived from this MAC in the most appropriate manner '
                    'per device platform. '
                    'Apstra automatically allocates a value for this field '
                    'unless user specifies an explicit override which will be '
                    'respected. From the schema viewpoint, ESI types 1 and 2, which '
                    'also use MAC address, are covered'))),
            'vlan_id': s.SparseOptional(SubinterfaceFields.vlan_id),
            'subintf_id': s.SparseOptional(s.SubintfId(
                description='For interfaces with if_type != subinterface, this '
                            'field is unused - recommend setting to None. '
                            'For interfaces with if_type == subinterface, this is '
                            'used to index subinterfaces of the physical interface. '
                            'It is required for generating subinterface names on '
                            'NXOS platform when subinterface\'s vlan_id value '
                            'cannot be used due to platform limitations, see '
                            'https://quickview.cloudapps.cisco.com/quickview/bug/'
                            'CSCux11016 for details. The value mush be unique '
                            'across subinterfaces on the same physical interface.',
                )),
            'ipv4_addr_type': s.SparseOptional(SubinterfaceFields.ipv4_addr_type),
            'ipv6_addr_type': s.SparseOptional(SubinterfaceFields.ipv6_addr_type),
            'l3_mtu': s.SparseOptional(s.Mtu()),
            'ref_count': s.SparseOptional(s.Integer(
                description='The reference counter to destroy the loopback '
                            'interface on generic when all EPT policies that use '
                            'this interface are destroyed',
                validate=[s.Range(min=1)]))
        },
        'domain': {
            'label': s.Optional(s.String()),
            'domain_type': s.Enum(
                ['autonomous_system', 'area', 'mlag'],
                description="An autonomous_system indicates a BGP ASN. "
                            "An Area indicates an OSPF Area ID. "
                            "An MLAG domain indicates collection of L2 MLAG "
                            "leafs in a rack and the servers that dual-attach to "
                            "them."),
            'domain_id': s.Optional(s.String()),
            'ref_count': s.Optional(s.Integer(
                description='The reference counter to destroy the domain '
                            'interface on generic when all EPT policies that use '
                            'this interface are destroyed',
                validate=[s.Range(min=1)]))
        },
        'virtual_network': {
            'label': s.Optional(VirtualNetworkFields.label),
            # NOTE(shanshan): It shares two common fields with
            # VnetRemediationPolicyVnetType in sdk/types.py and these two common
            # fields ['vlan', 'vxlan'] need to be in sync in both places
            'vn_type': VirtualNetworkFields.vn_type,
            'vn_id': s.Optional(VirtualNetworkFields.vn_id),
            'reserved_vlan_id': s.Optional(VirtualNetworkFields.reserved_vlan_id),
            'description': s.Optional(VirtualNetworkFields.description),
            # NOTE (skraynev): it's intentional duplication of vn_instance
            # properties, cause this data is required by validator and builder
            'ipv4_enabled': s.Optional(
                VirtualNetworkFields.ipv4_enabled,
                load_default=False
            ),
            'ipv6_enabled': s.Optional(
                VirtualNetworkFields.ipv6_enabled,
                load_default=False
            ),
            'ipv4_subnet': s.Optional(VirtualNetworkFields.ipv4_subnet),
            'ipv6_subnet': s.Optional(VirtualNetworkFields.ipv6_subnet),
            'virtual_mac': s.Optional(VirtualNetworkFields.virtual_mac),
            'virtual_gateway_ipv4_enabled': s.Optional(
                VirtualNetworkFields.virtual_gateway_ipv4_enabled,
                load_default=False
            ),
            'virtual_gateway_ipv6_enabled': s.Optional(
                VirtualNetworkFields.virtual_gateway_ipv6_enabled,
                load_default=False
            ),
            'virtual_gateway_ipv4': s.Optional(
                VirtualNetworkFields.virtual_gateway_ipv4
            ),
            'virtual_gateway_ipv6': s.Optional(
                VirtualNetworkFields.virtual_gateway_ipv6
            ),
            'l3_mtu': s.Optional(VirtualNetworkFields.l3_mtu),
        },
        'vn_instance': {
            'label': s.Optional(s.String()),
            'vlan_id': s.Optional(s.VlanId()),
            # Deprecated since 3.0.0.
            # NOTE (skraynev): l3_enabled is left only for upgrade plugin
            'l3_enabled': s.Optional(s.Boolean()),
            'ipv4_enabled': s.Optional(s.Boolean(), load_default=False),
            'ipv6_enabled': s.Optional(s.Boolean(), load_default=False),
            'ipv4_mode': s.Optional(s.SviIpv4AllocationMode,
                                    load_default='disabled'),
            'ipv6_mode': s.Optional(s.SviIpv6AllocationMode,
                                    load_default='disabled'),
            'dhcp_enabled': s.Boolean(),
            # NOTE: Not supported since Cumulus support was dropped
            'vni': s.Optional(s.VxlanId(description='Deprecated')),
            # NOTE: Not supported since Cumulus support was dropped
            'vni_type': s.Optional(s.Enum(['l2'], description='Deprecated')),
        },
        'vn_endpoint': {
            'label': s.Optional(s.String()),
            'tag_type': s.Enum(['vlan_tagged', 'untagged']),
        },
        'routing_zone_constraint': {
            'label': s.Optional(s.String()),
            'routing_zones_list_constraint': s.Optional(
                RoutingZoneConstraintFields.routing_zones_list_constraint),
            'max_count_constraint': s.Optional(
                RoutingZoneConstraintFields.max_count_constraint),
        },
        'routing_policy': {
            # TODO(elena): Should be updated RoutingPolicyFields.label when upgrade
            #  infra supports separate schemas for different releases
            'label': s.Optional(s.String()),
            'description': s.Optional(
                RoutingPolicyFields.description
            ),
            'policy_type': s.Optional(
                RoutingPolicyFields.policy_type
            ),
            'import_policy': s.Optional(
                RoutingPolicyFields.import_policy,
                load_default='all'),
            'export_loopbacks': s.Optional(
                RoutingPolicyFields.export_policy_loopbacks,
                load_default=True),
            'export_spine_leaf_links': s.Optional(
                RoutingPolicyFields.export_policy_spine_leaf_links,
                load_default=True),
            'export_spine_superspine_links': s.Optional(
                RoutingPolicyFields.export_policy_spine_superspine_links,
                load_default=True),
            'export_l2edge_subnets': s.Optional(
                RoutingPolicyFields.export_policy_l2edge_subnets,
                load_default=True),
            'export_l3edge_server_links': s.Optional(
                s.Boolean(description="This field is deprecated and should not "
                                      "be used."),
                load_default=True),
            'export_static_routes': s.Optional(
                RoutingPolicyFields.export_policy_static_routes,
                load_default=False,
            ),
            'aggregate_prefixes': s.Optional(
                RoutingPolicyFields.aggregate_prefixes,
                load_default=list),
            'extra_import_routes': s.Optional(
                RoutingPolicyFields.extra_import_routes,
                load_default=list,
                validate=RoutingPolicyFields.import_export_routes_validate
            ),
            'extra_export_routes': s.Optional(
                RoutingPolicyFields.extra_export_routes,
                load_default=list,
                validate=RoutingPolicyFields.import_export_routes_validate
            ),
            'expect_default_ipv4_route': s.Optional(
                RoutingPolicyFields.expect_default_ipv4_route,
                load_default=True,
            ),
            'expect_default_ipv6_route': s.Optional(
                RoutingPolicyFields.expect_default_ipv6_route,
                load_default=True,
            ),
        },
        'route_target_policy': {
            'import_RTs': s.Optional(RouteTargetPolicyFields.import_RTs),
            'export_RTs': s.Optional(RouteTargetPolicyFields.export_RTs),
        },
        # Only used for EVPN Remote GW, otherwise deprecated in AOS 4.0.0
        # For connectivity points, replaced by 'protocol_session'.
        'protocol': {
            'label': s.Optional(s.String()),
            'routing': s.Optional(s.Enum(ROUTING_TYPES)),
            'ttl': s.Optional(
                s.Integer(
                    description='Time to live (number of hops) value allowed '
                                'for the session',
                    validate=[s.Range(min=2, max=255)])
            ),
            'password': s.Optional(s.String(validate=[s.Length(min=1)])),
            'keepalive_timer': s.Optional(
                s.Integer(
                    description='Protocol session keep alive timer value',
                    validate=[s.Range(min=0, max=65535)])
            ),
            'holdtime_timer': s.Optional(
                s.Integer(
                    description='Protocol session hold time timer value',
                    validate=[s.Range(min=0, max=65535)])
            ),
            'afi_safi': s.Optional(
                s.List(
                    s.Dict({
                        'afi': s.Integer(
                            description='Address family identifier',
                            validate=[s.Range(min=0, max=65535)]),
                        'safi': s.Integer(
                            description='Subsequent address family identifier',
                            validate=[s.Range(min=0, max=255)])
                    })
                )
            ),
            'evpn_route_types': s.Optional(
                s.Enum(['all', 'type5_only'],
                       description='Indicates permitted EVPN route types to '
                                   'advertise to the EVPN-DCI peers. By default '
                                   'all EVPN route types are advertised. A pure '
                                   'type5-only option is for networks which do '
                                   'not require layer2 stretching between fabrics.'),
                load_default='all'),
        },
        'protocol_session': {
            'label': s.Optional(s.String()),
            'routing': ProtocolSessionFields.routing,
            'ipv4_safi': ProtocolSessionFields.ipv4_safi,
            'ipv6_safi': ProtocolSessionFields.ipv6_safi,
            'ttl': s.Optional(ProtocolSessionFields.ttl),
            'password': s.Optional(ProtocolSessionFields.password),
            # Matches OSPF 'hello_timer' attribute.
            'keepalive_timer': s.Optional(
                s.Integer(
                    description='Protocol session keep alive timer value.',
                    validate=[s.Range(min=1, max=65535)]),
            ),
            # Matches OSPF 'dead_timer' attribute.
            'holdtime_timer': s.Optional(
                s.Integer(
                    description='Protocol session hold time timer value.',
                    validate=[s.Range(min=2, max=65535)]),
            ),
            'bfd': s.Optional(ProtocolSessionFields.bfd,
                              load_default=DEFAULT_PROTOCOL_SESSION_BFD),
            'deploy_mode': s.Optional(
                s.Enum(BGP_PROTOCOL_SESSION_DEPLOY_MODES,
                       description='A computed property that is set by the builder '
                                   'based on link level drain intent. This is '
                                   'applicable to BGP and not applicable for OSPF.')
            ),
            # OSPF properties.
            'mtu_ignore': s.Optional(ProtocolSessionFields.mtu_ignore),
            'md5_key_id': s.Optional(ProtocolSessionFields.md5_key_id),
            'network_type': s.Optional(ProtocolSessionFields.network_type),
            'ref_count': s.Optional(s.Integer(
                description='The reference counter to destroy the protocol session '
                            'on generic when all EPT policies that use this '
                            'protocol session are destroyed',
                validate=[s.Range(min=1)]))
        },
        'protocol_endpoint': {
            'session_addressing_ipv4':
                s.Optional(ProtocolEndpointFields.session_addressing_ipv4),
            'session_addressing_ipv6':
                s.Optional(ProtocolEndpointFields.session_addressing_ipv6),
            'neighbor_asn_type_ipv4':
                s.Optional(ProtocolEndpointFields.neighbor_asn_type_ipv4),
            'neighbor_asn_type_ipv6':
                s.Optional(ProtocolEndpointFields.neighbor_asn_type_ipv6),
            'prefix_neighbor_ipv4':
                s.Optional(ProtocolEndpointFields.prefix_neighbor_ipv4),
            'prefix_neighbor_ipv6':
                s.Optional(ProtocolEndpointFields.prefix_neighbor_ipv6),
            'local_asn':
                s.Optional(ProtocolEndpointFields.local_asn)
        },
        # Deprecated since 4.0.0.
        'ospf_policy': {
            'mtu_ignore': s.Optional(s.Boolean(), load_default=True),
            'hello_timer': s.Optional(
                s.Integer(
                    description='Interval between transmission of hello packets',
                    validate=[s.Range(min=1, max=65535)])
            ),
            'dead_timer': s.Optional(
                s.Integer(
                    description='Interval to detect a dead peer',
                    validate=[s.Range(min=1, max=65535)])
            ),
            'bfd': s.Optional(s.Boolean()),
            'md5_key_id': s.Optional(
                s.Integer(
                    description='Message digest authentication key',
                    validate=[s.Range(min=1, max=255)])
            ),
            'md5_key': s.Optional(s.String()),
            'network_type': s.Optional(s.Enum(OSPF_NETWORK_TYPES),
                                       load_default='broadcast')
        },
        'l3_edge_ip_connectivity_policy': {
            'label': s.Optional(s.String()),
            'internal_subnets': s.Optional(s.List(s.Ipv6orIpv4NetworkAddress()),
                                           load_default=list),
            'external_subnets': s.Optional(s.List(s.Ipv6orIpv4NetworkAddress()),
                                           load_default=list),
        },
        'static_route': {
            'label': s.Optional(s.String()),
            'ip_version': StaticRouteFields.ip_version,
            'network': s.Optional(
                s.Ipv6orIpv4NetworkAddress(),
                description='Target network for the static route'),
            'ref_count': s.Optional(s.Integer(
                description='The reference counter to destroy the static route '
                            'when all EPT policies that use this static route '
                            'are unapplied',
                validate=[s.Range(min=1)]))
        },
        'logical_device': {
            'label': s.Optional(s.String()),
            'json': s.String(),
        },
        'interface_map': interface_map_fields,
        'device_profile': dp_fields,
        'group': {
            'label': s.Optional(s.String(
                description='Unique user-friendly name of a group.'
            )),
            'group_type': s.Enum([
                'global_leaves', # Deprecated since 2.2
                'global_virtual_networks', # Deprecated since 2.2
                'virtual_network', # Deprecated. Was never used
                'global_systems', # Deprecated since 2.3.0
                'internal_endpoints',
                'external_endpoints',
                'enforcement_points',
                'security_zones',
            ], description=GROUP_TYPE_DESCRIPTION),
            'description': s.Optional(s.Description()),
        },
        'policy': {
            'label': s.Optional(s.String(
                description='Unique user-friendly name of a policy.'
            )),
            'policy_type': s.Enum(
                ['dhcp_relay', 'security'],
                description='DHCP relay policy specifies DHCP server IP addresses '
                            'for a routing zone. '
                            'Security policy defines ACL rules for traffic.'
            ),
            'description': s.Optional(s.Description()),
            'dhcp_servers': s.Optional(
                s.List(
                    s.Ipv4OrIpv6Address(),
                    description='IP addresses of the DHCP servers. '
                                'Applicable for DHCP relay policy only.'),
                load_default=list),
            'enabled': s.Optional(
                s.Boolean(description=POLICY_ENABLED_DESCRIPTION),
                load_default=True)
        },
        'gbp_config': {
            'label': s.Optional(s.String()),
            'conflict_resolution': s.Optional(
                s.Enum(
                    ['more_specific_first', 'more_generic_first', 'disabled'],
                    description='Instructs how to handle full-containment '
                                'security rule intersections. '
                                'If "more_specific_first" is selected, '
                                'contained rule is rendered before containing. '
                                'If "more_generic_first" - containing '
                                'before contained. If "disabled" - no automatic '
                                'conflict resolution takes place.'
                ),
                load_default='more_specific_first'),
            'default_action': s.Optional(
                s.SecurityRuleAction(),
                description='An action to be performed by default by ACL for all '
                            'traffic. On whitelist devices (NXOS), we need to '
                            'explicitly add trailing "permit any any" rule if '
                            'user wants for ACL to behave as blacklist.',
                load_default='permit')
        },
        # Deprecated starting from 2.3.0.
        # This policy node was used to disable retries
        # during config deployment failures.
        'deploy_policy': {
            'label': s.Optional(s.String()),
            'retry_config_deploy_on_failure': s.Optional(s.Boolean(),
                                                         load_default=True)
        },
        # DEPRECATED in 4.2.1. The fields have been moved to `fabric_policy`.
        'virtual_network_policy': {
            'label': s.Optional(s.String()),
            'overlay_control_protocol': s.Optional(
                VNPolicyFields.overlay_control_protocol),
            'max_evpn_routes': s.Optional(VNPolicyFields.max_evpn_routes),
            'max_mlag_routes': s.Optional(VNPolicyFields.max_mlag_routes),
            'max_external_routes': s.Optional(VNPolicyFields.max_external_routes),
            'max_fabric_routes': s.Optional(VNPolicyFields.max_fabric_routes),
            'external_router_mtu': s.Optional(VNPolicyFields.external_router_mtu),
            'default_fabric_evi_route_target': s.Optional(
                VNPolicyFields.default_fabric_evi_route_target),
            'evpn_generate_type5_host_routes': s.Optional(
                VNPolicyFields.evpn_generate_type5_host_routes),
            'cumulus_vxlan_arp_suppression':
                VNPolicyFields.cumulus_vxlan_arp_suppression,
            'frr_rd_vlan_offset': VNPolicyFields.frr_rd_vlan_offset,
            'cumulus_bridge_mac_derivation':
                VNPolicyFields.cumulus_bridge_mac_derivation,
            'junos_evpn_routing_instance_type':
                VNPolicyFields.junos_evpn_routing_instance_type,
            'junos_evpn_max_nexthop_and_interface_number':
                VNPolicyFields.junos_evpn_max_nexthop_and_interface_number,
            'junos_graceful_restart': VNPolicyFields.junos_graceful_restart,
            'junos_ex_overlay_ecmp': VNPolicyFields.junos_ex_overlay_ecmp,
            'junos_evpn_duplicate_mac_recovery_time':
                VNPolicyFields.junos_evpn_duplicate_mac_recovery_time,
            'default_svi_l3_mtu': s.Optional(
                VNPolicyFields.default_svi_l3_mtu,
                load_default=DEFAULT_SVI_L3_MTU
            )
        },
        # security_zone represents an L3/routing domain. The physical underlay
        # fabric is itself considered an l3 domain represented by sz_type=l3_fabric.
        'security_zone': {
            'label': s.Optional(SecurityZoneFields.label),
            'sz_type': SecurityZoneFields.sz_type,
            'vni_id': s.Optional(SecurityZoneFields.vni_id),
            'vlan_id': s.Optional(SecurityZoneFields.vlan_id),
            'vrf_name': SecurityZoneFields.vrf_name,
            'vrf_id': s.Optional(SecurityZoneFields.vrf_id),
            'l3_mtu': s.Optional(SecurityZoneFields.l3_mtu),
            'junos_evpn_irb_mode': s.Optional(
                SecurityZoneFields.junos_evpn_irb_mode),
            'vrf_description': s.Optional(SecurityZoneFields.vrf_description),
        },
        'sz_instance': {
            'label': s.Optional(s.String(
                description='Internal label for Apstra. Not used in device configs.'
            )),
            'state': s.Optional(s.Enum(
                ['inactive', 'active'],
                description='Indicates if the routing zone should be implemented '
                            'on the system hosting this sz_instance. If "active", '
                            'then it means the VRF and related configs such as '
                            'BGP sessions and L3 VNIs are rendered on the system, '
                            'and expectations, such as BGP session expectations, '
                            'are rendered for that VRF. If "inactive", then VRF '
                            'and related configs and expectations are removed.'
            )),
        },
        # DEPRECATED in 4.2.1. It's been renamed to `fabric_policy`.
        'fabric_addressing_policy': {
            'label': s.Optional(s.String()),
            'spine_leaf_links': s.Optional(
                FABRIC_POLICY_FIELDS['spine_leaf_links']),
            'spine_superspine_links': s.Optional(
                FABRIC_POLICY_FIELDS['spine_leaf_links']),
            'leaf_loopbacks': s.Optional(
                FABRIC_POLICY_FIELDS['leaf_loopbacks']),
            'spine_loopbacks': s.Optional(
                FABRIC_POLICY_FIELDS['spine_loopbacks']),
            'mlag_svi_subnets': s.Optional(
                FABRIC_POLICY_FIELDS['mlag_svi_subnets']),
            'leaf_l3_peer_links': s.Optional(
                FABRIC_POLICY_FIELDS['leaf_l3_peer_links']),
            'esi_mac_msb': s.Optional(
                FABRIC_POLICY_FIELDS['esi_mac_msb']),
            'fabric_l3_mtu': FABRIC_POLICY_FIELDS['fabric_l3_mtu'],
        },
        'fabric_policy': {
            'spine_leaf_links': FABRIC_POLICY_FIELDS['spine_leaf_links'],
            'spine_superspine_links': FABRIC_POLICY_FIELDS['spine_leaf_links'],
            'leaf_loopbacks': FABRIC_POLICY_FIELDS['leaf_loopbacks'],
            'spine_loopbacks': FABRIC_POLICY_FIELDS['spine_loopbacks'],
            'mlag_svi_subnets': FABRIC_POLICY_FIELDS['mlag_svi_subnets'],
            'leaf_l3_peer_links': FABRIC_POLICY_FIELDS['leaf_l3_peer_links'],
            'esi_mac_msb': FABRIC_POLICY_FIELDS['esi_mac_msb'],
            'fabric_l3_mtu': FABRIC_POLICY_FIELDS['fabric_l3_mtu'],
            'anti_affinity': FABRIC_POLICY_FIELDS['anti_affinity'],
            'optimise_sz_footprint': (
                FABRIC_POLICY_FIELDS['optimise_sz_footprint']),
            'junos_evpn_routing_instance_type': (
                FABRIC_POLICY_FIELDS['junos_evpn_routing_instance_type']),
            'junos_evpn_max_nexthop_and_interface_number': (
                FABRIC_POLICY_FIELDS[
                    'junos_evpn_max_nexthop_and_interface_number']),
            'junos_graceful_restart': (
                FABRIC_POLICY_FIELDS['junos_graceful_restart']),
            'junos_ex_overlay_ecmp': (
                FABRIC_POLICY_FIELDS['junos_ex_overlay_ecmp']),
            'junos_evpn_duplicate_mac_recovery_time': FABRIC_POLICY_FIELDS[
                'junos_evpn_duplicate_mac_recovery_time'],
            'overlay_control_protocol':
                FABRIC_POLICY_FIELDS['overlay_control_protocol'],
            'external_router_mtu': FABRIC_POLICY_FIELDS['external_router_mtu'],
            'max_fabric_routes': FABRIC_POLICY_FIELDS['max_fabric_routes'],
            'max_external_routes': FABRIC_POLICY_FIELDS['max_external_routes'],
            'max_mlag_routes': FABRIC_POLICY_FIELDS['max_mlag_routes'],
            'max_evpn_routes': FABRIC_POLICY_FIELDS['max_evpn_routes'],
            'default_fabric_evi_route_target':
                FABRIC_POLICY_FIELDS['default_fabric_evi_route_target'],
            'evpn_generate_type5_host_routes':
                FABRIC_POLICY_FIELDS['evpn_generate_type5_host_routes'],
            'frr_rd_vlan_offset': FABRIC_POLICY_FIELDS['frr_rd_vlan_offset'],
            'default_svi_l3_mtu': FABRIC_POLICY_FIELDS['default_svi_l3_mtu'],
        },
        'asn_allocation_policy': {
            'label': s.Optional(s.String()),
            'spine_asn_scheme': s.Optional(s.Enum(['distinct', 'single']),
                                           load_default='distinct'),
        },
        # Indicates multicast related intent. Multicast policy is per security
        # zone and represented by a relationship. Absence of this node indicates no
        # multicast is enabled on the routing zone.
        'multicast_policy': {
            'mode': s.Optional(
                s.Enum(
                    ['disabled', 'pim-sparse', 'pim-dense'],
                    description='disabled means no multicast. '\
                        'pim-sparse or pim-dense means PIM is running on every '\
                        'leaf-spine interface and SVI in the routing zone'),
                load_default='disabled',
                description='Multicast mode for the whole routing zone'),
        },
        # Indicates a logical rendezvous point. The logical RP is hosted on one or
        # more systems identified by hosted_on relationship. This node is present
        # only when related multicast_policy.mode = pim-sparse
        'rendezvous_point': {
            'label': s.Optional(s.String(
                description='Human friendly label '
                            'only locally significant on Apstra')),
            'discovery_mode' : s.Optional(
                s.Enum(['static', 'auto-rp', 'bsr']),
                description='Discovery mechanism used by multicast routers to '\
                    'discover the RP',
                load_default='static'
            ),
            'redundancy_mode': s.Optional(
                s.Enum(['none', 'pim_anycast', 'msdp_anycast']),
                description='Redundancy mechanism used for RP HA if any. '\
                    'If *_anycast, the anycast_ip is configured on all systems '\
                    'acting as RPs. The anycast ip itself is identified by '\
                    'anycast_interface relationship to loopback interface node and '\
                    'anycast_ip is on this interface node'),
            'group_addr_ranges': s.Optional(
                s.List(
                    s.IpNetworkAddress(description=\
                        'Multicast Group CIDRs for which this RP is used')),
                load_default=['224.0.0.0/4']),
        },
        # Pod node is used for grouping systems in a pod
        # which includes leafs of and spines of all the racks
        # in the pod
        'pod': {
            'label': s.Optional(s.String(validate=[s.Length(min=1)])),
            'position': s.Optional(s.Integer(), load_default=0),
            'pod_type_json': s.Optional(
                s.String(validate=[s.Length(min=1)]),
                description=(
                    'Contains corresponding JSON-serialized pod type from '
                    'which this pod node was generated.'
                ),
            ),
        },
        # Superspine plane is used for grouping systems
        # such as superspines in a plane as well as spines that connect to
        # those superspines
        'superspine_plane': {
            'label': s.Optional(s.String(validate=[s.Length(min=1)])),
            'position': s.Optional(s.Integer(), load_default=0),
        },
        # Defines a custom IP address or IP range (subnet),
        # which represents a virtual IP,
        # or defines a traffic source / destination which can be a subject
        # of group-based policies directly or through
        # a number of groups it is member of.
        'ip_endpoint': {
            'label': s.Optional(s.String(
                description='Unique user-friendly name of an endpoint.'
            )),
            # NOTE: it's not possible to use strict schema here, because it breaks
            # external routing feature, where ipv4/6_addr have to be specified
            # as ip addresses with prefix (they could not be equal network address)
            'ipv4_addr': s.Optional(s.IpNetworkAddress()),
            'ipv6_addr': s.Optional(s.Ipv6NetworkAddress()),
            'endpoint_type': s.Enum(
                ['vip', 'internal', 'external'],
                description='VIP represents a virtual IP '
                            'that can be used by one or more routers. '
                            'Internal subnets are managed by Apstra directly. '
                            'External subnets are not controlled by Apstra directly.'
            ),
            'description': s.Optional(s.Description()),
        },
        'security_rule': {
            'label': s.GenericName(
                description='Unique user-friendly name of a rule.'
            ),
            'src_port': s.PortSetOrAny(),
            'dst_port': s.PortSetOrAny(),
            'protocol': s.SecurityRuleProtocol(),
            'action': s.SecurityRuleAction(),
            'description': s.Optional(s.Description()),
            'tcp_state_qualifier': s.Optional(s.TcpConnectionState()),
        },
        'interface_policy': {
            'label': s.String(validate=[s.Length(min=1, max=120)]),
            'dot1x_auth_mode': Dot1xPolicyFields.auth_mode,
            'dot1x_mac_auth_bypass': Dot1xPolicyFields.mac_auth_bypass,
            'dot1x_port_control': Dot1xPolicyFields.port_control,
            'dot1x_reauthentication_timeout':
                Dot1xPolicyFields.reauthentication_timeout,
            # eg, future use:
            #'stp_portfast': s.Boolean()
            #'stp_bpduguard': s.Boolean()
            #'stp_bpdufilter': s.Boolean()
        },
        'aaa_server': {
            'label': s.String(validate=[s.Length(min=1, max=120)]),
            'hostname': AAAServerFields.hostname,
            'key': AAAServerFields.key,
            'server_type': AAAServerFields.server_type,
            'auth_port': AAAServerFields.auth_port,
            'acct_port': AAAServerFields.acct_port,
        },
        # DEPRECATED in 4.2.1. It's been moved to `fabric_policy`.
        'anti_affinity_policy': {
            'mode': ANTI_AFFINITY_FIELDS['mode'],
            'algorithm': ANTI_AFFINITY_FIELDS['algorithm'],
            'max_links_per_slot': s.Optional(
                ANTI_AFFINITY_FIELDS['max_links_per_slot'], load_default=0),
            'max_links_per_port': s.Optional(
                ANTI_AFFINITY_FIELDS['max_links_per_port'], load_default=0),
            'max_per_system_links_per_slot': s.Optional(
                ANTI_AFFINITY_FIELDS['max_per_system_links_per_slot'],
                load_default=0),
            'max_per_system_links_per_port': s.Optional(
                ANTI_AFFINITY_FIELDS['max_per_system_links_per_port'],
                load_default=0),
        },
        'validation_policy': {
            'ip_overlap': s.Optional(
                VALIDATION_POLICY_FIELDS['ip_overlap']),
            'route_target_overlap': s.Optional(
                VALIDATION_POLICY_FIELDS['route_target_overlap']),
            'asn_overlap': s.Optional(
                VALIDATION_POLICY_FIELDS['asn_overlap']),
            'os_version': s.Optional(
                VALIDATION_POLICY_FIELDS['os_version']),
            'asic_features': s.Optional(
                VALIDATION_POLICY_FIELDS['asic_features']),
            'load_balancing_policy': s.Optional(
                VALIDATION_POLICY_FIELDS['load_balancing_policy']),
            'rail_optimized_design': s.Optional(
                VALIDATION_POLICY_FIELDS['rail_optimized_design']),

            # The subsequent fields are deprecated (4.2) and not used
            # in the latest version of Apstra.
            # They can't be removed, because the existing upgrade system
            # uses the latest version of the graph schema in order
            # to perform graph mutations during the upgrade, even if
            # the target version of the upgrade is very old.
            'svi_ip_overlaps': s.Optional(
                s.ValidationSeverityEnum(), description='DEPRECATED'),
            'uncontrolled_generic_loopbacks': s.Optional(
                s.ValidationSeverityEnum(), description='DEPRECATED'),
            'permit_internal_route_targets': s.Optional(
                s.ValidationSeverityEnum(), description='DEPRECATED'),
        },
        # DEPRECATED in 4.2.1. It's been moved to `fabric_policy`.
        'security_zone_policy': {
            'footprint_optimise': SecurityZonePolicyFields.footprint_optimise
        },
        'evpn_interconnect_group': {
            'label': s.Label(),
            'interconnect_route_target': s.RouteTarget(),
            'interconnect_esi_mac': s.Optional(s.EvpnInterconnectESIMac()),
        },
        'evpn_interconnect_l3': {
            'interconnect_route_target': s.RouteTarget(),
            'enabled_for_l3': s.Boolean(),
        },
        'rail': {
            # Serves as a local immutable identifier of the rail within the
            # rack, used when we want determinism in rails traversal
            # (e.g. for stable interface name assignments)
            'index': s.RailIndex(),
            'label': s.String(validate=[s.Length(min=1)]),
        },
        'load_balancing_policy': {
            'mode': LOAD_BALANCING_POLICY_FIELDS['mode'],
            'label': LOAD_BALANCING_POLICY_FIELDS['label'],
            'dlb_options': LOAD_BALANCING_POLICY_FIELDS['dlb_options'],
            'policy_type': LOAD_BALANCING_POLICY_FIELDS['policy_type'],
        },
    }

    relationships = [
        {
            'source': 'system',
            'type': 'hosted_interfaces',
            'target': 'interface',
        },
        {
            'source': 'system',
            'type': 'part_of_rack',
            'target': 'rack',
        },
        {
            'source': 'redundancy_group',
            'type': 'part_of_rack',
            'target': 'rack',
        },
        {
            'source': 'interface',
            'type': 'composed_of',
            'target': 'interface',
        },
        {
            'source': 'interface',
            'type': 'link',
            'target': 'link',
        },
        {
            'source': 'domain',
            'type': 'composed_of_systems',
            'target': 'system',
        },
        # This relationship exists only for redundancy_group nodes with rg_type=mlag
        {
            'source': 'domain',
            'type': 'composed_of_redundancy_group',
            'target': 'redundancy_group',
        },
        {
            'source': 'domain',
            'type': 'composed_of_interfaces',
            'target': 'interface',
        },
        {
            'source': 'system',
            'type': 'part_of_redundancy_group',
            'target': 'redundancy_group',
        },
        {
            'source': 'redundancy_group',
            'type': 'composed_of_systems',
            'target': 'system',
        },
        {
            'source': 'redundancy_group',
            'type': 'hosted_interfaces',
            'target': 'interface',
        },
        s.RelationshipSchema(
            type='instantiated_by',
            source_type='virtual_network',
            target_type='vn_instance',
            sticky=True,
        ),
        {
            'source': 'vn_instance',
            'type': 'instantiates',
            'target': 'virtual_network',
        },
        s.RelationshipSchema(
            type='hosted_vn_instances',
            source_type='system',
            target_type='vn_instance',
            sticky=True,
        ),
        {
            'source': 'virtual_network',
            'type': 'member_endpoints',
            'target': 'vn_endpoint',
        },
        {
            'source': 'vn_endpoint',
            'type': 'member_of',
            'target': 'virtual_network',
        },
        s.RelationshipSchema(
            type='hosted_vn_endpoints',
            source_type='interface',
            target_type='vn_endpoint',
        ),
        # This relationship from virtual_network to subinterface is created
        # when there exists a protocol session or/and static route between
        # SVI and subinterface
        s.RelationshipSchema(
            source_type='virtual_network',
            type='member_interfaces',
            target_type='interface'
        ),
        # This relationship remains due to backwards compatibility requirement
        # enforced by the upgrade infrastructure: each version of a graph must be
        # loadable with the current graph schema.
        s.RelationshipSchema(
            type='hosted_vn_endpoints',
            source_type='system',
            target_type='vn_endpoint',
            sticky=True,
        ),
        # A single ip_endpoint node can be connected to several vn_endpoint nodes.
        # From a network perspective in signifies that several router interfaces are
        # using the same virtual IP.
        s.RelationshipSchema(
            type='member_vn_endpoints',
            source_type='ip_endpoint',
            target_type='vn_endpoint',
        ),
        # A single ip_endpoint node can be connected to only one 'external' generic
        # system node. It's necessary for supporting BGP sessions
        # with a floating VM (NSX-T use-case)
        s.RelationshipSchema(
            type='hosted_ip_endpoints',
            source_type='system',
            target_type='ip_endpoint',
        ),
        s.RelationshipSchema(
            type='member_interfaces',
            source_type='vn_instance',
            target_type='interface',
            sticky=True,
        ),
        {
            'source': 'interface',
            'type': 'member_of_vn_instance',
            'target': 'vn_instance',
        },
        {
            'source': 'system',
            'type': 'logical_device',
            'target': 'logical_device',
        },
        {
            'source': 'system',
            'type': 'interface_map',
            'target': 'interface_map',
        },
        {
            'source': 'interface_map',
            'type': 'device_profile',
            'target': 'device_profile',
        },
        {
            'source': 'interface_map',
            'type': 'logical_device',
            'target': 'logical_device',
        },
        # Deprecated since 2.2.
        # Replaced by per-SZ DHCP relay policy association
        {
            'source': 'policy',
            'type': 'applied_on',
            'target': 'group',
        },
        # Deprecated since 2.3.0.
        s.RelationshipSchema(
            type='deploy_policy',
            source_type='group',
            target_type='deploy_policy',
        ),
        # No usage is found in the code. Deprecated since 2.4.
        {
            'source': 'group',
            'type': 'group_endpoint',
            'target': 'virtual_network',
        },
        s.RelationshipSchema(
            source_type='system',
            type='hosted_sz_instances',
            target_type='sz_instance',
            sticky=True,
        ),
        s.RelationshipSchema(
            source_type='security_zone',
            type='instantiated_by',
            target_type='sz_instance',
            sticky=True,
        ),
        # For default routing zone we do not create sz_instance -> interface
        # relationships. This is because (a) there is already hosted_on relationship
        # from system to (physical) interface which we model as belonging to the
        # default VRF, and (b) creating these relationships adds a large number of
        # relationships for networks using VRF-Lite in the fabric - one extra
        # relationship per fabric link.
        s.RelationshipSchema(
            source_type='sz_instance',
            type='member_interfaces',
            target_type='interface',
        ),
        # Every virtual network is associated with a routing zone. This applies
        # also to virtual networks created in default routing zone. The reason
        # we introduce this relationship even for default SZ is because it provides
        # uniformity in SZ -> VN association without adding too much cost, i.e.
        # 1 relationship per VN, compared to tens to hundreds of nodes/relationships
        # created for each VN for its vn_endpoint(s) and vn_instance(s).
        # This relationship is not sticky because we want to ensure that one cannot
        # remove a routing zone unless all associated virtual networks have been
        # removed.
        s.RelationshipSchema(
            source_type='security_zone',
            type='member_vns',
            target_type='virtual_network',
        ),
        s.RelationshipSchema(
            source_type='security_zone',
            type='policy',
            target_type='routing_policy',
        ),
        s.RelationshipSchema(
            source_type='security_zone',
            type='route_target_policy',
            target_type='route_target_policy',
        ),
        # One security_zone has utmost one multicast_policy
        s.RelationshipSchema(
            source_type='multicast_policy',
            type='sz',
            target_type='security_zone'
        ),
        # Only used for EVPN Remote GW, otherwise deprecated in AOS 4.0.0
        # If a pair of nodes are connected via a protocol node, it signifies
        # that external traffic is allowed to leave a particular routing zone
        # via these interfaces (incl. ip endpoint) using some links as next hops.
        # E.g. it can represent BGP sessions between a leaf and one or more routers
        s.RelationshipSchema(
            source_type='ip_endpoint',
            type='protocol',
            target_type='protocol'
        ),
        # Deprecated since 4.0.0.
        s.RelationshipSchema(
            source_type='interface',
            type='protocol',
            target_type='protocol'
        ),
        s.RelationshipSchema(
            source_type='interface',
            type='routing_zone_constraint',
            target_type='routing_zone_constraint'
        ),
        # Only used for EVPN Remote GW, otherwise deprecated in AOS 4.0.0
        # Routing policy that overrides SZ-wide policy with session-specific
        # properties
        s.RelationshipSchema(
            source_type='protocol',
            type='policy',
            target_type='routing_policy',
        ),
        s.RelationshipSchema(
            source_type='protocol_session',
            type='instantiates',
            target_type='protocol_endpoint',
            sticky=True,  # delete 'protocol_session' as well as 'protocol_endpoint'
        ),
        # Possible protocol endpoint targets.
        s.RelationshipSchema(
            source_type='protocol_endpoint',
            type='layered_over',
            target_type='interface'
        ),
        s.RelationshipSchema(
            source_type='protocol_endpoint',
            type='layered_over',
            target_type='ip_endpoint'
        ),
        {
            'source': 'protocol_endpoint',
            'type': 'policy',
            'target': 'routing_policy',
        },
        s.RelationshipSchema(
            source_type='protocol_endpoint',
            type='prefix_neighbor',
            target_type='virtual_network'
        ),
        s.RelationshipSchema(
            source_type='protocol_endpoint',
            type='prefix_neighbor',
            # .. and such interface should be having if_type='subinterface'
            target_type='interface'
        ),
        # multicast_policy is per routing zone and this relationship identifies
        # RPs in that zone, in case pim-sparse is used. For a given policy there is
        # one RP per list of multicast groups
        s.RelationshipSchema(
            source_type='multicast_policy',
            type='rp',
            target_type='rendezvous_point'
        ),
        # Identifies actual systems acting as rendezvous_points. There could be more
        # than one switch hosting a logical RP for redundancy reasons
        s.RelationshipSchema(
            source_type='rendezvous_point',
            type='hosted_on',
            target_type='system'
        ),
        # In case of anycast RP, this identifies the logical VIP for the RP that is
        # configured on all routers in multicast domain. This maybe omitted when
        # there is only one switch acting as RP and there is no need for VIP
        # For a given RP there is utmost one anycast_interface relation
        s.RelationshipSchema(
            source_type='rendezvous_point',
            type='anycast_interface',
            target_type='interface'
        ),
        # In case of PIM sparse mode, each switch acting as RP can choose to use
        # any of its interface (typically loopback) as the RP IP and this relation
        # indicates what interface is used for RP control plane traffic
        # For a given RP, there is one and only one instance of this relation
        # per participating system
        s.RelationshipSchema(
            source_type='rendezvous_point',
            type='member_interfaces',
            target_type='interface'
        ),
        # Leafs, spine that belong to a pod have this relationship
        s.RelationshipSchema(
            source_type='system',
            type='part_of_pod',
            target_type='pod'
        ),
        # Superspines in a plane and spines that connect to those
        # superspines have this relationship
        s.RelationshipSchema(
            source_type='system',
            type='part_of_superspine_plane',
            target_type='superspine_plane'
        ),
        # List of possible relationships used to define group membership.
        # Each relationship has type 'member_of'
        # with different source and destination node types.
        # IP endpoints, which represent a VIP cannot be grouped.
        {
            'source': 'security_zone',
            'type': 'member_of',
            'target': 'group',
        },
        {
            'source': 'ip_endpoint',
            'type': 'member_of',
            'target': 'group',
        },
        {
            'source': 'virtual_network',
            'type': 'member_of',
            'target': 'group',
        },
        {
            'source': 'virtual_network',
            'type': 'route_target_policy',
            'target': 'route_target_policy',
        },
        {
            'source': 'interface',
            'type': 'member_of',
            'target': 'group',
        },
        # Compound objects like virtual networks behave as group objects.
        # The relationship is allowed and mandatory for internal ip endpoints.
        {
            'source': 'ip_endpoint',
            'type': 'member_of',
            'target': 'virtual_network'
        },
        # Starting from 2.4 graph can have "recursive" edge types
        {
            'source': 'group',
            'type': 'member_of',
            'target': 'group',
        },
        # End of group membership relationship list
        # routing zone have default policies. For instance, each routing zone
        # is associated with a DHCP relay policy applied to all virtual networks
        # underneath the SZ, unless those virtual networks have more specific
        # DHCP relay policy (not currently possible).
        # DHCP relay policy for default SZ also applies on leafs for L3 blueprints.
        {
            'source': 'security_zone',
            'type': 'policy',
            'target': 'policy'
        },
        # Relationship from dhcp_relay policy to group is deprecated since 2.2
        # Replaced by per-SZ DHCP relay policy association
        {
            'source': 'group',
            'type': 'policy',
            'target': 'policy'
        },

        # Possible policy applications.
        {
            'source': 'virtual_network',
            'type': 'security_policy',
            'target': 'policy',
            'policy_direction': s.Enum(['from', 'to'],
                                       description=POLICY_DIRECTION_DESCRIPTION)
        },
        {
            'source': 'security_zone',
            'type': 'security_policy',
            'target': 'policy',
            'policy_direction': s.Enum(['from', 'to'],
                                       description=POLICY_DIRECTION_DESCRIPTION)
        },
        {
            'source': 'group',
            'type': 'security_policy',
            'target': 'policy',
            'policy_direction': s.Enum(['from', 'to'],
                                       description=POLICY_DIRECTION_DESCRIPTION)
        },
        {
            'source': 'ip_endpoint',
            'type': 'security_policy',
            'target': 'policy',
            'policy_direction': s.Enum(['from', 'to'],
                                       description=POLICY_DIRECTION_DESCRIPTION)
        },

        # Usage of security rules
        # Relationship from a policy to each of its rules.
        # A rule does not makes sense outside of policy context.
        # so the relationship is sticky.
        s.RelationshipSchema(
            source_type='policy',
            type='has_rule',
            target_type='security_rule',
            sticky=True
        ),
        # This relationship is used to order rules within a policy.
        # All rules in a policy except last must have this relationship.
        {
            'source': 'security_rule',
            'type': 'followed_by',
            'target': 'security_rule'
        },
        # The relationship identifies that a conflict between two rules
        # has been resolved manually or automatically and the source rule node
        # should be rendered before target rule node.
        {
            'source': 'security_rule',
            'type': 'precedes',
            'target': 'security_rule',
            'conflict_resolved_by': RESOLVED_BY_TYPE
        },
        # 'Identifies that source rule match set fully contains
        # the target rule match set and action of both rules is the same.
        # This means that rule set can be optimized by enforcing only source rule.
        {
            'source': 'security_rule',
            'type': 'shadows',
            'target': 'security_rule',
            'enabled': s.Optional(
                s.Boolean(description='Shadows relationship can be deactivated. '
                                      'This is needed to optimize '
                                      'rule processing performance.'),
                load_default=True
            )
        },
        # Identifies that two rules are in conflict.
        # This means that their match sets intersect and actions are different.
        {
            'source': 'security_rule',
            'type': 'in_conflict_with',
            'target': 'security_rule'
        },
        # Relationships to enforcement points. These relationships are optional.
        # They hint AOS that traffic source/destination lies behind target entity.
        {
            'source': 'ip_endpoint',
            'type': 'bound_to',
            'target': 'interface'
        },
        {
            'source': 'ip_endpoint',
            'type': 'bound_to',
            'target': 'group'
        },
        {
            'source': 'group',
            'type': 'bound_to',
            'target': 'interface'
        },
        {
            'source': 'group',
            'type': 'bound_to',
            'target': 'group'
        },
        # 802.1x (Interface policy) relationships
        {
            'source': 'interface',
            'type': 'interface_policy',
            'target': 'interface_policy',
        },
        {
            'source': 'interface_policy',
            'type': 'fallback_virtual_network',
            'target': 'vn_instance',
        },
        # Deprecated since 4.0.0.
        s.RelationshipSchema(
            source_type='domain',
            type='ospf_domain',
            target_type='protocol',
        ),
        # Deprecated since 4.0.0.
        s.RelationshipSchema(
            source_type='protocol',
            type='ospf_policy',
            target_type='ospf_policy',
            sticky=True
        ),
        {
            'source': 'ep_endpoint_policy',
            'type': 'vn_to_attach',
            'target': 'virtual_network',
        },
        {
            'source': 'ep_endpoint_policy',
            'type': 'attached_untagged_vlan',
            'target': 'virtual_network',
        },
        {
            'source': 'ep_endpoint_policy',
            'type': 'attached_tagged_vlans',
            'target': 'virtual_network',
        },
        {
            'source': 'interface',
            'type': 'ep_member_of',
            'target': 'ep_group',
        },
        {
            'source': 'vn_endpoint',
            'type': 'ep_member_of',
            'target': 'ep_group',
        },
        {
            'source': 'system',
            'type': 'ep_member_of',
            'target': 'ep_group',
        },
        {
            'source': 'domain',
            'type': 'ep_member_of',
            'target': 'ep_group',
        },
        {
            'source': 'protocol_endpoint',
            'type': 'ep_member_of',
            'target': 'ep_group',
        },
        {
            'source': 'security_zone',
            'type': 'ep_member_of',
            'target': 'ep_group',
        },
        {
            'source': 'static_route',
            'type': 'ep_member_of',
            'target': 'ep_group',
        },
        {
            'source': 'routing_policy',
            'type': 'ep_member_of',
            'target': 'ep_group',
        },
        {
            'source': 'ep_endpoint_policy',
            'type': 'security_zone',
            'target': 'security_zone'
        },
        {
            'source': 'ep_endpoint_policy',
            'type': 'routing_policy',
            'target': 'routing_policy'
        },
        {
            'source': 'ip_endpoint',
            'type': 'created_by',
            'target': 'ep_endpoint_policy'
        },
        {
            'source': 'protocol_session',
            'type': 'created_by',
            'target': 'ep_endpoint_policy'
        },
        {
            'source': 'static_route',
            'type': 'created_by',
            'target': 'ep_endpoint_policy'
        },
        s.RelationshipSchema(
            source_type='system',
            type='static_route',
            target_type='static_route',
        ),
        s.RelationshipSchema(
            source_type='security_zone',
            type='static_route',
            target_type='static_route',
        ),
        s.RelationshipSchema(
            source_type='static_route',
            type='network',
            target_type='interface',
        ),
        # Next hop can be interface or ip_endpoint
        s.RelationshipSchema(
            source_type='static_route',
            type='next_hop',
            target_type='interface',
        ),
        s.RelationshipSchema(
            source_type='static_route',
            type='next_hop',
            target_type='ip_endpoint',
        ),
        s.RelationshipSchema(
            source_type='static_route',
            type='source_interface',
            target_type='interface',
        ),
        s.RelationshipSchema(
            source_type='routing_zone_constraint',
            type='constraint',
            target_type='security_zone',
        ),
        s.RelationshipSchema(
            source_type='routing_zone_constraint',
            type='constraint',
            target_type='group',
        ),
        s.RelationshipSchema(
            source_type='ep_endpoint_policy',
            type='routing_zone_constraint_to_attach',
            target_type='routing_zone_constraint',
        ),
        # Describes membership of a single virtual network as part of an evpn
        # interconnect group for layer2 vxlan stretching and optional translation.
        # These options are stored at the relationship level as opposed to a vn
        # instance/vn, as they are unique per evpn interconnect group, and a vn
        # may be part of many of them. Additionally, all properties of the
        # l3 interconnect must be shared by all local gateways that participate in
        # the evpn interconnect group.
        s.RelationshipSchema(
            type='evpn_interconnect_vn',
            source_type='evpn_interconnect_group',
            target_type='virtual_network',
            properties=dict(
                # Translation_vni is an optional integer, apart from internal vxlan
                # id range validation, as foreign fabrics may have VNI IDs lower
                # than 4094
                translation_vni=s.SparseOptional(s.Integer(
                    validate=[s.Range(1, 2 ** 24)])),
                # If L2 is true, this VN participates in L2 interconnect
                l2=s.Boolean(),
                # If L3 is true, this VN participates in l3 interconnect, if the
                # evpn_interconnect_group->evpn_interconnect_l3 node has
                # enabled_for_l3 = True
                l3=s.Boolean(),
            )
        ),
        # evpn_interconnect_l3 is an intermediate node between an evpn interconnect
        # group and a security zone & routing-policy. This holds configuration
        # of the layer3 type5 routing policy and what security zone it belongs
        # to.
        s.RelationshipSchema(
            type='evpn_interconnect_l3',
            source_type='evpn_interconnect_group',
            target_type='evpn_interconnect_l3',
        ),
        # This relationship is sticky in order to handle removal of
        # evpn_interconnect_l3 & routing policy when the according security zone
        # is removed. This describes the security zone and its properties as related
        # to an EVPN DCI Type5 interconnect.
        s.RelationshipSchema(
            type='evpn_interconnect_sz',
            source_type='security_zone',
            target_type='evpn_interconnect_l3',
            sticky=True,
        ),
        # routing policy facade api blocks deletion of the routing policy if it is
        # associated to an evpn interconnect group. This policy controls a route-map
        # for incoming EVPN_GW and outgoing EVPN_GW routes during configuration
        # rendering to limit the type5 routes advertised and received.
        s.RelationshipSchema(
            type='evpn_interconnect_sz_policy',
            source_type='evpn_interconnect_l3',
            target_type='routing_policy',
        ),
        # Describes a relationship from an evpn_interconnect_group -> remote gateway
        # system node, transforming it from over-the-top mode into interconnect mode.
        s.RelationshipSchema(
            type='evpn_interconnect_peer',
            source_type='evpn_interconnect_group',
            target_type='system',
        ),
        {
            'source': 'security_zone',
            'type': 'tenant',
            'target': 'tenant',
        },
        s.RelationshipSchema(
            type='part_of_rack',
            source_type='rail',
            target_type='rack',
        ),
        s.RelationshipSchema(
            type='hosted_by',
            source_type='rail',
            target_type='system',
        ),
        s.RelationshipSchema(
            type='composed_of',
            source_type='rail',
            target_type='link',
        ),
        s.RelationshipSchema(
            type='load_balancing_policy',
            source_type='load_balancing_policy',
            target_type='system',
        )
    ]


OS_FEATURE_SCHEMA = s.Object({
    'sz_mandates_rd_and_rt': s.Optional(
        s.Boolean(), load_default=False,
        description='Flag to check if RD and RT need to be rendered for routing '
                    'zone when no virtual network created within the routing zone.'
    ),
})

DEFAULT_OS_FEATURE = OS_FEATURE_SCHEMA.load({})

# The feature matrix is used to keep track of platform specific feature support.
OS_FEATURE_MATRIX = {
    'junos':
        OS_FEATURE_SCHEMA.load({'sz_mandates_rd_and_rt': True})
}

SYSTEM_SCHEMA = s.Object(Schema.nodes['system'].properties)
INTERFACE_SCHEMA = s.Object(Schema.nodes['interface'].properties)
LINK_SCHEMA = s.Object(Schema.nodes['link'].properties)
POLICY_SCHEMA = s.Object(Schema.nodes['policy'].properties)
SECURITY_ZONE_SCHEMA = s.Object(Schema.nodes['security_zone'].properties)
GROUP_SCHEMA = s.Object(Schema.nodes['group'].properties)
REDUNDANCY_GROUP_SCHEMA = s.Object(Schema.nodes['redundancy_group'].properties)
