# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula
# pylint: disable=invalid-name,line-too-long
# mypy: disable-error-code="name-defined"

from __future__ import annotations

import typing as t

from aos.sdk.client import Client as _Client, RestResources, RestResource, Api, \
    api, resources
from aos.sdk.generator import (
    gen_evpn_interconnect_group,
    gen_load_balancing_policy,
)
from aos.sdk import schema as s

if t.TYPE_CHECKING:
    import collections.abc
    import aos.sdk.generator as g

    import typing_extensions as te
    import lollipop.types

    from aos.sdk import typing as tt

    _MAGIC: t.TypeAlias = t.Any
    aos: t.TypeAlias = t.Any


def _fm_schema(
    method: str,
    vtype: te.Literal['arg', 'result'] = 'arg'
) -> str:
    '''Helper for type annotations generation.

    :param method: name of the facade method
    :param vtype: attribute of the facade method which holds schema

    :return: reference to arg schema in form of a magic annotation
    '''
    return f'''
        _MAGIC.facade_method_schema[
            'aos.reference_design.two_stage_l3clos.facade.Facade',
            {method!r},
            {vtype!r}
        ]
    '''.strip()


class PredefinedProbe(Api):
    """ API segment for predefined probe.

    Used as a template for different predefined probes. Each probe has
    its own dedicated URL, while endpoint schema is shared between them.
    """
    def create(
        self,
        data: _MAGIC.lollipop_type['aos.scotch.libs.probe_schemas.PREDEFINED_PROBE_PARAMETERS'],
        **kwargs: te.Unpack[RestResource.TWriteKwargs],
    ) -> _MAGIC.lollipop_type['aos.scotch.schemas.schema.IdSchema']:
        """ Instantiate a predefined probe with parameters.

        :param data: Data to create a probe with.
        """
        return self._request(data=data, method='POST', **kwargs)


def predefined_probe(path: str):
    """ Shortcut to create URL segments related to specific Predefined Probe.

    :param path: URI path relative to parent resource
    """
    return api(path)(PredefinedProbe)


class Client(_Client):
    @api('/blueprints')
    class blueprints(Api):
        @api('/{blueprint_id}')
        class resource(Api):
            @api('/nodes')
            class nodes(Api):
                @api('/{node_id}')
                class resource(Api):
                    def get_configlets(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs],
                    ) -> _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'get_node_configlets',
                        'result']:
                        """ Get list of configlets for given system node.
                        """
                        return self._request('/configlets')

            def get_im_assignments(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs],
            ) -> _MAGIC.facade_method_schema[
                'aos.reference_design.two_stage_l3clos.facade.Facade',
                'get_interface_map_assignments',
                'result']:
                """ Get interface map assignments.

                Returns interface map assignments for systems (both fabric systems
                and generic systems) in the blueprint.
                """
                return t.cast(dict, self._request(
                    '/interface-map-assignments', **kwargs
                ))['assignments']

            def patch_im_assignments(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'assign_interface_maps',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> tt.JSON:
                """ Partially update interface map assignments.

                Updates system->interface map assignments in the blueprint.
                Only assignments for the systems present in the requests will be
                updated. Other systems' assignments will be intact.

                :param data: new assignments
                """
                return self._request(
                    '/interface-map-assignments',
                    method='PATCH', data=data,
                    **kwargs
                )

            def change_generic_systems_type(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'change_generic_type',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> tt.JSON:
                """ Change generic system types.

                Changes generic system types in the blueprint.
                This API will update generic system types along with logical devices.

                :param data: new generic type and logical device (if present)
                """
                return self._request(
                    '/change-generic-systems-type',
                    method='PATCH', data=data,
                    **kwargs
                )

            def cleanup_resource_overrides(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'cleanup_resource_overrides',
                    'arg'],
                **kwargs
            ) -> tt.JSON:
                """ Remove resource overrides for a given resource group.

                :param data: resource group name
                """
                return self._request(
                    url='/cleanup-resource-overrides',
                    method='POST', data=data, **kwargs)

            @api('/rails')
            class rails(Api):
                @api('/{node_id}')
                class resource(Api):
                    def update(
                            self,
                            data: _MAGIC.facade_method_schema[
                                'aos.reference_design.two_stage_l3clos.facade.Facade',
                                'update_rail_attributes',
                                'arg'],
                            **kwargs: te.Unpack[RestResources.TWriteKwargs],
                    ) -> tt.JSON:
                        """ Change rail attributes.

                        :param data: new rail attributes.
                        """
                        return self._request(method='PATCH', data=data, **kwargs)

            def change_rail_membership(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'change_rail_membership',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> tt.JSON:
                """ Change rail membership for link.

                Changes rail membership in the blueprint.
                This API will update link label and link group label.

                :param data: new rail assignments
                """
                return self._request(
                    '/change-rail-membership',
                    method='PATCH', data=data,
                    **kwargs
                )

            # Note that only POST/DELETE APIs for individual interface maps are
            # defined for now
            interface_maps = resources(
                '/interface-maps',
                post_schema=_fm_schema('add_interface_map'),
                collection_doc='''
                    Not supported yet.
                ''',
                resource_doc='''
                    Manage interface map of a blueprint.
                ''',
                resource_name='interface_maps',
            )

            @api('/interface-transformation')
            class interface_transformation(Api):
                def put(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'interface_transformation',
                        'arg'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> tt.JSON:
                    """ Update interface maps.

                    This method allows to modify interface maps used by systems.
                    Logical device also changes accordingly to match new interface
                    map.

                    :param data: modifications for interface maps
                    """
                    return self._request(method='PUT', data=data, **kwargs)

            @api('/pod-stats')
            class pod_statistic(Api):
                def get(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'get_pod_statistic',
                    'result']:
                    """ Get pod statistics.

                    Obtains number of racks that can be added to a given pod or all
                    pods in the blueprint if pod_id is not specified in params.

                    Example:
                    .. code-block:: python

                        api = Client(...)
                        api.blueprints[<bp_id>].pod_statistic.get()
                        api.blueprints[<bp_id>].pod_statistic.get(params={
                            'pod_id': <pod_id>})
                    """
                    return self._request(method='GET', **kwargs)

            @api('/rack-stats')
            class rack_statistic(Api):
                def get(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'get_rack_statistic',
                    'result']:
                    """ Get rack statistics.

                    Obtains available number of systems that can be added to the
                    rack. Filtering for pod/rack is achieved via params.

                    Example:
                    .. code-block:: python

                        api = Client(...)
                        api.blueprints[<bp_id>].rack_statistic.get()
                        api.blueprints[<bp_id>].rack_statistic.get(params={
                            'pod_id': <pod_id>, 'rack_id': <rack_id>})
                    """
                    return self._request(**kwargs)

            @api('/pod-type-capacity')
            class pod_type_capacity(Api):
                def get(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'get_pod_capacity',
                    'result']:
                    """ Get pod capacity.

                    Obtains number of pods that can be added based on the available
                    superspine ports.
                    """
                    return self._request(method='GET', **kwargs)

            @api('/cabling-map')
            class cabling_map(Api):
                def update(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'set_cabling_map',
                        'arg'
                    ] | _MAGIC.lollipop_type[
                        'aos.reference_design.two_stage_l3clos.cabling_map.CABLING_MAP_SET_SCHEMA'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> tt.JSON:
                    """ Update cabling map.

                    Update link configuration such as speed, connected systems,
                    interface names etc.

                    :param data: new link configurations
                    """
                    if isinstance(data, list):
                        data = {'links': data}
                    return self._request(method='PATCH', data=data, **kwargs)

                @api('/lldp')
                class lldp(Api):
                    def get(
                        self,
                        system_id: t.Optional[tt.GraphNodeId] = None,
                        **kwargs: te.Unpack[RestResource.TReadKwargs],
                    ) -> _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'get_cabling_map_lldp',
                        'result']:
                        """ Get cabling map LLDP data.

                        Get information about system links gathered via LLDP.

                        :param system_id: id of the system for which data will be
                            collected
                        """
                        params = {'system_id': system_id} if system_id else {}
                        return t.cast(
                            dict,
                            self._request(params=params, **kwargs)  # type: ignore[misc]
                        )['links']

                @api('/diff')
                class diff(Api):
                    def get(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs],
                    ) -> _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'get_cabling_map_diff',
                        'result']:
                        """
                        Get cabling map diff.

                        Get difference between LLDP data and intended configuration
                        of system links.
                        """
                        return t.cast(dict, self._request(**kwargs))['links']

            def racks(self) -> _MAGIC.facade_method_schema[
                'aos.reference_design.two_stage_l3clos.facade.Facade',
                'get_racks',
                'result']:
                """ Get racks.

                Obtains racks in blueprint.
                """
                return self._request('/racks')

            def add_racks(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'add_racks',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'add_racks',
                    'result']:
                """ Add racks.

                :param data: configuration of added racks
                """
                return self._request(
                    '/add-racks',
                    method='POST', data=data,
                    **kwargs
                )

            def modify_racks(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'modify_racks',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'modify_racks',
                    'result']:
                """ Modify racks.

                Recreates racks based on the specified rack type.

                :param data: consist of a new rack type and which racks to update
                """
                return self._request(
                    '/modify-racks',
                    method='POST', data=data,
                    **kwargs
                )

            def delete_racks(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'delete_racks',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'delete_racks',
                    'result']:
                """ Delete racks.

                Delete racks from blueprint by rack IDs.

                :param data: which racks to delete
                """
                return self._request(
                    '/delete-racks',
                    method='POST', data=data,
                    **kwargs
                )

            def add_leaf_to_rack(
                self,
                rack_id: tt.GraphNodeId,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'add_leaf_to_rack',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'add_leaf_to_rack',
                    'result']:
                """ Add new leaf to rack.

                Add new leaf to existing rack with a given ID.

                :param rack_id: id of the rack which will hold newly created leaf
                :param data: leaf's configuration
                """
                return self._request(
                    '/rack-leaf/{}'.format(rack_id),
                    method='POST', data=data,
                    **kwargs
                )

            def add_leaf_pair_to_rack(
                self,
                rack_id: tt.GraphNodeId,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'add_leaf_pair_to_rack',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'add_leaf_pair_to_rack',
                    'result']:
                """ Add new leaf pair to rack.

                Add new leaf pair to existing rack with a given ID.

                :param rack_id: id of the rack which will hold new leaf pair
                :param data: leaf pair's configuration
                """
                return self._request(
                    '/rack-leaf-pair/{}'.format(rack_id),
                    method='POST', data=data,
                    **kwargs
                )

            def delete_leaf_from_rack(
                self,
                rack_id: tt.GraphNodeId,
                leaf_id: tt.GraphNodeId,
                **kwargs: te.Unpack[RestResource.TReadKwargs],
            ) -> tt.JSON:
                """ Delete leaf.

                Delete leaf from rack

                :param rack_id: id of the rack from which leaf should be removed
                :param leaf_id: id of the leaf which should be removed
                """
                return self._request(
                    '/rack-leaf/{}/{}'.format(rack_id, leaf_id),
                    method='DELETE',
                    **kwargs
                )

            def delete_leaf_pair_from_rack(
                self,
                rack_id: tt.GraphNodeId,
                rg_id: tt.GraphNodeId,
                **kwargs: te.Unpack[RestResource.TReadKwargs],
            ) -> tt.JSON:
                """ Delete leaf pair.

                Deletes leaf pair from rack.

                :param rack_id: id of the rack from which leaf pair should be removed
                :param rg_id: id of the leaf pair which should be removed
                """
                return self._request(
                    '/rack-leaf-pair/{}/{}'.format(rack_id, rg_id),
                    method='DELETE',
                    **kwargs
                )

            def add_pods(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'add_pods',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> _MAGIC.facade_method_schema[
                'aos.reference_design.two_stage_l3clos.facade.Facade',
                'add_pods',
                'result']:
                """ Add pods.

                Add pods to blueprint based on passed pod type.

                :param data: configuration of the new pod
                """
                return self._request(
                    '/add-pods',
                    method='POST', data=data,
                    **kwargs
                )

            def add_pods_by_id(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'add_pods_by_id',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> _MAGIC.facade_method_schema[
                'aos.reference_design.two_stage_l3clos.facade.Facade',
                'add_pods_by_id',
                'result']:
                """ Deprecated.

                Use :py:meth:`add_pods` instead.
                """
                return self._request(
                    '/add-pods-by-id',
                    method='POST', data=data,
                    **kwargs
                )

            def delete_pods(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'delete_pods',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> _MAGIC.facade_method_schema[
                'aos.reference_design.two_stage_l3clos.facade.Facade',
                'delete_pods',
                'result']:
                """ Delete pods.

                Removes all racks associated with the specified pod.

                :param data: IDs of pods to be deleted
                """
                return self._request(
                    '/delete-pods',
                    method='POST', data=data,
                    **kwargs
                )

            def add_leaf_peer_links(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'add_leaf_peer_links',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> _MAGIC.facade_method_schema[
                'aos.reference_design.two_stage_l3clos.facade.Facade',
                'add_leaf_peer_links',
                'result']:
                """ Add links between leaf peers in a mlag pair.

                :param data: configuration of links
                """
                return self._request(
                    '/leaf-peer-links',
                    method='POST',
                    data=data,
                    **kwargs)

            def add_access_peer_links(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'add_access_peer_links',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> _MAGIC.facade_method_schema[
                'aos.reference_design.two_stage_l3clos.facade.Facade',
                'add_access_peer_links',
                'result']:
                """ Add links between access peers in an esi pair.

                :param data: configuration of links
                """
                return self._request(
                    '/access-peer-links',
                    method='POST',
                    data=data,
                    **kwargs)

            def add_leaf_leaf_links(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'add_leaf_leaf_links',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> _MAGIC.facade_method_schema[
                'aos.reference_design.two_stage_l3clos.facade.Facade',
                'add_leaf_leaf_links',
                'result']:
                """ Add links between leafs in L3Collapsed topology.

                :param data: configuration of links
                """
                return self._request(
                    '/leaf-leaf-links',
                    method='POST',
                    data=data,
                    **kwargs)

            def change_leaf_server_link_labels(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'change_server_link_labels',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> tt.JSON:
                """ Update link group labels.

                Links will be joined into bonds or bonds will be split into links in
                accordance with the specified group labels.

                :param data: configuration of links
                """
                return self._request(
                    '/leaf-server-link-labels',
                    method='PATCH',
                    data=data, **kwargs)

            def change_server_labels_and_hostnames(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'change_server_labels_and_hostnames',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> tt.JSON:
                """ Update server labels and hostnames.

                :param data: server's node id to new label and hostname
                """
                return self._request(
                    '/server-labels-and-hostnames',
                    method='PATCH',
                    data=data, **kwargs)

            def change_logical_device(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'change_logical_device',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> tt.JSON:
                """ Change system logical device.

                Changes logical device for selected systems to the specified one.
                Logical device can also be updated together with interface map and
                device profile.

                :param data: new logical device, interface map, device profile for
                    specified systems
                """
                return self._request(
                    '/change-logical-device',
                    method='POST',
                    data=data, **kwargs)

            def get_server_hostnames_lldp(
                self,
                **kwargs: te.Unpack[RestResource.TReadKwargs],
            ) -> _MAGIC.facade_method_schema[
                'aos.reference_design.two_stage_l3clos.facade.Facade',
                'get_server_hostnames_lldp',
                'result']:
                """ Get server hostnames from lldp info on leafs.
                """
                return self._request(
                    '/server-hostnames-lldp', **kwargs)

            def set_physical_link_speed(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'set_physical_link_speed',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> tt.JSON:
                """ Set physical link speed.

                Sets given speed to the given physical link (except for links to
                access switches and generic systems).

                :param data: configuration of links
                """
                return self._request(
                    '/set-physical-link-speed',
                    method='PUT',
                    data=data,
                    **kwargs)

            def set_switch_system_link_speed(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'set_switch_system_link_speed',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> tt.JSON:
                """ Set switch system link speed.

                Sets given speed to the given links to access switch or generic
                system.

                :param data: configuration of links
                """
                return self._request(
                    '/set-switch-system-link-speed',
                    method='PUT',
                    data=data,
                    **kwargs)

            def add_switch_system_link(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'add_switch_system_link',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> _MAGIC.facade_method_schema[
                'aos.reference_design.two_stage_l3clos.facade.Facade',
                'add_switch_system_link',
                'result']:
                """ Add links to generic system or to access switch.

                Add a link between a switch (access switch, ESI access switch pair,
                leaf or leaf pair) and a system (generic system, access switch or
                ESI access switch pair).

                Can be used to create new system.

                :param data: configuration of links and new systems
                """
                return self._request(
                    '/switch-system-links',
                    method='POST',
                    data=data,
                    **kwargs)

            def change_port_channel_id_range(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'change_port_channel_id_range',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> tt.JSON:
                """ Change port channel ID range.

                Changes port channel id range for selected generic system nodes.

                :param data: new port channel id ranges for selected systems
                """
                return self._request(
                    '/port-channel-id',
                    method='POST',
                    data=data,
                    **kwargs)

            def delete_physical_links(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'delete_physical_links',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> tt.JSON:
                """ Delete fabric links between leafs.

                :param data: ids of links to be deleted
                """
                return self._request(
                    '/delete-physical-links',
                    method='POST',
                    data=data,
                    **kwargs)

            def delete_switch_system_links(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'delete_switch_system_links',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> tt.JSON:
                """ Delete links to generic system or to access switch.

                Delete links from switch (leaf, access) facing other system (generic
                or access).

                Removing the last link towards system leads to the system removal.

                :param data: ids of links to be removed
                """
                return self._request(
                    '/delete-switch-system-links',
                    method='POST',
                    data=data,
                    **kwargs)

            def virtual_network_plugged_eps(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'virtual_network_plugged_eps',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> _MAGIC.facade_method_schema[
                'aos.reference_design.two_stage_l3clos.facade.Facade',
                'virtual_network_plugged_eps',
                'result']:
                """ Get virtual network's dependant nodes.

                Get virtual network's dependant connectivity templates and
                application endpoint nodes.

                :param data: ids of virtual network nodes
                """
                return self._request(
                    '/virtual-network-plugged-eps',
                    method='POST',
                    data=data,
                    **kwargs
                )

            def security_zone_plugged_eps(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'security_zone_plugged_eps',
                    'arg'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs],
            ) -> _MAGIC.facade_method_schema[
                'aos.reference_design.two_stage_l3clos.facade.Facade',
                'security_zone_plugged_eps',
                'result']:
                """ Get routing zone's dependant nodes.

                Get routing zone's dependant connectivity templates and application endpoint
                nodes.

                :param data: ids of routing zone nodes
                """
                return self._request(
                    '/security-zone-plugged-eps',
                    method='POST',
                    data=data,
                    **kwargs
                )

            @api('/external-generic-systems')
            class external_generic_systems(Api):
                def create(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'create_external_generic_system',
                        'arg'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'create_external_generic_system',
                    'result']:
                    """ Create external system.

                    Create external generic system. External means outside of racks.

                    :param data: configuration of the new system
                    """
                    return self._request(method='POST', data=data, **kwargs)

                @api('/{system_id}')
                class resource(Api):
                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs],
                    ) -> tt.JSON:
                        """ Delete external system.

                        Delete external generic system.
                        """
                        return self._request(method='DELETE', **kwargs)

                    def update(
                        self,
                        data: _MAGIC.facade_method_schema[
                            'aos.reference_design.two_stage_l3clos.facade.Facade',
                            'assign_logical_device_to_external_generic_system',
                            'arg'],
                        **kwargs: te.Unpack[RestResource.TWriteKwargs]
                    ) -> tt.JSON:
                        """ Update external system.

                        Update specific fields of external generic system.

                        :param data: updates for a system
                        """
                        return self._request(method='PATCH', data=data, **kwargs)

            @api('/virtual-networks')
            class virtual_networks(RestResources):
                def create_batch(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'add_virtual_networks',
                        'arg'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'add_virtual_networks',
                    'result']:
                    """ Add multiple virtual networks.

                    Create new virtual networks with provided parameters.

                    :param data: configurations of new virtual networks
                    """
                    if isinstance(data, list):
                        data = {'virtual_networks': data}
                    return self._request(
                        '-batch',
                        method='POST', data=data,
                        **kwargs
                    )

                def patch_batch(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'patch_virtual_networks',
                        'arg'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> tt.JSON:
                    """ Update multiple virtual networks.

                    Update existing virtual networks with provided parameters.

                    :param data: updates for virtual networks
                    """
                    if isinstance(data, list):
                        data = {'virtual_networks': data}
                    return self._request(
                        '-batch-patch',
                        method='PATCH', data=data,
                        **kwargs
                    )

                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type[
                    'aos.reference_design.two_stage_l3clos.virtual_network.VIRTUAL_NETWORK_LIST_SCHEMA']:
                    """ Get virtual networks.
                    """
                    return t.cast(
                        dict,
                        self._request(**kwargs)
                    )['virtual_networks']

                @api('/{virtual_network_id}')
                class resource(RestResource):
                    """ Manage selected virtual network in a blueprint.
                    """
                    @api('/endpoints')
                    class endpoints(RestResources):
                        def create(
                            self,
                            data: _MAGIC.facade_method_schema[
                                'aos.reference_design.two_stage_l3clos.facade.Facade',
                                'add_virtual_network_endpoint',
                                'arg'],
                            **kwargs: te.Unpack[RestResources.TWriteKwargs],
                        ) -> _MAGIC.facade_method_schema[
                            'aos.reference_design.two_stage_l3clos.facade.Facade',
                            'add_virtual_network_endpoint',
                            'result']:
                            """ Add virtual network endpoint.

                            Create new virtual network endpoint with provided
                            parameters.

                            It is recommended to use Connectivity Templates to
                            create virtual network endpoints.

                            :param data: configuration of the new endpoint
                            """
                            return self._request(method='POST', data=data, **kwargs)

                        def update(
                            self,
                            data: _MAGIC.facade_method_schema[
                                'aos.reference_design.two_stage_l3clos.facade.Facade',
                                'update_virtual_network_endpoints',
                                'arg'],
                            **kwargs: te.Unpack[RestResources.TWriteKwargs],
                        ) -> tt.JSON:
                            """ Update virtual network endpoints.

                            If virtual network endpoint was created using
                            Connectivity Template, only label changes are allowed
                            via this API.

                            :param data: new parameters of the endpoint
                            """
                            return self._request(method='PUT', data=data, **kwargs)

                        @api('/{endpoint_id}')
                        class resource(Api):
                            def delete(
                                self,
                                **kwargs: te.Unpack[RestResource.TReadKwargs],
                            ) -> None:
                                """ Delete virtual network endpoint.

                                If virtual network endpoint was created using
                                Connectivity Template, it must not be removed via
                                this API.
                                """
                                self._request(method='DELETE')
                                self._client.remove_cleanup(self._url)

            @api('/delete-virtual-networks')
            class delete_virtual_networks(Api):
                def post(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'delete_virtual_networks',
                        'arg'],
                    **kwargs: te.Unpack[RestResources.TWriteKwargs],
                ) -> tt.JSON:
                    """ Delete multiple virtual networks.

                    :param data: list of virtual network ids to be deleted
                    """
                    return self._request(method='POST', data=data, **kwargs)

            @api('/virtual-networks-csv-bulk')
            class virtual_networks_csv_bulk(Api):
                def get(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'export_virtual_networks',
                    'result']:
                    """ Export virtual networks.

                    Export virtual networks data into CSV.
                    """
                    return self._request(method='GET', **kwargs)

                def patch(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'import_virtual_networks',
                        'arg'],
                        **kwargs: te.Unpack[RestResources.TWriteKwargs],
                ) -> tt.JSON:
                    """ Import virtual networks.

                    Import virtual networks via CSV. This API adds new virtual
                    networks or updates existing ones depending on virtual network
                    ids.

                    :param data: virtual networks configuration
                    """
                    return self._request(method='PATCH', data=data, **kwargs)

                def post(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'export_selected_virtual_networks',
                        'arg'],
                    **kwargs: te.Unpack[RestResources.TWriteKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'export_selected_virtual_networks',
                    'result']:
                    """ Export virtual networks.

                    Export virtual networks data into CSV.
                    Similar to :py:meth:`get` but allows to specify VNs list to
                    export.

                    :param data: list of virtual network ids to export
                    """
                    return self._request(method='POST', data=data, **kwargs)

            @api('/floating-ips')
            class floating_ips(
                RestResources,
                create__data=_fm_schema('create_floating_ip', 'arg'),
                create__=_fm_schema('create_floating_ip', 'result'),
                __create='''
                    Create floating IP address.

                    Create ip_endpoint with endpoint_type 'VIP'.

                    :param data: configuration of the new floating IP
                '''
            ):
                """ API to manage floating IPs.
                """
                def list(
                    self,
                    virtual_network_id: t.Optional[tt.GraphNodeId] = None,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'get_floating_ips',
                    'result']:
                    """ Get list of floating IP addresses.

                    Get list of ip_endpoints with type VIP.

                    :param virtual_network_id: Filter by virtual network ID
                    """
                    params = {'virtual_network_id': virtual_network_id}  # type: ignore[arg-type]
                    return t.cast(dict, self._request(  # type: ignore[misc]
                        method='GET', params=t.cast(dict, params), **kwargs
                    ))['items']

                @api('/{floating_ip_node_id}')
                class resource(
                    RestResource,
                    get__=_fm_schema('get_floating_ip', 'result'),
                    patch__data=_fm_schema('patch_floating_ip', 'arg'),
                    __get='''
                        Get floating IP address.

                        Get detailed information about ip_endpoint with type VIP.
                    ''',
                    __patch='''
                        Update floating IP address.

                        Partly update ip_endpoint with type VIP data.

                        :param cmds: Data to update floating IP with.
                    ''',
                ):
                    """ API to manage selected floating IP.
                    """
                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> None:
                        """ Delete floating IP address.

                        Delete ip_endpoint with type VIP.
                        """
                        self._request(method='DELETE')
                        self._client.remove_cleanup(self._url)

            # XXX: do we really need it to be RestResources?
            #  Facade endpoints are not defined for '/configlet-previews', thus
            #  inheritance from Api fits better
            @api('/configlet-previews')
            class configlet_previews(RestResources):
                """ Collection of configlet previews.

                Note that API endpoints are not defined for this API, thus
                underlying resource should always be used, e.g.:

                .. code-block:: python

                    client.blueprints[<bp_id>].configlet_previews[<configlet_id>].get()
                    client.blueprints[<bp_id>].configlet_previews[<configlet_id>].node[<node_id>].get()
                    client.blueprints[<bp_id>].configlet_previews[<configlet_id>].deployed.get()
                """
                @api('/{node_id}')
                class resource(
                    RestResource,
                    get__=_fm_schema('get_configlet_preview', 'result'),
                    __get='''
                        Get preview of rendered configlet.
                    '''
                ):
                    node = resources(
                        '/node',
                        get_schema=_fm_schema(
                            'get_configlet_preview_for_node',
                            'result'
                        ),
                        collection_doc='''
                            Collection management not supported. Use single resource
                            instead.
                        ''',
                        resource_doc='''
                            Get preview of rendered configlet for given system.

                            Only GET method is supported.
                        ''',
                        resource_name='node',
                    )

                    @api('?type=deployed')
                    class deployed(
                        RestResource,
                        get__=_fm_schema('get_configlet_preview', 'result'),
                        __get='''
                            Get preview of rendered configlet in deployed graph.
                        '''
                    ):
                        # XXX: doubled "?type=deployed" doesn't seem to be working
                        node = resources(
                            '?type=deployed',
                            get_schema=_fm_schema(
                                'get_configlet_preview_for_node',
                                'result'
                            ),
                            collection_doc='''
                                Collection management not supported. Use single
                                resource instead.
                            ''',
                            resource_doc='''
                                Get preview of rendered configlet for given system
                                in deployed graph.

                                Only GET method is supported.
                            ''',
                            resource_name='node',
                        )

            @api('/security-zones')
            class security_zones(
                RestResources,
                list__=_fm_schema('list_security_zones', 'result'),
                create__data=_fm_schema('add_security_zone', 'arg'),
                create__=_fm_schema('add_security_zone', 'result'),
                __create='''
                    Add routing zone.

                    Add new routing zone (previously security zone) with provided
                    attributes.

                    :param data: configuration of the new routing zone
                ''',
                __list='''
                    List routing zones.

                    List all routing zones (previously security zones) from
                    blueprint.
                '''
            ):
                """ Routing zones management APIs.
                """

                @api('/{security_zone_id}')
                class resource(
                    RestResource,
                    update__data=_fm_schema('put_security_zone', 'arg'),
                    patch__data=_fm_schema('patch_security_zone', 'arg'),
                    __get='''
                        Get routing zone.

                        Get routing zone (previously security zone) by id.
                    ''',
                    __update='''
                        Update routing zone.

                        Update existing routing zone (previously security zone)
                        with provided attributes.

                        :param data: New attributes for security zone
                    ''',
                    __patch='''
                        Update routing zone.

                        Similar to :py:meth:`update` request but allows to update
                        attributes with null values.

                        :param data: New attributes for security zone
                    ''',
                    __delete='''
                        Delete routing zone.

                        Delete existing routing zone (previously security zone).
                    ''',
                ):
                    @api('/dhcp-servers')
                    class dhcp_servers(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResource.TReadKwargs]
                        ) -> list[str]:
                            """ Get routing zone DHCP servers.

                            Get routing zone (previously security zone) DHCP server
                            IPs list.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['items']

                        def update(
                            self,
                            data: _MAGIC.facade_method_schema[
                                'aos.reference_design.two_stage_l3clos.facade.Facade',
                                'update_security_zone_default_dhcp_relay_servers',
                                'arg'] | list[str],
                            **kwargs: te.Unpack[RestResources.TWriteKwargs],
                        ) -> tt.JSON:
                            """ Update routing zone DHCP servers.

                            Update routing zone (previously security zone) DHCP
                            server IPs list.

                            :param data: updated dhcp server IPs
                            """
                            if isinstance(data, list):
                                data = {'items': data}
                            return self._request(method='PUT', data=data, **kwargs)

                    @api('/loopbacks')
                    class loopbacks(Api):
                        def patch(
                            self,
                            data: _MAGIC.facade_method_schema[
                                'aos.reference_design.two_stage_l3clos.facade.Facade',
                                'update_security_zone_loopbacks',
                                'arg'],
                            **kwargs: te.Unpack[RestResources.TWriteKwargs],
                        ) -> tt.JSON:
                            """ Update routing zone loopbacks.

                            Update routing zone (previously security zone) loopback
                            interfaces' IP addresses.

                            :param data: updated loopback IPs
                            """
                            return self._request(method='PATCH', data=data, **kwargs)

            @api('/security-zones-csv-bulk')
            class security_zones_csv_bulk(Api):
                def get(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'export_routing_zones',
                    'result']:
                    """ Export routing zones.

                    Export routing zones (previously security zones) data into CSV.
                    """
                    return self._request(method='GET', **kwargs)

                def patch(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'import_routing_zones',
                        'arg'],
                    **kwargs: te.Unpack[RestResources.TWriteKwargs],
                ) -> tt.JSON:
                    """
                    Import routing zones.

                    Import routing zones (previously security zones) via CSV.
                    This API adds new routing zones or updates existing ones
                    depending on routing zone ids.

                    :param data: routing zones configuration in CSV format
                    """
                    return self._request(method='PATCH', data=data, **kwargs)

                def post(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'export_selected_routing_zones',
                        'arg'],
                    **kwargs: te.Unpack[RestResources.TWriteKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'export_selected_routing_zones',
                    'result']:
                    """
                    Export routing zones.

                    Similar to :py:meth:`get` request but allows to specify RZs list
                    to export.

                    :param data: security zone ids to be exported
                    """
                    return self._request(method='POST', data=data, **kwargs)

            @api('/delete-security-zones')
            class delete_security_zones(Api):
                def post(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'delete_security_zones',
                        'arg'],
                    **kwargs: te.Unpack[RestResources.TWriteKwargs],
                ) -> tt.JSON:
                    """ Delete multiple routing zones.

                    :param data: routing zone ids to be removed
                    """
                    return self._request(method='POST', data=data, **kwargs)

            @api('/subinterfaces')
            class subinterfaces(
                RestResources,
                create__data=_fm_schema('create_subinterface', 'arg'),
                create__=_fm_schema('create_subinterface', 'result'),
                __create='''
                    Create subinterface.

                    Creates a subinterface on interface which is a part of physical
                    link or aggregate link with 'to_generic' role.

                    It's recommended to use Connectivity Templates to create
                    subinterfaces.

                    :param data: configuration of new subinterfaces
                '''
            ):
                def patch(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'update_subinterfaces',
                        'arg'],
                    **kwargs: te.Unpack[RestResources.TWriteKwargs],
                ) -> tt.JSON:
                    """ Update subinterfaces.

                    If a subinterface was created using a Connectivity Template,
                    only IPv4/IPv6 addresses are allowed to modify via this API.

                    :param data: new configuration for subinterfaces
                    """
                    return self._request(
                        method='PATCH', data=data, **kwargs)

                @api('/{subinterface_id}')
                class resource(Api):
                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> None:
                        """ Delete subinterface.

                        If a subinterface was created using a Connectivity Template,
                        it must not be removed via this API.
                        """
                        self._request(method='DELETE')
                        self._client.remove_cleanup(self._url)

            @api('/superspines-config')
            class superspines_config(Api):
                def get(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'get_superspine_config',
                    'result']:
                    """ Get information of current superspine configuration.

                    Numbers of superspine planes, number nodes per plane and used
                    logical device.
                    """
                    return self._request(method='GET', **kwargs)

                def patch(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'update_superspine_config',
                        'arg'],
                    **kwargs: te.Unpack[RestResources.TWriteKwargs],
                ) -> tt.JSON:
                    """ Update superspine configuration.

                    The endpoint allows increasing number of superspine per plane
                    and changing number of planes, speed of the links and allows
                    modifying logical device. Decreasing number of superspines is
                    not allowed.

                    :param data: new configuration for superspines
                    """
                    return self._request(
                        method='PATCH', data=data, **kwargs)

            @api('/pods')
            class pods(RestResources):
                """ API to manage pods inside blueprint.
                """
                @api('/{pod_id}')
                class resource(RestResource):
                    @api('/spine-config')
                    class spine_config(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResource.TReadKwargs]
                        ) -> _MAGIC.facade_method_schema[
                            'aos.reference_design.two_stage_l3clos.facade.Facade',
                            'get_spine_config',
                            'result']:
                            """ Get current spine configuration for the pod.

                            Obtains numbers of spines in the pod, count and speed of
                            spine-superspine links and used logical device.
                            """
                            return self._request(method='GET', **kwargs)

                        def patch(
                            self,
                            data: _MAGIC.facade_method_schema[
                                'aos.reference_design.two_stage_l3clos.facade.Facade',
                                'update_spine_config',
                                'arg'],
                            **kwargs: te.Unpack[RestResources.TWriteKwargs],
                        ) -> tt.JSON:
                            """ Update spine configuration for the pod.

                            The endpoint allows increasing spine count and changing
                            number of spine-superspine links on a per superspine
                            plane basis, speed of the links and allows modifying
                            logical device.

                            :param data: new configuration for the pod
                            """
                            return self._request(
                                method='PATCH', data=data, **kwargs)

            @api('/l3-dot1q-links')
            class l3_dot1q_links(
                RestResources,
                create__data=_fm_schema('create_logical_link', 'arg'),
                __create='''
                    Create logical link.

                    Creates a logical link for two specified subinterfaces which are
                    hosted on interfaces of physical link.

                    It is recommended to use Connectivity Templates to create a
                    logical link.

                    :param data: :param data: configuration of links
                '''
            ):
                @api('/{logical_link_id}')
                class resource(Api):
                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> None:
                        """ Delete logical link.

                        Deletes a logical link between two specified subinterfaces
                        which are hosted on interfaces of physical link.

                        If a logical link was created using a Connectivity Template,
                        it must not be deleted via this API.
                        """
                        self._request(method='DELETE')
                        self._client.remove_cleanup(self._url)

            @api('/iba/predefined-probes')
            class predefined_probes(Api):
                fabric_ecmp_imbalance = predefined_probe('/fabric_ecmp_imbalance')
                spine_superspine_ecmp_imbalance = predefined_probe(
                    '/spine_superspine_ecmp_imbalance')
                external_ecmp_imbalance = predefined_probe(
                    '/external_ecmp_imbalance')
                fabric_hotcold_ifcounter = predefined_probe(
                    '/fabric_hotcold_ifcounter')
                spine_superspine_hotcold_ifcounter = predefined_probe(
                    '/spine_superspine_hotcold_ifcounter')
                specific_hotcold_ifcounter = predefined_probe(
                    '/specific_hotcold_ifcounter')
                fabric_interface_flapping = predefined_probe(
                    '/fabric_interface_flapping')
                spine_superspine_interface_flapping = predefined_probe(
                    '/spine_superspine_interface_flapping')
                specific_interface_flapping = predefined_probe(
                    '/specific_interface_flapping')
                eastwest_traffic = predefined_probe('/eastwest_traffic')
                esi_imbalance = predefined_probe('/esi_imbalance')
                mlag_imbalance = predefined_probe('/mlag_imbalance')
                vlan = predefined_probe('/virtual_infra_vlan_match')
                missing_vlan_vms = predefined_probe('/missing_vlan_vms')
                drain_node_traffic_anomaly = predefined_probe(
                    '/drain_node_traffic_anomaly')
                external_routes = predefined_probe('/external_routes')
                evpn_host_flapping = predefined_probe('/evpn_host_flapping')
                evpn_vxlan_type3 = predefined_probe('/evpn_vxlan_type3')
                evpn_vxlan_type5 = predefined_probe('/evpn_vxlan_type5')
                interface_policy_dot1x = predefined_probe('/interface_policy_dot1x')
                device_health = predefined_probe('/device_health')
                interface_error_counters = predefined_probe(
                    '/interface_error_counters')
                packet_discard_percentage = predefined_probe(
                    '/packet_discard_percentage')
                capacity_fault_tolerance = predefined_probe(
                    '/capacity_fault_tolerance')
                multiagent_detector = predefined_probe(
                    '/multiagent_detector')
                traffic = predefined_probe('/traffic')
                optical_transceivers = predefined_probe('/optical_transceivers')
                bgp_session = predefined_probe('/bgp_session')

            @api('/experience')
            class experience(Api):
                @api('/web')
                class web(Api):
                    @api('/cabling-map')
                    class cabling_map(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> list[
                            _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.cabling_map.CABLING_MAP_LINK_SCHEMA']
                        ]:
                            """ Get information about system links.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['links']

                        def get_redundancy_group_port_channels(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> list[
                            _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.cabling_map.REDUNDANCY_GROUP_PORT_CHANNEL_SCHEMA']
                        ]:
                            """ Get information about redundancy group port
                            channels.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['redundancy_group_port_channels']

                        # TODO: Should be remove as we don't have such endpoint
                        @api('/meta')
                        class meta(Api):
                            def get(
                                self,
                                **kwargs: te.Unpack[RestResources.TReadKwargs],
                            ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.blueprint_cache_facade.EXPERIENCE_META_SCHEMA']:
                                """ Get cabling map cache meta data.
                                """
                                return self._request(method='GET', **kwargs)

                    @api('/leaf-server-links-digest')
                    class leaf_server_links_digest(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.switch_system_links.LINKS_GET_DIGEST_SCHEMA']:
                            """ Get leaf server links digest.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['links']

                    @api('/switch-server-links-digest')
                    class switch_server_links_digest(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.switch_system_links.LINKS_GET_DIGEST_SCHEMA']:
                            """ Get switch server links digest.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['links']

                    @api('/load-balancing-policies')
                    class load_balancing_policies(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.experience.web.load_balancing_policy.LOAD_BALANCING_POLICY_SCHEMA']:
                            """ Get load balancing policies.

                            Lists all load balancing policies in the blueprint.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['load_balancing_policies']

                        def get_assignments(
                                self,
                                **kwargs
                        ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.experience.web.load_balancing_policy.LOAD_BALANCING_POLICY_SCHEMA']:
                            return t.cast(
                                dict,
                                self.request(url='/assignments', method='GET', **kwargs)
                            )['policy_assignments']

                    @api('/leaf-server-links')
                    class leaf_server_links(Api):
                        @api('/{virtual_network_id}')
                        class virtual_network_links(Api):
                            def get(
                                self,
                                **kwargs: te.Unpack[RestResources.TReadKwargs],
                            ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.switch_system_links.LINK_LIST_SCHEMA']:
                                """ Get leaf-server links for the virtual network in
                                the blueprint.
                                """
                                return t.cast(
                                    dict,
                                    self._request(method='GET', **kwargs)
                                )['links']

                    @api('/switch-server-links')
                    class switch_server_links(Api):
                        @api('/{virtual_network_id}')
                        class virtual_network_links(Api):
                            def get(
                                self,
                                **kwargs: te.Unpack[RestResources.TReadKwargs],
                            ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.switch_system_links.LINK_LIST_SCHEMA']:
                                """ Get switch-server links for the virtual network.
                                """
                                return t.cast(
                                    dict,
                                    self._request(method='GET', **kwargs)
                                )['links']

                    @api('/racks')
                    class racks(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.rack.RACK_SCHEMA_LIST']:
                            """ Get racks.

                            Gets all racks in the blueprint.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['items']

                        # TODO: Should be remove as we don't have such endpoint
                        @api('/meta')
                        class meta(Api):
                            def get(
                                self,
                                **kwargs: te.Unpack[RestResources.TReadKwargs],
                            ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.blueprint_cache_facade.EXPERIENCE_META_SCHEMA']:
                                """ Get rack cache meta data.
                                """
                                return self._request(method='GET', **kwargs)

                    @api('/virtual-networks')
                    class virtual_networks(Api):
                        def list(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.virtual_network.VIRTUAL_NETWORK_LIST_SCHEMA']:
                            """ Get virtual networks in the blueprint.
                            """
                            return t.cast(dict, self._request(
                                method='GET', **kwargs))['virtual_networks']

                    @api('/resource-pools')
                    class resource_pools(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.experience.web.resources.EXPERIENCE_RESOURCES_SCHEMA']:
                            """ Get resource pools.

                            Gets resource allocation statistics in the blueprint.
                            """
                            return t.cast(dict, self._request(
                                method='GET', **kwargs))['resource_pools']

                    @api('/protocol-sessions')
                    class protocol_sessions(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> list[
                            _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.experience.web.protocol_sessions.PROTOCOL_SESSION_GET_SCHEMA']
                        ]:
                            """ Get protocol sessions.

                            Lists all protocol sessions in the blueprint.
                            """
                            return t.cast(dict, self._request(
                                method='GET', **kwargs))['protocol_sessions']

                    @api('/floating-ips')
                    class floating_ips(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.experience.web.floating_ips.FLOATING_IPS_SCHEMA']:
                            """Get all floating IPs.

                            Floating IPs are virtual IP addresses that can be used
                            by one or more routers.
                            """
                            return t.cast(dict, self._request(
                                method='GET', **kwargs))['floating_ips']

                    @api('/system-info')
                    class system_info(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> list[
                            _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.experience.web.systems.SYSTEM_INFO_SCHEMA']
                        ]:
                            """ Get systems info in the blueprint.
                            """
                            return t.cast(dict, self._request(
                                method='GET', **kwargs))['data']

                    @api('/catalog')
                    class catalog(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> list[
                            _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.experience.web.systems.CATALOG_ENTRY_SCHEMA']
                        ]:
                            """Get blueprint catalog information.
                            """
                            return t.cast(dict, self._request(
                                method='GET', **kwargs))['data']

                    @api('/subinterfaces')
                    class subinterfaces(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> list[
                            _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.experience.web.subinterfaces.SUBINTERFACE_SCHEMA']
                        ]:
                            """ Get subinterfaces.

                            List all subinterfaces in the blueprint.
                            """
                            return t.cast(dict, self._request(
                                method='GET', **kwargs))['subinterfaces']

                    @api('/static-routes')
                    class static_routes(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> list[
                            _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.experience.web.static_routes.STATIC_ROUTES_SCHEMA']
                        ]:
                            """ Get static routes.

                            List all static routes in the blueprint.
                            """
                            return t.cast(dict, self._request(
                                method='GET', **kwargs))['static_routes']

                    @api('/security-zones')
                    class security_zones(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.experience.web.security_zones.SECURITY_ZONES_SCHEMA']:
                            """ Get routing zones.

                            Lists all routing zones (previously security zones) in
                            the blueprint.
                            """
                            return t.cast(dict, self._request(
                                method='GET', **kwargs))['security_zones']

                    @api('/routing-policies')
                    class routing_policies(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.routing_policy.ROUTING_POLICY_LIST_SCHEMA']:
                            """ Get routing policies.

                            Lists all routing policies in the blueprint.
                            """
                            return t.cast(dict, self._request(
                                method='GET', **kwargs))['routing_policies']

                    @api('/endpoint-policies')
                    class endpoint_policies(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.extension.endpoint_policy.endpoint_policies_experience.ENDPOINT_POLICIES_SCHEMA']:
                            """ Get connectivity templates.

                            List all connectivity templates in given blueprint.
                            """
                            return t.cast(dict, self._request(
                                method='GET', **kwargs))['endpoint_policies']

                    @api('/obj-policies-by-application-points')
                    class obj_policies_by_application_points(Api):
                        def post(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.blueprint_cache_facade.APPLICATION_POINTS_SCHEMA']:
                            """ Retrieve connectivity templates for provided
                            application endpoints.
                            """
                            return t.cast(dict, self._request(
                                method='POST', **kwargs))['application_points']

                    @api('/logical-devices')
                    class logical_devices(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> list[
                            _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.experience.web.logical_devices.LOGICAL_DEVICE_SCHEMA']
                        ]:
                            """ Get list of logical devices.
                            """
                            return t.cast(dict, self._request(
                                method='GET', **kwargs))['items']

                    @api('/interface-maps')
                    class interface_maps(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> list[
                            _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.experience.web.interface_maps.INTERFACE_MAP_SCHEMA']
                        ]:
                            """ Get interface maps.
                            """
                            return t.cast(dict, self._request(
                                method='GET', **kwargs))['items']

                    @api('/device-profiles')
                    class device_profiles(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> list[
                            _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.experience.web.device_profiles.DEVICE_PROFILE_SCHEMA']
                        ]:
                            """ Get device profiles.
                            """
                            return t.cast(dict, self._request(
                                method='GET', **kwargs))['items']

                    @api('/remote-gateways')
                    class remote_gateways(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> list[
                            _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.experience.web.remote_gateways.REMOTE_GW_SCHEMA']
                        ]:
                            """ Get remote gateways.

                            Gets all remote gateways in the blueprint.
                            """
                            return t.cast(dict, self._request(
                                method='GET', **kwargs))['items']

                    @api('/evpn_interconnect_groups')
                    class evpn_interconnect_groups(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> list[
                            _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.remote_gateway.EVPN_INTERCONNECT_GET_SCHEMA']
                        ]:
                            """ Get EVPN interconnect groups.
                            """
                            return t.cast(dict, self._request(
                                method='GET', **kwargs))['items']

                    @api('/virtual-stats')
                    class virtual_stats(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> list[
                            _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.experience.web.switch_system_links.VIRTUAL_STAT_SCHEMA']
                        ]:
                            """ Get virtual statistics.
                            """
                            return t.cast(dict, self._request(
                                method='GET', **kwargs))['items']

                    @api('/tenants')
                    class tenants(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> list[
                            _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.experience.web.tenants.TENANTS_CACHE_SCHEMA']
                        ]:
                            """ Get tenants.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['items']

                    @api('/dci_settings')
                    class dci_settings(Api):
                        def get(
                                self,
                                **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> _MAGIC.lollipop_type[
                            'aos.reference_design.two_stage_l3clos.experience.web.dci_settings.DCI_SETTINGS_SCHEMA'
                        ]:
                            """ Get DCI settings.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['dci_settings']

                    @api('/rails')
                    class rails(Api):
                        def get(
                                self,
                                **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> _MAGIC.lollipop_type[
                            'aos.reference_design.two_stage_l3clos.experience.web.rails.RAILS_SCHEMA'
                        ]:
                            """ Get rails.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['rails']

                    @api('/meta')
                    class meta(Api):
                        @api('/virtual-networks')
                        class virtual_networks(Api):
                            def get(
                                self,
                                **kwargs: te.Unpack[RestResources.TReadKwargs],
                            ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.blueprint_cache_facade.EXPERIENCE_META_SCHEMA']:
                                """ Get virtual networks meta.
                                """
                                return self._request(method='GET', **kwargs)

                        @api('/leaf-server-links-digest')
                        class leaf_server_links_digest(Api):
                            def get(
                                self,
                                **kwargs: te.Unpack[RestResources.TReadKwargs],
                            ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.blueprint_cache_facade.EXPERIENCE_META_SCHEMA']:
                                """ Get leaf-server links digest meta.
                                """
                                return self._request(method='GET', **kwargs)

                        @api('/switch-server-links-digest')
                        class switch_server_links_digest(Api):
                            def get(
                                self,
                                **kwargs: te.Unpack[RestResources.TReadKwargs],
                            ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.blueprint_cache_facade.EXPERIENCE_META_SCHEMA']:
                                """ Get switch-server links digest meta.
                                """
                                return self._request(method='GET', **kwargs)

                        @api('/leaf-server-links')
                        class leaf_server_links(Api):
                            @api('/{virtual_network_id}')
                            class virtual_network(Api):
                                def get(
                                    self,
                                    **kwargs: te.Unpack[RestResources.TReadKwargs],
                                ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.blueprint_cache_facade.EXPERIENCE_META_SCHEMA']:
                                    """ Get leaf-server links meta for the virtual
                                    network.
                                    """
                                    return self._request(method='GET', **kwargs)

                        @api('/switch-server-links')
                        class switch_server_links(Api):
                            @api('/{virtual_network_id}')
                            class virtual_network(Api):
                                def get(
                                    self,
                                    **kwargs: te.Unpack[RestResources.TReadKwargs],
                                ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.blueprint_cache_facade.EXPERIENCE_META_SCHEMA']:
                                    """ Get switch-server links meta for the virtual
                                    network.
                                    """
                                    return self._request(method='GET', **kwargs)

                        @api('/all')
                        class all(Api):
                            def get(
                                self,
                                **kwargs: te.Unpack[RestResources.TReadKwargs],
                            ) -> _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.blueprint_cache_facade.UNIFIED_EXPERIENCE_META_SCHEMA']:
                                """ Get unified meta in the blueprint.

                                Get meta for all available experience endpoints. Can
                                be used to compare known data's version without
                                fetching the actual data.
                                """
                                return self._request(method='GET', **kwargs)

            @api('/policies')
            class policies(
                RestResources,
                create__data=_fm_schema('create_policy'),
                __create='''
                    Create security policy.

                    :param data: configuration of the new security policy
                '''
            ):
                @api('/{resource_id}')
                class resource(
                    RestResource,
                    get__=_fm_schema('get_policy', 'result'),
                    update__data=_fm_schema('update_policy', 'arg'),
                    patch__data=_fm_schema('patch_policy', 'arg'),
                    __update='''
                        Update security policy.

                        Update security policy with a given node ID in the
                        specified blueprint.

                        :param data: new parameters of the policy
                    ''',
                    __patch='''
                        Patch security policy.

                        :param cmds: new parameters of the policy
                    ''',
                    __delete='''
                        Delete security policy.
                    '''
                ):
                    pass

                def list(
                    self,
                    **kwargs: te.Unpack[RestResources.TReadKwargs],
                ) -> list[_MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.policy.POLICY_GET_SCHEMA']]:
                    """ Get all security policies.

                    Return all security policies from the blueprint.
                    """
                    return t.cast(dict, self._request(
                        method='GET', **kwargs
                    ))['policies']

                @api('/conflicts')
                class conflicts(Api):
                    def list(
                        self,
                        **kwargs: te.Unpack[RestResources.TReadKwargs],
                    ) -> list[_MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.policy.CONFLICT_GET_SCHEMA']]:
                        """ Get all conflicts.

                        Return conflicts for all security policies.
                        """
                        return t.cast(dict, self._request(
                            method='GET', **kwargs
                        ))['conflicts']

            @api('/internal_endpoints')
            class internal_endpoints(
                RestResources,
                create__data=_fm_schema('create_internal_endpoint', 'arg'),
                __create='''
                    Create internal endpoint.

                    Create an internal endpoint in the specified blueprint.

                    :param data: configuration of the new internal endpoint
                '''
            ):
                @api('/{resource_id}')
                class resource(
                    RestResource,
                    get__=_fm_schema('get_internal_endpoint', 'result'),
                    update__data=_fm_schema('update_internal_endpoint', 'arg'),
                    __get='''
                        Get internal endpoint.

                        Return an internal endpoint by a given node ID from the
                        specified blueprint.
                    ''',
                    __update='''
                        Update internal endpoint.

                        Update an internal endpoint with a given node ID in the
                        specified blueprint.

                        :param data: new parameters of the internal endpoint
                    ''',
                    __delete='''
                        Delete internal endpoint.

                        Delete an internal endpoint with a given node ID from the
                        specified blueprint.
                    '''
                ):
                    pass

                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> list[_MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.policy.INTERNAL_ENDPOINT_GET_SCHEMA']]:
                    """ Get all internal endpoints.

                    Return a list of all internal endpoints from the specified
                    blueprint.
                    """
                    return t.cast(dict, self._request(
                        method='GET', **kwargs
                    ))['internal_endpoints']

            @api('/external_endpoints')
            class external_endpoints(
                RestResources,
                create__data=_fm_schema('create_external_endpoint'),
                __create='''
                    Create external endpoint.

                    Create an external endpoint in the specified blueprint.
                '''
            ):
                @api('/{resource_id}')
                class resource(
                    RestResource,
                    get__=_fm_schema('get_external_endpoint', 'result'),
                    update__data=_fm_schema('update_external_endpoint', 'arg'),
                    __get='''
                        Get external endpoint.

                        Return an external endpoint by a given node ID from the
                        specified blueprint.
                    ''',
                    __update='''
                        Update external endpoint.

                        Update an external endpoint with a given node ID in the
                        specified blueprint.

                        :param data: new parameters of the external endpoint
                    ''',
                    __delete='''
                        Delete external endpoint.

                        Delete an external endpoint with a given node ID from
                        the specified blueprint.
                    '''
                ):
                    pass

                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> list[_MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.policy.EXTERNAL_ENDPOINT_GET_SCHEMA']]:
                    """ Get all external endpoints.

                    Return a list of all external endpoints from the specified
                    blueprint.
                    """
                    return t.cast(dict, self._request(
                        method='GET', **kwargs
                    ))['external_endpoints']

            @api('/enforcement_points')
            class enforcement_points(RestResources):
                @api('/{resource_id}')
                class resource(
                    RestResource,
                    get__=_fm_schema('get_enforcement_point', 'result'),
                    __get='''
                        Get enforcement point.

                        Return an enforcement point information by its graph
                        node ID.
                    '''
                ):
                    pass

                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> list[_MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.policy.ENFORCEMENT_POINT_GET_SCHEMA']]:
                    """ Get all enforcement points.

                    Obtain a list of all enforcement points from the specified
                    blueprint.
                    """
                    return t.cast(dict, self._request(
                        method='GET', **kwargs
                    ))['enforcement_points']

            @api('/groups')
            class groups(
                RestResources,
                create__data=_fm_schema('create_group'),
                __create='''
                    Create endpoint group.

                    Create a group in the specified blueprint.

                    :param data: configuration of the new group
                ''',
            ):
                @api('/{resource_id}')
                class resource(
                    RestResource,
                    get__=_fm_schema('get_group', 'result'),
                    update__data=_fm_schema('update_group', 'arg'),
                    __get='''
                        Get endpoint group.

                        Return a group by a given ID from the specified blueprint.
                    ''',
                    __update='''
                        Update endpoint group.

                        Update a group by a given ID in the specified blueprint.

                        :param data: new parameters of the group
                    ''',
                    __delete='''
                        Delete endpoint group.

                        Delete a group by a given ID from the specified blueprint.
                    '''
                ):
                    pass

                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> list[_MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.policy.GROUP_GET_SCHEMA']]:
                    """ Get list of endpoint groups.

                    Return a list of groups by a given filter from the specified
                    blueprint.
                    """
                    return t.cast(dict, self._request(
                        method='GET', **kwargs
                    ))['groups']

            @api('/policy_digests')
            class policy_digests(Api):
                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> list[_MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.policy.POLICY_DIGEST_GET_SCHEMA']]:
                    """ Get all security policy digests.
                    """
                    return t.cast(dict, self._request(
                        method='GET', **kwargs
                    ))['policy_digests']

            @api('/application_point_decomposition')
            class application_point_decomposition(Api):
                @api('/{application_point_id}')
                class resource(Api):
                    def get(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs],
                    ) -> list[_MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.policy.NODE_DIGEST_WITH_IPV4_SUBNET_SCHEMA']]:
                        """ Get decomposition for security policy application point.

                        Decomposition is represented by a set of elementary
                        particles - virtual networks and IP endpoints the
                        application point consists of.
                        """
                        return t.cast(dict, self._request(
                            method='GET', **kwargs
                        ))['application_point_decomposition']

            @api('/policy_search')
            class policy_search(Api):
                def execute(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'policy_search',
                        'arg'],
                    **kwargs: te.Unpack[RestResources.TWriteKwargs],
                ) -> list[_MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.policy.POLICY_SEARCH_RESULT_LIST_SCHEMA']]:
                    """ Find security policies.

                    Found policies include information about rules and intersection status.

                    :param data: criteria for policies to be found
                    """
                    return t.cast(dict, self._request(
                        method='POST', data=data, **kwargs
                    ))['policies']

            @api('/conflict_resolutions')
            class conflict_resolutions(Api):
                def create(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'resolve_conflict',
                        'arg'],
                    **kwargs: te.Unpack[RestResources.TWriteKwargs],
                ) -> str:
                    """ Resolve conflict between two security rules.

                    Manually resolve a conflict between 'src_rule' and 'dst_rule',
                    which means that source rule will be rendered before the
                    destination rule.

                    :param data: source rule and destination rule ids
                    """
                    return t.cast(dict, self._request(
                        method='POST', data=data, **kwargs
                    ))['id']

                @api('/{resolution_id}')
                class resource(Api):
                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResources.TReadKwargs],
                    ) -> tt.JSON:
                        """ Delete user-defined conflict resolution.

                        Delete a user-defined conflict resolution ('precedes'
                        relationship) by a given ID from the specified blueprint.
                        """
                        return self._request(method='DELETE', **kwargs)

            @api('/fabric-settings')
            class fabric_settings(Api):
                def get(
                    self,
                    **kwargs: te.Unpack[RestResources.TReadKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'get_fabric_settings',
                    'result']:
                    """ Get fabric policy details.
                    """
                    return self._request(method='GET', **kwargs)

                def update(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'update_fabric_settings',
                        'arg'],
                    **kwargs: te.Unpack[RestResources.TWriteKwargs],
                ) -> tt.JSON:
                    """ Update fabric settings.

                    Updates properties of fabric policy in the graph.

                    :param data: new fabric settings
                    """
                    return self._request(method='PATCH', data=data, **kwargs)

            @api('/interface-policies')
            class interface_policies(Api):

                def list(
                    self,
                    mode: t.Literal['lite', 'verbose'] = 'lite',
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> dict[
                    tt.GraphNodeId,
                    _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.policy.POLICY_SEARCH_RESULT_LIST_SCHEMA']]:
                    """ List interface policies.

                    Returns interface policy IDs, but not their system and interface
                    assignments.

                    :param mode: Indicates whether API response is verbose or lite.
                        The default is lite.  "Verbose" will include system
                        assignments for all interface policy assignments.
                    """
                    self._url += '?mode=%s' % mode
                    return t.cast(
                        dict,
                        self._request(method='GET', **kwargs)
                    )['items']

                def create(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'post_interface_policy',
                        'arg'],
                    **kwargs: te.Unpack[RestResources.TWriteKwargs],
                ) -> _MAGIC.lollipop_type['aos.scotch.schemas.schema.IdSchema']:
                    """ Creates interface policy.

                    :param data: configuration of the new interface policy
                    """
                    return self._request(method='POST', data=data, **kwargs)

                @api('/capable-systems')
                class capable_systems(Api):
                    def list(self) -> None | _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.policy.LIST_CAPABLE_SYSTEMS_SCHEMA']:
                        """ Get 802.1x capable systems.

                        Returns 802.1x capable systems along with interface policies
                        assigned to such systems (if any).
                        """
                        return t.cast(dict, self._request(method='GET'))['items']

                    @api('/{node_id}')
                    class resource(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> _MAGIC.facade_method_schema[
                            'aos.reference_design.two_stage_l3clos.facade.Facade',
                            'get_capable_interfaces_for_system',
                            'result']:
                            """ Get interfaces capable and ready for assignment on
                            the given system.

                            Returns physical (`ethernet`) interfaces of a given
                            system facing a generic system.
                            """
                            return self._request(method='GET', **kwargs)

                # XXX: do we really need it to be RestResources?
                #  Facade endpoints are not defined for '/interface-policies/policy',
                #  thus inheritance from Api fits better
                @api('/policy')
                class policy(RestResources):

                    @api('/{interface_policy_id}')
                    class resource(RestResource):
                        def get(
                            self,
                            mode: t.Literal['lite', 'verbose'] = 'lite',
                            **kwargs: te.Unpack[RestResource.TReadKwargs],
                        ) -> _MAGIC.facade_method_schema[
                            'aos.reference_design.two_stage_l3clos.facade.Facade',
                            'get_interface_policy',
                            'result']:
                            """ Get interface policy.

                            Obtains information about a given interface policy by ID.

                            :param mode: whether 'lite' or 'verbose' response is
                                requested
                            """
                            self._url += '?mode=%s' % mode
                            return self._request(method='GET', **kwargs)

                        def update(
                            self,
                            data: _MAGIC.facade_method_schema[
                                'aos.reference_design.two_stage_l3clos.facade.Facade',
                                'update_interface_policy',
                                'arg'],
                            **kwargs: te.Unpack[RestResources.TWriteKwargs],
                        ) -> tt.JSON:
                            """ Update interface policy.

                            Updates an existing interface policy.

                            :param data: new parameters of the interface policy
                            """
                            return self._request(method='PATCH', data=data, **kwargs)

                        def delete(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> tt.JSON:
                            """ Delete interface policy.

                            Removal of interface policy also leads to removal of any
                            interface assignments of this policy.
                            """
                            return self._request(method='DELETE', **kwargs)

                        @api('/system')
                        class system(Api):
                            @api('/{node_id}')
                            class resource(Api):
                                def get(
                                    self,
                                    **kwargs: te.Unpack[RestResources.TReadKwargs],
                                ) -> _MAGIC.facade_method_schema[
                                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                                    'get_capable_interfaces_for_system_with_policy_id',
                                    'result']:
                                    """ Get interfaces capable of specific interface
                                    policy assignment.
                                    """
                                    return self._request(method='GET', **kwargs)

            @api('/aaa-servers')
            class aaa_servers(
                RestResources,
                create__data=_fm_schema('create_aaa_server', 'arg'),
                __create='''
                    Create AAA server.

                    :param data: configuration of the new AAA server
                ''',
            ):
                def list(  # type: ignore[override]
                    self,
                    **kwargs: te.Unpack[RestResources.TReadKwargs],
                ) -> dict[
                        tt.GraphNodeId,
                        _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.aaa_servers.AAA_SERVER_GET_SCHEMA']]:
                    """ List AAA servers.

                    List all AAA servers associated to the blueprint.
                    """
                    return t.cast(
                        dict,
                        self._request(method='GET', **kwargs)
                    )['items']

                @api('/{aaa_server_id}')
                class resource(
                    RestResource,
                    get__=_fm_schema('get_aaa_server', 'result'),
                    __get='''
                        Get AAA server.

                        Get details about AAA server by ID.
                    ''',
                    __delete='''
                        Delete AAA server.

                        Delete AAA server by ID.
                    '''
                ):
                    def update(
                        self,
                        data: _MAGIC.facade_method_schema[
                            'aos.reference_design.two_stage_l3clos.facade.Facade',
                            'update_aaa_server',
                            'arg'],
                        **kwargs: te.Unpack[RestResource.TWriteKwargs],
                    ) -> tt.JSON:
                        """ Update AAA server.

                        Update settings of the AAA server using the AAA server ID.

                        :param data: new settings of the AAA server
                        """
                        return self._request(method='PATCH', data=data, **kwargs)

            @api('/evpn_interconnect_groups')
            class evpn_interconnect_groups(RestResources):
                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> list[_MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.remote_gateway.EVPN_INTERCONNECT_GET_SCHEMA']]:
                    """ List all EVPN interconnect groups.

                    List all EVPN interconnect groups within a blueprint, keyed by
                    EVPN interconnect group node ID.  Each item of the list is the
                    full GET response for each interconnect group.
                    """
                    return t.cast(
                        dict,
                        self._request(method='GET', **kwargs)
                    )['evpn_interconnect_groups']

                def create(self,  # type: ignore[override]
                           label: str,
                           interconnect_route_target: str,
                           remote_gateway_node_ids: t.Optional[collections.abc.Sequence[tt.GraphNodeId]] = None,
                           interconnect_virtual_networks: t.Optional[
                               _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.remote_gateway.EVPN_INTERCONNECT_VIRTUAL_NETWORKS_SCHEMA']] = None,
                           interconnect_security_zones: t.Optional[
                               _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.remote_gateway.EVPN_INTERCONNECT_SECURITY_ZONES_SCHEMA']] = None,
                           interconnect_esi_mac: t.Optional[str] = None,
                           **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> _MAGIC.lollipop_type['aos.scotch.schemas.schema.IdSchema']:
                    """ Create EVPN interconnect group.

                    An EVPN interconnect group is a collection of remote gateway
                    nodes, with according local gateway systems attached to them.
                    The EVPN interconnect group is an implementation of VXLAN
                    Stitching for EVPN as part of RFC9104.

                    :param label: label of the new interconnect group
                    :param interconnect_route_target: Defines the EVPN interconnect
                        route-target.
                    :param remote_gateway_node_ids: Ids of remote gateway nodes
                    :param interconnect_virtual_networks: mapping from virtual
                        network id to parameters of translation vni
                    :param interconnect_security_zones: mapping from security zone
                        ID to interconnect security zone data
                    :param interconnect_esi_mac: User-defined interconnect ESI MAC
                    """
                    data = gen_evpn_interconnect_group(
                        label=label,
                        interconnect_route_target=interconnect_route_target,
                        remote_gateway_node_ids=remote_gateway_node_ids,
                        interconnect_virtual_networks=interconnect_virtual_networks,
                        interconnect_security_zones=interconnect_security_zones,
                        interconnect_esi_mac=interconnect_esi_mac
                    )
                    return self._request(method='POST', data=data, **kwargs)

                @api('/{evpn_interconnect_group_id}')
                class resource(
                    RestResource,
                    get__=_fm_schema('get_evpn_interconnect_group', 'result'),
                    __get='''
                        Get EVPN interconnect group.

                        Get information about a given EVPN interconnect group and
                        all associated interconnect security zones, virtual
                        networks, and interconnect properties.
                    ''',
                    __delete='''
                        Delete EVPN interconnect group.

                        Removes an EVPN interconnect group and all according graph
                        structure.
                    ''',
                ):

                    # pylint: disable=arguments-renamed
                    def update(self,
                           label: str | lollipop.types.MissingType = s.MISSING,
                           interconnect_route_target: str | lollipop.types.MissingType = s.MISSING,
                           remote_gateway_node_ids: collections.abc.Sequence[tt.GraphNodeId] | lollipop.types.MissingType = s.MISSING,
                           interconnect_virtual_networks: lollipop.types.MissingType |
                               _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.remote_gateway.EVPN_INTERCONNECT_VIRTUAL_NETWORKS_SCHEMA'] = s.MISSING,
                           interconnect_security_zones: lollipop.types.MissingType |
                               _MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.remote_gateway.EVPN_INTERCONNECT_SECURITY_ZONES_SCHEMA'] = s.MISSING,
                           interconnect_esi_mac: str | lollipop.types.MissingType = None,
                           **kwargs: te.Unpack[RestResource.TWriteKwargs],
                    ) -> tt.JSON:
                        """ Update EVPN interconnect group.

                        If a virtual_network node ID is not present in the PATCH
                        response, then all EVPN interconnect relationships will be
                        removed from the according VN.

                        :param label: new label of the interconnect group
                        :param interconnect_route_target: Defines the EVPN
                        interconnect route-target.
                        :param remote_gateway_node_ids: Ids of remote gateway nodes
                        :param interconnect_virtual_networks: mapping from virtual
                            network id to parameters of translation vni
                        :param interconnect_security_zones: mapping from security
                            zone ID to interconnect security zone data
                        :param interconnect_esi_mac: User-defined interconnect ESI
                            MAC
                        """
                        data = gen_evpn_interconnect_group(
                            label=label,
                            interconnect_route_target=interconnect_route_target,
                            remote_gateway_node_ids=remote_gateway_node_ids,
                            interconnect_virtual_networks=\
                                interconnect_virtual_networks,
                            interconnect_security_zones=interconnect_security_zones,
                            interconnect_esi_mac=interconnect_esi_mac,
                        )
                        data = {k: v for k, v in data.items() if v != s.MISSING}
                        return self._request(method='PATCH', data=data, **kwargs)

            @api('/remote_gateways')
            class remote_gateways(
                RestResources,
                create__data=_fm_schema('create_remote_gateway', 'arg'),
                __create='''
                    Create remote gateway.

                    Remote EVPN Gateway is a logical function that you could
                    instantiate anywhere and on any device.

                    :param data: configuration of the new remote gateway
                '''
            ):
                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> list[_MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.remote_gateway.REMOTE_GW_GET_SCHEMA']]:
                    """ List all remote gateways.

                    List all remote gateways within a blueprint, keyed by
                    remote gateway node ID.
                    """
                    return t.cast(
                        dict,
                        self._request(method='GET', **kwargs)
                    )['remote_gateways']

                @api('/{remote_gateway_id}')
                class resource(Api):
                    def get(
                        self,
                        **kwargs: te.Unpack[RestResources.TReadKwargs],
                    ) -> _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'get_remote_gateway',
                        'result']:
                        """ Get remote gateway.

                        Get full information about a remote gateway.
                        """
                        return self._request(method='GET', **kwargs)

                    def put(
                        self,
                        data: _MAGIC.facade_method_schema[
                            'aos.reference_design.two_stage_l3clos.facade.Facade',
                            'update_remote_gateway',
                            'arg'],
                        **kwargs: te.Unpack[RestResources.TWriteKwargs],
                    ) -> tt.JSON:
                        """ Update remote gateway.

                        Update a remote gateway.

                        :param data: new parameters of the remote gateway
                        """
                        return self._request(method='PUT', data=data, **kwargs)

                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResources.TReadKwargs],
                    ) -> tt.JSON:
                        """ Delete remote gateway.

                        Delete a remote gateway by given id from the specified
                        blueprint.
                        """
                        return self._request(method='DELETE', **kwargs)

            @api('/systems')
            class systems(Api):
                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> list[_MAGIC.lollipop_type['aos.scotch.blueprints.device_manager.DEVICE_GET_SCHEMA']]:
                    """ Get all systems.

                    A list of all devices in AOS is returned.
                    """
                    return t.cast(
                        dict,
                        self._request(method='GET', **kwargs)
                    )['items']

                @api('/{system_id}')
                class resource(Api):
                    @api('/loopback')
                    class loopback(Api):
                        @api('/{loopback_id}')
                        class resource(Api):
                            def get(
                                self,
                                **kwargs: te.Unpack[RestResources.TReadKwargs],
                            ) -> _MAGIC.facade_method_schema[
                                'aos.reference_design.two_stage_l3clos.facade.Facade',
                                'get_generic_system_loopback',
                                'result']:
                                """ Get loopback of a generic system.

                                Returns information on a generic system's loopback.
                                """
                                return self._request(method='GET', **kwargs)

                            def patch(
                                self,
                                data: _MAGIC.facade_method_schema[
                                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                                    'patch_generic_system_loopback',
                                    'arg'],
                                **kwargs: te.Unpack[RestResources.TWriteKwargs],
                            ) -> tt.JSON:
                                """ Update loopback of a generic system.

                                Updates IPv4/IPv6 addresses of a generic system's
                                loopback. If a generic system wasn't assigned
                                loopback addresses initially, this method would
                                create a `loopback` node.

                                Alternatively, clearing both IPv4 and IPv6 addresses
                                will result in removal of a `loopback` node, given
                                that there are no other resources (like protocol
                                sessions or static routes, for example) that refer
                                to that loopback.

                                :param data: new configuration of the loopback
                                """
                                return self._request(method='PATCH', data=data,
                                                     **kwargs)

                    @api('/domain')
                    class domain(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                        ) -> _MAGIC.facade_method_schema[
                            'aos.reference_design.two_stage_l3clos.facade.Facade',
                            'get_domain',
                            'result']:
                            """ Get domain of a generic system.

                            Returns information on a domain associated with a
                            generic system.
                            """
                            return self._request(method='GET', **kwargs)

                        def patch(
                            self,
                            data: _MAGIC.facade_method_schema[
                                'aos.reference_design.two_stage_l3clos.facade.Facade',
                                'patch_domain',
                                'arg'],
                            **kwargs: te.Unpack[RestResources.TWriteKwargs],
                        ) -> tt.JSON:
                            """ Update domain of a generic system.

                            Updates domain_id (i.e. BGP ASN) of a generic system. If
                            a generic system didn't have an ASN initially, this
                            method would create a `domain` node.

                            Alternatively, unsetting will result in removal of a
                            `domain` node, given that there are no other resources
                            (like protocol sessions, for example) that refer to that
                            domain.

                            :param data: new configuration of the domain
                            """
                            return self._request(method='PATCH', data=data, **kwargs)

            @api('/protocol-sessions')
            class protocol_sessions(
                RestResources,
                create__data=_fm_schema('create_protocol_session', 'arg'),
                __create='''
                    Create protocol session.

                    Create a protocol session. Protocol session is an abstraction
                    over dynamic routing protocol (BGP) established between fabric
                    switch and generic system.

                    :param data: configuration of the new protocol session
                '''
            ):
                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> list[_MAGIC.lollipop_type['aos.reference_design.two_stage_l3clos.protocol_session.PROTOCOL_SESSION_GET_SCHEMA']]:
                    """ Get list of protocol sessions.

                    Return a list of all protocol sessions from the specified blueprint.
                    """
                    return t.cast(dict, self._request(
                        method='GET', **kwargs
                    ))['protocol-sessions']

                @api('/{resource_id}')
                class resource(
                    RestResource,
                    get__=_fm_schema('get_protocol_session', 'result'),
                    update__data=_fm_schema('update_protocol_session', 'arg'),
                    __get='''
                        Get protocol session.

                        Return a protocol session by a given id from the specified
                        blueprint.
                    ''',
                    __update='''
                        Update protocol session.

                        Update a protocol session in the specified blueprint.

                        :param data: new configuration of the protocol session
                    ''',
                    __delete='''
                        Delete protocol session.

                        Delete a protocol session by a given id from the specified
                        blueprint.
                    '''
                ):
                    pass

            @api('/static-routes')
            class static_routes(
                RestResources,
                create__data=_fm_schema('create_static_route', 'arg'),
                __create='''
                    Create static route.

                    Creates a static route in the specified blueprint.

                    :param data: configuration of the new static route
                ''',
            ):
                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'list_static_routes',
                    'result']:
                    """ Get static routes.

                    Lists all static routes associated with the blueprint.
                    """
                    return self._request(method='GET', **kwargs)

                @api('/{static_route_id}')
                class resource(
                    RestResource,
                    get__=_fm_schema('get_static_route', 'result'),
                    __get='''
                        Get static route.
                    ''',
                    __delete='''
                        Delete static route.

                        Deletes a static route by id.
                    '''
                ):
                    def update(
                        self,
                        data: _MAGIC.facade_method_schema[
                            'aos.reference_design.two_stage_l3clos.facade.Facade',
                            'update_static_route',
                            'arg'],
                        **kwargs: te.Unpack[RestResources.TWriteKwargs],
                    ) -> tt.JSON:
                        """ Update static route.

                        Updates a static route by ID.

                        :param data: new configuration of the static route
                        """
                        return self._request(method='PATCH', data=data, **kwargs)

            @api('/routing-policies')
            class routing_policies(
                RestResources,
                create__data=_fm_schema('create_routing_policy', 'arg'),
                __create='''
                    Create routing policy.

                    Creates a new routing policy and adds it to the graph.

                    :param data: configuration of the new routing policy
                ''',
            ):
                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'list_routing_policies',
                    'result']:
                    """ Get routing policies.

                    Obtains list of routing policies.
                    """
                    return self._request(method='GET', **kwargs)

                @api('/{routing_policy_id}')
                class resource(
                    RestResource,
                    get__=_fm_schema('get_routing_policy', 'result'),
                    __get='''
                        Get routing policy info.

                        Obtains detailed information about a given routing policy by
                        ID.
                    ''',
                    __delete='''
                        Delete routing policy.
                    '''
                ):
                    def update(
                        self,
                        data: _MAGIC.facade_method_schema[
                            'aos.reference_design.two_stage_l3clos.facade.Facade',
                            'update_routing_policy',
                            'arg'],
                        **kwargs: te.Unpack[RestResources.TWriteKwargs],
                    ) -> tt.JSON:
                        """ Update routing policy.

                        Updates an existing routing policy.

                        :param data: new configuration of the routing policy
                        """
                        return self._request(method='PATCH', data=data, **kwargs)

            @api('/routing-zone-constraints')
            class routing_zone_constraints(
                RestResources,
                create__data=_fm_schema('create_routing_zone_constraint', 'arg'),
                __create='''
                    Create a routing zone constraint.

                    Routing zone constraint gives an ability to manage Port-Routing
                    Zone participation.

                    :param data: configuration of the new routing zone constraint
                '''
            ):
                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'list_routing_zone_constraints',
                    'result']:
                    """ Obtain list of routing zones constraints.
                    """
                    return self._request(method='GET', **kwargs)

                @api('/{routing_zone_constraint_id}')
                class resource(
                    RestResource,
                    get__=_fm_schema('get_routing_zone_constraint', 'result'),
                    __get='''
                        Obtain information about a given routing zone constraint by
                        ID.
                    ''',
                    __delete='''
                        Delete a routing zone constraint.
                    '''
                ):
                    def update(
                        self,
                        data: _MAGIC.facade_method_schema[
                            'aos.reference_design.two_stage_l3clos.facade.Facade',
                            'update_routing_zone_constraint',
                            'arg'],
                        **kwargs: te.Unpack[RestResources.TWriteKwargs],
                    ) -> tt.JSON:
                        """ Update an existing routing zone constraint.

                        :param data: new configuration of the routing zone constraint
                        """
                        return self._request(method='PATCH', data=data, **kwargs)

            @api('/virtual_infra')
            class virtual_infra(Api):
                @api('/predefined_probes')
                class predefined_probes(Api):
                    @api('/virtual_infra_vlan_match')
                    class virtual_infra_vlan_match(Api):
                        @api('/anomaly_resolver')
                        class anomaly_resolver(Api):
                            def post(
                                self,
                                data: _MAGIC.lollipop_type['aos.scotch.libs.probe_schemas.PREDEFINED_PROBE_PARAMETERS'],
                                **kwargs: te.Unpack[RestResource.TWriteKwargs],
                            ) -> _MAGIC.lollipop_type['aos.scotch.schemas.schema.IdSchema']:
                                """ Update blueprint virtual network config to
                                resolve anomalies.

                                :param data: probe id and stage name
                                """
                                return self._request(method='POST', data=data,
                                                     **kwargs)

            @api('/interface-operation-state')
            class interface_operation_state(Api):
                def patch(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'patch_interface_operation_state',
                        'arg'],
                    **kwargs: te.Unpack[RestResources.TWriteKwargs],
                ) -> tt.JSON:
                    """ Change `operation_state` of interfaces.

                    Updates interfaces' operation state in the blueprint.

                    :param data: new operation state of the interfaces
                    """
                    return self._request(method='PATCH', data=data, **kwargs)

            def batch(
                self,
                operations: _MAGIC.lollipop_type['aos.scotch.libs.batch_facade_mutation.REQUEST_SCHEMA_FIELDS_OPERATIONS'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs]
            ) -> _MAGIC.lollipop_type['aos.scotch.libs.batch_facade_mutation.RESPONSE_SCHEMA']:
                """Batch operations

                Batch operations for AOS REST APIs. Execute multiple requests which
                are submitted as a batch.

                :param operations: payload with operations to be executed
                """
                return self._request(url='/batch', method='POST', data={
                    'operations': operations
                }, **kwargs)

            @api('/validation-policy')
            class validation_policy(Api):
                def get(
                        self,
                        **kwargs: te.Unpack[RestResources.TReadKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'get_validation_policy',
                    'result']:
                    """Get validation policy.

                    The `validation_policy` node of the graph specifies various policies
                    related to the validation of the graph, including what
                    errors/warnings should be raised in case of misconfigurations.
                    """
                    return self._request(
                        method='GET',
                        **kwargs
                    )

                def update(
                        self,
                        data: _MAGIC.facade_method_schema[
                            'aos.reference_design.two_stage_l3clos.facade.Facade',
                            'update_validation_policy',
                            'arg'],
                        **kwargs: te.Unpack[RestResources.TWriteKwargs],
                ) -> tt.JSON:
                    """Update validation policy.

                    The `validation_policy` node of the graph specifies various
                    policies related to the validation of the graph, including what
                    errors/warnings should be raised in case of misconfigurations.

                    :param data: new configuration of the validation policy
                    """
                    return self._request(
                        method='PUT',
                        data=data,
                        **kwargs
                    )

                def patch(
                        self,
                        data: _MAGIC.facade_method_schema[
                            'aos.reference_design.two_stage_l3clos.facade.Facade',
                            'patch_validation_policy',
                            'arg'],
                        **kwargs: te.Unpack[RestResources.TWriteKwargs],
                ) -> tt.JSON:
                    """Patch validation policy.

                    The `validation_policy` node of the graph specifies various
                    policies related to the validation of the graph, including what
                    errors/warnings should be raised in case of misconfigurations.

                    :param data: new configuration of the validation policy
                    """
                    return self._request(
                        method='PATCH',
                        data=data,
                        **kwargs
                    )

            @api('/system-properties')
            class system_properties(Api):
                @api('/{node_id}')
                class resource(RestResource):
                    # pylint: disable=arguments-renamed
                    def patch(
                        self,
                        data: _MAGIC.facade_method_schema[
                            'aos.reference_design.two_stage_l3clos.facade.Facade',
                            'update_system_properties',
                            'arg'],
                        **kwargs: te.Unpack[RestResources.TWriteKwargs],
                    ) -> tt.JSON:
                        """Update system properties.

                        The API endpoint allows modifying nodes of type "system" by
                        overwriting its properties.

                        :param data: new configuration of the system
                        """
                        return self._request(method='PATCH', data=data, **kwargs)

            @api('/load-balancing-policies')
            class load_balancing_policies(
                RestResources,
            ):
                def create(
                        self,
                        label: str,
                        mode: tt.LBPolicyMode,
                        dlb_options: g.GenLoadBalancingDLBPolicySpec | None = None,
                        policy_type: tt.LBPolicyPolicyType = 'user_defined',
                        **kwargs: te.Unpack[RestResources.TWriteKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'create_load_balancing_policy',
                    'result']:
                    data = gen_load_balancing_policy(
                        label=label,
                        mode=mode,
                        dlb_options=dlb_options,
                        policy_type=policy_type,
                    )
                    return self._request(
                        method='POST',
                        data=data,
                        **kwargs)

                def update_assignments(
                        self,
                        policy_assignments: g.GenLoadBalancingPolicyAssignmentSpec,
                        **kwargs
                ):
                    return self.request(
                        url='/assignments',
                        data={'policy_assignments': policy_assignments},
                        method='PUT',
                        **kwargs
                    )

                def get_assignments(
                        self,
                        **kwargs
                ) -> g.GenLoadBalancingPolicyAssignmentSpec:
                    return self.request(
                        url='/assignments',
                        method='GET',
                        **kwargs
                    )

                def list(
                        self,
                        **kwargs: te.Unpack[RestResources.TReadKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.two_stage_l3clos.facade.Facade',
                    'list_load_balancing_policies',
                    'result']:
                    return self._request(method='GET', **kwargs)

                @api('/{load_balancing_policy_id')
                class resource(RestResource):
                    def get(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                    ) -> _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'get_load_balancing_policy',
                        'result']:
                        return self._request(method='GET', **kwargs)

                    def delete(
                            self,
                            **kwargs: te.Unpack[RestResources.TReadKwargs],
                    ) -> tt.JSON:
                        return self._request(method='DELETE', **kwargs)

                    def update(
                            self,
                            label: str,
                            mode: tt.LBPolicyMode,
                            dlb_options: g.GenLoadBalancingDLBPolicySpec | None = None,
                            policy_type: tt.LBPolicyPolicyType = 'user_defined',
                            **kwargs: te.Unpack[RestResources.TWriteKwargs],
                    ) -> dict[t.Literal['id'], tt.GraphNodeId]:
                        data = gen_load_balancing_policy(
                            label=label,
                            mode=mode,
                            dlb_options=dlb_options,
                            policy_type=policy_type,
                        )
                        return self._request(
                            method='PUT',
                            data=data,
                            **kwargs)

            @api('/rail-vlan-state')
            class rail_vlan_state(Api):
                def get(
                        self,
                        **kwargs: te.Unpack[RestResources.TReadKwargs]
                ) -> _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'get_rail_vlan_state',
                        'result']:
                    return self._request(
                        method='GET',
                        **kwargs
                    )

            @api('/rail-vlan-provision')
            class rail_vlan_provision(Api):
                def post(
                        self,
                        data: _MAGIC.facade_method_schema[
                            'aos.reference_design.two_stage_l3clos.facade.Facade',
                            'provision_rail_vlan',
                            'arg'],
                        **kwargs: te.Unpack[RestResources.TWriteKwargs]
                ) -> _MAGIC.facade_method_schema[
                        'aos.reference_design.two_stage_l3clos.facade.Facade',
                        'provision_rail_vlan',
                        'result']:
                    return self._request(
                        method='POST',
                        data=data,
                        **kwargs
                    )
