# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""Utility methods to generate contents in two_stage_l3clos blueprints"""

# pylint: disable=redefined-builtin
import copy
import hashlib
import json

from textwrap import wrap

import six

from aos.sdk.generator import compact_dict, gen_id
from aos.sdk.types import DEFAULT_ESI_MAC_MSB, MAX_VN_LABEL_SIZE

MISSING = object()

def create_bound_to_payload(
        system_id,
        vlan_id=None,
        access_switch_node_ids=None,
        compact=True,
    ):
    payload = {
        'system_id': system_id,
        'vlan_id': vlan_id,
        'access_switch_node_ids': access_switch_node_ids or [],
    }
    if compact:
        return compact_dict(payload)
    return payload


def gen_vnet_endpoint(hosted_on, label=MISSING, tag_type='vlan_tagged', **kwargs):
    if label is MISSING:
        label = gen_id()

    return compact_dict(dict({
        'label': label,
        'interface_id': hosted_on,
        'tag_type': tag_type,
    }, **kwargs))


def gen_svi_payload(
        system_id,
        ipv4_addr=None,
        ipv6_addr=None,
        ipv4_mode=None,
        ipv6_mode=None
    ):
    return compact_dict({
        'system_id': system_id,
        'ipv4_addr': ipv4_addr,
        'ipv6_addr': ipv6_addr,
        'ipv4_mode': ipv4_mode,
        'ipv6_mode': ipv6_mode
    })


def gen_vnet(
        bound_to=(), endpoints=None, vn_type='vlan', label=None, description=None,
        vn_id=None, ipv4_subnet=None, svi_ips=None, virtual_gateway_ipv4=None,
        ipv6_subnet=None, virtual_gateway_ipv6=None, ipv4_enabled=None,
        ipv6_enabled=None, virtual_gateway_ipv4_enabled=None,
        virtual_gateway_ipv6_enabled=None, dhcp_service=None,
        default_endpoint_tag_types=None, security_zone_id=None,
        reserved_vlan_id=None,
        rt_policy=None,
        l3_mtu=None):
    if not default_endpoint_tag_types:
        default_endpoint_tag_types = {}
    if isinstance(svi_ips, dict):
        svi_ips = [gen_svi_payload(node_id, ip)
                   for node_id, ip in six.iteritems(svi_ips)]
    if isinstance(bound_to, tuple):
        bound_to = list(bound_to)
    if bound_to and not isinstance(bound_to, list):
        bound_to = [bound_to]
    return compact_dict({
        'label': label or gen_id()[:MAX_VN_LABEL_SIZE],
        'vn_type': vn_type,
        'bound_to': copy.deepcopy(bound_to),
        'endpoints': copy.deepcopy(endpoints or []),
        'description': description,
        'vn_id': str(vn_id) if vn_id else None,
        'reserved_vlan_id': reserved_vlan_id,
        'ipv4_subnet': ipv4_subnet,
        'ipv6_subnet': ipv6_subnet,
        'svi_ips': copy.deepcopy(svi_ips or []),
        'virtual_gateway_ipv4': virtual_gateway_ipv4,
        'virtual_gateway_ipv6': virtual_gateway_ipv6,
        'virtual_gateway_ipv4_enabled': virtual_gateway_ipv4_enabled,
        'virtual_gateway_ipv6_enabled': virtual_gateway_ipv6_enabled,
        'ipv4_enabled': ipv4_enabled,
        'ipv6_enabled': ipv6_enabled,
        'dhcp_service': dhcp_service,
        'default_endpoint_tag_types': default_endpoint_tag_types,
        'security_zone_id': security_zone_id,
        'rt_policy': copy.deepcopy(rt_policy),
        'l3_mtu': l3_mtu,
    })

def gen_link_role(node1, node2):
    # leaf_leaf role cannot be returned by this method due to conflict with
    # leaf_peer_link. It should be set explicitly
    if node1.role == 'leaf' and node1.role == node2.role:
        return 'leaf_peer_link'
    if node1.role == 'access' and node1.role == node2.role:
        return 'access_l3_peer_link'

    node_roles = [node1.role, node2.role]

    if 'generic' in node_roles:
        return 'to_generic'
    # Link roles follow an order. Ex: leaf_spine is invalid, spine_leaf is valid
    types = ['spine', 'leaf', 'access', 'superspine']
    return '%s_%s' % tuple(sorted(
        (node1.role, node2.role),
        key=lambda t: types.index(t) if t in types else -1
    ))


def mb_to_port_speed_string(size_in_mb):
    return {
        10: '10M',
        100: '100M',
        1000: '1G',
        2500: '2500M',
        5000: '5G',
        10000: '10G',
        25000: '25G',
        40000: '40G',
        50000: '50G',
        100000: '100G',
        150000: '150G',
        200000: '200G',
        400000: '400G',
        800000: '800G',
    }[size_in_mb]


def port_speed_string_to_mb(speed_str):
    return {
        '10M': 10,
        '100M': 100,
        '1G': 1000,
        '2500M': 2500,
        '5G': 5000,
        '10G': 10000,
        '25G': 25000,
        '40G': 40000,
        '50G': 50000,
        '100G': 100000,
        '150G': 150000,
        '200G': 200000,
        '400G': 400000,
        '800G': 800000,
    }[speed_str.upper()]

def gen_vn_route_target(vn_type, vn_id=None):
    """ Generate route-target field for a given virtual network
    :param (int) vn_id: VNI ID for the virtual network
    :return (str, None): Route-target ID used for import/export policies and config
        rendering
    """
    if vn_type == 'vxlan' and vn_id:
        return '%s:1' % vn_id
    return None


def gen_sz_route_target(sz_type, vni_id=None):
    """ Generate route-target field for routing zone.
    :param sz_type: Routing zone Type for routing zone rendering. Currently only
        sz_type of 'evpn' has modelled intent for route-target.
    :param (int) vni_id : VNI ID associated with the routing zone.
    :return (str, None): Route-target ID used for import/export policies and config
        rendering
    """
    if sz_type == 'evpn' and vni_id:
        return '%s:1' % vni_id
    return None


def gen_svi_interface_name(vlan_id, os_family):
    if os_family.lower() == 'junos':
        if_name = 'irb.%s' % vlan_id
    elif os_family.lower() == 'cumulus':
        if_name = 'bridge.%s' % vlan_id
    else:
        if_name = 'Vlan%s' % vlan_id
    return if_name


def generate_mac_address(base_mac_addr_str, offset, mac_msb=None):
    '''Generate the MAC address string given a base MAC address string, offset and
       mac_msb. [44:38:39]:[ff]:[00:00]
                    ^       ^       ^
                    |       |       |
         base mac (24)      |       |
                   mac_msb (8)      |
                          offset  (16)

        :param (str) base_mac_addr_str: MAC Address prefix, eg '44:38:99:ff:00:00'
        :param (int) offset:  Offset the last part of the MAC addr, semantically
            this comes from redundancy_group.group_id
        :param (int) mac_msb:  The MAC MSB is from fabric_policy.esi_msb
            This is used for Cumulus to disambiguate EVPN RMAC IDs between multiple
            blueprints when using EVPN-DCI.  When passed as None, MAC address will
            remain unchanged as long as DEFAULT_ESI_MAC_MSB remains consistent.
    '''
    if mac_msb is None:
        mac_msb = DEFAULT_ESI_MAC_MSB

    msb_bitmask = (2**24)-(2**16)
    mac_int = int(base_mac_addr_str.replace(':', ''), 16)
    # Extract 44:38:39:[ff]:00:00
    msb_component = (mac_int & msb_bitmask) >> 16
    # Add mac_msb offset, while subtracting the default ESI MAC MSB - this is to
    # avoid changes in existing reference design topology, so they continue to use
    # hard-coded MAC address base strings from jinjas
    # Ensure we only grab 2 bytes (0xff) so integer rollover does not increase
    # the base mac address when adding
    add_msb_component = ((msb_component - mac_msb + DEFAULT_ESI_MAC_MSB) & 0xff)
    # Subtract the existing msb component
    mac_int -= msb_component << 16
    # Add the new calculated msb component
    mac_int += add_msb_component << 16
    # MLAG redundancy_group.group_id
    mac_int += int(offset)
    new_mac = ':'.join(wrap('%012x' % mac_int, width=2))
    return new_mac


def make_rack_type_without_tags(rack_type, deepcopy=True):
    """Makes a copy of rack_type_json without tags.

    Tags in rack types are specified per groups of resources. However, tags in
    blueprints are specified per individual instances of such groups resources.
    More importantly, users are able to continue manage tags per individual
    instances which means that such changes can't be propagated back to rack types
    without splitting resources on smaller groups. As this back propagation is not
    possible generally, copies of rack types stored in the rack nodes are set
    to empty lists and will not be further updated when users modify tag assignments
    and change racks.
    """
    rack_type_json = copy.deepcopy(rack_type) if deepcopy else rack_type
    rack_type_json['tags'] = []
    for system_type in ('leafs', 'access_switches', 'generic_systems'):
        for system in rack_type_json.get(system_type, ()):
            system['tags'] = []
            for link in system.get('links', ()):
                link['tags'] = []
    return rack_type_json


def make_pod_type_without_tags(pod_type, deepcopy=True):
    """Makes a copy of pod_type_json without tags.

    The same as with rack types, pod templates allow to manage tags only for spines
    as a group of resources and not individually per each spine. However, tags in
    blueprints are managed individually per each spines. Having this inability
    to propagate changed in tag assigned in spine system nodes to their
    corresponding group in a pod template, this function sets tags for spines
    in the pod template to an empty list as tags for all embedded rack types.
    """
    pod_type_json = copy.deepcopy(pod_type) if deepcopy else pod_type
    pod_type_json['rack_types'] = [make_rack_type_without_tags(rack_type, False)
                                   for rack_type in pod_type_json['rack_types']]
    if 'spine' in pod_type_json:
        pod_type_json['spine']['tags'] = []
    return pod_type_json


def get_hash(obj):
    """Return a hash value calculated from a serialized object sorted by keys to a
    JSON formatted string."""
    # It is important to encode a dumped string to UTF-8, otherwise
    # the error 'TypeError: Unicode-objects must be encoded before hashing' is thrown
    # for python3
    return hashlib.sha1(json.dumps(obj, sort_keys=True).encode('utf-8')).hexdigest()


def calc_rack_type_id(rack_type):
    """Calculate a rack type ID, where ID is a hash value of a rack type. Tags and ID
    fields do not participate in calculation, so they are dropped."""
    rack_type = make_rack_type_without_tags(rack_type)
    rack_type.pop('id', None)
    rack_type.pop('last_modified_at', None)
    return get_hash(rack_type)
