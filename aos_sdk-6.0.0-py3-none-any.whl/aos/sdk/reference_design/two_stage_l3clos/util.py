# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=too-many-return-statements

def get_port_mtu(interface_role, external_router_mtu=None, model='',
                 os_family='', remote_model='', remote_os_family=''):
    """ Returns the effective interface MTU used by configuration rendering.

    :param str: interface_role:
    :param (optional int): external_router_mtu:
        external_router_mtu is configured from virtual_network_policy,
        and indicates the L3 MTU rendered facing external generic subinterfaces.
        If None, implies no virtual network policy is used so do not render an
        MTU command on the device.
    :param str: model:
        Device hardware model, as extracted from the device profile. Note, the
        format is manufacturer + '_' + model, e.g. 'Juniper_QFX5130-32CD', etc.
    :param str: os_family:
        OS Family, as extracted from the device profile. Will be compared with
        the remote_os_family for some use cases and workarounds.
    :param (:obj:`str`, optional) remote_model:
        Device hardware model of remote endpoint, as extracted from the device
        profile. Note, the format is manufacturer + '_' + model, e.g.
        'Juniper_QFX5130-32CD', etc.
    :param str: remote_os_family:
       OS Family of the device on the other side of this intf->link->intf.  This
       is used to compare multivendor MTU semantics.
    :return int:
        The effective interface as used in configuration rendering.  A value of 0
        implies that the MTU command should not be rendered at all, instructing
        the device to use OS defaults.  MTU should not be rendered on all types
        of interfaces.
    """
    # MTU is by default 1500 bytes for l3 ports, but we want to make it
    # 9000 for carrying jumbo frames. For fabric links which can carry
    # encapsulated vxlan traffic, incrementing it by 50 bytes to account
    # for vxlan header.
    # fabric links: 9050
    # l3edge : no mtu change needed, keep the default
    # l2edge : no mtu change needed, default is 9216. Peer link role is l2edge too.
    # unused : revert to default mtu.
    os_family = os_family.lower() if os_family else ''
    remote_os_family = remote_os_family.lower() if remote_os_family else ''
    # Note, the model string setting can be found in
    # reference_design/two_stage_l3clos/deploy/device_model.py where it says:
    # "This is node's hcl manufacturer + '_' + model"
    model = model.lower() if model else ''
    remote_model = remote_model.lower() if remote_model else ''

    # Arista vEOS does not support rendering the 'mtu' command, the CLI rejects
    # this config.
    if 'veos' in model and os_family == 'eos':
        return 0
    if os_family == 'junos':
        # If Junos & a Non-JunOS are bgp peering with each other, do not
        # render 9216 bytes: Fall back to 9050 bytes instead in order to add
        # multi-vendor L3 MTU interop.  This is important for large BGP updates,
        # otherwise BGP sessions will expire with holdtime errors as the
        # ACK was not received due to being dropped on the wire.
        # Junos + Junos renders 9216.
        # Junos + Anything else renders 9050.
        if remote_os_family == 'junos' and \
                interface_role in ['spine_leaf', 'spine_superspine', 'l3peer']:
            # WARNING: values returned in this section actually rendered as L2 MTU
            # as opposed to other values in this function that drive max size
            # of IP packet i.e. L3 MTU

            # The virtual EX9214 can't go beyond 9192, so if there's any
            # junos - junos connection where at least one of the endpoints is
            # a virtual EX9214, we'll just lower the MTU.
            if 'virtual-ex9214' in model or 'virtual-ex9214' in remote_model or \
               'vjunos-switch' in model or 'vjunos-switch' in remote_model:
                return 9192
            return 9216
        elif interface_role in ['leaf_access', 'l2edge', 'l2peer']:
            return 9100
    if interface_role in ['spine_leaf', 'spine_superspine']:
        return 9050
    elif interface_role in ['leaf_access']:
        return 9000
    elif interface_role in ['l2edge']:
        return 9000
    elif interface_role in ['l2peer']:
        return 9050
    elif interface_role in ['l3peer']:
        return 9050
    # AOS-42783: 'access_access' role should be here, it's not related to
    # external_router_mtu.
    # We put it here due to an old bug, when access<->access interfaces had 'l3edge'
    # role. The bug was later fixed and such interfaces are processed correctly in
    # new deployments, but for old deployments it leads to a BGP flap after upgrade
    # due to MTU change. We "reinvent" the bug to prevent such BGP flaps.
    elif interface_role in ['l3edge', 'access_access'] and external_router_mtu:
        return external_router_mtu
    else:
        return 0


def get_junos_max_l2_mtu(model):
    """
    Returns maximal Ethernet frame size particular Junos
    model can handle i.e. L2 MTU.
    """

    model = model.lower()

    if 'virtual-ex9214' in model or 'vjunos-switch' in model:
        return 9192

    # NOTE: some Juniper models (e.g. QFX10k series or PTX) can actually go higher
    return 9216


def is_unmanaged_generic_system(system):
    return system.role == 'generic' \
           and system.management_level == 'unmanaged'

