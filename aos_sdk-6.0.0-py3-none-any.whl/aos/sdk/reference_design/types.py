#!/usr/bin/python
# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from aos.sdk import schema as s

EXTERNAL_SYSTEM_FIELDS = {
    'system_id': s.String(
        description=(
            'Unique id for the manager instance returned from the'
            'system agent associated with this instance.'
        )
    ),
    'agent_id': s.String(
        description=(
            'ID of a system agent, we store agent_id solely for '
            'performance reasons, so we can efficiently lookup '
            'agent config to enrich GET facade APIs with '
            'additional user-friendly context such as manager '
            'management address.'
        )
    )
}



