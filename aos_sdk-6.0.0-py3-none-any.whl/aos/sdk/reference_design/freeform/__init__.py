# Copyright 2021-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import annotations

import typing as t

from .client import Client

from aos.sdk.reference_design.extension import (
    preferences,
    tags,
    resource_allocation,
)

if t.TYPE_CHECKING:
    import types


EXTENSIONS: list[types.ModuleType] = [
    preferences,
    tags,
    resource_allocation,
]
