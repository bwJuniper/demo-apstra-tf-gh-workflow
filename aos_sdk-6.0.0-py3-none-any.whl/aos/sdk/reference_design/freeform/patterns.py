# Copyright 2022-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""Central place to house common patterns in current reference design graph"""

from aos.sdk.graph.query import node, match
import aos.sdk.graph.query as m


def linked_systems(system1=None, system2=None,
                   interface1='interface1', interface2='interface2',
                   link=None,
                   link_filters=None,
                   interface1_filters=None, interface2_filters=None,
                   system1_filters=None, system2_filters=None):

    system1_filters = system1_filters or {}
    system2_filters = system2_filters or {}
    interface1_filters = interface1_filters or {}
    interface2_filters = interface2_filters or {}
    link_filters = link_filters or {}
    return (
        node('system', name=system1, **system1_filters)
        .out('hosted_interfaces', name='system1_hosted_interfaces')
        .node('interface', name=interface1, **interface1_filters)
        .out('link')
        .node('link', name=link, **link_filters)
        .in_('link')
        .node('interface', name=interface2, **interface2_filters)
        .in_('hosted_interfaces', name='system2_hosted_interfaces')
        .node('system', name=system2, **system2_filters)
        .ensure_different(interface1, interface2)
    )


def connected_physical_interfaces(
        device='device', interface='interface',
        remote_device='remote_device', remote_interface='remote_interface',
        link='link', if_types=None, **filters):
    """Return path query for linked physical interfaces. Named nodes are device,
    interface, link, remote_interface and remote_device.
    """
    if_types = if_types if if_types else ['ethernet',]
    return match(
        linked_systems(system1=device, system2=remote_device,
                       interface1=interface, interface2=remote_interface,
                       link=link, **filters),
        node('interface', name=interface, if_type=m.is_in(if_types)),
    )


def connected_port_channels(
        device='device', remote_device='remote_device',
        named_child_link='child_link',
        interface='interface', remote_interface='remote_interface',
        child_interface='child_interface',
        remote_child_interface='remote_child_interface',
        device_filters=None,
        remote_device_filters=None, named_child_link_filters=None,
        interface_filters=None, remote_interface_filters=None):
    """
    Return path query for port-channels with a connected child (physical) interface.
    Named nodes are device, interface (representing port-channel), child_interface,
    child_link, remote_child_interface, remote_interface (port-channel)
    and remote_device.

    This pattern uses physical links connectivity to determine which
    port channels on the other side of the aggregate link are neighbors.
    """
    device_filters = device_filters or {}
    remote_device_filters = remote_device_filters or {}
    named_child_link_filters = named_child_link_filters or {}
    interface_filters = interface_filters or {}
    remote_interface_filters = remote_interface_filters or {}
    return (
        node('system', name=device, **device_filters)
        .out('hosted_interfaces')
        .node('interface', name=interface, if_type='port_channel',
              **interface_filters)
        .out('composed_of')
        .node('interface', name=child_interface)
        .out('link')
        .node('link', name=named_child_link, **named_child_link_filters)
        .in_('link')
        .node('interface', name=remote_child_interface)
        .in_('composed_of')
        .node('interface', name=remote_interface, if_type='port_channel',
              **remote_interface_filters)
        .in_('hosted_interfaces')
        .node('system', name=remote_device, **remote_device_filters)
        .ensure_different(child_interface, remote_child_interface)
    )


def connected_top_level_port_channels(
        interface='interface', remote_interface='remote_interface', link='link',
        interface_filters=None, remote_interface_filters=None, link_filters=None
):
    interface_filters = interface_filters or {}
    remote_interface_filters = remote_interface_filters or {}
    link_filters = link_filters or {}
    return (
        node('interface', name=interface, if_type='port_channel',
             **interface_filters)
        .out('link')
        .node('link', name=link, link_type='aggregate_link', **link_filters)
        .in_('link')
        .node('interface', name=remote_interface, if_type='port_channel',
              **remote_interface_filters)
        .ensure_different(interface, remote_interface)
    )


def aggregate_link_endpoints(
        link='link', parent_po='parent_po', child_po='child_po',
        device='device',
        link_filters=None, parent_po_filters=None, child_po_filters=None,
        device_filters=None
):
    link_filters = link_filters or {}
    parent_po_filters = parent_po_filters or {}
    child_po_filters = child_po_filters or {}
    device_filters = device_filters or {}

    return (
        match(
            node('link', name=link, link_type='aggregate_link', **link_filters)
            .in_('link')
            .node('interface', name=parent_po, if_type='port_channel',
                  **parent_po_filters)
            .out('composed_of')
            .node('interface', name=child_po, if_type='port_channel',
                  **child_po_filters)
            .in_('hosted_interfaces')
            .node('system', name=device, **device_filters),

            node(name=child_po)
            .in_('hosted_interfaces')
            .node(name=device)
        )
    )


def aggregate_link_endpoints_with_ethernet_interfaces(
        link='link', parent_po='parent_po', child_po='child_po',
        child_intf='child_intf', device='device',
        link_filters=None, parent_po_filters=None, child_po_filters=None,
        child_intf_filters=None, device_filters=None
):
    child_intf_filters = child_intf_filters or {}
    return (
        match(
            aggregate_link_endpoints(
                link=link, parent_po=parent_po, child_po=child_po,
                device=device, link_filters=link_filters,
                parent_po_filters=parent_po_filters,
                child_po_filters=child_po_filters, device_filters=device_filters),

            node(name=child_po)
            .out('composed_of')
            .node('interface', name=child_intf, if_type='ethernet',
                  **child_intf_filters)
        )
    )
