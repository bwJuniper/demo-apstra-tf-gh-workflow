# Copyright 2022-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import absolute_import
from __future__ import division

import aos.sdk.py3compat  # pylint: disable=unused-import

import ast
import os.path
import uuid

import jinja2
import jinja2.ext
import six

from aos.sdk import schema as s
from aos.sdk import query_parser
from aos.sdk import yaml_utils
from aos.sdk import types as t
from aos.sdk.jinja_lib.jinja_common_environment import CommonJinjaEnvironment


MAX_LENGTH_NODE_ID = len(str(uuid.uuid4()))
MAX_LABEL_LENGTH = 64

VALID_IF_TYPES = (
    'ethernet',
    'port_channel',
)

VALID_LINK_TYPES = (
    'ethernet',
    'aggregate_link',
)

VALID_LINK_ROLES = (
    'internal',
    'external',
)

VALID_OS_FAMILIES = (
    'Junos',
)

VALID_DEPLOY_MODES = (
    'deploy',
    'ready',
    'drain',
    'undeploy',
)

VALID_SYSTEM_TYPES = (
    'internal',
    'external',
)

VALID_RESOURCE_TYPES = (
    'ip',
    'host_ip',
    'ipv6',
    'host_ipv6',
    'asn',
    'vni',
    'vlan',
    'integer',
)

VALID_LOCAL_POOL_TYPES = (
    'integer',
)

VALID_LOCAL_POOL_RESOURCE_TYPES = (
    'vlan',
    'integer',
)


def validate_jinja2_template(value):
    try:
        CommonJinjaEnvironment(loader=None).from_string(value)
    except jinja2.TemplateError as exc:
        six.raise_from(s.ValidationError(str(exc)), exc)


def validate_python_expression_string(value):
    try:
        ast.parse(value)
    except Exception as exc:  # pylint: disable=broad-except
        six.raise_from(s.ValidationError(str(exc)), exc)


def validate_scope_query(value):
    try:
        query_parser.parse_graph_query(value)
    except query_parser.QueryParsingError as exc:
        six.raise_from(s.ValidationError(str(exc)), exc)


def validate_yaml_string(value):
    try:
        yaml_utils.from_yaml(value)
    except yaml_utils.YamlDeserializationError as exc:
        error = six.ensure_text(exc.message)

        if exc.mark:
            error += str(exc.mark)

        six.raise_from(s.ValidationError(error), exc)


def make_file_extension_validator(extension):
    if not extension.startswith('.'):
        extension = '.' + extension

    def func(value):
        _, ext = os.path.splitext(value)
        if ext != extension:
            raise s.ValidationError(
                'Incorrect file extension {}. Should be {}'.format(ext, extension))

    return func


NodeId = s.validated_type(
    s.String,
    'NodeId',
    s.Length(min=1, max=MAX_LENGTH_NODE_ID))

Label = s.validated_type(
    s.String,
    'Label',
    [s.Length(min=1, max=MAX_LABEL_LENGTH), t.validate_is_ascii])

PositiveInteger = s.validated_type(
    s.Integer,
    'PositiveInteger',
    s.Range(min=0))

JinjaString = s.validated_type(
    s.String,
    'JinjaTemplate',
    validate_jinja2_template)

SubnetPrefix = s.validated_type(
    s.Integer,
    'SubnetPrefix',
    s.Range(min=1, max=128))

PythonExpressionString = s.validated_type(
    s.String,
    'PythonExpressionString',
    validate_python_expression_string)

PythonIdentifierString = s.validated_type(
    s.String,
    'PythonIdentifierString',
    s.Regexp(
        r'^[a-zA-Z_][a-zA-Z0-9_]*$',
        error=(
            'Invalid Pythonic identifier. Correct identifier must contain '
            'only letters of latin alphabet, digits and underscore. It must '
            'not start with a digit.'
        )
    )
)


OsFamily = s.Enum(
    VALID_OS_FAMILIES,
    description='OS families that work with Freeform reference design')

DeviceProfileId = s.NodeId(
    description='ID of the device profile in the global catalog')

PortId = PositiveInteger(
    description='ID of the port in the device profile')

TransformationId = PositiveInteger(
    description='ID of the transformation in the device profile')

IfName = t.NonEmptyString(
    description='Interface name',
    validate=s.Regexp(r'\A([\w\/\-\:]([\w\/\-\: ]*[\w\/\-\:])?)?\Z'))

IfType = s.Enum(
    tuple(VALID_IF_TYPES),
    description='Type of the interface')

IfIndex = s.Integer(
    description='Index of the interface in the link. Used to control the order in '
                'which link endpoints are returned for API Client'
                'convenience (only).',
    validate=[s.Range(min=0)],
)

PortChannelId = PositiveInteger(
    description='ID of the port-channel interface')

LinkType = s.Enum(
    VALID_LINK_TYPES,
    description=(
        "Link Type. An 'ethernet' link is a normal front-panel interface. "
        "An 'aggregate_link' is a bonded interface which is typically used "
        "for LACP or Static LAGs.  Note that the lag_mode parameter is a "
        "property of the interface and not the link, since interfaces "
        "may have different lag modes on opposite sides of the link - "
        "eg lacp_passive <-> lacp_active."
    ))

LinkRole = s.Enum(
    VALID_LINK_ROLES,
    description=(
        "The role of the link. An 'internal' link connects between systems "
        "of type 'internal' which are managed by Apstra. An 'external' link "
        "connects between systems of type 'external' which are not managed"))

DeployMode = s.Enum(
    VALID_DEPLOY_MODES,
    description=(
        "Systems in deploy mode 'deploy' will render the full reference "
        "design configuration and all telemetry expectations. "
        "Systems in deploy mode 'ready' should only render basic interface "
        "information: This mode is intended to do basic LLDP Cabling map "
        "discovery only.  No IPs should be rendered, no vlan endpoints "
        "should be created by the user's configuration template.  The"
        "intent for 'ready' should not permit the system to participate in "
        "any layer 3 or layer2 processes. "
        "Systems in deploy mode 'drain' are intended for Jinja usage for "
        "the user to handle their own semantics of what 'drain' means - "
        "for example, rendering different route-maps on BGP sessions."
        "Systems in deploy mode 'undeploy' do not render any configuration "
        "or telemetry expectations. This basically means do not manage "
        " that device at all and it can be used as a maintenance workflow "
        "option. Deploy mode can also be consulted in IBA probes."))

SystemId = s.SystemId(
    description=(
        "System ID of the system. The system ID is used to correlate "
        "this graph node to the managed device as it appears in "
        "the 'Managed Devices' tab, and is also referred to as the "
        "'Device Key' or 'Serial Number'. The system_id is only used "
        "for systems of type 'internal'. Specifying system_id for an "
        "'external' system will result in validation errors."))

SystemType = s.Enum(
    VALID_SYSTEM_TYPES,
    description=(
        "Systems of type 'internal' are considered managed by Apstra "
        "in which telemetry and config rendering can take place. "
        "'external' systems are not managed at all by Apstra, "
        "and are considered external systems."))

ResourceType = s.Enum(
    VALID_RESOURCE_TYPES,
    description=(
        'A type of the resource. "ip" resource type means IPv4 subnet in '
        'CIDR format; "ipv6" - IPv6 subnet. "asn" type means a number of ASN'
        'that is managed by a device. "vni" - a number of virtual network'
        '"vlan" type refers to a VLAN ID assigned to a device. "integer"'
        'means an abstract data type which semantics is defined by a user.'))

ResourceLabel = Label(
    description=(
        'Label of the resource. This resource will be accessible in '
        'Jinja templates by this label.'))

ResourceValue = s.String(
    description=(
        'A value of the resource. This value can be obtained in 2 ways: '
        'if resource does not allocate its value from any source like '
        'resource allocation group, then this value is provided by user. '
        'Otherwise, resource allocation framework reserves a value from a '
        'source and writes it here on build stage.'))

ResourceAllocatedFrom = NodeId(
    description=(
        'ID of the node that works as a source for this resource. This '
        'could be an ID of resource allocation group or another resource ('
        'in case of IP/Host IP allocation). This also can be empty. In that '
        'case it is required that value for this resource is provided by user.'))

ResourceGroupId = NodeId(
    description=(
        'ID of the resource group it belongs to.'))

ResourceAssignedTo = NodeId(
    description=(
        'ID of the target node that requires this resource.'))

ResourceGeneratorId = NodeId(
    description=(
        'ID of the resource generator that created the resource.'))

GroupParentId = NodeId(
    description=(
        'ID of the group node that is present as a parent of the current one '
        'in parent/children relationship. If group is a top-level one, '
        "then 'parent_id' is equal to None/null."))

GroupLabel = Label(
    description=(
        'Label of the group. Group will be accessible by this '
        'label in Jinja templates.'))

GroupData = s.Dict(
    description=(
        'Arbitrary key-value mapping that is useful in a context of this group. '
        'For example, you can store some VRF-related data there or add '
        'properties that are useful only in context of resource allocation, '
        'but not systems or interfaces.'),
    values=s.Any())

GroupGeneratorId = NodeId(
    description=(
        'ID of the group generator that created the group.'))

TemplateId = s.NodeId(
    description='ID of the configuration template in global catalog')

JinjaTemplate = JinjaString(
    description='Jinja2 configuration template')

TemplateLabel = Label(
    description=(
        'The name of the template. This name will be included in template loader'
        'so user can refer to it with "include" stanzas. This name must'
        'contain only ASCII characters (+ underscore and dash) and be max 64 '
        'character long. Also, it has to have a file extension of .jinja'),
    validate=make_file_extension_validator('.jinja'))

JSONPoolDefinition = t.JSONString(
    description='JSON definition of the pool (specific to the pool type)')

SubnetPrefixLen = SubnetPrefix(
    description='Length of subnet prefix')

Scope = PythonExpressionString(
    description=(
        'QE-syntax expression defining nodes for which a relevant '
        'node type should be instantiated.'),
    validate=validate_scope_query)

ScopeNodePoolLabel = s.Label(
    description=(
        'Label of the Local Pool (owned by the scope node) the '
        'resource should be allocated from. This is mutually '
        'exclusive to having an "allocated_from" relationship '
        'pointing to the "resource_allocation_group", '
        '"resource" or "local_pool" node. '
        'When "allocated_from" relationship is present on the '
        'resource generator level it points to the single '
        'source for all the resources that will be created '
        '(one for each node in scope). It does not allow to '
        'cover the cases where resources allocate values from '
        'separate pools (owned by the scope node). '
        'For instance we want to allocate VLAN ID from each '
        'system in scope of the generator and use its own pool '
        'to allocate the value from'))

LocalPoolType = s.Enum(
    VALID_LOCAL_POOL_TYPES,
    description='Type of the local pool')

LocalPoolResourceType = s.Enum(
    VALID_LOCAL_POOL_RESOURCE_TYPES,
    description='Resource type for the values allocated from the Local Pool'
)

LocalPoolLabel = Label(
    description=(
        'The label of the local pool. This label is important in a context '
        'of resource generators that uses it to generate a list of required '
        'resources and allocate them from this pool. Please see a '
        "description for 'scope_node_pool_label' of resource generator type."))

IntegerLocalPoolDefinition = s.Dict(
    {
        'chunks': s.List(
            s.Dict(
                {
                    'start': s.Integer(
                        description=(
                            'The first number of a chunk. '
                            'This is an inclusive bound.')),
                    'end': s.Integer(
                        description=(
                            'The last number of a chunk.'
                            'This is an inclusive bound.')),
                },
                description='A continuous range of integer numbers')
        )
    },
    description=(
        'Definition of integer pool. This pool is a collection of integer '
        'numbers that is expressed in a form of chunks: a continuous range '
        'of integers defined by start and finish. Each chunk does not '
        'intersect with others. Each time when pool wants to allocate a number, '
        'it picks a chunk and reserves a number from it'))

LocalPoolDefinitions = s.OneOf(
    [
        IntegerLocalPoolDefinition,
    ],
    description=(
        'Each local pool has its own type that is defined by local pool type. '
        'But this type not always necessarily defines all possible pool value '
        'variants. For example, if local pool type is integer, then it is '
        'unclear what is a shape of this pool, how many chunks are defined. '
        'This is complementary set of parameters for a local pool type that '
        'helps to build a correct local pool.'))

LocalPoolGeneratorId = NodeId(
    description=(
        'ID of the local pool generator that created the local pool.'))

Preferences = s.Dict(s.Any(
    description=(
        "Contains UI metadata to assist in visualization of the blueprint "
        "topology diagram or other UI-specific key-value storages.")))

PropertySetValues = s.Dict(
    values=s.Any(
        description=(
            'JSON Deserializable dictionary. All assigned values will be '
            'stored under properties[key] = values as an arbitrary data '
            'model for Jinja usage')),
    key_type=PythonIdentifierString(
        description=(
            'User-defined key which exposes a dictionary key in a dictionary '
            'under property set label in if this property set is global. '
            'Otherwise, this key will be a dictionary key in a dictionary '
            'named as property set label but in "system_properties" dictionary.')))

YamlString = s.validated_type(s.String, 'YamlString', [validate_yaml_string])

PropertySetValuesYaml = YamlString(
    description='YAML representation of property set values')

MemberLinks = s.List(
    s.NodeId(),
    validate=s.Length(min=1,
                      error="Member links must be defined.  A member link is "
                            "defined as a relationship between two physical "
                            "front-panel interfaces of if_type 'ethernet'"),
)

EndpointGroupId = NodeId(
    description='ID of an endpoint group, which is a top-level port channel '
                'interface that aggregates port channels on individual systems.')

EndpointGroupIdx = s.StringInteger(
    validate=[s.Range(min=0, max=1)],
    description='Index of the group this endpoint belongs to, can be 0 or 1.')
