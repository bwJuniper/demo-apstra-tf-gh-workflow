# Copyright 2021-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula
# pylint: disable=invalid-name,line-too-long
# mypy: disable-error-code="name-defined, index"

from __future__ import annotations

import typing as t

from aos.sdk.client import Client as _Client, api, Api

if t.TYPE_CHECKING:
    import collections.abc

    import typing_extensions as te

    from aos.sdk import typing as tt
    from aos.sdk.client import RestResource

    _MAGIC: t.Any
    aos: t.Any



class Client(_Client):
    @api('/blueprints')
    class blueprints(Api):
        @api('/{blueprint_id}')
        class resource(Api):

            @api('/device-profiles')
            class device_profiles(Api):
                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.freeform.facade.Facade',
                    'list_device_profiles',
                    'result']:
                    """ Get all device profiles.

                    Obtains a list of device profile dictionaries that exist within
                    the blueprint, keyed based on the device profile graph node ID.
                    """
                    return t.cast(
                        dict,
                        self._request(method='GET', **kwargs)
                    )['items']

                def import_(
                    self,
                    device_profile_ids: collections.abc.Iterable[tt.GraphNodeId],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs]
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.freeform.facade.Facade',
                    'import_device_profiles',
                    'result']:
                    """ Import device profile.

                    Imports the specified list of device profile IDs from the global
                    catalog into the blueprint.

                    :param device_profile_ids: list of device profile IDs
                    """
                    data = {'device_profile_ids': list(iter(device_profile_ids))}
                    return self._request(
                        url='/import', method='POST', data=t.cast(dict, data),
                        **kwargs)

                @api('/{device_profile_id}')
                class resource(Api):
                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> tt.JSON:
                        """ Delete an unused device profile node from the graph.

                        If the specified device profile does not exist or is in use
                        an error will be raised.
                        """
                        return self._request(method='DELETE', **kwargs)

            @api('/generic-systems')
            class systems(Api):
                def create(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'create_system',
                        'arg'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs]
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.freeform.facade.Facade',
                    'create_system',
                    'result']:
                    """ Create a system node.

                    For more information, please, see REST API Explorer.

                    :param data: configuration of the new system
                    """
                    return self._request(method='POST', data=data, **kwargs)

                def list(
                    self,
                    system_node_id: t.Optional[tt.GraphNodeId] = None,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.facade.GET_SYSTEM_SCHEMA_LIST']:
                    """ List systems.

                    Obtains a list of all systems which are instantiated in the
                    graph.

                    :param system_node_id: Obsolete, for single system info use
                        :py:class:`resource`.
                    """
                    params = t.cast(dict, (
                        {'system_node_id': system_node_id}
                        if system_node_id else None
                    ))
                    return t.cast(dict, self._request(  # type: ignore[misc]
                        method='GET', params=params, **kwargs))['items']

                @api('/{system_node_id}')
                class resource(Api):
                    def get(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'get_system',
                        'result']:
                        """ Get system.

                        Obtain information about a particular system based on its
                        graph node ID.
                        """
                        return self._request(method='GET', **kwargs)

                    def patch(
                        self,
                        cmds: _MAGIC.facade_method_schema[
                            'aos.reference_design.freeform.facade.Facade',
                            'patch_system',
                            'arg'],
                        **kwargs: te.Unpack[RestResource.TWriteKwargs]
                    ) -> tt.JSON:
                        """ Update system.

                        Incrementally updates (patches) a system in-place within the
                        blueprint.

                        :param cmds: new configuration of the system
                        """
                        return self._request(method='PATCH', data=cmds, **kwargs)

                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> tt.JSON:
                        """ Delete system.

                        Deletes a system from the graph and any links that it shares
                        with other systems.
                        """
                        return self._request(method='DELETE', **kwargs)

                    @api('/property-set')
                    class property_set(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResource.TReadKwargs]
                        ) -> _MAGIC.facade_method_schema[
                            'aos.reference_design.freeform.facade.Facade',
                            'list_property_sets',
                            'result']:
                            """ Get system property set.

                            Returns the system-specific property set for a given
                            system.
                            """
                            return self._request(method='GET', **kwargs)

            @api('/generic-systems-import')
            class generic_systems_import(Api):
                def post(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'import_system',
                        'arg'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.freeform.facade.Facade',
                    'import_system',
                    'result']:
                    """ Import system.

                    Import a system from a known Managed Device and instantiate an
                    internal system node within the blueprint.

                    For more information, please, see REST API Explorer.

                    :param data: configuration of the system
                    """
                    return self._request(
                        method='POST',
                        data=data,
                        **kwargs)

            @api('/links')
            class links(Api):
                def create(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'create_link',
                        'arg'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.freeform.facade.Facade',
                    'create_link',
                    'result']:
                    """Add link.

                    Adds interface nodes and a link node between two systems.

                    For more information, please, see REST API Explorer.

                    :param data: configuration of the new link
                    """
                    return self._request(method='POST', data=data, **kwargs)

                def list(
                    self,
                    system_node_id: t.Optional[tt.GraphNodeId] = None,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.facade.GET_LINKS_SCHEMA_LIST']:
                    """ Get links.

                    Obtains a list of links created in the blueprint.

                    :param system_node_id: if specified, only links of that
                        particular system are returned.
                    """
                    params = t.cast(dict, (
                        {'system_node_id': system_node_id}
                        if system_node_id else None
                    ))
                    return t.cast(dict, self._request(  # type: ignore[misc]
                        method='GET', params=params, **kwargs))['items']

                @api('/{link_id}')
                class resource(Api):
                    def get(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'get_link',
                        'result']:
                        """ Get information about a specific link

                        This API is intended for links of link_type 'ethernet', and
                        will not return aggregate links.
                        """
                        return self._request(method='GET', **kwargs)

                    def patch(
                        self,
                        cmds: _MAGIC.facade_method_schema[
                            'aos.reference_design.freeform.facade.Facade',
                            'update_link',
                            'arg'],
                        **kwargs: te.Unpack[RestResource.TWriteKwargs],
                    ) -> tt.JSON:
                        """ Update link.

                        Updates a link in-place in the graph.

                        :param cmds: new configuration of the link
                        """
                        return self._request(method='PATCH', data=cmds, **kwargs)

                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> tt.JSON:
                        """ Delete link.

                        Deletes the link in the graph and all attached interfaces
                        associated with the link.
                        """
                        return self._request(method='DELETE', **kwargs)

            @api('/aggregate-links')
            class aggregate_links(Api):
                def create(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'create_aggregated_link',
                        'arg'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.freeform.facade.Facade',
                    'create_aggregated_link',
                    'result']:
                    """ Create aggregate link.

                    Selects member ``interface`` nodes of type ``ethernet`` and
                    creates an aggregate interface which is intended for use by
                    bonding protocols.

                    The specified endpoints are created and associated to their
                    corresponding systems as interfaces of if_type ``port_channel``.
                    A graph link node will be created between the endpoints as
                    link_type ``aggregate_link``.

                    The specified member link IDs must already exist within the
                    graph.

                    :param data: configuration of the new aggregate link
                    """
                    return self._request(method='POST', data=data, **kwargs)

                def list(
                    self,
                    system_node_id: t.Optional[tt.GraphNodeId] = None,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.facade.GET_AGGREGATED_LINKS_SCHEMA_LIST']:
                    """ Get a list of aggregate links.

                    :param system_node_id: if specified, only links attached to that
                        particular system will be returned
                    """
                    params = t.cast(dict, (
                        {'system_node_id': system_node_id}
                        if system_node_id else None
                    ))
                    return t.cast(dict, self._request(  # type: ignore[misc]
                        method='GET', params=params, **kwargs))['items']

                @api('/{link_id}')
                class resource(Api):
                    def get(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'get_aggregated_link',
                        'result']:
                        """ Get aggregate link.

                        Obtain details about a specific aggregated link from the
                        graph by ID, including the port_channel interfaces attached
                        to each corresponding system.
                        """
                        return self._request(method='GET', **kwargs)

                    def patch(
                        self,
                        cmds: _MAGIC.facade_method_schema[
                            'aos.reference_design.freeform.facade.Facade',
                            'update_aggregated_link',
                            'arg'],
                        **kwargs: te.Unpack[RestResource.TWriteKwargs],
                    ) -> tt.JSON:
                        """ Update aggregate link.

                        Updates properties of an aggregate link in the graph.

                        :param cmds: new configuration of the aggregate link
                        """
                        return self._request(method='PATCH', data=cmds, **kwargs)

                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> tt.JSON:
                        """ Delete aggregate link.

                        Deletes a specific aggregate link from the graph, including
                        the port_channel interfaces associated to that link.
                        """
                        return self._request(method='DELETE', **kwargs)

            @api('/config-templates')
            class config_templates(Api):
                def create(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'create_config_template',
                        'arg'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.freeform.facade.Facade',
                    'create_config_template',
                    'result']:
                    """ Create config template.

                    Creates a config template in the graph directly without making
                    use of the global catalog.

                    For more information, please, see REST API Explorer.

                    :param data: config template configuration
                    """
                    return self._request(method='POST', data=data, **kwargs)

                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.facade.GET_CONFIG_TEMPLATE_SCHEMA_LIST']:
                    """ List config templates.
                    """
                    return t.cast(
                        dict,
                        self._request(method='GET', **kwargs)
                    )['items']

                @api('/{config_template_id}')
                class resource(Api):
                    def get(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'get_config_template',
                        'result']:
                        """ Get config template.

                        Gets information about the specified config template from
                        the blueprint.
                        """
                        return self._request(method='GET', **kwargs)

                    def patch(
                        self,
                        cmds: _MAGIC.facade_method_schema[
                            'aos.reference_design.freeform.facade.Facade',
                            'update_config_template',
                            'arg'],
                        **kwargs: te.Unpack[RestResource.TWriteKwargs],
                    ) -> tt.JSON:
                        """ Update config template.

                        :param cmds: new configuration of the config template
                        """
                        return self._request(method='PATCH', data=cmds, **kwargs)

                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> tt.JSON:
                        """ Delete config template.

                        Deletes a specific config template from the blueprint.
                        """
                        return self._request(method='DELETE', **kwargs)

            @api('/config-templates-assignments')
            class config_templates_assignments(Api):
                def get(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.config_templates.CONFIG_ASSIGNMENTS_SCHEMA']:
                    """ Obtain the config template system-to-template assignment map.

                    Only systems with assigned config templates will be returned,
                    this API will not return internal systems which are missing
                    config assignments
                    """
                    return t.cast(
                        dict,
                        self._request(method='GET', **kwargs)
                    )['assignments']

                def patch(
                    self,
                    cmds: _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'patch_config_assignments',
                        'arg'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> tt.JSON:
                    """ Change config assignments.

                    Assigns configuration templates directly to specified systems.

                    :param cmds: mapping from system node IDs to config template IDs
                    """
                    return self._request(method='PATCH', data=cmds, **kwargs)

            @api('/config-templates-import')
            class config_templates_import(Api):
                def post(
                    self,
                    config_template_ids: collections.abc.Iterable[tt.GraphNodeId],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs]
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.freeform.facade.Facade',
                    'import_config_templates',
                    'result']:
                    """ Import config templates.

                    Imports the specified global config template IDs from the global
                    catalog.

                    :param config_template_ids: IDs of the templates to be imported
                    """
                    return self._request(
                        method='POST',
                        data={'config_template_ids': list(iter(config_template_ids))},
                        **kwargs
                    )

            @api('/property-sets')
            class property_sets(Api):
                def create(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'create_property_set',
                        'arg'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.freeform.facade.Facade',
                    'create_property_set',
                    'result']:
                    """ Create property set.

                    For more information, please, see REST API Explorer.

                    :param data: configuration of the property set
                    """
                    return self._request(method='POST', data=data, **kwargs)

                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs],
                ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.facade.GET_PROPERTY_SET_SCHEMA_LIST']:
                    """ List property sets.

                    Obtains information about all property sets from the blueprint.
                    """
                    return t.cast(
                        dict,
                        self._request(method='GET', **kwargs)
                    )['items']

                @api('/{property_set_id}')
                class resource(Api):
                    def get(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.property_sets.PROPERTY_SET_GET_SCHEMA']:
                        """ Get property set.

                        Obtain information about a particular property set by ID and
                        display the assigned values. The property set response for
                        the ``values`` key will be JSON encoded.
                        """
                        return self._request(method='GET', **kwargs)

                    def patch(
                        self,
                        cmds: _MAGIC.facade_method_schema[
                            'aos.reference_design.freeform.facade.Facade',
                            'update_property_set',
                            'arg'],
                        **kwargs: te.Unpack[RestResource.TWriteKwargs],
                    ) -> tt.JSON:
                        """ Update property set.

                        :param cmds: new configuraion of the property set
                        """
                        return self._request(method='PATCH', data=cmds, **kwargs)

                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> tt.JSON:
                        """ Delete property set.

                        Deletes the specified property set from the blueprint.

                        This will also remove the relationships for system-specific
                        property sets.
                        """
                        return self._request(method='DELETE', **kwargs)

            @api('/ra-groups')
            class ra_groups(Api):
                def create(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'create_group',
                        'arg'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.freeform.facade.Facade',
                    'create_group',
                    'result']:
                    """ Create group for resources.

                    Creates a group which is used to group user-defined resources.

                    Note that groups can be nested. If ``parent_id`` is specified
                    then this becomes a child group of the parent group.

                    :param data: configuration of the new group
                    """
                    return self._request(method='POST', data=data, **kwargs)

                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.facade.GET_GROUP_SCHEMA_LIST']:
                    """ List all user-defined resource groups in the blueprint.
                    """
                    return t.cast(
                        dict,
                        self._request(method='GET', **kwargs)
                    )['items']

                @api('/{group_id}')
                class resource(Api):
                    def get(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.resource_allocation.group.GROUP_SCHEMA']:
                        """ Get user-defined resource group.

                        If the group is a child of a parent group then ``parent_id``
                        will also be included in the response.
                        """
                        return self._request(method='GET', **kwargs)

                    def patch(
                        self,
                        cmds: _MAGIC.facade_method_schema[
                            'aos.reference_design.freeform.facade.Facade',
                            'patch_group',
                            'arg'],
                        **kwargs: te.Unpack[RestResource.TWriteKwargs],
                    ) -> tt.JSON:
                        """ Update user-defined group in-place.

                        :param cmds: new configuration of the resource group
                        """
                        return self._request(method='PATCH', data=cmds, **kwargs)

                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> tt.JSON:
                        """ Delete user-defined group.
                        """
                        return self._request(method='DELETE', **kwargs)

                    @api('/children')
                    class children(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResource.TReadKwargs]
                        ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.facade.GET_GROUP_SCHEMA_LIST']:
                            """ Get child groups.

                            Obtains a list of children groups for which ``group_id``
                            is a parent.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['items']

                    @api('/assignments')
                    class assignments(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResource.TReadKwargs]
                        ) -> _MAGIC.facade_method_schema[
                            'aos.reference_design.freeform.facade.Facade',
                            'get_groups_assignments',
                            'result']:
                            """ Get resource allocation group assignments.

                            Returns information about the specific user-defined
                            resource group and its associated assignments.
                            """
                            return self._request(method='GET', **kwargs)

                        def update(
                            self,
                            cmds: _MAGIC.facade_method_schema[
                                'aos.reference_design.freeform.facade.Facade',
                                'update_groups_assignments',
                                'arg'],
                            **kwargs: te.Unpack[RestResource.TWriteKwargs],
                        ) -> tt.JSON:
                            """ Update resource allocation group assignments.

                            Updates ``group -> assigned_to -> {assigned_target}``
                            relationships.

                            Adds missing relationships and will remove extra
                            relationships if this api is called and the target is
                            not included in ``assigned_to``.

                            :param cmds: new assignments
                            """
                            return self._request(method='PUT', data=cmds, **kwargs)

            @api('/ra-resources')
            class ra_resources(Api):
                def create(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'create_resource',
                        'arg'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.freeform.facade.Facade',
                    'create_resource',
                    'result']:
                    """ Create user-defined resource.

                    :param data: configuration of the new resource
                    """
                    return self._request(method='POST', data=data, **kwargs)

                def list(
                    self,
                    group_id: t.Optional[str] = None,
                    with_values_only: t.Optional[t.Literal['true', 'false']] = None,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.facade.GET_RESOURCE_SCHEMA_LIST']:
                    """ Get a list of user-defined resources.

                    :param group_id: if specified, constraints the API response to
                        only include resource groups that are associated to this
                        specific group ID
                    :param with_values_only: if flag is enabled returns only
                        resources with the values assigned. Together with fetching
                        data from the config graph allows to identify the resources
                        with the manual overrides provided
                    """
                    params = {}
                    if group_id:
                        params['group_id'] = group_id
                    if with_values_only:
                        params['with_values_only'] = str(with_values_only)
                    return t.cast(dict, self._request(  # type: ignore[misc]
                        method='GET', params=params, **kwargs))['items']

                @api('/{resource_id}')
                class resource(Api):
                    def get(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'get_resource',
                        'result']:
                        """ Get information about a specific resource by its ID.
                        """
                        return self._request(method='GET', **kwargs)

                    def patch(
                        self,
                        cmds: _MAGIC.facade_method_schema[
                            'aos.reference_design.freeform.facade.Facade',
                            'update_resource',
                            'arg'],
                        **kwargs: te.Unpack[RestResource.TWriteKwargs],
                    ) -> tt.JSON:
                        """ Update user-defined resource.

                        :param cmds: new configuration of the resource
                        """
                        return self._request(method='PATCH', data=cmds, **kwargs)

                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> tt.JSON:
                        """ Delete resource.

                        Deletes the specific resource and any derivative resources
                        for which it is the parent.
                        """
                        return self._request(method='DELETE', **kwargs)

                    @api('/assignments')
                    class assignments(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResource.TReadKwargs]
                        ) -> _MAGIC.facade_method_schema[
                            'aos.reference_design.freeform.facade.Facade',
                            'get_resource_assignments',
                            'result']:
                            """ Obtain a mapping of a specific resource and its
                            associated assignments.
                            """
                            return self._request(method='GET', **kwargs)

                        def update(
                            self,
                            data: _MAGIC.facade_method_schema[
                                'aos.reference_design.freeform.facade.Facade',
                                'update_resource_assignments',
                                'arg'],
                            **kwargs: te.Unpack[RestResource.TWriteKwargs],
                        ) -> tt.JSON:
                            """ Update resource assignments.

                            Update resource assignments for a specific resource.
                            If the assignments map specifies a resource with a null
                            ``assigned_to``, then that relationship is deleted.

                            When updating resource assignments for a specific
                            resource, ensure to include all resource assignments,
                            not only the assignment which is undergoing change.

                            :param data: nwe assignments
                            """
                            return self._request(method='PUT', data=data, **kwargs)

            @api('/ra-group-generators')
            class ra_group_generators(Api):
                def create(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'create_group_generator',
                        'arg'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.freeform.facade.Facade',
                    'create_group_generator',
                    'result']:
                    """ Create group generator.

                    Creates a group generator object. A group generator is a node
                    which describes semantics of group creation and membership
                    automation.

                    :param data: configuration of the new generator
                    """
                    return self._request(method='POST', data=data, **kwargs)

                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.facade.GET_GROUP_GENERATOR_SCHEMA_LIST']:
                    """ List group generators.

                    Obtains a list of all user-defined resource group generators
                    from the blueprint.
                    """
                    return t.cast(
                        dict,
                        self._request(method='GET', **kwargs)
                    )['items']

                @api('/{group_generator_id}')
                class resource(Api):
                    def get(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'get_group_generator',
                        'result']:
                        """ Get group generator.

                        Obtains information about a specific user-defined resource
                        group generator and its properties.
                        """
                        return self._request(method='GET', **kwargs)

                    def patch(
                        self,
                        cmds: _MAGIC.facade_method_schema[
                            'aos.reference_design.freeform.facade.Facade',
                            'update_group_generator',
                            'arg'],
                        **kwargs: te.Unpack[RestResource.TWriteKwargs],
                    ) -> tt.JSON:
                        """ Update resource group generator in-place.

                        :param cmds: new configuration of the generator
                        """
                        return self._request(method='PATCH', data=cmds, **kwargs)

                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> tt.JSON:
                        """ Delete group generator.

                        Recursively delete the group generator, all associated
                        groups, all nested group generators, and all nested
                        resources for the specified ``group_generator_id``.
                        """
                        return self._request(method='DELETE', **kwargs)

            @api('/ra-resource-generators')
            class ra_resource_generators(Api):
                def create(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'create_resource_generator',
                        'arg'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.freeform.facade.Facade',
                    'create_resource_generator',
                    'result']:
                    """ Create user-defined resource generator.

                    This API is used to build a hierarchical relationship of groups
                    and individual user-defined group relationships.

                    :param data: configuration of new generators
                    """
                    return self._request(method='POST', data=data, **kwargs)

                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.facade.GET_RESOURCE_GENERATOR_SCHEMA_LIST']:
                    """ Get resource generators.

                    Obtains a list of all resource generators from the blueprint.
                    """
                    return t.cast(
                        dict,
                        self._request(method='GET', **kwargs)
                    )['items']

                @api('/{resource_generator_id}')
                class resource(Api):
                    def get(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'get_resource_generator',
                        'result']:
                        """ Get resource generator.

                        Obtains information about a specific user-defined resource
                        generator by node ID. This API is used to obtain a mapping
                        from the generator to any created resources and their
                        resource relationships.
                        """
                        return self._request(method='GET', **kwargs)

                    def patch(
                        self,
                        cmds: _MAGIC.facade_method_schema[
                            'aos.reference_design.freeform.facade.Facade',
                            'update_resource_generator',
                            'arg'],
                        **kwargs: te.Unpack[RestResource.TWriteKwargs],
                    ) -> tt.JSON:
                        """ Update resource generator.

                        :param cmds: new configuration of the resource generator
                        """
                        return self._request(method='PATCH', data=cmds, **kwargs)

                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> tt.JSON:
                        """ Delete resource generator.

                        Recursively deletes the specified resource generator and any
                        associated resources which it created.
                        """
                        return self._request(method='DELETE', **kwargs)

            @api('/ra-local-pools')
            class ra_local_pools(Api):
                def create(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'create_pool',
                        'arg'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.freeform.facade.Facade',
                    'create_pool',
                    'result']:
                    """ Create user-defined resource pool.

                    Creates a local user-defined resource allocation pool which only
                    exists within the context of a single system node.

                    :param data: configuration of the new pool
                    """
                    return self._request(method='POST', data=data, **kwargs)

                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.facade.GET_POOL_SCHEMA_LIST']:
                    """ Get user-defined local pools.

                    Obtains a list of all available user-defined local resource
                    pools.
                    """
                    return t.cast(
                        dict,
                        self._request(method='GET', **kwargs)
                    )['items']

                @api('/{local_pool_id}')
                class resource(Api):
                    def get(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'get_pool',
                        'result']:
                        """ Get user-defined resource pool.
                        """
                        return self._request(method='GET', **kwargs)

                    def patch(
                        self,
                        cmds: _MAGIC.facade_method_schema[
                            'aos.reference_design.freeform.facade.Facade',
                            'patch_pool',
                            'arg'],
                        **kwargs: te.Unpack[RestResource.TWriteKwargs],
                    ) -> tt.JSON:
                        """ Update user-defined local pool.

                        Updates a user-defined local resource allocation pool
                        in-place.

                        :param cmds: new configuration of the resource pool
                        """
                        return self._request(method='PATCH', data=cmds, **kwargs)

                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> tt.JSON:
                        """ Delete user-defined local resource allocation pool.

                        Recursively deletes a specific user-defined local resource
                        allocation pool and all resources which were instantiated
                        from it.
                        """
                        return self._request(method='DELETE', **kwargs)

            @api('/ra-local-pool-generators')
            class ra_local_pool_generators(Api):
                def create(
                    self,
                    data: _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'create_pool_generator',
                        'arg'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs],
                ) -> _MAGIC.facade_method_schema[
                    'aos.reference_design.freeform.facade.Facade',
                    'create_pool_generator',
                    'result']:
                    """ Create user-defined pool generator.

                    Instantiate a resource pool generator. A resource pool generator
                    is a node which describes semantics of creating resource pools
                    as they relate to specific systems or interfaces.

                    :param data: configuration of the new generator
                    """
                    return self._request(method='POST', data=data, **kwargs)

                def list(
                    self,
                    **kwargs: te.Unpack[RestResource.TReadKwargs]
                ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.facade.GET_POOL_GENERATOR_SCHEMA_LIST']:
                    """ List user-defined pool generators.

                    Obtains a list of all local resource pool generators from the
                    blueprint.
                    """
                    return t.cast(
                        dict,
                        self._request(method='GET', **kwargs)
                    )['items']

                @api('/{local-pool_generator_id}')
                class resource(Api):
                    def get(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> _MAGIC.facade_method_schema[
                        'aos.reference_design.freeform.facade.Facade',
                        'get_pool_generator',
                        'result']:
                        """ Get user-defined pool generator.

                        Obtains information about a specific user-defined local
                        resource pool within the blueprint.
                        """
                        return self._request(method='GET', **kwargs)

                    def patch(
                        self,
                        cmds: _MAGIC.facade_method_schema[
                            'aos.reference_design.freeform.facade.Facade',
                            'patch_pool_generator',
                            'arg'],
                        **kwargs: te.Unpack[RestResource.TWriteKwargs],
                    ) -> tt.JSON:
                        """ Update user-defined local resource pool.

                        :param cmds: new configuration of the pool
                        """
                        return self._request(method='PATCH', data=cmds, **kwargs)

                    def delete(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> tt.JSON:
                        """ Delete user-defined pool generator.

                        Deletes a user-defined resource pool generator from within
                        the blueprint. When the generator is deleted, all created
                        pools which were instantiated by that pool generator are
                        also deleted.
                        """
                        return self._request(method='DELETE', **kwargs)

            @api('/cabling-map')
            class cabling_map(Api):
                def update(
                    self,
                    data: _MAGIC.lollipop_type['aos.reference_design.freeform.cabling_map.CABLING_MAP_SET_SCHEMA'] |
                          _MAGIC.facade_method_schema[
                            'aos.reference_design.freeform.facade.Facade',
                            'set_cabling_map',
                            'arg'],
                    **kwargs: te.Unpack[RestResource.TWriteKwargs]
                ) -> tt.JSON:
                    """ Update cabling map.

                    Updates the cabling map (physical links between devices).

                    Note that this endpoint does not allow to create a new link, but
                    only update already existing ones.

                    :param data: new configuration of the cabling map
                    """
                    if isinstance(data, list):
                        data = {'links': data}
                    return self._request(method='PATCH', data=data, **kwargs)

                @api('/lldp')
                class lldp(Api):
                    def get(
                        self,
                        system_id: t.Optional[tt.GraphNodeId] = None,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.cabling_map.CABLING_MAP_GET_SCHEMA_LIST']:
                        """ Retrieve cabling map.

                        Retrieves the cabling map (physical links connecting the
                        devices) constructed using actual reported LLDP data.

                        Note that links that are not modelled in the blueprint are
                        not going to be reported by this API.

                        :param system_id: if specified, result is filtered by links
                            of this system
                        """
                        params = {'system_id': system_id} if system_id else {}
                        return t.cast(
                            dict,
                            self._request(params=params, **kwargs)  # type: ignore[misc]
                        )['links']

                @api('/diff')
                class diff(Api):
                    def get(
                        self,
                        **kwargs: te.Unpack[RestResource.TReadKwargs]
                    ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.cabling_map.CABLING_MAP_DIFF_SCHEMA_LIST']:
                        """ Get cabling map differences with LLDP data.

                        Calculates the diff between cabling constructed using LLDP
                        telemetry reported by devices.
                        """
                        return t.cast(dict, self._request(**kwargs))['links']

            def batch(
                self,
                operations: _MAGIC.lollipop_type['aos.scotch.libs.batch_facade_mutation.REQUEST_SCHEMA_FIELDS_OPERATIONS'],
                **kwargs: te.Unpack[RestResource.TWriteKwargs]
            ) -> _MAGIC.lollipop_type['aos.scotch.libs.batch_facade_mutation.RESPONSE_SCHEMA']:
                """ Batch operations

                Batch operations for AOS REST APIs. Execute multiple requests which
                are submitted as a batch.

                :param operations: payload with operations to be executed
                """
                return self._request(url='/batch', method='POST', data={
                    'operations': operations
                }, **kwargs)

            def cleanup_resource_overrides(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.freeform.facade.Facade',
                    'cleanup_resource_overrides',
                    'arg'],
                **kwargs
            ) -> tt.JSON:
                """ Remove resource overrides for a given resource allocation group
                (RAG).

                :param data: resource group type and name
                """
                return self._request(
                    url='/cleanup-resource-overrides',
                    method='POST', data=data, **kwargs)

            def export(
                self,
                data: _MAGIC.facade_method_schema[
                    'aos.reference_design.freeform.facade.Facade',
                    'export',
                    'arg'],
                **kwargs
            ) -> _MAGIC.facade_method_schema[
                'aos.reference_design.freeform.facade.Facade',
                'export',
                'result']:
                """ Export blueprint into JSON applying specific set of filters.

                By default, the whole blueprint is exported and no filters are
                applied. When certain parts of the blueprint need to be filtered out
                in the export result, engage the filters by supplying "true" for the
                required filters.

                The output of this endpoint can (in its turn) be used to create a
                new blueprint.

                :param data: filters to be applied to the result
                """
                return self._request(
                    url='/export', method='POST', data=data, **kwargs)

            @api('/resource_groups')
            class resource_groups(Api):
                @api('/{resource_type}')
                class resource_type(Api):
                    def create(
                            self,
                            data: _MAGIC.facade_method_schema[
                                'aos.reference_design.freeform.facade.Facade',
                                'create_resource_allocation_group',
                                'arg'
                            ],
                            **kwargs: te.Unpack[RestResource.TWriteKwargs],
                    ) -> tt.JSON:
                        """ Create resource allocation group with given name and
                        resource type.

                        :param data: configuration of the new resource group
                        """
                        return self._request(method='POST', data=data,
                                             **kwargs)['id']

                    @api('/{group_name}')
                    class group(Api):
                        def delete(
                                self,
                                **kwargs: te.Unpack[RestResource.TReadKwargs]
                        ) -> tt.JSON:
                            """ Delete resource allocation group from the graph.
                            """
                            return self._request(method='DELETE', **kwargs)

            @api('/experience')
            class experience(Api):
                @api('/web')
                class web(Api):

                    @api('/resource-allocation')
                    class resource_allocation(Api):
                        @api('/groups')
                        class groups(Api):
                            def get(
                                self,
                                **kwargs: te.Unpack[RestResource.TReadKwargs],
                            ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.experience.web.resource_allocation.groups.ITEM_LIST_SCHEMA']:
                                """ Obtains information about all resource
                                allocation groups in the blueprint.
                                """
                                return t.cast(
                                    dict,
                                    self._request(method='GET', **kwargs)
                                )['items']

                        @api('/groups-assignments')
                        class groups_assignments(Api):
                            def get(
                                self,
                                **kwargs: te.Unpack[RestResource.TReadKwargs],
                            ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.experience.web.resource_allocation.groups.ASSIGNMENTS_LIST_SCHEMA']:
                                """ Obtains information about all resource
                                allocation group assignments in the blueprint.
                                """
                                return t.cast(
                                    dict,
                                    self._request(method='GET', **kwargs)
                                )['items']

                        @api('/resources')
                        class resources(Api):
                            def get(
                                self,
                                **kwargs: te.Unpack[RestResource.TReadKwargs],
                            ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.experience.web.resource_allocation.resources.SCHEMA_LIST']:
                                """ Obtains information about all resources in the
                                blueprint.
                                """
                                return t.cast(
                                    dict,
                                    self._request(method='GET', **kwargs)
                                )['items']

                        @api('/resources-assignments')
                        class resources_assignments(Api):
                            def get(
                                self,
                                **kwargs: te.Unpack[RestResource.TReadKwargs],
                            ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.experience.web.resource_allocation.resources.ASSIGNMENTS_LIST_SCHEMA']:
                                """ Obtains information about all resource
                                assignments in the blueprint.
                                """
                                return t.cast(
                                    dict,
                                    self._request(method='GET', **kwargs)
                                )['items']

                        @api('/group-generators')
                        class group_generators(Api):
                            def get(
                                self,
                                **kwargs: te.Unpack[RestResource.TReadKwargs],
                            ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.experience.web.resource_allocation.group_generators.SCHEMA_LIST']:
                                """ Obtains information about all group generators
                                in the blueprint.
                                """
                                return t.cast(
                                    dict,
                                    self._request(method='GET', **kwargs)
                                )['items']

                        @api('/resource-generators')
                        class resource_generators(Api):
                            def get(
                                self,
                                **kwargs: te.Unpack[RestResource.TReadKwargs],
                            ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.experience.web.resource_allocation.resource_generators.SCHEMA_LIST']:
                                """ Obtains information about all resource
                                generators in the blueprint.
                                """
                                return t.cast(
                                    dict,
                                    self._request(method='GET', **kwargs)
                                )['items']

                        @api('/local-pools')
                        class local_pools(Api):
                            def get(
                                self,
                                **kwargs: te.Unpack[RestResource.TReadKwargs],
                            ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.experience.web.resource_allocation.local_pools.SCHEMA_LIST']:
                                """ Obtains information about all local pools in the
                                blueprint.
                                """
                                return t.cast(
                                    dict,
                                    self._request(method='GET', **kwargs)
                                )['items']

                        @api('/local-pool-generators')
                        class local_pool_generators(Api):
                            def get(
                                self,
                                **kwargs: te.Unpack[RestResource.TReadKwargs],
                            ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.experience.web.resource_allocation.local_pool_generators.SCHEMA_LIST']:
                                """ Obtains information about all local pool
                                generators in the blueprint.
                                """
                                return t.cast(
                                    dict,
                                    self._request(method='GET', **kwargs)
                                )['items']

                    @api('/aggregate-links')
                    class aggregate_links(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResource.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.experience.web.aggregated_links.AGGREGATE_LINKS_SCHEMA_LIST']:
                            """Obtain a list of aggregate links from the blueprint.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['items']

                    @api('/config-templates')
                    class config_templates(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResource.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.experience.web.config_templates.CONFIG_TEMPLATES_SCHEMA_LIST']:
                            """ Obtains a list of config templates that exist within
                            the blueprint.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['items']

                    @api('/config-templates-assignments')
                    class config_templates_assignments(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResource.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.config_templates.CONFIG_ASSIGNMENTS_SCHEMA']:
                            """ Obtain the config template system-to-template
                            assignment map.

                            Only systems with assigned config templates will be
                            returned, this API will not return internal systems
                            which are missing config assignments.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['items']

                    @api('/device-profiles')
                    class device_profiles(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResource.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.experience.web.device_profiles.DEVICE_PROFILES_SCHEMA_LIST']:
                            """ Obtain a list of device profile dictionaries that
                            exist within the blueprint, keyed based on the device
                            profile graph node ID.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['items']

                    @api('/links')
                    class links(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResource.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.experience.web.links.LINKS_SCHEMA_LIST']:
                            """ Obtain a list of links created in the blueprint.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['items']

                    @api('/property-sets')
                    class property_sets(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResource.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.experience.web.property_sets.PROPERTY_SETS_LIST_SCHEMA']:
                            """ Obtains information about all property sets from
                            the blueprint.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['items']

                    @api('/resource-groups')
                    class resource_groups(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResource.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.experience.web.resource_groups.LIST_SCHEMA']:
                            """ Obtains resource allocation groups.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['items']

                    @api('/resource-groups-stats')
                    class resource_groups_stats(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResource.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.experience.web.resource_groups_stats.STATS_RESULT_LIST']:
                            """ Obtains allocation statistics about resource
                            allocation groups.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['items']

                    @api('/generic-systems')
                    class systems(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResource.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.experience.web.systems.SYSTEMS_SCHEMA_LIST']:
                            """ Obtain a list of all systems which are instantiated
                            in the graph.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['items']

                    @api('/tags')
                    class tags(Api):
                        def get(
                            self,
                            **kwargs: te.Unpack[RestResource.TReadKwargs],
                        ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.experience.web.tags.TAGS_SCHEMA_LIST']:
                            """ Obtains information about all tags from the
                            blueprint.
                            """
                            return t.cast(
                                dict,
                                self._request(method='GET', **kwargs)
                            )['items']

                    @api('/meta')
                    class meta(Api):

                        @api('/all')
                        class all(Api):
                            def get(
                                self,
                                **kwargs: te.Unpack[RestResource.TReadKwargs],
                            ) -> _MAGIC.lollipop_type['aos.reference_design.freeform.blueprint_cache_facade.UNIFIED_EXPERIENCE_META_SCHEMA']:
                                """ Get unified meta in the blueprint.
                                """
                                return self._request(method='GET', **kwargs)
