# Copyright 2022-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import annotations

import typing as t

from aos.sdk.graph import is_node, query as q

if t.TYPE_CHECKING:
    import typing_extensions as te
    import aos.sdk.typing as tt

    GraphNodeOrId: te.TypeAlias = tt.GraphNode | tt.GraphNodeId

    _MAGIC: t.Any
    aos: t.Any


def _node(blueprint: tt.Graph, node: GraphNodeOrId) -> tt.GraphNode | None:
    if not is_node(node):
        return blueprint.get_node(node)
    return node


def get_interfaces(
    blueprint: tt.Graph,
    system: GraphNodeOrId,
    **iface_filters: te.Unpack[_MAGIC.lollipop_type[
        'aos.sdk.reference_design.freeform.schema.INTERFACE_SCHEMA'
    ]]
) -> t.List[tt.GraphNode]:
    system_ = _node(blueprint, system)
    return list(
        blueprint.traverse(system_)
        .out('hosted_interfaces')
        .target('interface', **iface_filters))


def get_system_hosting_interface(
    blueprint: tt.Graph,
    interface: GraphNodeOrId
) -> tt.GraphNode | None:
    interface_ = _node(blueprint, interface)
    return (blueprint.traverse(interface_)
            .in_('hosted_interfaces')
            .source('system')
            .first)


def get_system_device_profile(
    blueprint: tt.Graph,
    system: GraphNodeOrId
) -> tt.GraphNode | None:
    system_ = _node(blueprint, system)
    return (blueprint.traverse(system_)
            .out('device_profile')
            .target('device_profile')
            .first)


def get_neighbor_interface(
    blueprint: tt.Graph,
    local_intf: GraphNodeOrId
) -> tt.GraphNode | None:
    local_intf_ = _node(blueprint, local_intf)
    assert local_intf_ is not None
    return next((
        path['intf'] for path in q.iterate(
            blueprint,
            q.node('interface', id=local_intf_.id)
            .out('link')
            .node('link')
            .in_('link')
            .node('interface', name='intf', id=q.ne(local_intf_.id))
        )
    ), None)


def get_port_channel_by_interface(
    blueprint: tt.Graph,
    intf: GraphNodeOrId
) -> tt.GraphNode | None:
    intf_ = _node(blueprint, intf)
    return (blueprint.traverse(intf_)
            .in_('composed_of')
            .node('interface', if_type='port_channel')
            .first)


def get_member_interfaces_by_port_channel(
    blueprint: tt.Graph,
    port_channel: GraphNodeOrId
) -> t.List[tt.GraphNode]:
    port_channel_ = _node(blueprint, port_channel)
    assert port_channel_ is not None
    return list(
        path['interface'] for path in q.iterate(
            blueprint,
            q.node('interface', if_type='port_channel', id=port_channel_.id)
            .out('composed_of')
            .node('interface', if_type='ethernet', name='interface'))
    )


def get_tags(blueprint: tt.Graph, node: GraphNodeOrId) -> t.List[tt.GraphNode]:
    node_ = _node(blueprint, node)
    return list(
        blueprint.traverse(node_)
        .in_('tag')
        .source('tag')
    )


def get_systems_by_config_template(
    blueprint: tt.Graph,
    config_template: GraphNodeOrId
) -> t.List[tt.GraphNode]:
    config_template_ = _node(blueprint, config_template)
    return list(
        blueprint.traverse(config_template_)
        .out('applied_on')
        .target('system')
    )


def get_system_by_property_set(
    blueprint: tt.Graph,
    property_set: GraphNodeOrId
) -> tt.GraphNode | None:
    property_set_ = _node(blueprint, property_set)
    return (blueprint.traverse(property_set_)
            .in_('property_set')
            .source('system')
            .first)
