# Copyright 2021-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from aos.sdk import schema as s
from aos.sdk import types as bt
from aos.sdk.device_profile.device_profile_schema import (
    device_profile_fields,
    selector_schema_fields,
)
from aos.sdk.graph.schema import RelationshipSchema
from aos.sdk.reference_design.freeform import types as t


DEVICE_PROFILE_FIELDS = dict(
    device_profile_fields,
    selector=s.Optional(
        s.Dict(dict(selector_schema_fields, os=t.OsFamily))))

DEVICE_PROFILE_FIELDS_WITH_ID = dict(
    DEVICE_PROFILE_FIELDS,
    device_profile_id=t.DeviceProfileId)

RESOURCE_ASSIGNED_TO_TARGET_TYPES = ['system', 'interface', 'link']
RESOURCE_ALLOCATED_FROM_TARGET_TYPES = [
    'resource', 'resource_allocation_group', 'local_pool']
GROUP_ASSIGNED_TO_TARGET_TYPES = ['system', 'interface']
RESOURCE_GENERATOR_CONTAINER_TYPE = ['group', 'group_generator']
POOL_OWNER_NODE_TYPES = ['system']


class Schema(s.Schema):
    nodes = {
        'system': s.NodeSchema('system', {
            'label': s.Optional(t.Label()),
            'system_type': t.SystemType,
            'hostname': s.Optional(s.Hostname()),
            'system_id': s.Optional(t.SystemId),
            'deploy_mode': t.DeployMode,
            'management_level': s.ManagementLevel,
        }),
        'device_profile': s.NodeSchema(
            'device_profile',
            DEVICE_PROFILE_FIELDS_WITH_ID
        ),
        'interface': s.NodeSchema('interface', {
            'label': s.Optional(t.Label()),
            'if_type': t.IfType,
            'if_name': s.Optional(t.IfName),
            'description': s.Optional(s.InterfaceDescription()),
            'ipv4_addr': s.SparseOptional(s.IpNetworkAddress()),
            'ipv6_addr': s.SparseOptional(s.Ipv6NetworkAddress()),
            'lag_mode': s.SparseOptional(s.LagModes),
            'port_channel_id': s.SparseOptional(t.PositiveInteger()),
            'port_id': s.Optional(t.PortId),
            'port_speed': s.Optional(s.PortSpeed),
            'transformation_id': s.Optional(t.TransformationId),
            'index': s.Optional(t.IfIndex),
            'member_count': s.SparseOptional(t.PositiveInteger(
                description='Derivative of a number of outbound  "composed_of" '
                            'relationships. Computed for top-level port channel '
                            'interfaces to simplify query construction. '
                            'Not exposed via the API.'))
        }),
        'link': s.NodeSchema('link', {
            'label': s.Optional(t.Label()),
            'link_type': t.LinkType,
            'role': t.LinkRole,
            'speed': s.Optional(s.PortSpeed),
        }),
        'config_template': s.NodeSchema('config_template', {
            'template_id': s.Optional(t.TemplateId),
            'label': t.TemplateLabel,
            'text': t.JinjaTemplate,
        }),
        'property_set': s.NodeSchema('property_set', {
            'label': s.Optional(t.Label()),
            'values': bt.JSONKVMap,
        }),
        # resource allocation
        'resource': s.NodeSchema('resource', {
            'resource_type': t.ResourceType,
            'label': t.ResourceLabel,
            'value': s.Optional(t.ResourceValue),
            'subnet_prefix_len': s.Optional(t.SubnetPrefixLen),
        }),
        'group': s.NodeSchema('group', {
            'label': t.GroupLabel,
            'data': s.Optional(bt.JSONKVMap),
        }),
        'group_generator': s.NodeSchema('group_generator', {
            'label': t.GroupLabel,
            'scope': t.Scope,
        }),
        'resource_generator': s.NodeSchema('resource_generator', {
            'resource_type': t.ResourceType,
            'label': t.ResourceLabel,
            'scope': s.Optional(t.Scope),
            'subnet_prefix_len': s.Optional(t.SubnetPrefixLen),
            'scope_node_pool_label': s.Optional(t.ScopeNodePoolLabel),
        }),
        'local_pool': s.NodeSchema('local_pool', {
            'pool_type': t.LocalPoolType,
            # we can not use t.LocalPoolResourceType because it would be
            # incompatible with CPP graphs upgrades framework
            'resource_type': t.ResourceType,
            'label': t.LocalPoolLabel,
            'definition': t.JSONPoolDefinition,
        }),
        'local_pool_generator': s.NodeSchema('local_pool_generator', {
            'label': t.LocalPoolLabel,
            'pool_type': t.LocalPoolType,
            'resource_type': t.ResourceType,
            'definition': t.JSONPoolDefinition,
            'scope': t.Scope,
        })
    }
    relationships = [
        {
            'source': 'system',
            'type': 'device_profile',
            'target': 'device_profile',
        },
        {
            'source': 'system',
            'type': 'hosted_interfaces',
            'target': 'interface',
        },
        {
            'source': 'interface',
            'type': 'composed_of',
            'target': 'interface',
        },
        {
            'source': 'interface',
            'type': 'link',
            'target': 'link',
        },
        {
            'source': 'config_template',
            'type': 'applied_on',
            'target': 'system',
        },
        RelationshipSchema(
            source_type='system',
            type='property_set',
            target_type='property_set'),
        # resource allocation
        RelationshipSchema(
            source_type='group',
            type='contains',
            target_type='resource',
        ),
        RelationshipSchema(
            source_type='group',
            type='parent',
            target_type='group',
        ),
        # TODO: do we need chains of group generators?
        RelationshipSchema(
            source_type='group_generator',
            type='parent',
            target_type='group',
        ),
        RelationshipSchema(
            source_type='group',
            type='contains',
            target_type='resource_generator',
        ),
        RelationshipSchema(
            source_type='group_generator',
            type='contains',
            target_type='resource_generator',
        ),
        RelationshipSchema(
            source_type='group_generator',
            type='creates',
            target_type='group',
        ),
        RelationshipSchema(
            source_type='resource_generator',
            type='creates',
            target_type='resource',
        ),
        RelationshipSchema(
            source_type='system',
            type='local_pool',
            target_type='local_pool',
            sticky=True,
        ),
        RelationshipSchema(
            source_type='local_pool_generator',
            type='creates',
            target_type='local_pool',
        ),
    ]

    for target_type in RESOURCE_ALLOCATED_FROM_TARGET_TYPES:
        relationships.append(
            RelationshipSchema(
                source_type='resource',
                type='allocated_from',
                target_type=target_type))
        relationships.append(
            RelationshipSchema(
                source_type='resource_generator',
                type='allocated_from',
                target_type=target_type))

    for target_type in RESOURCE_ASSIGNED_TO_TARGET_TYPES:
        relationships.append(
            RelationshipSchema(
                source_type='resource',
                type='assigned_to',
                target_type=target_type))

    for target_type in GROUP_ASSIGNED_TO_TARGET_TYPES:
        relationships.append(
            RelationshipSchema(
                source_type='group',
                type='assigned_to',
                target_type=target_type))


INTERFACE_SCHEMA = s.Object(Schema.nodes['interface'].properties)
