# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=missing-docstring,undefined-variable,invalid-name

"""Base class for defining expectation rendering plugins in reference designs"""

class ExpectationRenderingPlugin(object):
    """Base class for expectation rendering plugins.

       Attributes:
        expectation_store   Instance of ExpectationStore
        indexes             Application index classes
    """
    def __init__(self, expectation_store, indexes=None):
        self.expectation_store = expectation_store
        self.indexes = indexes

    def get_service_system_id_map(self, graph):
        """Returns a dictionary mapping service name to a mapping of node id to
           system id.
           For example:

            {
                'interface': {'leaf1': sn1', 'leaf2': sn2'},
                'lldp': {'leaf1': sn1', 'leaf2': sn2'},
                ...
            }

           Used by BlueprintExpectationGenerator on commit to ensure proper
           expectations are flushed to Aos::Device::<service>Config entities.
           For each reference design, there should be at least one rendering plugin
           that provides this mapping. The mappings from all rendering plugins
           should cover all services for all system ids assigned to the blueprint.

           Args:
            graph   aos.sdk.graph.Graph instance
        """
        return {}

    def on_commit(self, graph):
        """Called when BlueprintExpectationGenerator is about to commit changes
           in expectations for its blueprint. A rendering plugin may choose to
           override this method to update all expectations for a service(s)
           via ExpectationStore.

           Args:
            graph   aos.sdk.graph.Graph instance
        """
