# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""Base class for defining per reference design BlueprintRegistry plugins
   plus helpers
"""

# pylint: disable=missing-docstring

from collections import namedtuple
import six
import logging

logger = logging.getLogger()

class BlueprintSystemMap(object):
    System = namedtuple('System', ['id', 'deploy_mode', 'role', 'device_profile_id'])

    def __init__(self):
        self._systems = {}

    def add_system(self, system_id, deploy_mode='deploy',
                   role='unknown', device_profile_id=''):
        assert not deploy_mode or deploy_mode in [
            'deploy', 'ready', 'undeploy', 'drain']
        if not deploy_mode:
            logger.warning('deploy_mode is unset for system_id %s', system_id)
        self._systems[system_id] = self.System(system_id,
                                               deploy_mode or 'deploy',
                                               role or 'unknown',
                                               device_profile_id)

    def remove_system(self, system_id):
        self._systems.pop(system_id, None)

    def __iter__(self):
        for system in six.itervalues(self._systems):
            yield system

    def __len__(self):
        return len(self._systems)

    def __contains__(self, system):
        return system in six.itervalues(self._systems)

    def __getitem__(self, system_id):
        return self._systems.get(system_id)

    @property
    def system_ids(self):
        return list(six.iterkeys(self._systems))


class BlueprintRegistryPlugin(object):
    """Base class for per reference design plugins to create
       blueprint <-> system mappings
    """
    def _new_map(self):
        return BlueprintSystemMap()

    def get_blueprint_system_map(self, graph):
        """Given grapi.Graph instance, returns an instance of BlueprintSystemMap
           that contains information about each system in the blueprint.
           Must be implemented by reference design.
        """
        raise NotImplementedError()
