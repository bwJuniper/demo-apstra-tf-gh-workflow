# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import annotations

__all__ = [
    'CLIENT_REGISTRY',
]

# pylint: disable=broad-except

import logging
import importlib
import os.path
import sys

LOGGER = logging.getLogger('aos.sdk.reference_design.registry')


CLIENT_REGISTRY: _MAGIC.ref_design_registry = {}
clients_path = os.path.dirname(sys.modules[__name__].__file__)


def extend_class(class1, class2):
    return type(class1.__name__, (class1, class2), {})


def extend_reference_design(ref_design, extension):
    """
    Extend reference design with an extension or another reference design.
    Currently use-case is mainly for Client,
    we can extend this to handle other cases.
    :return: extended clients for reference_design
    """
    for component in ('Client',):
        if not hasattr(extension, component):
            continue

        if not hasattr(ref_design, component):
            result = getattr(extension, component)
        else:
            result = extend_class(getattr(ref_design, component),
                                  getattr(extension, component))

        setattr(ref_design, component, result)

    return ref_design


def normalize_reference_design(name, ref_design):
    if not hasattr(ref_design, 'NAME'):
        ref_design.NAME = name
    if hasattr(ref_design, 'EXTENSIONS'):
        extensions = getattr(ref_design, 'EXTENSIONS')

        for extension in extensions:
            ref_design = extend_reference_design(ref_design, extension)
    return ref_design


# Load reference design clients from aos.sdk.reference_design module
for module in os.listdir(clients_path):

    if module == 'extension':
        continue

    module_path = os.path.join(clients_path, module)
    if not (os.path.isdir(module_path) and
            os.path.isfile(os.path.join(module_path, '__init__.py'))):
        continue

    try:
        design = normalize_reference_design(module,
                                            importlib.import_module(
                                                'aos.sdk.reference_design.'
                                                + module))
        CLIENT_REGISTRY[design.NAME] = design
    except Exception as exc:
        LOGGER.exception(exc)
        LOGGER.error('Failed to load clients for reference design"%s"', module)


