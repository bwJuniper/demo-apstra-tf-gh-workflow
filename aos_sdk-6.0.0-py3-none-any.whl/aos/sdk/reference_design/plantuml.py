# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

""" Renders an arbitrary AOS graph
"""

import jinja2
import os
from aos.sdk.graph import Graph, GraphObserver, copy_graph, BatchUpdateGraph
import aos.sdk.schema as s
from copy import deepcopy
import six
from six.moves import range

def _render_jinja(context):
    """ Renders Jinja template from given reference design topology.
    Returns PlantUML """

    loader = jinja2.FileSystemLoader(os.path.dirname(__file__))
    env = jinja2.Environment(loader=loader,
                             lstrip_blocks=True,
                             trim_blocks=True,
                            )
    template = env.get_template('plantuml.jinja2')
    output = template.render(**context)

    return output


# colors copied from aos-web-ui/src/js/brandPalette.less
BRAND_COLORS = ['red', 'orange', 'olive', 'green', 'teal', 'blue', 'violet',
                'purple', 'pink', 'brown', 'grey']

BRAND_PALETTE = \
    list('%lighten("{}", 60)'.format(color) for color in BRAND_COLORS) + \
    list('%lighten("{}", 30)'.format(color) for color in BRAND_COLORS) + \
    list('%lighten("{}", 90)'.format(color) for color in BRAND_COLORS)

# Preferred directions for relations on diagram.
# It is a dict of relation_types to value of {"up", "left", "right", "down"}
# If 'part_of_rack' is 'up' then node1 will be position
# below node2 on diagram (if possible)
PREFERRED_DIRECTIONS = {
    'part_of_rack': 'up',
    'part_of_redundancy_group': 'down',
    'policy': 'up',
}

def make_property_string(property_data, is_optional=False, definitions=None):
    definitions = definitions or {}
    default = ' default: %s' % property_data['default'] if property_data.get(
        'default') else ''
    type_str = 'unknown'
    value_str = default
    children = {}

    if '$ref' in property_data:
        ref = property_data['$ref'].split('#/definitions/')[-1]
        property_data = definitions[ref]

    required = property_data.get('required', [])
    if 'type' not in property_data:
        type_str = 'ERROR'
        value_str = 'ERROR'
    elif property_data['type'] == 'boolean':
        type_str = 'bool'
    elif property_data['type'] == 'string':
        if 'enum' in property_data:
            type_str = 'one_of'
            value_str = str(sorted(property_data['enum'])) + default
        else:
            type_str = 'string'
    elif property_data['type'] in ('integer', 'number'):
        type_str = {
            'integer': 'int',
            'number': 'float',
        }[property_data['type']]
        int_min = str(property_data.get('minimum', ''))
        int_max = str(property_data.get('maximum',''))
        constraints = []
        if int_min:
            constraints.append(f'min={int_min}')
        if int_max:
            constraints.append(f'max={int_max}')
        value_str = ' '.join(constraints)
        value_str += default

    elif property_data['type'] == 'array':
        type_str = 'list'
        if '$ref' in property_data['items']:
            inner_schema = definitions[property_data['items']['$ref'].split(
                '#/definitions/')[-1]]
            required = inner_schema.get('required', [])
            item_properties = inner_schema['properties']
            inner_type = inner_schema['type']
        else:
            inner_type = property_data['items']['type']
            item_properties = property_data['items'].get('properties')
        if inner_type == 'object':
            inner_type = 'dict'
        constraints = []
        if property_data.get('minItems'):
            constraints.append(f'min_length={property_data["minItems"]}')
        if property_data.get('maxItems'):
            constraints.append(f'max_length={property_data["minItems"]}')
        if property_data.get('uniqueItems'):
            constraints.append('unique')
        if constraints:
            constraints = ' ' + ' '.join(constraints)
        value_str = f"[<{inner_type}>, ...]{constraints}{default}"
        if isinstance(item_properties, dict):
            for key, value in item_properties.items():
                children[key] = make_property_string(
                    value,
                    is_optional=required and key not in required,
                    definitions=definitions)

    elif property_data['type'] == 'object':
        additional_properties = property_data.get('additionalProperties')
        object_properties = property_data.get('properties')
        if (isinstance(additional_properties, dict) and
                additional_properties.get('type')):
            child = make_property_string(
                additional_properties)
            type_str = child['type_str']
            value_str = child['value_str']
        elif isinstance(object_properties, dict):
            type_str = 'dict'
            for key, value in object_properties.items():
                children[key] = make_property_string(
                    value, is_optional=required and key not in required,
                    definitions=definitions)

    elif property_data['type'] == 'any':
        type_str = 'any'
        value_str = f'any{default}'

    else:
        type_str = f"unknown_{property_data['type']}"

    if is_optional:
        value_str += ' <optional>'

    return {
        'type_str': type_str,
        'value_str': value_str,
        'children': children,
    }


def describe_object_properties(schema_obj, definitions=None, required=None,
                               obj_schema_dict=None):
    required = required or []
    properties = {}
    obj_schema_dict = obj_schema_dict or {}
    for property_name, schema_prop in schema_obj.properties.items():
        if property_name in ['property_set', 'tags']:
            continue
        inner_json = obj_schema_dict['properties'][property_name]
        is_optional = isinstance(schema_prop, (s.Optional, s.SparseOptional))
        props = make_property_string(
            inner_json,
            is_optional=(required and property_name not in required) or is_optional,
            definitions=definitions)
        properties[property_name] = {
            'type_str': props['type_str'],
            'value_str': props['value_str'],
            'children': props['children'],
        }
    return properties

def render(new_graph,
           old_graph=None,
           display_schema=True,
           display_nodes=True,
           filter_node_types=None,
           filter_relationship_types=None,
           filename=None,
           changes_only=False,
           use_brand_colors=False,
           use_preferred_directions=False,
           use_narrow_nodes=False,
           legend='',
           title='',
           node_notes=None,
           node_errors=None,
           display_entire_schema=False):
    """ Renders a plantuml diagram of an input graph, helpful for
        visualization and troubleshooting.

        This will write a tmp file for you to open, or you can print it.

    :param new_graph: AOS blueprint Graph() object to render a diagram for
    :param old_graph (optional): AOS blueprint Graph() object to render a diagram for
    :param display_schema: If True, will include a simple drawing of all of the
                          schemas for node types in use for this graph and the
                          defined relationships between their types
    :param display_nodes: If True, draws nodes and relationships between nodes
    :param filter_node_types: If None, display all node types. If list, filter nodes
                       in output to only specified node types.
    :param filter_relationship_types: If None, display all rel types. If list,
                                      filter rels in output to only specified node
                                      types.
    :param filename: If set, will write plantuml text output to this location
    :param changes_only: If set, will only display nodes and relationships that are
                         added, removed, or changed between new graph and old
                         graph.
    :param use_brand_colors: If True, the nodes colors will be different for
                             different node types
                             (Works only if changes_only is False)
    :param use_preferred_directions: If True, the nodes will be located
                                     relative to each other, if possible,
                                     in accordance with PREFERRED_DIRECTIONS
    :param use_narrow_nodes: If True, then the nodes in the diagram will be narrower
                             due to the fact that the nodes IDs become multiline
    :param title (str): Optional title
    :param legend (str): Optional legend
    :param node_notes: A dictionary of node or relationship IDs notes, eg, config
                       {node_id: "note text"}
    :param node_errors: Includes node and relationship errors in node properties.
                   {node_id: ["error", "error"]}
    :param display_entire_schema: If True, will include entire schema even for unused
        node types. This will honor filter_node_types and filter_relationship_types,
        and disregard the display_schema option.

    :return: Rendered PlantUML text.  Feed this into plantuml.com or a renderer
             of your choice (There is a great pycharm plugin)

    Examples:

        from aos.sdk.reference_design.plantuml import render
        graph = create_blueprint()
        graph.add_node('system', role='leaf', system_type='leaf')
        render(graph)
        render(graph, display_schema=False)
        render(graph, filter_node_types=['security_zone'])
        render(graph, filter_relationship_types=['composed_of_systems'])
        render(graph, filename='tmp/foo')

        or

        from aos.sdk.graph import copy_graph
        from aos.sdk.reference_design.plantuml import render

        new_graph = create_blueprint()
        old_graph = create_blueprint()

        rmv = new_graph.add_leaf(**sysargs('removed-leaf'))
        new_graph.add_leaf(**sysargs('same-leaf'))


        copy_graph(old_graph, new_graph, commit=False)
        new_graph.add_leaf(**sysargs('new-leaf'))


        render(new_graph, display_schema=False,
               old_graph, filename='/tmp/render_output.puml')

        For more usage examples, see plantuml_test.py

    """
    schema = new_graph.schema
    node_defns = {}
    rel_defns = {}
    node_notes = node_notes if node_notes else {}
    node_errors = node_errors if node_errors else {}
    if display_entire_schema:
        display_schema = True

    def changed(obj):
        if not changes_only:
            return True
        if obj['changed']:
            return True
        return False

    def filter_nodes(node_type):
        if isinstance(filter_node_types, list) \
                and node_type not in filter_node_types:
            return False
        return True

    def filter_relationships(relationship_type):
        if isinstance(filter_relationship_types, list) \
                and relationship_type not in filter_relationship_types:
            return False
        elif relationship_type == 'tag':
            return False
        return True

    def process_output_objects(
            old_objs: dict, new_objs: dict, obj_type: str) -> dict:
        """ Provides output color formatting based on graph differences between
            old and new graphs.

        :param old_objs: Key-values are node or relationship IDs/values from old
        :param new_objs: Key-values are node or relationship IDs/values from new
        :param obj_type: One of 'node' or 'relationship'
        :return: Key-value mapping of nodes with additional properties to pass to
            the jinja context for rendering, such as:
            color: Specifies the color of the node or relationship arrow
            errors: any node or relationship errors will be displayed inline:
              node: A node will include errors as additional 'properties' within the
                plantuml class
              relationship: Relationship errors are concatnated with escaped newlines
                to allow plantuml positioning of these errors as newlines near
                the arrow label.
            properties:
                Unchanged properties will render with the default color
                style of the plantuml template. For node properties which are
                changing, new properties will re-colored. The old value will
                be red and the new value will be green to indicate change.
        """
        output_objects = {}
        default_color = '#grey' if obj_type == 'relationship' else '#yellow'
        assert obj_type in ['node', 'relationship']

        for new_obj_id, new_obj_data in six.iteritems(new_objs):
            output_objects[new_obj_id] = deepcopy(new_obj_data)
            output_obj = output_objects[new_obj_id]
            output_obj['changed'] = False
            output_obj['errors'] = node_errors.get(new_obj_id, [])

            # PROPERTIES
            if new_obj_id in old_objs:  # Node is neither new or old
                output_objects[new_obj_id]['color'] = default_color
                old_obj_data = old_objs[new_obj_id]

                old_props = set(old_obj_data['properties'].keys())
                new_props = set(new_obj_data['properties'].keys())
                for same_prop in old_props & new_props:  # Same
                    old_value = old_obj_data['properties'][same_prop]
                    new_value = new_obj_data['properties'][same_prop]

                    if old_value != new_value:
                        del output_obj['properties'][same_prop]
                        output_obj['properties'][
                            '- <color:red>%s' % same_prop] = \
                            '%s</color>' % old_value
                        output_obj['properties'][
                            '+ <color:green>%s' % same_prop] = \
                            '%s</color>' % new_value
                        output_obj['changed'] = True

                for removed_prop in old_props - new_props:  # Removed
                    old_value = old_obj_data['properties'][removed_prop]

                    output_obj['properties'][
                        '- <color:red>%s' % removed_prop] = \
                        '%s</color>' % old_value
                    output_obj['changed'] = True

                for added_prop in new_props - old_props:  # Added
                    new_value = new_obj_data['properties'][added_prop]

                    del output_obj['properties'][added_prop]
                    output_obj['properties'][
                        '+ <color:green>%s' % added_prop] = \
                        '%s</color>' % new_value
                    output_obj['changed'] = True

            elif new_obj_id not in old_objs:  # Node is new
                if old_graph:
                    output_obj['color'] = '#green'
                elif 'color' not in output_objects[new_obj_id]:
                    output_obj['color'] = default_color
                output_obj['changed'] = old_graph is not None

        for old_node_id, old_obj_data in six.iteritems(old_objs):

            if old_node_id not in new_objs:
                output_objects[old_node_id] = deepcopy(old_obj_data)
                output_obj = output_objects[old_node_id]
                output_obj['color'] = '#red'
                output_obj['changed'] = True
                # No errors on removed nodes, but keep syntax uniform
                output_obj['errors'] = []  # For uniformity with new nodes.

        # END OF PROPERTIES

        # Relationships are rendered differently in plantuml where newline handling
        # is sensitive. In order to have extra metadata context on relationships
        # (properties, relationship errors), these must be concatenated
        # in jinja. Transform key,value structures into compatible plantuml
        # syntax. This syntax requires escaped \n newline characters that appear
        # on the same line within the output plantuml.
        # There are also some minor style colorization differences between nodes
        # and relationships that are adjusted to minimize visual clutter.
        if obj_type == 'relationship':
            for output_rel_id, output_rel in output_objects.items():
                if output_rel['properties']:
                    output_rel['properties'] = (
                            '\\n' + '\\n'.join(
                        f'{k}: {v}' for k, v in sorted(
                            output_rel['properties'].items(),
                            key=lambda x: x[0]))
                    )
                else:
                    output_rel['properties'] = ''

                if output_rel['errors']:
                    # Format errors 'inline' in a single arrow.
                    output_rel['errors'] = (
                            '\\n<color:red>ERRORS:\\n' +
                            '\\n'.join(
                                f'<color:red>{error}</color>'
                                for error in sorted(output_rel['errors']))
                    )
                else:
                    output_rel['errors'] = ''

                # Default color for relationships is '#grey', but change to '#yellow'
                # if only relationship properties are changing, not their
                # relationship adjacencies with other nodes.
                if (
                        output_rel['changed'] and
                        output_rel_id in new_objs and
                        output_rel_id in old_objs
                ):
                    output_rel['color'] = '#yellow'

        return output_objects

    def get_schema_dict(obj_schema, obj_type):
        assert obj_type in ['node', 'relationship']
        obj_schema_properties = s.Object(obj_schema.properties)
        obj_schema_dict = s.json_schema(obj_schema_properties)
        if obj_type == 'relationship':
            obj_schema_dict['source_type'] = obj_schema.source_type
            obj_schema_dict['target_type'] = obj_schema.target_type
            obj_schema_dict['sticky'] = obj_schema.sticky
            obj_schema_dict['type'] = obj_schema.type
        obj_schema_dict['properties'] = describe_object_properties(
            obj_schema,
            definitions=obj_schema_dict.get('definitions'),
            required=obj_schema_dict.get('required', []),
            obj_schema_dict=obj_schema_dict)
        return obj_schema_dict

    def relationship_key(relationship):
        return f'{relationship.source_type},{relationship.type},{relationship.target_type}'  # pylint: disable=line-too-long

    all_node_schemas = {
        n_type: n_data for n_type, n_data in schema.nodes.items()
        if filter_nodes(n_type)}
    all_relationship_schemas = {
        relationship_key(rel_schema): rel_schema
        for rel_schema in schema.relationships
        if filter_relationships(rel_schema.type)
    }
    node_schemas = {}
    relationship_schemas = {}
    if display_entire_schema:
        node_schemas = all_node_schemas
        relationship_schemas = all_relationship_schemas
    elif display_schema:
        relationship_schemas = {}
        # Limit schemas in the context to only nodes which are visible in the
        # graph.
        node_schemas = {n_type: all_node_schemas[n_type]
                        for n_type in {n.type for n in new_graph.get_nodes()
                                       if filter_nodes(n.type)}}

        # relationship types are not a unique key as the 'type' can be used
        # between different relationship schemas. Collect all types from all
        # relationships.
        seen_rel_types = {r.type for r in new_graph.get_relationships()
                           if filter_relationships(r.type)}
        for rel_key, rel_schema in all_relationship_schemas.items():
            # "Tag" schemas are heavily duplicated
            if rel_schema.type not in seen_rel_types:
                continue
            # If the source and destination node types are not used by node type
            # then do not include the unused relationship schema in the dump.
            if rel_schema.source_type not in node_schemas:
                continue
            if rel_schema.target_type not in node_schemas:
                continue
            relationship_schemas[rel_key] = rel_schema

    node_types_colors = {node_type: (BRAND_PALETTE[i % len(BRAND_PALETTE)])
                         for i, node_type in enumerate(node_schemas, start=1)}

    for node_type, node_schema in node_schemas.items():
        node_defns[node_type] = get_schema_dict(node_schema, 'node')
        if use_brand_colors:
            node_defns[node_type]['color'] = node_types_colors[node_type]
    for relationship_key, relationship_schema in relationship_schemas.items():
        rel_defns[relationship_key] = get_schema_dict(
            relationship_schema, 'relationship')
        if use_brand_colors:
            target_color = node_types_colors[relationship_schema.target_type]
            rel_defns[relationship_key]['color'] = target_color


    def nodes():
        def node_format(node):
            """ Some ref design schema objects are just loud and too busy. """
            dict_node = {'properties': deepcopy(node.properties),
                         'id': node.id,
                         'type': node.type}
            if node.type == 'device_profile':
                dict_node['properties']['ports'] = 'removed'
            if node.type == 'interface_map':
                dict_node['properties']['interfaces'] = 'removed'
            if node.type == 'logical_device':
                dict_node['properties']['json'] = 'removed'
            if not changes_only and use_brand_colors:
                dict_node['color'] = node_types_colors[node.type]
            return dict_node

        new_nodes = {n.id: node_format(n) for n in new_graph.get_nodes()
                     if filter_nodes(n.type)}
        old_nodes = {n.id: node_format(n) for n in
                     old_graph.get_nodes()
                     if filter_nodes(n.type)} if old_graph else {}

        return process_output_objects(
            old_objs=old_nodes,
            new_objs=new_nodes,
            obj_type='node')

    def relationships(output_nodes):

        def rel_format(rel):
            return {
                'source_id': rel.source_id,
                'target_id': rel.target_id,
                'type': rel.type,
                'id': rel.id,
                'properties': rel.properties,
            }

        new_rels = {r.id: rel_format(r) for r in new_graph.get_relationships()
                    if filter_relationships(r.type)}
        old_rels = {r.id: rel_format(r) for r in
                    old_graph.get_relationships()
                    if filter_relationships(r.type)} if old_graph else {}

        output_rels = process_output_objects(
            old_objs=old_rels,
            new_objs=new_rels,
            obj_type='relationship',
        )

        return [
            r for r in output_rels.values()
            if r['source_id'] in output_nodes and
               r['target_id'] in output_nodes]

    # need to post-process nodes
    output_nodes = nodes()
    output_rels = relationships(output_nodes)

    # Display unchanged nodes for changed relationships
    if changes_only:
        def has_changed_rel(node):
            node_id = node['id']

            # pylint: disable=consider-using-in
            if [r for r in output_rels if (r['changed']) and \
                    (node_id == r['source_id'] or node_id == r['target_id'])]:
                return True
            return False

        output_nodes = {k: v for k, v in six.iteritems(output_nodes) if
                        changed(v) or has_changed_rel(v) or k in node_notes}
        output_rels = [r for r in output_rels if changed(r)]

    if use_narrow_nodes:
        def narrow(long_str, n=8):
            chunks = [long_str[i:i + n] for i in range(0, len(long_str), n)]
            return '\\n'.join(chunks)

        # make node IDs narrower by splitting them over multiple lines
        for node in output_nodes.values():
            node['id'] = narrow(node['id'])
        output_nodes = {narrow(id): node for id, node in six.iteritems(output_nodes)}
        for rel in output_rels:
            rel['source_id'] = narrow(rel['source_id'])
            rel['target_id'] = narrow(rel['target_id'])

    context = {
        'schema': {'nodes': node_defns,
                   'relationships': rel_defns} if display_schema else {},
        'nodes': output_nodes if display_nodes else {},
        'relationships': output_rels if display_nodes else {},
        'display_schema': display_schema,
        'legend': legend,
        'title': title,
        'filename': filename if filename else '',
        'node_notes': {node_id: note
                       for node_id, note in six.iteritems(node_notes)
                       if node_id in output_nodes},
    }
    if use_preferred_directions:
        context['preferred_directions'] = PREFERRED_DIRECTIONS

    output = _render_jinja(context)
    if filename:
        try:
            with open(filename, 'w') as f:
                f.write(output)
        except (OSError, IOError):
            pass
    return output


def monitor_commits(
        graph,
        filename="/tmp/monitor_commits.puml",
        versioned_filename=False,
):
    """ Monitors graph commits, and creates a diagram for visual output on each
        corresponding graph change.

        This function is used to easily visually represent graph changes.

        This function only shows changed nodes and relationships in the output
        diagram.  If this is the first commit to a blueprint, all of the graph
        changes will appear as 'added' (because they are Diff from an empty graph)

        To use:

        from aos.sdk.reference_design.plantuml import monitor_commits

        monitor_commits(blueprint, filename='tmp/monitor_commits.puml')

        On every successive graph commit, this filename will be written to.

        If the variable 'versioned_filename' is specified, then a new filename
        per graph commit version will be displayed. This can help a developer
        to make many graph changes and observe the incremental deltas between
        those two changes.

    :param graph: AOS Graph to monitor changes for
    :param filename (optional): Filename to write plantUML to.
                                Defaults to /tmp/monitor_commits.puml
    :param versioned_filename: If True, each graph commit will
        write to a unique filename per graph commit version. This allows a
        commit-by-commit visual view of a graph. This is helpful for complicated
        unit tests which perform many commits and visualization of deltas between
        each commit is needed.
        Given filename='/tmp/monitor_commits.puml', this flag will write
        to output filenames '/tmp_monitor_commits_v1.puml',
        '/tmp_monitor_commits_v2.puml' per graph commit version.
    """

    if versioned_filename and not filename.endswith('.puml'):
        raise ValueError(
            f"Filename {filename} must end with .puml for versioned_filename=True")
    def gen_filename(graph):
        if not versioned_filename:
            return filename
        return filename.split('.puml')[0] + f'_v{graph.version}.puml'

    def render_change(old_graph, new_graph):
        render(
            new_graph, old_graph,
            display_schema=False,
            changes_only=True,
            filename=gen_filename(new_graph))
        copy_graph(new_graph, old_graph, commit=False)

    # We will store a copy of the graph in the original graph as 'old_graph'
    # attribute as generic class storage. This isn't necessarily efficient, but
    # because this is a debug tool, we don't need to worry about this detail.
    if not hasattr(graph, 'old_graph'):
        graph.old_graph = BatchUpdateGraph(Graph(schema=graph.schema))
        copy_graph(graph, graph.old_graph, commit=False)

    graph.add_observer(GraphObserver(
        on_graph=lambda _: render_change(graph.old_graph, graph),
    ))
