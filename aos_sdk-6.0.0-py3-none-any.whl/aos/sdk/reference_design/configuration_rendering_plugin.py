# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=missing-docstring,undefined-variable,invalid-name

"""Base class for defining configuration rendering plugins in reference designs"""

from collections import namedtuple

SystemInfo = namedtuple('SystemInfo', [
    'system_node_id', 'device_id', 'role', 'os_family'])


class ConfigurationRenderingPlugin(object):
    """Base class for configuration rendering plugins. Derived classes can have
    methods decorated with @aos.grappa.rule_engine.rule annotations for any local
    bookkeeping purposes

    An instance of this class is created at startup, one for each blueprint in the
    system. As blueprints get created and removed, corresponding instances are
    created and discarded. The instance lifecycle is same as the lifecycle of
    corresponding blueprint or deployment agent, whichever is smaller

    Attributes:
        graph - an instance of aos.sdk.graph.Graph
    """
    def __init__(self, graph):
        self.graph = graph

    def get_system_ids(self):
        """
        Get an iterable of system ids that are present in the current blueprint
        """
        raise NotImplementedError()

    def get_renderable_system_infos(self):
        """
        Returns SystemInfo structure for all renderable systems in the blueprint
        """
        raise NotImplementedError()

    def get_system_os_family(self, node_id):
        """
        Returns given system's (by graph node ID) OS family.
        When OS family can not be determined returns None.
        When node with given ID is not found raises ValueError.
        """
        raise NotImplementedError()

    @classmethod
    def generate_negation_config(cls, device_profile_dict, old_ctx):
        """
        This method generates the negation of config based on the old rendering
        context(new rendering context is None).

        :return: An instance of ConfigGenerationResult
        """
        raise NotImplementedError()

    def skip_config_deploy(self, system_id):
        """
        Return True if config deploy is not allowed on a system based on its current
        state as per reference design.
        """
        return False

    def generate_config(
            self, system_id, current_context, config_apply_mode, config_source,
            aos_version, device_info, device_context_only=False, user_config=None):
        """
        This method is called by the framework whenever it determines a new config
        for the specified system_id needs to be generated

        Attributes:
            system_id: system id for which to generate the config
            current_context: context returned from previous call to generate_config
                This will be None for the maiden call or if previous call returned
                no context
            config_apply_mode: incremental or complete.
            config_source: trigger(s) for current config push on the device.
                Following is the explanation for various config sources:
                    blueprint; // config push due to blueprint intent update
                                  and device in BP
                    deviceStatus; // config push due to device deployment
                                     status::state updates
                    deviceMgmtStatus; // config push due to device
                                         being ack'ed / approved in AOS
                    fullConfigApi; // config push due to full config push API
                    aosUpgrade; // config push due to AOS version update
                    nosUpgrade; // config push as part of NOS upgrade
            aos_version: pass the current aos_version, this is used to determine
            if an upgrade is needed
            device_info: object of DeploymentDeviceInfo consisting device information
             os_version, management_ip
            device_context_only: If True, only returns the device context and does
                not render any config_text in the ConfigGenerationResult. This is
                used to preview device context only without executing any config
                templates, jinjas, etc. This is desired because a jinja rendering
                error may be caused by invalid context usage, and it is too
                difficult to diagnose template issues when the context required to
                render is not retrievable due to those raised exceptions.
            user_config: Passes user config from mounted device management user
                config, for purposes of reading the 'location' attribute or otherwise

        Return an instance of ConfigGenerationResult
        """
        raise NotImplementedError()

    def generate_preview_config(self, system_id, old_context, new_context):
        """
        This is used to generate config summary.

        When this function is called, it generates config from jinjas with tags.
        example: AOS_CONFIG_PREVIEW_TAG PREFIX_LISTS
        This is then used to summarize contents for UI/aos upgrade preview

        :param old_context:
        :param new_context:
        :return:
        """
        # new_context must have
        # Used only during upgrade preview
        return """
        AOS_CONFIG_PREVIEW_TAG NONE
        """


class ConfigGenerationResult(object):
    """Class to represent result of config generation of a device."""
    def __init__(
            self, succeeded, config_string, running_config='',
            config_type='service', context=''):
        """
        succeeded: Indicates if config generation succeeded or failed.
        config_string: config string generated for the device.
        running_config: config snippets that should match running config
            upon successful deploy
        config_type: optional opaque string accompanying this config
        context: optional opaque string to store any associated context
        """
        self.succeeded = succeeded
        self.config_string = config_string
        self.running_config = running_config
        self.config_type = config_type
        self.context = context

    def __repr__(self):
        return 'Success: %s, config_type: %s, config_string: %s, \
            running_config: %s, context: %s' % (
                self.succeeded, self.config_type, self.config_string,
                self.running_config, self.context)
