# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


def get_os_family_for_system_id(system_id, aos_library):
    device_info = aos_library.device_infos.get(system_id)
    if device_info is None:
        return None
    return device_info.osFamily


def get_agent_id_for_system_id(system_id, aos_library):
    onbox_device_id_index = aos_library.onbox_device_id_index
    agent_id = onbox_device_id_index.serialNumberToUuid.get(system_id)
    if agent_id:
        return agent_id

    offbox_admin_configs = aos_library.offbox_admin_configs
    offbox_admin_statuses = aos_library.offbox_admin_statuses

    for config in offbox_admin_configs:
        agent_id = config.name
        status = offbox_admin_statuses.get(agent_id)
        if status and status.serialNumber == system_id:
            return agent_id

    return None
