# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import six


class DiffInputPlugin(object):
    element_type = None
    Schema = None

    @classmethod
    def make_element_diff(cls):
        return None

    @classmethod
    def make_element_digest(cls):
        return None

    def __init__(self, graph, facade):
        self.facade = facade
        self.output_graph = graph

    def on_commit(self, graph):
        pass

    def get_state(self):
        """Get state kept across commits."""
        return {}

    def set_state(self, state):
        """Override state kept across commits."""

    def clean_up_stale_entries(self, graph):
        for node in list(self.output_graph.get_nodes(self.element_type)):
            if graph.get_node(node.id) is None:
                self.output_graph.del_node(node)

    @staticmethod
    def format_json_output_for_diff(graph):
        graph_json = graph.json()

        return {
            node["id"]: {
                property_name: property_value
                for property_name, property_value in six.iteritems(node)
                if property_name not in ["id", "tags", "type"]
            }
            for node in six.itervalues(graph_json["nodes"])
        }

    @staticmethod
    def get_source_version(graph):
        return graph.version


class CacheDiffInputPlugin(object):
    element_type = None

    @classmethod
    def make_element_diff(cls):
        return None

    @classmethod
    def make_element_digest(cls):
        return None

    @staticmethod
    def format_json_output_for_diff(cache_entry, cache_encoder):
        if not cache_entry.data:
            return {}

        data = cache_encoder.decode(cache_entry.data)

        return {
            node["id"]: {
                property_name: property_value
                for property_name, property_value in six.iteritems(node)
                if property_name not in ["id", "tags"]
            }
            for node in data
        }

    @staticmethod
    def get_source_version(cache_entry):
        return cache_entry.sourceVersion.get('graph', 0)
