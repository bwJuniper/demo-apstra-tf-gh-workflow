# Copyright 2022-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula
'''
DiffRenderingPlugin is required for ConfigDiffRenderingAgent that uses a
special version of graph to generate diffs for systems.

An idea of Config Rendering Graph is following: let's have a graph that tracks
an original one but patches each system pretending it is deployed. This is
required for ConfigRenderingPlugin to generate a correct configuration for a
system. So, if we have a 'old' system and 'new' one, then we can generate
configurations for them and emit a diff.

DiffRenderingPlugin defines if node has to be filtered out from patching (e.g
exclude all non-leaf systems) and how to patch them so ConfigRenderingPlugin
can do its job.
'''

import abc
import six


class Base(six.with_metaclass(abc.ABCMeta, object)):
    def __init__(self, graph):
        self._graph = graph

    @abc.abstractmethod
    def get_nodes(self):
        '''This method returns iterator for nodes that are
        potentially required to be patched.
        '''
        raise NotImplementedError()

    @abc.abstractmethod
    def need_to_patch(self, node):
        '''This method verifies if given node has to be patched using
        this plugin.
        '''
        raise NotImplementedError()

    @abc.abstractmethod
    def get_node_patch(self, node):
        '''This method generates a map with property updated for
        a given node. If node should not be patched, then empty dict
        has to be returned.

        In other words, you can safely do

            graph.set_node(node, **plugin.get_node_patch(node))
        '''
        raise NotImplementedError()


class Dummy(Base):
    '''Dummy is a base implementation of DiffRenderingPlugin that skips all
    potential patching and returns no updates for any node.
    '''

    def get_nodes(self):
        return iter(tuple())

    def need_to_patch(self, node):
        return False

    def get_node_patch(self, node):
        return {}
