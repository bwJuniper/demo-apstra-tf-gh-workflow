# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import absolute_import
from __future__ import division

__all__ = [
    'Facade',
    'BlueprintCacheFacade',

    # errors
    'ConflictError',
    'FacadeError',
    'ResourceNotFoundError',

    # decorators
    'web_api',
    'arg_schema',
    'result_schema',
    'modifier',
    'blueprint_initializer',
    'multi_stage',
    'action_read',
    'skip_arg_schema',
    'insert_staging_graph',
    'init_blueprint_explicitly',
    'INIT_BLUEPRINT_DATA_SCHEMA',
    'supports_batch',

    'UserContext',
]

from collections import namedtuple
from functools import partial

import six

from aos.sdk.aos_library import AosLibraryBase
from aos.sdk.schema import Optional, Object, Dict, Any, ValidationError
from aos.sdk.utils import json_unicode_to_str


def _arg_schema_from_object(schema):
    assert isinstance(schema, Object)
    def wrapper(f):
        f.arg_schema = schema
        return f
    return wrapper


def arg_schema(**fields):
    schema = Object(fields)

    def wrapper(f):
        f.arg_schema = schema
        return f
    return wrapper


def skip_arg_schema():
    def wrapper(f):
        f.skip_arg_schema = True
        return f
    return wrapper


arg_schema.from_object = _arg_schema_from_object


def result_schema(schema=None):
    if schema is None:
        schema = Optional(Object({}), load_default=lambda: {})

    def wrapper(f):
        f.result_schema = schema
        return f
    return wrapper


Route = namedtuple('Route', ['path', 'methods', 'doc', 'status_code'])


def web_api(path, method='GET', doc=None, skip_result_schema_dump=False,
            status_code=None, deprecated=None, removed=None):
    assert method in ['DELETE', 'GET', 'PATCH', 'POST', 'PUT', 'OPTIONS']

    if status_code is None:
        if method in ['PUT', 'PATCH', 'DELETE']:
            status_code = 204
        elif method == 'POST':
            status_code = 201
        else:
            status_code = 200

    def wrapper(f):
        f.route = Route(path, methods=[method], doc=doc, status_code=status_code)
        f.skip_result_schema_dump = skip_result_schema_dump
        f.task_type = (method, path)
        f.deprecated = deprecated
        f.removed = removed
        return f

    return wrapper


def modifier(f):
    f.modifier = True
    return f


def is_multi_stage(f):
    return getattr(f, 'multi_stage', False)


def multi_stage(f):
    """Indicates that the wrapper facade method has multiple execution stages.

       Currently only 1 type of multi-stage facade is supported.
       A facade API handler is broken into 2 stages:

       1. First, it executes in the Web server. Using the relevant scotch libraries,
          the handler extracts the necessary information from Sysdb and returns
          an updated payload (dictionary). This updated payload is passed to the
          task executor agent.

       2. Second, task executor agent invokes stage 2 (a.k.a. task stage).
          The task stage method is invoked with the updated payload from stage 1.
          The result of stage 2 is validated by the facade's result_schema, if
          the schema available and skip_result_schema_dump is False.

       Once a method is decorated with multi_stage, a new decorator task_stage
       is created for you to decorate another method for stage 2.

       For example:

            @arg_schema(
                entity_id=schema.s.String(),
                foo=schema.String(),
            )
            @result_schema(schema.Dict({
                'id': schema.String(),
            })
            @web_api('/multi/<entity_id>', method='PATCH')
            @modifier
            @multi_stage
            def multi_stage_facade(self, entity_id, foo):
                entity = open_entity_else_404(entity_id)
                nodes = self.graph.traverse(...)
                node_id, bar = extract_info(entity, nodes)
                return {
                    'node_id': node_id,
                    'bar': bar,
                }

            @multi_stage_facade.task_stage
            def multi_stage_facade_task(self, node_id, bar):
                # Update config blueprint
                self.graph.set_node(node_id, bar=bar)
                return {'id': node_id}

       The example above defines the API endpoint PATCH /multi/<entity_id>.
       As usual, the url parameter 'entity_id' and request JSON payload key
       'foo' are provided when the API handler method 'multi_stage_facade'
       is invoked. The main differences for multi-stage facade are as follows:

       - The stage1 method could return a dictionary that has a different schema
         compared to the PATCH payload schema.
       - The stage2 method is invoked with this new dictionary as kwargs
       - The 'result_schema' validates the return value of the stage2 method
         'multi_stage_facade_task'
       - 'multi_stage_facade' is executed in the Web server with access to
         all blueprint types, IBA control/data plane state, design phase
         entities, etc.
       - 'multi_stage_facade_task' is executed in the blueprint task agent,
         which has limited access to Sysdb state
    """
    if getattr(f, 'multi_stage', None):
        raise RuntimeError('Method %s already decorated as multi-stage' % \
                           f.__name__)

    def stage(func, stage_name):
        if stage_name in f.exec_stages:
            raise RuntimeError('Function %s already has stage: %s method: %s' % \
                               f.__name__, stage_name, func.__name__)
        f.exec_stages[stage_name] = func
        return func

    def task_stage(func):
        return stage(func, 'task')

    f.multi_stage = True
    f.exec_stages = {}
    f._stage = stage
    f.task_stage = task_stage
    return f


def exec_all_stages(f, facade, **kwargs):
    response = f(facade, **kwargs)
    if is_multi_stage(f):
        for stage_name in ['task',]:
            stage = f.exec_stages[stage_name]
            new_response = stage(facade, **response)
            response = new_response
    return response


def get_task_stage(f):
    return f.exec_stages.get('task', None)


def insert_staging_graph(f):
    """ Indicates that wrapped facade method requires "staging_graph" attribute
    to be injected into the Facade instance.
    """
    f.insert_staging_graph = True
    return f


def action_read(f):
    """Indicate that wrapped facade method should have read action.

    The action is used to determine correct authorization permission.
    """

    f.action = 'read'
    return f


def action_write(f):
    """Indicate that wrapped facade method should have write action.

    The action is used to determine correct authorization permission.
    """

    f.action = 'write'
    return f


def blueprint_initializer(init_type, schema, skip_validation=False,
                          is_default=False):
    def wrapper(f):
        f.blueprint_init_type = init_type
        f.blueprint_init_schema = schema
        f.blueprint_init_skip_validation = skip_validation
        f.is_default_blueprint_initializer = is_default
        return f
    return wrapper


class FacadeError(Exception):
    def json(self):
        return self.args[0] if self.args else str(self)


class ResourceNotFoundError(FacadeError):
    def __init__(self, *args):
        if not args:
            args = ('Resource not found',)
        super(ResourceNotFoundError, self).__init__(*args)


class ConflictError(FacadeError):
    pass


INIT_BLUEPRINT_DATA_SCHEMA = Dict(Any())

TYPE_MISSING_IN_SCHEMA_ERROR_TEMPLATE = (
    'Schema load was explicitly requested for node or relationship with type "{}", '
    'but it is missing from the schema')

EXTRA_PROPERTIES_ERROR_TEMPLATE = ('Entity with type "{}" has properties that are '
                                   'not in the schema: {}')


def _explicit_schema_load(schema, types_require_load, _type, data):
    """ Explicitly load schema for requested types

    It's preferable to explicitly do "schema.load" for nodes and relationships which
    have nested properties in their schema. Otherwise, this might lead to
    inconsistencies between config/staging/deployed/backup graphs when "explicit"
    blueprint initializer is used.
    """
    if _type not in types_require_load:
        return data

    if _type not in schema:
        raise ValidationError(TYPE_MISSING_IN_SCHEMA_ERROR_TEMPLATE.format(_type))

    id_in_data = 'id' in data
    _id = data.pop('id', None)

    entity_schema = schema[_type]
    extra_properties = set(data.keys()) - set(entity_schema.properties.keys())
    if extra_properties:
        raise ValidationError(
            EXTRA_PROPERTIES_ERROR_TEMPLATE.format(_type, sorted(extra_properties)))

    loaded_data = entity_schema.load(data)
    if id_in_data:
        loaded_data['id'] = _id
    return loaded_data


# TODO(michael): Improve schema and validation error reporting
def init_blueprint_explicitly(graph, data, types_require_explicit_schema_load=None):
    '''Initialize blueprint with explicit graph data'''
    data = json_unicode_to_str(data)

    types_require_explicit_schema_load = types_require_explicit_schema_load or {}
    # Note that relationships are not "explicitly loaded" because there are no use
    # cases with complex schemas so far. Also, relationship schema is used a bit
    # differently than node schema, e.g. "sticky" property is not stored in the
    # Relationship object itself but is inspected via accessing the schema.
    explicit_nodes_schema_load = partial(
        _explicit_schema_load, graph.schema.nodes,
        types_require_explicit_schema_load.get('nodes', ()))

    for idx, node in enumerate(data['nodes']):
    # TODO(vkrasikov): to fix error (AOS-25763)
    #  ===
    #  Failed to create a blueprint
    #  {
    #   "nodes": {
    #     "0": "type not specified"
    #   }
    #  }
    #  ===
    #  suggest replacing the line:
    #  for idx, node in enumerate(data['nodes']):
    #  to
    #  for idx, (id, node) in enumerate(data['nodes'].iteritems()):
        if 'type' not in node:
            raise ValidationError({
                'nodes': {idx: 'type not specified'}
            })
        try:
            node_type = node.pop('type')
            if node_type != 'metadata':
                graph.add_node(node_type,
                               **explicit_nodes_schema_load(node_type, node))
        except ValueError as exc:
            err = ValidationError({
                'nodes': {idx: exc.args[0]}
            })
            six.raise_from(err, exc)

    for idx, rel in enumerate(data['relationships']):
        for attr in ['type', 'source_id', 'target_id']:
            if attr not in rel:
                raise ValidationError({
                    'relationships': {idx: '%s not specified' % attr}
                })
        try:
            rel_type = rel.pop('type')
            source = rel.pop('source_id')
            target = rel.pop('target_id')
            graph.add_relationship(rel_type, source, target, **rel)
        except ValueError as exc:
            err = ValidationError({
                'relationships': {idx: exc.args[0]}
            })
            six.raise_from(err, exc)


BatchApiHandle = namedtuple('BatchApiHandle', ['id_extractor'])


BATCH_SUPPORT_API_DESCRIPTION = 'Supported by Batch mutation API'


def supports_batch(id_field=None):
    def wrapper(endpoint):
        # in order for Local ID to be usable with an endpoint that creates the
        # resource we need to be able to figure out the ID of the resource given
        # the result -- this is something that "ID extractor" is doing, it accepts
        # the facade endpoint result and extract the Resource ID from it;
        endpoint.batch_api_handle = BatchApiHandle(
            id_extractor=(lambda result: result[id_field]) if id_field else None)
        return endpoint
    return wrapper


def check_endpoint_supports_batch(endpoint):
    return getattr(endpoint, 'batch_api_handle', None) is not None


UserContext = namedtuple('UserContext', ['user_id', 'design', 'authorizer'])


class Facade(object):
    def __init__(self, graph, aos_library=None, blueprint_type="staging",
                 context=None):
        self.graph = graph
        self.blueprint_type = blueprint_type
        self.aos_library = aos_library or AosLibraryBase()
        self.context = context

    def blueprint_digest(self):
        """Gets a digest of the blueprint
           Reference design should override this function to return customized
           digest
        """

    @property
    def user_context(self):
        if not self.context:
            return UserContext(None, None, None)

        return UserContext(self.context.user_id, self.design,
                           self.context.blueprint_authorizer)


class BlueprintCacheFacade(object):
    def __init__(self, cache_dir):
        self.cache_dir = cache_dir
