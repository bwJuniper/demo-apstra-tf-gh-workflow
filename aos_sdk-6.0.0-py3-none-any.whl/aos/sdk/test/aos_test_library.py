# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=redefined-builtin

from aos.sdk.aos_library import AosLibraryBase, AosLibraryResources
from aos.sdk.utils import cachedproperty
import six


class AosTestLibraryResources(AosLibraryResources):
    def __init__(self):
        super(AosTestLibraryResources, self).__init__()
        self._items = {}
        self._refs = {}

    def list(self):
        return list(six.itervalues(self._items))

    def get(self, id):
        return self._items.get(id)

    def add(self, id, item):
        action = 'updated' if id in self._items else 'added'
        self._items[id] = item
        self._notify(item, action)

    def remove(self, id):
        if id not in self._items:
            return

        item = self._items[id]
        del self._items[id]
        self._notify(item, 'removed')

    def clear(self):
        for id in list(self._items.keys()):
            self.remove(id)

    def add_ref(self, id, referral_type, referral_id):
        if id not in self._refs:
            self._refs[id] = []
        self._refs[id].append((referral_type, referral_id))

    def remove_ref(self, id, referral_type, referral_id):
        if id not in self._refs:
            return
        ref = (referral_type, referral_id)
        refs = self._refs[id]
        if ref not in refs:
            return
        refs.remove(ref)

    def list_refs(self):
        return {
            k: sorted(v)
            for k, v in six.iteritems(self._refs)
        }

    def get_refs(self, id):
        return sorted(self._refs.get(id, []))


class AosTestLibrary(AosLibraryBase):
    def __init__(self, *args, **kwargs):
        super(AosTestLibrary, self).__init__(*args, **kwargs)
        self._service_lldp_data = {}
        self._device_info = {}

    @cachedproperty
    def logical_devices(self):
        return AosTestLibraryResources()

    @cachedproperty
    def interface_maps(self):
        return AosTestLibraryResources()

    @cachedproperty
    def interface_maps_digest(self):
        return AosTestLibraryResources()

    @cachedproperty
    def device_profiles(self):
        return AosTestLibraryResources()

    @cachedproperty
    def rack_types(self):
        return AosTestLibraryResources()

    @cachedproperty
    def design_templates(self):
        return AosTestLibraryResources()

    @cachedproperty
    def external_routers(self):
        return AosTestLibraryResources()

    @cachedproperty
    def property_sets(self):
        return AosTestLibraryResources()

    @cachedproperty
    def config_templates(self):
        return AosTestLibraryResources()

    @cachedproperty
    def device_infos(self):
        return AosTestLibraryResources()

    @cachedproperty
    def device_statuses(self):
        return AosTestLibraryResources()

    @cachedproperty
    def devices_pristine_config(self):
        return AosTestLibraryResources()

    def get_service_lldp_data(self, system_id):
        return self._service_lldp_data.get(system_id)

    def set_service_lldp_data(self, system_id, data):
        self._service_lldp_data[system_id] = data

    def get_device_info(self, system_id):
        return self._device_info.get(system_id)

    def set_device_info(self, system_id, data):
        self._device_info[system_id] = data
