# Copyright 2024-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from aqa.framework import aqa_test
from warnings import catch_warnings


class WarningsTest(aqa_test.TestCase):
    def test_import(self):
        with catch_warnings(record=True) as warnings:
            # OK
            import aos.sdk.reference_design.extension.tags
            self.assertEqual(0, len(warnings))

            # not OK
            import aos.sdk.reference_design.extension.one_stage_l2.client
            self.assertEqual(1, len(warnings))
            for warning in warnings:
                self.assertEqual(DeprecationWarning, warning.category)
                self.assertEqual('One Stage L2 reference design is deprecated.',
                                 str(warning.message))
