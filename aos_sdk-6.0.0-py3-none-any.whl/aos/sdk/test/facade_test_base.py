# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=line-too-long

from __future__ import print_function
from __future__ import absolute_import
from __future__ import division

import aos.sdk.py3compat  # pylint: disable=unused-import

from collections import namedtuple
import flask
import werkzeug.exceptions
from six.moves import json

import aos.infra.logging
import aos.sdk.schema as s
from aos.auth.auth_utils import AuthError
from aos.grappa.test_lib.graph_blueprint_test import GraphBlueprintTestBase
from aos.grappa.table.cpp_graph import CppBatchUpdateGraph
from aos.grappa.table.query_engine import is_cpp_graph
from aos.sdk.client import Client
from aos.sdk.facade import (
    ConflictError,
    Facade,
    ResourceNotFoundError,
    exec_all_stages,
)
from aos.sdk.graph import BatchUpdateGraph, FrozenGraph
from aos.sdk.test.aos_test_library import AosTestLibrary
from aos.sdk.validator import get_facade_validator, Severity, dump_errors

LOGGER = aos.infra.logging.getLogger(__name__)


UserContextInfo = namedtuple('UserContextInfo', ['username', 'tenants'])

def get_user_context_info():
    return UserContextInfo(
        getattr(flask.g, 'user_name', ''),
        getattr(flask.g, 'tenants', '*'),
    )


def set_user(user_name='', tenants=''):
    flask.g.user_name = user_name
    flask.g.tenants = tenants


class FacadeTestBase(GraphBlueprintTestBase):
    design = None
    flask_klass = flask.Flask

    def __build_app(self, facade_klass):
        app = self.flask_klass(self.__class__.__name__)

        # Allows context modification in tests
        app.app_context().push()

        # pylint: disable=unused-variable
        @app.route(
            '/api/blueprints/<blueprint_id>/<path:path>',
            methods=['DELETE', 'GET', 'PATCH', 'POST', 'PUT', 'OPTIONS'],
        )
        def process_facade_call(blueprint_id, path):
            if not self.config_blueprint.is_committed():
                print('WARNING: Called facade handler on dirty graph. It leads to ' \
                      'Validator not listening for graph updates unless graph is ' \
                      'committed. Graph will be automatically committed.')
                self.config_blueprint.commit()

            rules = []
            for attr_name in dir(facade_klass):
                method = getattr(facade_klass, attr_name)

                if not callable(method) or getattr(method, 'route', None) is None:
                    continue

                route = method.route
                rules.append(werkzeug.routing.Rule(route.path, methods=route.methods,
                                                   endpoint=method))

            urls = werkzeug.routing.Map(rules).bind('localhost')
            try:
                (endpoint, args) = urls.match(path, method=flask.request.method)
            except werkzeug.exceptions.NotFound:
                return json.dumps({'errors': 'Url not found'}), 404

            user_context = get_user_context_info()
            tenants = user_context.tenants.split(',')

            validator = None
            if getattr(endpoint, 'modifier', False):
                # TODO(menc): Change to
                #  if self.should_use_table_graphs():
                #  and fix affected unittests
                if is_cpp_graph(self.config_blueprint):
                    blueprint = CppBatchUpdateGraph(self.config_blueprint)
                else:
                    blueprint = BatchUpdateGraph(self.config_blueprint)
                validator = get_facade_validator(self.design, graph=blueprint,
                                                 user=user_context.username,
                                                 tenants=tenants)
                validator.start()
            else:
                blueprint_type = flask.request.args.get('type', 'staging', type=str)
                blueprint = self.blueprint_types.get(blueprint_type)
                if not blueprint:
                    return json.dumps({'errors': {
                        'type': 'Invalid blueprint type: %s' % blueprint_type,
                    }}), 400

                blueprint = FrozenGraph(blueprint)

            facade = facade_klass(blueprint, self.library)
            facade.design = self.design
            facade.context = self.facade_context

            try:
                if getattr(endpoint, 'insert_staging_graph', False):
                    facade.staging_graph = FrozenGraph(
                        self.blueprint_types.get('staging'))

                if hasattr(endpoint, 'arg_schema') or hasattr(endpoint, 'skip_arg_schema'):
                    if flask.request.args:
                        args.update({k: v for k, v in flask.request.args.items()})
                    if flask.request.data:
                        payload = flask.request.get_json(force=True)
                        if isinstance(payload, dict):
                            args.update(payload)
                        #AOS-41366: temporarily allow 'null' payload as acceptable.
                        # Once the UI library has been fixed, such payload should
                        # raise BadRequest HTTP 400.
                        elif payload is not None:
                            raise werkzeug.exceptions.BadRequest()
                    if hasattr(endpoint, 'arg_schema'):
                        args = endpoint.arg_schema.load(args)
                else:
                    args = {}

                result = exec_all_stages(endpoint, facade, **args)
                if isinstance(result, tuple):
                    result = result[0]

                return_code = endpoint.route.status_code
                if hasattr(endpoint, 'result_schema'):
                    if not endpoint.skip_result_schema_dump:
                        # Lollipop's "dump" is designed to be used as a
                        # flattening tool, not as a validation. It's
                        # primary goal is to transform objects
                        # created by (or stored on) the backend
                        # to the flat structure consumable by the API.
                        #
                        # Thus, the schema's "validators" are not run
                        # against the `result`. It's a responsibility
                        # of a developer to cover API endpoints with
                        # tests checking all the corner cases
                        # of the schema.
                        #
                        # We might want to think about using "load"
                        # instead of "dump" to slightly change the
                        # philosophy of the `result_schema` - validating
                        # how the data was compiled on the backend
                        # by analogy with validating the user's data
                        # in accordance with the `arg_schema`.
                        #
                        # However, it's a bit doubtful and looks like
                        # it's more appropriate to be present in tests
                        # rather than in production.
                        result = endpoint.result_schema.dump(result)
                else:
                    result = ''
                    return_code = 204

                if validator:
                    validator.commit()
                    critical = Severity.CRITICAL
                    node_errors = \
                        validator.errors.get_node_errors(severity=critical)
                    rel_errors = \
                        validator.errors.get_relationship_errors(severity=critical)
                    if node_errors or rel_errors:
                        design_errors = getattr(self.design, 'Errors', None)
                        result, return_code = {'errors': {
                            'nodes': dump_errors(node_errors, design_errors),
                            'relationships': dump_errors(rel_errors, design_errors)
                        }}, 409
                    else:
                        blueprint.commit()
            except s.ValidationError as ve:
                result, return_code = {'errors': ve.messages}, 422
            except ResourceNotFoundError as nfe:
                result, return_code = {'error': nfe.args[0]}, 404
            except ConflictError as ce:
                result, return_code = {'error': ce.args[0]}, 409
            except AuthError as ae:
                result, return_code = {'errors': ae.message}, ae.code
            except werkzeug.exceptions.BadRequest as bre:
                result, return_code = {'errors': 'invalid input'}, 400
            except Exception as e:  # pylint: disable=broad-except
                LOGGER.exception('Error processing path %s', path)
                result, return_code = 'Internal server error: %s' % e, 500

            # pylint: disable=redefined-variable-type
            if isinstance(result, list):
                result = {'items': result}

            if result is not None:
                result = json.dumps(result)

            return result, return_code

        return app

    # pylint: disable=arguments-differ
    def setUp(self, aos_library_cls=AosTestLibrary):
        super(FacadeTestBase, self).setUp()

        if self.design is None:
            raise ValueError('Design is not configured')
        design_name = getattr(self.design, 'NAME', 'default_design')
        self.design_registry = {design_name: self.design}
        self.config_blueprint = self._create_blueprint_base(
            design_name=design_name)
        self.staging_blueprint = self._create_blueprint_base(
            design_name=design_name, id=self.config_blueprint.id)
        self.library = aos_library_cls()

        self.blueprint_types = {
            'config': self.config_blueprint,
            'staging': self.staging_blueprint,
        }

        self._app = self.__build_app(getattr(self.design, 'Facade', Facade))
        self.client = getattr(self.design, 'Client', Client)(self._app)
        self.facade_context = None
