#!/usr/bin/env python3
# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import absolute_import
from __future__ import division

import unittest

import six

from aos.sdk.graph import Graph, DummySchema, is_node, is_relationship
from aos.sdk.validator import MemoryErrorReporter, ValidationError, Severity
from aos.sdk.errors import build_related_entity_ids


class ValidatorTestBase(unittest.TestCase):
    schema = DummySchema
    validator = None

    def setUp(self):
        super(ValidatorTestBase, self).setUp()
        if not hasattr(self.__class__, 'validator'):
            raise ValueError('Validator should be defined as class attribute')

        self.graph = Graph(self.schema())
        self.errors = MemoryErrorReporter()
        # pylint: disable=not-callable
        self.validator = self.__class__.validator(self.graph, self.errors)
        self.validator.start()


class ErrorVerifierTestHelper(object):
    def get_entity_errors_plain(self, error_reporter, entity_id=None,
                                relationship=False):
        entity_errors = self._get_errors(error_reporter, entity_id, relationship)
        if entity_id:
            return [
                (error_type, related_entity_ids, error)
                for error_type, errors_per_type in six.iteritems(entity_errors)
                for related_entity_ids, error in six.iteritems(errors_per_type)
            ]
        return [
            (_entity_id, error_type, related_entity_ids, error)
            for _entity_id, errors in six.iteritems(entity_errors)
            for error_type, errors_per_type in six.iteritems(errors)
            for related_entity_ids, error in six.iteritems(errors_per_type)
        ]

    @staticmethod
    def _get_errors(error_reporter, entity_id=None, relationship=False):
        return (error_reporter.get_relationship_errors(entity_id)
                if relationship else error_reporter.get_node_errors(entity_id))

    @staticmethod
    def _normalize_entity(entity):
        return entity.id if is_node(entity) or is_relationship(entity) else entity

    @staticmethod
    def get_errors_by_entity_type(error_reporter, entity):
        return (error_reporter.get_relationship_errors() if is_relationship(entity)
                else error_reporter.get_node_errors())

    def _validate_no_errors(self, error_reporter, entity_with_error,
                            severities=None):
        errors = self.get_errors_by_entity_type(error_reporter, entity_with_error)
        entity_with_error = self._normalize_entity(entity_with_error)
        if severities:
            for errs_by_type in six.itervalues(errors.get(entity_with_error, {})):
                for error_data in six.itervalues(errs_by_type):
                    self.assertNotIn(
                        error_data.severity, severities,
                        'Error with {severity} presented on entity '
                        '{entity}'.format(severity=error_data.severity,
                                          entity=entity_with_error))
        else:
            self.assertNotIn(entity_with_error, errors,
                             'Error for the specified entity is found:\n{}'.format(
                                 errors.get(entity_with_error)))

    def _validate_errors(self, error_reporter, entity_with_error, error_type,
                         context=None,
                         related_entity_ids=None, severity=Severity.CRITICAL,
                         resolutions=None, error_set=True, error_count=None,
                         relationship=False, ignore_resolutions=False) -> bool:
        """
        Check if error exists on specific graph entity

        :param error_reporter: instance of TacErrorReporter or MemoryErrorReporter;
        :param entity_with_error: node or relationship or ID of such entity;
        :param error_type: instance of ErrorMetaData, presence of which error type
                           should be examined. If error_set == False and
                           context, related_entity_ids and resolutions are not
                           specified all together, this method will check
                           absence of the error_type on entity.
                           If not specified and error_set is False, checks that no
                           errors are raised.
        :param context: context of the error. If not specified, error with empty
                        context is expected. If error is expected to have context,
                        then it should be fully specified.
        :param related_entity_ids: unifier of errors. If not specified, error with
                                   empty related_entity_ids is expected. For special
                                   cases check 'expected_by_type' and
                                   'expected_by_primary_key'
        :param severity: instance of Severity;
        :param resolutions: list of error resolutions. If not specified, error with
                            empty resolutions is expected. If error is expected to
                            have resolutions, then it should be fully specified;
        :param error_set: True or False. Checks whether errors is set or not;
        :param error_count: number of expected errors with specified severity;
        :param relationship: True or False. Whether errors should be looked up in
                             relationships error storage or not. Can be used when
                             entity_with_error provided as ID.
        :param ignore_resolutions: True or False. If False, resolutions will be
                                   checked according to :param resolutions:
                                   If True, resolutions will not be checked.
                                   This is need to ease test development to not fill
                                   all the fields.
        :returns: True if error has been successfully validated
        """
        entity_with_error = self._normalize_entity(entity_with_error)
        errors = self._get_errors(error_reporter, relationship=relationship)
        raised_errors = errors.get(entity_with_error, {})

        # When error_set=False, it's convenient to check (entity_id, error_type)
        # was not raised
        expected_by_type = (related_entity_ids is None and
                            context is None and
                            resolutions is None)
        # When error_set=False, sometimes it's also convenient to check that
        # (entity_id, error_type, related_entity_ids) was not raised, e.g. when
        # same error_type is raised against different "related entities"
        expected_by_primary_key = (related_entity_ids is not None and
                                   context is None and
                                   resolutions is None)

        context = context or {}
        context = {k: str(v) for k, v in six.iteritems(context)}

        if context:
            # Check that valid context is passed for this error and all formatted
            # string arguments are filled correctly. Error will be thrown which is
            # a good indicator for tests.
            error_type.get_error_message(context)

        expected_resolutions_count = len(error_type.resolutions) if error_type else 0

        related_entity_ids = [self._normalize_entity(entity)
                              for entity in related_entity_ids or []]
        related_entity_ids = build_related_entity_ids(related_entity_ids)
        error_type = error_type.id if error_type else None

        raised_error = raised_errors.get(error_type, {}).get(related_entity_ids)
        expected_error = ValidationError(severity, context or {}, resolutions or [])

        err_prefix = 'Entity with error: \'{}\'. '.format(entity_with_error)

        if error_set:
            self.assertIn(entity_with_error, errors,
                          err_prefix + 'Error for the specified entity is not found')
            if not ignore_resolutions:
                resolutions_count = len(resolutions) if resolutions else 0
                self.assertLessEqual(
                    expected_resolutions_count, resolutions_count,
                    err_prefix + 'Resolutions are partially missing')
            if raised_error:
                if expected_error.ne(raised_error, ignore_resolutions):
                    self.fail(
                        err_prefix + 'Raised error with type {error_type} and '
                                     'related_entity_ids {related_entity_ids}: \n'
                                     '({raised_error}) does not match expected: \n'
                                     '({expected_error}) \n'
                                     'resolutions ignored: '
                                     '{ignore_resolutions}'.format(
                                         error_type=error_type,
                                         related_entity_ids=related_entity_ids,
                                         raised_error=str(raised_error),
                                         expected_error=str(expected_error),
                                         ignore_resolutions=ignore_resolutions))
            else:
                self.fail(
                    err_prefix + 'Error ({error_type}, {related_entity_ids}) was '
                                 'not found, expected: {expected}.\nOther errors '
                                 'are {others}'.format(
                                     error_type=error_type,
                                     related_entity_ids=related_entity_ids,
                                     expected=str(expected_error),
                                     others=raised_errors))
        else:  # error expected not to be set
            if error_type is None:
                self.assertEqual(0, len(raised_errors),
                                 err_prefix + 'Errors have been found: '
                                              '{}'.format(raised_errors))
            else:
                if expected_by_type:
                    if error_type in raised_errors:
                        self.fail(err_prefix + 'Error ({error_type}) found, but '
                                               'expected to be missing'.format(
                                                   error_type=error_type))
                elif expected_by_primary_key:
                    if raised_error:
                        self.fail(err_prefix + 'Error ({}, {}) found, but '
                                               'expected to be missing'.format(
                                                   error_type, related_entity_ids))
                elif raised_error and expected_error.eq(raised_error,
                                                        ignore_resolutions):
                    self.fail(err_prefix + 'Error ({error_type}, {error}) found, '
                                           'but expected to be missing'.format(
                                               error_type=error_type,
                                               error=raised_error))
                elif raised_error:
                    print('Error with the same (error_type, related_entity_ids) was'
                          ' found, but other properties differ. Make sure to pass'
                          ' correct context and severity level or use'
                          ' expected_by_primary_key flag')
        if error_count is not None:
            entity_errors = (
                error_reporter.get_relationship_errors(id=entity_with_error,
                                                       severity=severity)
                if relationship
                else error_reporter.get_node_errors(id=entity_with_error,
                                                    severity=severity))
            if entity_with_error:
                entity_errors = {entity_with_error: entity_errors}

            count = 0
            for errors in six.itervalues(entity_errors):
                for _error_type, errors_for_type in six.iteritems(errors):
                    count += len(errors_for_type)
            self.assertEqual(error_count, count,
                             err_prefix + 'Expected {} number of errors with '
                                          'severity {}, but found {}: {}'.format(
                                              error_count, len(entity_errors),
                                              severity, count))
        return True
