# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=arguments-differ, arguments-renamed

from collections import defaultdict
import unittest
from aos.sdk.graph import Graph, DummySchema
from aos.sdk.builder import (
    Builder,
    BuilderPlugin,
)
from aos.sdk.validator import MemoryErrorReporter
from aos.sdk.test.aos_test_library import AosTestLibrary
import six


class TestResourcePoolRequest(object):
    def __init__(self):
        self.resources = {}
        self.pool_ids = []


class TestResourcePoolResult(object):
    def __init__(self):
        self.results = {}
        self.errors = {}


class TestResourcePool(object):
    request_type = TestResourcePoolRequest

    def __init__(self, callback):
        self._callback = callback
        self.updated = set()
        self._requests = defaultdict(self.__class__.request_type)
        self._results = defaultdict(TestResourcePoolResult)

    def start(self):
        pass

    def stop(self):
        pass

    def cleanup(self):
        self._requests = defaultdict(TestResourcePoolRequest)
        self._results = defaultdict(TestResourcePoolResult)

    def allocate(self, group, name, value=None):
        self._requests[group].resources[name] = value
        return self._responses[group].results.get(name)

    def deallocate(self, group, name):
        if name in self._requests[group].resources:
            del self._requests[group].resources[name]
            if self.is_group_empty(group):
                del self._requests[group]

    def is_group_empty(self, group):
        return not self._requests[group].resources

    def set_pool_ids(self, group, pool_ids):
        self._requests[group].pool_ids = pool_ids

    def commit(self):
        pass

    def set_results(self, group, values, errors=None):
        results = self._results[group]
        for name, value in six.iteritems(values):
            if value:
                results.results[name] = value
            else:
                if name in results.results:
                    del results.results[name]

        for name, error in six.iteritems(errors):
            if error:
                results.errors[name] = error
            else:
                if name in results.errors:
                    del results.errors[name]

        self._callback(self._requests[group].resources,
                       results.results,
                       results.errors)


class TestIpPoolRequest(TestResourcePoolRequest):
    def __init__(self):
        super(TestIpPoolRequest, self).__init__()
        self.prefix = 32


class TestIpPool(TestResourcePool):
    request_type = TestIpPoolRequest

    def allocate(self, group, prefix, name, value=None):
        request = super(TestIpPool, self).allocate(group, name, value=value)
        request.prefix = prefix
        return request


class TestIpv6PoolRequest(TestResourcePoolRequest):
    def __init__(self):
        super(TestIpv6PoolRequest, self).__init__()
        self.prefix = 128


class TestIpv6Pool(TestResourcePool):
    request_type = TestIpv6PoolRequest

    def allocate(self, group, prefix, name, value=None):
        request = super(TestIpv6Pool, self).allocate(group, name, value=value)
        request.prefix = prefix
        return request


class BuilderTestBase(unittest.TestCase):
    schema = DummySchema
    builder_plugin_class = None

    def _on_pool_results(self, group, requests, results, errors):
        def notify(resource_id):
            node = self.input.get_node(resource_id)
            if node:
                self.builder.on_node(self.input, node, node)
                return

            relationship = self.input.get_relationship(resource_id)
            if relationship:
                self.builder.on_relationship(self.input, relationship, relationship)

        for resource_id in results:
            notify(resource_id)

        for resource_id in errors:
            if resource_id not in results:
                notify(resource_id)

        for resource_id in requests:
            if resource_id not in results and resource_id not in errors:
                notify(resource_id)

        self.builder.commit()

    def init_builder(self, input_graph, output_graph, input_source_name=None,
                     output_source_name=None):
        self.input = input_graph
        self.output = output_graph
        self.errors = MemoryErrorReporter()

        self.ip_pool = TestIpPool(self._on_pool_results)
        self.ipv6_pool = TestIpv6Pool(self._on_pool_results)
        self.asn_pool = TestResourcePool(self._on_pool_results)
        self.vlan_pool = TestResourcePool(self._on_pool_results)
        self.vni_pool = TestResourcePool(self._on_pool_results)
        self.device_pool = TestResourcePool(self._on_pool_results)
        self.integer_pool = TestResourcePool(self._on_pool_results)
        self.builder_lib = AosTestLibrary()

        # pylint: disable=not-callable
        self.builder = Builder(
            plugin_class=self.__class__.builder_plugin_class,
            input=self.input, output=self.output,
            ip_pool=self.ip_pool,
            ipv6_pool=self.ipv6_pool,
            asn_pool=self.asn_pool,
            vlan_pool=self.vlan_pool,
            vni_pool=self.vni_pool,
            device_pool=self.device_pool,
            integer_pool=self.integer_pool,
            errors=self.errors,
            builder_lib=self.builder_lib,
            input_source_name=input_source_name,
            output_source_name=output_source_name,
        )

    def setUp(self):
        super(BuilderTestBase, self).setUp()
        if not hasattr(self.__class__, 'builder_plugin_class'):
            raise ValueError('builder_plugin_class should be defined as '
                             'class attribute')

        if not issubclass(self.__class__.builder_plugin_class, BuilderPlugin):
            raise ValueError('builder_plugin_class should be a reference to a class '
                             'derived from sdk.builder.BuilderPlugin')

        self.input = Graph(self.schema())
        self.output = Graph(self.schema())
        self.init_builder(self.input, self.output)
        self.builder.start()

    def tearDown(self):
        self.builder_lib.stop()
        self.builder.stop()

        super(BuilderTestBase, self).tearDown()
