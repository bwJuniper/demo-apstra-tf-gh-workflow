# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# pylint: disable=redefined-builtin,invalid-name

import aos.sdk.schema as s
from collections import defaultdict


class TestDataSourcesManager(object):
    class Attachment(object):
        def __init__(self, type, id, agent):
            self.type = type
            self.id = id
            self.agent = agent

    def __init__(self):
        self.attachments = []
        self._sources = defaultdict(list)

    def add_source(self, type, source):
        self._sources[type].append(source)
        for attachment in self.attachments:
            if attachment.type == type and (attachment.id is None or
                                            attachment.id == source.id):
                attachment.agent.on_attach(attachment.type, source)

        return source

    def remove_source(self, type, id=None):
        for source in self._sources[type]:
            if source.type == type and (id is None or source.id == id):
                for attachment in self.attachments:
                    if attachment.type == s.type and (attachment.id is None or
                                                      attachment.id == source.id):
                        attachment.agent.on_detach(attachment.type, source.graph)

    def attach(self, type, agent, id=None):
        attachment = None
        for a in self.attachments:
            if a.type == type and a.agent == agent and a.id == id:
                # Already attached
                return

        attachment = self.Attachment(type=type, id=id, agent=agent)
        self.attachments.append(attachment)

        for source in self._sources[type]:
            if attachment.id is None or source.id == attachment.id:
                attachment.agent.on_attach(attachment.type, source)

    def detach(self, type, agent, id=None):
        attachment = None
        for a in self.attachments:
            if a.type == type and a.agent == agent and a.id == id:
                attachment = a
                self.attachments.remove(a)
                break

        if attachment is None:
            return

        for source in self._sources:
            if source.type == attachment.type and \
                    (attachment.id is None or attachment.id == source.id):
                attachment.agent.on_detach(attachment.type, source.graph)

    def detach_all(self, agent):
        new_attachments = []
        for a in self.attachments[:]:
            if a.agent != agent:
                new_attachments.append(a)
                continue

            for source in self._sources[a.type][:]:
                if source.id == a.id:
                    agent.on_detach(a.type, source)
                    self._sources[a.type].remove(source)

        self.attachments = new_attachments
