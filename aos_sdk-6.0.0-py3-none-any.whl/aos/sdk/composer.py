# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

__all__ = [
    'Composer',
    'ComposerPluginBase',

    'rule',
    'startup',
    'commit',

    'match',
    'node'
]
from weakref import proxy

from aos.sdk.graph import BatchUpdateGraph
from aos.sdk.graph.graph_upserter import GraphUpserter
from aos.sdk.graph.query import QueryEngine, match, node
from collections import defaultdict, namedtuple

# pylint: disable=redefined-builtin,redefined-outer-name

import logging
LOGGER = logging.getLogger(__name__)

from aos.sdk.time_profiler import make_profiler
PROFILE = make_profiler(LOGGER.info)


_Rule = namedtuple('Rule', ['target', 'query'])


def rule(target, query):
    def wrapper(f):
        if not hasattr(f, 'rules'):
            f.rules = []
        f.rules.append(_Rule(target, query))
        return f
    return wrapper


def startup(f):
    f.on_start = True
    return f


def commit(f):
    f.on_commit = True
    return f


class ComposerPluginBase(object):
    """Base class for plugin being run in a Composer instance (see below).

    Reference designs should define a class that derives from this class,
    and implement the logic of composing the source graphs in the derived class.
    The next decorators are supposed to be used in a ComposerPlugin class:
        @startup - is executed at Composer instance start.
        @rule(target, query) - executed every time the path specified by the query
            is updated in any graph from specified target. Updated path and action
            type (added, updated or removed) will be provided.
        @commit - is executed before commit changes to the output graph.
    """
    upsert_sources = []

    def __init__(self, composer):
        self.composer = proxy(composer)

    @property
    def input(self):
        return self.composer.input

    @property
    def output(self):
        return self.composer.output

    def start(self):
        pass

    def stop(self):
        pass


class Composer(object):
    """Composes input and several source graphs into output graph.

    Composer replays all updates from the input graph to the output graph.
    Also it creates a QueryEngine instance for input, output graphs
    and per each source graph. Rules provided by ref-design
    specific plugin_class is used to incrementally update the output graph.

    When the table graphs mode is on (should_use_tables flag), all handlers are
    called in the context of simultaneous transactions for each Sysdb from which
    the input and source graphs are mounted. The next diagram shows the Composer
    workflow in terms of the propagating updates from the input/source graphs
    to the output graph:

    << input graph added >>      << input/source graph >>
            |                     <<version increment>>
            v                              |
      TableGraphDirReactor                 v
     requests a transaction*       TransactionalReadOnlyGraph
            |                        requests a transaction*--------------------
            |                             |                                     |
            v                             |        << source graph added >>     |
    ComposerTableGraphReactor             v                   |                 |
        on_graph_added()            QueryEngine               v                 |
            |                       .on_graph()        TableGraphDirReactor     |
            |                           |              requests a transaction*  |
            v                           v                      |                |
      creates Composer       ComposerPlugin.rule()             v                |
            |                     |         |          TableGraphDataSources    |
            v                     |         |            .on_graph_added()      |
    ComposerPlugin.on_start()     |     Composer               |                |
            |             |       |     .detach()              v                |
            |             v       v                    DataSourcesAgent         |
            |        Composer.attach()--------------     .on_attach()           |
            |                                       |           |               |
            |                                       v           v               |
            |       --------------------------Composer.on_source_added()        |
            |      |                                                            |
            |      |                                                            |
            |      |       Composer.node_upsert() <-- Composer.on_node() <------|
            |      |                                                            |
            |      |      Composer.rel.._upsert() <--  Composer.on_rel..() <----|
            v      v                                                            |
         Composer.commit() <----------- Composer.on_graph() <-------------------
                |
                v
      ComposerPlugin.on_commit
                |
                v
      Composer.output.commit()

    * TableGraphDirReactor's and TransactionalReadOnlyGraph instances
      use the same MultiTransactionManager instance that ensures transaction
      context for all the TransactionMountFactories from which the
      input, output and source graphs are mounted.
    """
    class DataSourceAgent(object):
        def __init__(self, on_attach, on_detach):
            self.on_attach = on_attach
            self.on_detach = on_detach

    def __init__(self, plugin_class, input, output, sources=None,
                 should_use_tables=False, query_engine_type=QueryEngine,
                 graph_upserter_type=GraphUpserter):

        self.plugin = plugin_class(self)

        self.input = input
        self.output = output
        self.__real_output = output
        self.__sources = sources
        self._should_use_tables = should_use_tables
        self.query_engine_type = query_engine_type
        self.graph_upserter_type = graph_upserter_type

        self.__agent = self.DataSourceAgent(
            self.__on_source_added,
            self.__on_source_removed,
        )

        self.__initial = True
        self.__engines = {}
        self.__target_rules = defaultdict(list)
        self.__on_start = []
        self.__on_commit = []
        self.__on_next_commit = set()
        self.__comitting = False

        # input always performs upsert operation
        # additional upsert sources are specified in the ComposerPlugin
        self.__upsert_sources = ['input'] + self.plugin.upsert_sources
        self.__upserters = {}

        for k in dir(self.plugin):
            v = getattr(self.plugin, k)
            if hasattr(v, 'rules'):
                for rule in v.rules:
                    self.__target_rules[rule.target].append((rule, v))
            if hasattr(v, 'on_start') and v.on_start is True:
                self.__on_start.append(v)
            if hasattr(v, 'on_commit') and v.on_commit is True:
                self.__on_commit.append(v)

    def start(self):
        self.plugin.start()

        self.__on_source_added('input', self.input)

        for f in self.__on_start:
            f()

        # recursive queries are not supported for cpp graphs
        if not self._should_use_tables:
            self.__on_source_added('output', self.output)

        if self.input.is_committed():
            self.wrap_output_with_batch_update_graph()
            self.on_graph(self.input)
        else:
            self.__initial = True

    def wrap_output_with_batch_update_graph(self):
        if not self._should_use_tables:
            self.output = BatchUpdateGraph(self.output)
            for upserter in self.__upserters.values():
                upserter.set_output(self.output)

        self.__initial = False

    def unwrap_output(self):
        self.output = self.__real_output
        if not self._should_use_tables:
            for upserter in self.__upserters.values():
                upserter.set_output(self.output)

    def stop(self):
        self.plugin.stop()

        LOGGER.info('Stop composer.')
        for source in self.__engines:  # pylint: disable=consider-using-dict-items
            self.__engines[source].unwatch(source)
            source.remove_observer(self)
        self.__sources.detach_all(self.__agent)
        self.__engines = {}
        self.unwrap_output()

    def attach(self, type, id=None):
        if self.__sources is None:
            raise RuntimeError('Additional sources are not available')
        self.__sources.attach(type, self.__agent, id)

    def get_source(self, type, id=None):
        return self.__sources.get_source(type, id)

    def detach(self, type, id=None):
        self.__sources.detach(type, self.__agent, id)

    def __on_source_added(self, type, source):
        LOGGER.info('on source added type: %s, source %s', type, source)
        if source in self.__engines:
            return

        # Order of the source graph observers notifications on updates:
        # 1. GraphUpserter (if specified for this type of input)
        # provides updates form the source to the output graph
        if type in self.__upsert_sources:
            self.__upserters[source] = self.graph_upserter_type(
                source, self.output)
            self.__upserters[source].start(full_sync=source == self.input)

        # 2. QueryEngine process rules incrementally
        engine = self.query_engine_type()
        for rule, callback in self.__target_rules[type]:
            engine.register_query(rule.query, callback)

        self.__engines[source] = engine
        engine.watch(source)

        # 3. Composer.on_graph() -> Composer.commit()
        source.add_observer(self)

        if source.version:
            self.commit()

    def __on_source_removed(self, type, source):
        source.remove_observer(self)

        if source in self.__engines:
            self.__engines[source].unwatch(source)
            del self.__engines[source]

        if source in self.__upserters:
            self.__upserters[source].stop()
            del self.__upserters[source]

    def on_commit(self, f, *args, **kwargs):
        '''Schedule a code to be executed on commit'''
        self.__on_next_commit.add((f, tuple(args), tuple(sorted(kwargs.items()))))

    def commit(self):
        if self.__comitting:
            return

        self.__comitting = True

        for f in self.__on_commit:
            f()

        for (f, args, kwargs) in self.__on_next_commit:
            f(*args, **dict(kwargs))
        self.__on_next_commit = set()

        self.output.commit()
        if self.__initial:
            self.wrap_output_with_batch_update_graph()
            self.__initial = False

        self.__comitting = False

    def on_graph(self, graph):
        if graph not in self.__engines:
            return

        self.commit()

    def on_node(self, graph, old_node, new_node):
        pass

    def on_relationship(self, graph, old_rel, new_rel):
        pass


class EmptyComposerPlugin(ComposerPluginBase):
    pass
