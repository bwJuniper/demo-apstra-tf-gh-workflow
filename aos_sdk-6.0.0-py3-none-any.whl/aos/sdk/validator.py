# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

__all__ = [
    'Validator',
    'NoopValidator',
    'Severity',
    'MemoryErrorReporter',
    'ValidationError',

    'rule',
    'match',
    'node',
    'optional',

    'get_facade_validator',
    'get_rbac_validator',
    'run_with_rbac_validator',

    'severity_from_string',
]

# pylint: disable=redefined-builtin
from collections import defaultdict, Counter

from aos.sdk.errors import build_related_entity_ids
from aos.sdk.graph import is_node, is_relationship
from aos.sdk.graph.query import QueryEngine, match, node, optional
from aos.sdk.profiling.stats_manager import NoopStatsManager
from aos.sdk.time_profiler import make_profiler
from aos.sdk.profiling.instrument import instrument
from aos.sdk.graph.query import utils
from aos.sdk.collection_utils import (
    dict_sort_key,
    none_or_something_to_comparable_tuple,
)
from aos.sdk import schema

import logging
import time
import six


LOGGER = logging.getLogger(__name__)

PROFILE = make_profiler(LOGGER.info)

instrument = instrument.nested(source=__name__)


class Severity(object):
    WARNING = 0
    ERROR = 1
    CRITICAL = 2


class Action(object):
    DELETED = 0
    ADDED = 1


def severity_from_string(s):
    s = s.lower()
    assert s in ('error', 'warning', 'critical')
    if s == 'error':
        return Severity.ERROR
    elif s == 'warning':
        return Severity.WARNING
    else:
        return Severity.CRITICAL


class ValidationError(object):
    def __init__(self, severity, context=None, resolutions=None):
        """DTO for errors. Data stored here will be also stored in Tac.
        Additional error information is filled with it in API.
        :param severity: enum of Severity. Represents of the error level.
        :param context: dict with string values which are filled in error pattern.
        :param resolutions: list of pairs ((resolution_id, entity_id), also
                            represented as list) for UI mapping (form/field/view/etc)
        Other error data (like id of the entity, error_type, related_entity_ids)
        is not used here.
        """
        self.severity = severity
        self.context = context or {}
        self.resolutions = resolutions or []

    def __eq__(self, other):
        return self.eq(other)

    def __ne__(self, other):
        return self.ne(other)

    def __repr__(self):
        return ('ValidationError(severity={severity}, context={context},'
                ' resolutions={resolutions})'.format(
                    severity=self.severity, context=self.context,
                    resolutions=self.resolutions))

    def eq(self, other, ignore_resolutions=False):
        self_res = []
        o_res = []
        for res in self.resolutions:
            if isinstance(res, dict):
                self_res.append(
                    {
                        k:none_or_something_to_comparable_tuple(v)
                        for k, v in six.iteritems(res)
                    }
                )
            else:
                self_res.append(res)
        for res in other.resolutions:
            if isinstance(res, dict):
                o_res.append(
                    {
                        k:none_or_something_to_comparable_tuple(v)
                        for k, v in six.iteritems(res)
                    }
                )
            else:
                o_res.append(res)
        return (
            self.severity == other.severity and
            self.context == other.context and
            (
                ignore_resolutions or
                sorted(self_res, key=dict_sort_key) ==
                sorted(o_res, key=dict_sort_key)
            )
        )

    def ne(self, other, ignore_resolutions=None):
        return not self.eq(other, ignore_resolutions)


class MemoryErrorReporter(object):
    def __init__(self):
        self._node_errors = {}
        self._relationship_errors = {}
        self._observers = []
        self.version = 0
        self.source_versions = {}
        self._counts = Counter()

    def _update_error_counts(self, severity, action=Action.ADDED):
        diff = 1 if action == Action.ADDED else -1
        self._counts[severity] += diff

    def add_observer(self, observer):
        self._observers.append(observer)

    def remove_observer(self, observer):
        self._observers.remove(observer)

    def reset(self):
        self._node_errors = {}
        self._relationship_errors = {}
        self._counts.clear()
        self.commit(version=0)

    def commit(self, version=None, source_versions=None):
        if source_versions is not None:
            self.source_versions = dict(source_versions)

        self.version = version if version is not None else (self.version + 1)

        for observer in self._observers:
            observer.on_errors(self)

    @staticmethod
    def _get_entity_errors(entity_errors, severity, exact, error_type):
        if error_type:
            entity_errors = {
                error_type.id: entity_errors.get(error_type.id, {})
            }

        matching_errors = {
            error_type: {
                related_entity_ids: error
                for related_entity_ids, error in six.iteritems(errors)
                if severity is None or (
                    (not exact and error.severity >= severity) or
                    error.severity == severity
                )
            }
            for error_type, errors in six.iteritems(entity_errors)
        }

        for _error_type, errors in list(six.iteritems(matching_errors)):
            if not errors:
                del matching_errors[_error_type]

        return matching_errors

    def _get_errors(self, error_dict, id, error_type=None, severity=None,
                    exact=False):
        assert id is None or isinstance(id, str), 'id = ' + str(id)
        assert severity in [
            None,
            Severity.WARNING,
            Severity.ERROR,
            Severity.CRITICAL,
        ], 'severity = ' + str(severity)

        if id is not None:
            return self._get_entity_errors(error_dict.get(id, {}), severity, exact,
                                           error_type)
        matching_errors = {
            entity_id: self._get_entity_errors(entity_errors, severity, exact,
                                               error_type)
            for entity_id, entity_errors in six.iteritems(error_dict)
        }

        # clear empty entries
        for entity_id, errors in list(six.iteritems(matching_errors)):
            if not errors:
                del matching_errors[entity_id]
        return matching_errors

    def _toggle_error(self, error_dict, id, error_type, related_entity_ids, severity,
                      context, resolutions, exists):
        context = context or {}
        context = {k: str(v) for k, v in six.iteritems(context)}

        resolutions = resolutions or []

        related_entity_ids = build_related_entity_ids(related_entity_ids)
        # Store enum string only to be consistent with TACC schema
        error_type = error_type.id
        old_error = error_dict.get(id, {}).get(error_type, {}).get(
            related_entity_ids, {})
        old_severity = old_error.severity if old_error else None

        if exists:
            assert severity in [
                Severity.WARNING,
                Severity.ERROR,
                Severity.CRITICAL,
            ], 'severity = ' + str(severity)
            error = ValidationError(severity, context, resolutions)

            errors = error_dict.setdefault(id, defaultdict(dict))
            errors[error_type][related_entity_ids] = error
            if old_severity is not None:
                self._update_error_counts(old_severity, Action.DELETED)
            self._update_error_counts(severity, Action.ADDED)
        else:
            errors = error_dict.get(id)
            if (errors is None or
                    error_type not in errors or
                    related_entity_ids not in errors[error_type]):
                return
            del errors[error_type][related_entity_ids]

            if not errors[error_type]:
                del errors[error_type]

            if not errors:
                del error_dict[id]

            self._update_error_counts(old_severity, Action.DELETED)

    def _clear_errors(self, error_dict, id, error_types, related_entity_ids,
                      predicate):
        """
        Remove errors with "error type" from error_types if specified;
          If related_entity_ids are specified, remove only errors that match
          error_type + related_entity_ids;
          Related_entity_ids must only be used with exactly one error_type specified;
        Remove errors matching predicate - this approach is SLOW as all entries are
        checked. Use with caution;
        Both error_types and predicate can not be specified simultaneously.
        """
        assert not (error_types and predicate), ('error_types and predicate must not'
                                                 ' be specified simultaneously')
        if related_entity_ids:
            assert error_types and len(error_types) == 1, (
                'related_entity_ids must be used with exactly one error_type')
            related_entity_ids = build_related_entity_ids(related_entity_ids)

        if id not in error_dict:
            return

        if error_types:
            error_types = ([error_types]
                           if not isinstance(error_types, (list, tuple, set))
                           else error_types)
            error_types = [error_type.id for error_type in error_types]

            errors = error_dict.get(id, defaultdict(dict))
            for error_type in set(error_types).intersection(errors.keys()):
                if not related_entity_ids:
                    for error in errors[error_type].values():
                        self._update_error_counts(error.severity, Action.DELETED)
                    del errors[error_type]
                elif related_entity_ids in errors[error_type]:
                    self._update_error_counts(
                        errors[error_type][related_entity_ids].severity,
                        Action.DELETED)
                    del errors[error_type][related_entity_ids]
        elif predicate:
            for error_type, errors_by_entities in list(six.iteritems(
                    error_dict.get(id, {}))):
                for _related_entity_ids, error in list(six.iteritems(
                        errors_by_entities)):
                    if predicate(error_type, _related_entity_ids, error):
                        self._update_error_counts(error.severity, Action.DELETED)
                        del errors_by_entities[_related_entity_ids]

                        if not errors_by_entities:
                            del error_dict[id][error_type]
                            break

        if id in error_dict:
            if (not error_types and not predicate) or not error_dict[id]:
                for errors_by_entities in error_dict[id].values():
                    for error in errors_by_entities.values():
                        self._update_error_counts(error.severity, Action.DELETED)
                del error_dict[id]

    def get_node_errors(self, id=None, severity=None, exact=False, error_type=None):
        if is_node(id):
            id = id.id
        return self._get_errors(self._node_errors, id, error_type, severity,
                                exact=exact)

    def toggle_node_error(self, id, error_type, related_entity_ids=None,
                          severity=None, context=None, resolutions=None,
                          exists=True):
        if is_node(id):
            id = id.id
        self._toggle_error(self._node_errors, id, error_type, related_entity_ids,
                           severity, context, resolutions, exists)

    def clear_node_errors(self, id, error_types=None, related_entity_ids=None,
                          predicate=None):
        if is_node(id):
            id = id.id
        self._clear_errors(self._node_errors, id, error_types, related_entity_ids,
                           predicate)

    def get_relationship_errors(self, id=None, severity=None, exact=False,
                                error_type=None):
        if is_relationship(id):
            id = id.id
        return self._get_errors(self._relationship_errors, id, error_type,
                                severity, exact=exact)

    def toggle_relationship_error(self, id, error_type, related_entity_ids=None,
                                  severity=None, context=None, resolutions=None,
                                  exists=True):
        if is_relationship(id):
            id = id.id
        self._toggle_error(self._relationship_errors, id, error_type,
                           related_entity_ids, severity, context, resolutions,
                           exists)

    def clear_relationship_errors(self, id, error_types=None,
                                  related_entity_ids=None, predicate=None):
        if is_relationship(id):
            id = id.id
        self._clear_errors(self._relationship_errors, id, error_types,
                           related_entity_ids, predicate)

    def has_errors(self, severity):
        return bool(self.get_node_errors(severity=severity) or
                    self.get_relationship_errors(severity=severity))

    def get_errors_count(self, severity):
        if severity is None:
            return self._counts.total()

        return self._counts[severity]


def dump_error(error, error_type, error_meta):
    assert error_meta, 'Error with type {error_type} not found in design'.format(
        error_type=error_type)
    result = {
        'severity': {
            Severity.CRITICAL: 'critical',
            Severity.ERROR: 'error',
            Severity.WARNING: 'warning',
        }[error.severity] if isinstance(error.severity, int) else error.severity,
        'display_category': error_meta.display_category,
        'resolutions': error_meta.get_resolutions(error.resolutions),
        'message': error_meta.get_error_message(error.context),
        'error_type': error_type,
        'entity_type': error_meta.entity_type,
    }

    return result


def dump_errors(errors, design_errors=None):
    if errors and not design_errors:
        raise RuntimeError('Errors class is not found in a reference design, but '
                           'errors are present.')

    result = defaultdict(list)
    for id, errors_by_type in six.iteritems(errors):
        for error_type, errors_by_entities in six.iteritems(errors_by_type):
            error_meta = design_errors.errors.get(error_type)

            result[id].extend(
                dump_error(error, error_type, error_meta)
                for related_entity_ids, error in six.iteritems(errors_by_entities)
            )

    return result


rule = utils.rule


class Validator(object):
    def __init__(self, graph, errors=None, builder_lib=None,
                 stats_manager=None,
                 query_engine_type=QueryEngine,
                 input_source_name=None,
                 user=None, tenants=None):
        self.graph = graph
        self.errors = errors or MemoryErrorReporter()

        self._stats_manager = stats_manager or NoopStatsManager()
        self._stats_execute = self._stats_manager.create_namespace('execute')
        self._stats_commit = self._stats_manager.create_namespace('commit')
        self._stats_plugin_on_commit = \
            self._stats_manager.create_namespace('plugin_on_commit')
        self._stats_qe = self._stats_manager.create_namespace('QueryEngine')

        self._engine = query_engine_type(stats_manager=self._stats_qe)
        self._query_ids = utils.register_rules(self, self._engine)
        self.builder_lib = builder_lib

        # Initially do not react to any updates. On start, only
        # start reacting to node / relationship changes if the graph
        # is already committed, so that validator queries need not be
        # executed for every node / relationship change during blueprint
        # scaffolding.
        self._react_to_updates = False
        self._input_source_name = input_source_name

    def log_on_commit_stats(self, data):
        data.setdefault('tags', {}).update({
            'graph_id': self.graph.id,
            'graph_version': self.graph.version,
        })
        self._stats_plugin_on_commit.add_entry(data)

    def execute(self):
        ts_begin = time.time()
        self._engine.execute_all(self.graph)
        ts_end = time.time()

        self._stats_execute.add_entry({
            'tags': {
                'graph_id': self.graph.id,
                'graph_version': self.graph.version
            },
            'engine_execute_all': ts_end - ts_begin,
        })

    def start(self):
        self._react_to_updates = self.graph.is_committed()
        if not self._query_ids:
            self._query_ids = utils.register_rules(self, self._engine)
        self.graph.add_observer(self)

    def stop(self):
        self.graph.remove_observer(self)
        for qid in self._query_ids:
            self._engine.remove_query(qid)
        self._query_ids = []

    def _engine_on_graph(self):
        self._engine.on_graph(self.graph)

    def commit(self):
        activity_id = instrument.begin(
            'validator commit', graph_id=self.graph.id, version=self.graph.version)

        ts_begin = time.time()
        self._engine_on_graph()
        instrument.checkpoint(activity_id, 'QE on_graph')

        ts_on_commit = time.time()
        self.on_commit()
        instrument.checkpoint(activity_id, 'on_commit')

        ts_errors_commit = time.time()
        source_versions = None
        if self._input_source_name:
            source_versions = {
                self._input_source_name: self.graph.version,
            }
        self.errors.commit(source_versions=source_versions)
        instrument.checkpoint(activity_id, 'errors commit')

        ts_end = time.time()

        instrument.end(activity_id)
        self._stats_commit.add_entry({
            'tags': {
                'graph_id': self.graph.id,
                'graph_version': self.graph.version,
            },
            'engine_on_graph': ts_on_commit - ts_begin,
            'on_commit': ts_errors_commit - ts_on_commit,
            'errors_commit': ts_end - ts_errors_commit,
        })

    def on_commit(self):
        pass

    def on_graph(self, graph):
        if not self._react_to_updates:
            self._react_to_updates = True
            with PROFILE('%s initial execute all:' % graph.id):
                self.execute()
        self.commit()

    def on_node(self, graph, old_node, new_node):
        if not self._react_to_updates:
            return
        self._engine.on_node(graph, old_node, new_node)

    def on_relationship(self, graph, old_rel, new_rel):
        if not self._react_to_updates:
            return
        self._engine.on_relationship(graph, old_rel, new_rel)


class NoopValidator(object):
    def __init__(self, graph, errors=None, builder_lib=None,
                 query_engine_type=None, *args, **kwargs):
        self.graph = graph
        self.errors = errors or MemoryErrorReporter()

    def start(self):
        pass

    def stop(self):
        pass

    def commit(self):
        pass

    def execute(self):
        pass


def get_facade_validator(design, *args, **kwargs):
    validator_cls = getattr(design, 'FacadeValidator', None)
    if validator_cls is None:
        validator_cls = getattr(design, 'Validator', Validator)

    return validator_cls(*args, **kwargs)


def get_rbac_validator(design, *args, **kwargs):
    validator_cls = getattr(design, 'RbacValidator', NoopValidator)
    return validator_cls(*args, **kwargs)


def assert_errors(validator, design):
    node_errors = validator.errors.get_node_errors(severity=Severity.CRITICAL)
    rel_errors = validator.errors.get_relationship_errors(severity=Severity.CRITICAL)

    if node_errors or rel_errors:
        design_errors = getattr(design, 'Errors', None)
        raise schema.ValidationError({
            'nodes': dump_errors(node_errors, design_errors),
            'relationships': dump_errors(rel_errors, design_errors)
        })


def run_with_rbac_validator(design, blueprint_authorizer, user_id, graph,
                            permissions, f):
    user = blueprint_authorizer.get_user(user_id)
    username = user.username if user else ''
    tenants = blueprint_authorizer.get_tenants(user_id, graph.id, permissions)

    # FIXME: Use CPP QE for CPP graph stack instead of SDK QE unconditionally
    tenancy_validator = get_rbac_validator(design,  graph=graph,
                                           user=username, tenants=tenants)
    tenancy_validator.start()
    try:
        result = f()
        tenancy_validator.commit()
        assert_errors(tenancy_validator, design)
        return result
    finally:
        tenancy_validator.stop()
