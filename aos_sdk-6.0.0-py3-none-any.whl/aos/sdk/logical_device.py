#!/usr/bin/env python3
# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import copy
from six.moves import range
from six.moves import zip

SPEED_UNIT_MULTIPLIERS = {'M': 1, 'G': 1000}


def port_speeds_match(speed1, speed2):
    """Returns True if port speeds match"""
    value1 = speed1['value'] * SPEED_UNIT_MULTIPLIERS[speed1['unit']]
    value2 = speed2['value'] * SPEED_UNIT_MULTIPLIERS[speed2['unit']]
    return value1 == value2


def logical_port_groups_match(port_group1, port_group2):
    """Returns True if and only if given port groups (dictionary representation)
       are a match (identical)
    """
    return (
        port_group1['count'] == port_group2['count'] and
        port_speeds_match(port_group1['speed'], port_group2['speed']) and
        set(port_group1['roles']) == set(port_group2['roles'])
    )

def logical_panels_match(panel1, panel2):
    """Returns True if and only if the given panels (dictionary represenation)
       are a match, i.e. their panel layout and port groups are identical, and
       panels start with the same port index
    """
    return (
        panel1['panel_layout'] == panel2['panel_layout'] and
        all(logical_port_groups_match(pg1, pg2)
            for pg1, pg2 in zip(panel1['port_groups'], panel2['port_groups'])) and
        panel1['port_indexing']['start_index'] == \
        panel2['port_indexing']['start_index']
    )

def logical_devices_match(device1, device2):
    """Given two logical devices (dictionary representation), returns True if and
       only if their panels match. Two panels match if their panel layout and port
       groups are identical.
    """
    panels1 = device1.get('panels', [])
    panels2 = device2.get('panels', [])
    if len(panels1) != len(panels2):
        return False
    for i in range(len(panels1)):
        if not logical_panels_match(panels1[i], panels2[i]):
            return False
    return True


class LogicalDeviceBuilder(object):
    """Instances of this class allows programmatic creation of
       Aos::IPFabric::LogicalDevice entities. User first creates a dictionary
       representation of the logical device using the member functions, and
       then use entity_loads() to update a LogicalDevice entity using the
       constructed dictionary representation. Each instance of this class
       is to be used for construction of one LogicalDevice.
    """
    def __init__(self, display_name=''):
        """init"""
        self.device = {
            'id': display_name,
            'display_name': display_name,
            'panels': []
        }

    def add_panel(self, port_start_index, port_row_count, port_column_count,
                  schema='absolute', order='T-B, L-R'):
        """Add a logical panel to dictionary representation of logical device"""
        if port_start_index < 0:
            raise ValueError('Invalid starting port index: %d' % port_start_index)
        if port_row_count <= 0 or port_column_count <= 0:
            raise ValueError('Invalid port layout %d x %d' % \
                             (port_row_count, port_column_count))
        panel = {
            'port_indexing': {
                'order': order,
                'schema': schema,
                'start_index': port_start_index
            },
            'panel_layout': {
                'row_count': port_row_count,
                'column_count': port_column_count
            },
            'port_groups': []
        }
        self.device['panels'].append(panel)

    def panel_max_port_count(self, panel):
        """Get maximum port capacity of logical panel"""
        layout = panel['panel_layout']
        return layout['row_count'] * layout['column_count']

    def panel_port_count(self, panel):
        """Get current port count of logical panel based on existing port groups"""
        return sum([group['count'] for group in panel['port_groups']])  # pylint: disable=consider-using-generator

    def add_port_group(self, panel_id, port_count, speed, speed_unit, roles):
        """Add a port group to a logical panel. The port group must not cause
           the panel's port capacity to be overflowed.
        """
        if panel_id <= 0 or panel_id > len(self.device['panels']):
            raise ValueError('Panel %d does not exist' % panel_id)
        if port_count <= 0:
            raise ValueError('Invalid port count %d' % port_count)
        panel = self.device['panels'][panel_id - 1]
        cur_port_count = self.panel_port_count(panel)
        max_port_count = self.panel_max_port_count(panel)
        if cur_port_count + port_count > max_port_count:
            raise ValueError('Panel %d does not have %d free ports ' \
                             '(now has %d ports, max %d ports)' % \
                             (panel_id, port_count, cur_port_count, max_port_count))
        group = {'count': port_count,
                 'speed': {'value': speed, 'unit': speed_unit},
                 'roles': roles}
        panel['port_groups'].append(group)

    @property
    def json(self):
        """Return json representation of logical device"""
        return copy.deepcopy(self.device)
