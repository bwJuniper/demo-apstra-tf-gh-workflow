#!/usr/bin/python
# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula
""" Schema for Telemetry Collector """

from .types import (
    Any,
    Boolean,
    Dict,
    Enum,
    FirstFailing,
    Float,
    Integer,
    IpAddress,
    Ipv4OrIpv6Address,
    List,
    MacAddress,
    MacAddressOrEmpty,
    MAX_VLAN_ID,
    Object,
    Optional,
    OneOf,
    Preprocess,
    Range,
    Regexp,
    SecurityZoneName,
    String,
    Transform,
    ValidationError,
    validated_type,
)


def prefix_range_check(data):
    return int(data) >= 0 and int(data) <= 128


def interface_lane_index_validator(data):
    if not data.isdigit():
        raise ValidationError('Interface lane index should be positive integer')
    elif int(data) < 0 or int(data) > 255:
        raise ValidationError('Interface lane index should be from 0 to 255')


def to_camel_case(snake, lower_camel_case=False):
    camel_case_str = ''.join(word.capitalize() for word in snake.split('_'))

    if lower_camel_case:
        camel_case_str = camel_case_str[0].lower() + camel_case_str[1:]

    return camel_case_str


IPv4OrIPv6PrefixLen = validated_type(String, 'IPv4OrIPv6PrefixLen',
                                     validate=prefix_range_check)


OpticalInterfaceLane = validated_type(String, 'OpticalInterfaceLane',
                                      validate=interface_lane_index_validator)


lldp = Object({
    'items': List(Optional(Object({
        'interface_name': String(),
        'neighbor_system_id': String(),
        'neighbor_interface_name': String(),
        'sys_description': String(),
        'chassis_id': MacAddressOrEmpty()
    })))
})

optical_xcvr = Object({
    'items': List(Object({
        'name': String(
            description='Interface name'),
        'property': Object({
            # Common properties.
            'wave_length': Float(
                description='The length of the wave. Units: nm.'),
            'media_type': String(
                description='The type of the media.'),
            'vendor_sn': String(
                description='Vendor Serial Number.'),
            'fiber_type': Transform(
                Enum(['unknown', 'single_mode', 'multi_mode'],
                     description='Type of the fiber.'),
                post_load=lambda data: to_camel_case(data, lower_camel_case=True),
            ),
            'vendor': String(
                description='Vendor name'),
            'part_number': String(
                description='Vendor\'s part number'),

            # Per interface thresholds.
            'temperature_low_warn': Float(
                description='The warning is raised when '
                'temperature gets lower than this value. Units: C.'),
            'temperature_high_warn': Float(
                description='The warning is raised when '
                'temperature gets higher than this value. Units: C.'),
            'temperature_low_alarm': Float(
                description='The alarm is raised when '
                'temperature gets lower than this value. Units: C.'),
            'temperature_high_alarm': Float(
                description='The alarm is raised when '
                'temperature gets higher than this value. Units: C.'),

            'voltage_low_warn': Float(
                description='The warning is raised when '
                'voltage gets lower than this value. Units: V.'),
            'voltage_high_warn': Float(
                description='The warning is raised when '
                'voltage gets higher than this value. Units: V.'),
            'voltage_low_alarm': Float(
                description='The alarm is raised when '
                'voltage gets lower than this value. Units: V.'),
            'voltage_high_alarm': Float(
                description='The alarm is raised when '
                'voltage gets higher than this value. Units: V.'),

            # Per lane thresholds.
            'tx_power_low_warn': Float(
                description='The warning is raised when '
                'tx_power gets lower than this value. Units: dBm.'),
            'tx_power_high_warn': Float(
                description='The warning is raised when '
                'tx_power gets higher than this value. Units: dBm.'),
            'tx_power_low_alarm': Float(
                description='The alarm is raised when '
                'tx_power gets lower than this value. Units: dBm.'),
            'tx_power_high_alarm': Float(
                description='The alarm is raised when '
                'tx_power gets higher than this value. Units: dBm.'),

            'rx_power_low_warn': Float(
                description='The warning is raised when '
                'rx_power gets lower than this value. Units: dBm.'),
            'rx_power_high_warn': Float(
                description='The warning is raised when '
                'rx_power gets higher than this value. Units: dBm.'),
            'rx_power_low_alarm': Float(
                description='The alarm is raised when '
                'rx_power gets lower than this value. Units: dBm.'),
            'rx_power_high_alarm': Float(
                description='The alarm is raised when '
                'rx_power gets higher than this value. Units: dBm.'),

            'tx_bias_low_warn': Float(
                description='The warning is raised when '
                'tx_bias gets lower than this value. Units: mA.'),
            'tx_bias_high_warn': Float(
                description='The warning is raised when '
                'tx_bias gets higher than this value. Units: mA.'),
            'tx_bias_low_alarm': Float(
                description='The alarm is raised when '
                'tx_bias gets lower than this value. Units: mA.'),
            'tx_bias_high_alarm': Float(
                description='The alarm is raised when '
                'tx_bias gets higher than this value. Units: mA.'),
        }, allow_extra_fields=False),

        # Per interface actual values.
        'interface': Object({
            'temperature': Float(
                description='The current temperature value. Units: C.'),
            'temperature_has_low_warn': Boolean(
                description='Is temperature out of warning lower threshold'),
            'temperature_has_high_warn': Boolean(
                description='Is temperature out of warning higher threshold'),
            'temperature_has_low_alarm': Boolean(
                description='Is temperature out of alarm lower threshold'),
            'temperature_has_high_alarm': Boolean(
                description='Is temperature out of alarm higher threshold'),
            'voltage': Float(
                description='The current voltage value. Units: V.'),
            'voltage_has_low_warn': Boolean(
                description='Is voltage out of warning lower threshold'),
            'voltage_has_high_warn': Boolean(
                description='Is voltage out of warning higher threshold'),
            'voltage_has_low_alarm': Boolean(
                description='Is voltage out of alarm lower threshold'),
            'voltage_has_high_alarm': Boolean(
                description='Is voltage out of alarm higher threshold'),
        }, allow_extra_fields=False),

        # Per lane actual values.
        'lane': Dict(values=Object({
            'tx_power': Float(
                description='The current tx_power value. Units: dBm.'),
            'tx_power_has_low_warn': Boolean(
                description='Is tx_power out of warning lower threshold'),
            'tx_power_has_high_warn': Boolean(
                description='Is tx_power out of warning higher threshold'),
            'tx_power_has_low_alarm': Boolean(
                description='Is tx_power out of alarm lower threshold'),
            'tx_power_has_high_alarm': Boolean(
                description='Is tx_power out of alarm higher threshold'),

            'rx_power': Float(
                description='The current rx_power value. Units: dBm.'),
            'rx_power_has_low_warn': Boolean(
                description='Is rx_power out of warning lower threshold'),
            'rx_power_has_high_warn': Boolean(
                description='Is rx_power out of warning higher threshold'),
            'rx_power_has_low_alarm': Boolean(
                description='Is rx_power out of alarm lower threshold'),
            'rx_power_has_high_alarm': Boolean(
                description='Is rx_power out of alarm higher threshold'),

            'tx_bias': Float(
                description='The current tx_bias value. Units: mA.'),
            'tx_bias_has_low_warn': Boolean(
                description='Is tx_bias out of warning lower threshold'),
            'tx_bias_has_high_warn': Boolean(
                description='Is tx_bias out of warning higher threshold'),
            'tx_bias_has_low_alarm': Boolean(
                description='Is tx_bias out of alarm lower threshold'),
            'tx_bias_has_high_alarm': Boolean(
                description='Is tx_bias out of alarm higher threshold'),
        }, allow_extra_fields=False), key_type=OpticalInterfaceLane()),
    }, allow_extra_fields=False))
})

environment = Object({
    'power_supplies': List(Object({
        'name': String(),
        'status': Enum(['ok', 'testing', 'failed', 'absent', 'present',
                        'offline', 'no_data']),
        'airflow_direction': Enum(['unknown', 'front_to_back', 'back_to_front']),
        'fans': List(Object({
            'name': String(),
            'status': Enum(['ok', 'check']),
            'speed': Optional(Integer())
        })),
        'temperature_sensors': List(Object({
            'name': String(),
            'status': Enum(['ok', 'yellow', 'red', 'fire', 'no_data']),
            'measurement': Float(),
        })),
    })),
    'ok_power_supply_count': Integer(),
    'fan_trays': List(Object({
        'name': String(),
        'airflow_direction': Enum(['front_to_back', 'back_to_front']),
        'fans': List(Object({
            'name': String(),
            'status': Enum(['ok', 'check']),
            'speed': Integer(),
        })),
    })),
    'temperature_sensors': List(Object({
        'name': String(),
        'status': Enum(['ok', 'yellow', 'red', 'fire', 'no_data']),
        'measurement': Float(),
    })),
    'airflow_alarms': List(Object({
        'description': String(),
    })),
})


interface = Object({
    'items': List(Optional(Object({
        'interface_name': String(),
        'value': Enum(['unknown', 'down', 'up', 'missing']),
        'admin_state': Optional(
            Enum(['unknown', 'down', 'up', 'missing']),
            load_default='unknown',
        ),
    })))
})

nsxt = Object({
    'uplink_profiles': List(Optional(Object({
        'name': String(),
        'label': String(),
        'transport_vlan': Integer(validate=Range(min=0, max=MAX_VLAN_ID)),
        'teaming': List(Object({
            'name': String(),
            'active_list': List(String()),
            'standby_list': List(String()),
            'teaming_policy': Enum(['failover', 'loadbalance', 'loadbalancemac']),
        }))
    }))),
    'logical_switches': List(Optional(Object({
        'name': String(),
        'label': String(),
        'type': Enum(['overlay', 'vlan']),
        'vlan': Optional(List(Integer(validate=Range(min=0, max=MAX_VLAN_ID)))),
        'vni' : Optional(Integer()),
        'tz_id': String(),
        'teaming_name': String(),
    }))),
    'transport_zones': List(Object({
        'id': String(),
        'type': Enum(['overlay', 'vlan']),
        'label': String(),
    })),
    'transport_nodes': List(Object({
        'name': String(),
        'label': String(),
        'type': Enum(['compute', 'edge']),
        'host_name': String(),
        'host_id': String(),
        'vcenter_uuid': String(),
        'host_switch': List(Object({
            'name': String(),
            'label': String(),
            'uplink_profile': List(String()),
            'uplink_map': List(Object({
                'nsxt_uplink': String(),
                'vds_uplink': String()
            })),
            'tz_endpoint': List(String()),
            'tunnel_endpoint': List(Object({
                'interface': String(),
                'ip': String()
            })),
        })),
    })),
    'management_ip': String(),
})


# TODO: Fix Tac code to use integers for ASNs, then remove this type
StringAsn = validated_type(String, 'StringAsn', validate=FirstFailing(
    Regexp(r'\d+'), Preprocess(int, Range(1, 2**32-1))
))


# The following FsmState is a temporary workaround. Ideally we need the Fsm State to
# be a string. Till we make that change, we will support a set of enums and in case
# the device reports a device specific state, the catch all "intransition" state
# is utilized. Having a Enum that overrides to a "catch all" value on load is not
# ideal(the validation makes no more sense), but considering this to be a stop gap
# solution, this should be alright.
class EnumWithCatchAll(Enum):
    def __init__(self, choices, catch_all_value, *args, **kwargs):
        self.choices = choices
        self.catch_all_value = catch_all_value
        super(EnumWithCatchAll, self).__init__(choices, *args, **kwargs)

    def load(self, value, *args, **kwargs):
        # The value received is not among the known choices. Override the value to be
        # 'intransition'.
        if value not in self.choices:
            value = self.catch_all_value
        return super(EnumWithCatchAll, self).load(value, *args, **kwargs)


bgp = Object({
    'items': List(Optional(Object({
        # source address can be unspecified (None) when there is no known
        # route to the peer and so a local address can not be inferred
        'source_ip': Optional(Ipv4OrIpv6Address()),
        'source_asn': StringAsn(),
        'dest_ip': Ipv4OrIpv6Address(),
        'dest_asn': StringAsn(),
        'vrf_name': SecurityZoneName(),
        'addr_family': Enum(
            ['ipv4', 'ipv6', 'evpn'],
            description='Address family'),
        'flap_count': Optional(
            Integer(validate=Range(min=0)),
            load_default=0,
        ),
        'fsm_state': EnumWithCatchAll([
            'idle', 'connect', 'active', 'opensent', 'openconfirm', 'established',
            'intransition'
        ], 'intransition'),
        'value': Enum(['unknown', 'down', 'up', 'missing'])
    })))
})

route = Object({
    'items': List(Optional(Object({
        'prefix': Ipv4OrIpv6Address(),
        'prefix_len': IPv4OrIPv6PrefixLen(),
        'route_status': Enum(['unknown', 'up', 'partial', 'missing']),
        'next_hops': List(Optional(Object({
            'prefix': Ipv4OrIpv6Address(),
            'prefix_len': Optional(IPv4OrIPv6PrefixLen()),
            'tag': String(),
            'type': Enum(['unknown', 'direct', 'bgp', 'stat']),
            'status': Enum(['unknown', 'up', 'missing'])
        })))
    })))
})

route_lookup = Object({
    'items': List(Optional(Object({
        'vrf': String(),
        'target_prefix': Ipv4OrIpv6Address(),
        'target_prefix_len': IPv4OrIPv6PrefixLen(),
        'prefix': Optional(Ipv4OrIpv6Address()),
        'prefix_len': Optional(IPv4OrIPv6PrefixLen()),
        'route_status': Enum(['unknown', 'up', 'missing']),
        'next_hops': List(Optional(Object({
            'prefix': Ipv4OrIpv6Address(),
            'prefix_len': Optional(IPv4OrIPv6PrefixLen()),
            'type': Enum(['unknown', 'direct', 'bgp', 'stat']),
            'status': Enum(['unknown', 'up', 'missing'])
        })))
    })))
})

arp = Object({
    'items': List(Optional(Object({
        'vrf_name': SecurityZoneName(),
        'ip_address': IpAddress(),
        'mac_address': MacAddress(),
        'interface_name': String(),
        'type': Enum(['dynamicArp', 'staticArp', 'unknown']),
        'l2_info': Optional(String())
        })))
})

mac = Object({
    'items': List(Optional(Object({
        'mac_address': MacAddress(),
        'vlan': Integer(validate=Range(min=0, max=MAX_VLAN_ID)),
        'interface_name': String(),
        'type': Enum(['dynamicMac', 'staticMac'])
    })))
})

hostname = Object({
    'items': List(Object({
        'domain': String(),
        'hostname': String()
    }))
})

xcvr = Object({
    'items': List(Optional(Object({
        'interface': String(),
        'xcvr_detail': String()
    })))
})

lag = Object({
    'items': List(Optional(Object({
        'lag_name': String(),
        'value': Enum(['unknown', 'down', 'up', 'missing', 'partial']),
        'interfaces': List(Optional(Object({
            'interface_name': String(),
            'value': Enum(['unknown', 'down', 'up', 'missing'])
        })))
    })))
})

mlag = Object({
    'mlag_global': Optional(Object({
        'domain_id': String(),
        'domain_state': Enum(['active', 'inactive', 'disabled',
                              'missing', 'unknown']),
        'local_interface': Optional(String()),
        'local_intf_status': Optional(Enum(['unknown', 'down', 'up', 'missing']),
                                      load_default='unknown'),
        'peer_link': Optional(String()),
        'peer_link_status': Optional(String()),
        'peer_address': Optional(IpAddress()),
        'config_sanity': Optional(String())
        })),
    'mlag_interface': Optional(List(Object({
        'intf_name': String(),
        'mlag_id': Integer(),
        'intf_state': Enum(['active_full', 'active_partial', 'inactive',
                            'configured', 'disabled', 'missing', 'unknown'])
        })))
})

generic = Object({
    'global': Optional(String()),
    'items': List(Optional(Object({
        'identity': String(),
        'value': Optional(OneOf(types=[String(), Dict(values=Any())])),
    })))
})


def validate_no_pipe(item):
    if '|' in item:
        raise ValidationError('| not allowed')


StringWithoutPipe = validated_type(String, 'StringWithoutPipe', validate_no_pipe)


iba_integer_data = List(
    Object({
        'key': Dict(
            values=StringWithoutPipe(),
            key_type=StringWithoutPipe(),
        ),
        'value': Integer(),
    }),
)

iba_string_data = List(
    Object({
        'key': Dict(
            values=StringWithoutPipe(),
            key_type=StringWithoutPipe(),
        ),
        'value': StringWithoutPipe(),
    }),
)

iba_data = List(
    Dict({
        'key': Dict(
            values=StringWithoutPipe(),
            key_type=StringWithoutPipe(),
        ),
        'value': Dict(
            values=OneOf(
                types={
                    'str': StringWithoutPipe(),
                    'int': Integer(),
                },
            ),
            key_type=StringWithoutPipe(),
        ),
    })
)

# schema for interface counters is same as response from
# "GET /systems/<system_id>/counters"
interface_counters = Object({
    'items': List(Object({
        'interface_name': String(),
        'rx_unicast_packets': Integer(),
        'rx_broadcast_packets': Integer(),
        'rx_multicast_packets': Integer(),
        'rx_error_packets': Integer(),
        'rx_discard_packets': Integer(),
        'rx_bytes': Integer(),
        'tx_unicast_packets': Integer(),
        'tx_broadcast_packets': Integer(),
        'tx_multicast_packets': Integer(),
        'tx_error_packets': Integer(),
        'tx_discard_packets': Integer(),
        'tx_bytes': Integer(),
        'alignment_errors': Integer(),
        'fcs_errors': Integer(),
        'symbol_errors': Integer(),
        'runts': Integer(),
        'giants': Integer(),
    }, description='All counter values are rates per delta_microseconds')),
    'delta_microseconds': Integer(description='microseconds since last update'),
})

# We already have the schema validation done for the builin collectors utilizing
# lollipop schema. We do not require application schema in this case. Hence,
# adding an accept all application schema.
builtin_service_application_schema = {}

default_generic_application_schema = {
    'type': 'object',
    'properties': {
        'identity': {
            'type': 'string',
        },
        'value': {
            'type': 'string',
        },
    },
    'required': ['identity', 'value'],
}

default_iba_integer_application_schema = {
    'type': 'object',
    'properties': {
        'key': {
            'type': 'object',
        },
        'value': {
            'type': 'integer',
        },
    },
    'required': ['key', 'value'],
}

default_iba_string_application_schema = {
    'type': 'object',
    'properties': {
        'key': {
            'type': 'object',
        },
        'value': {
            'type': 'string',
        },
    },
    'required': ['key', 'value'],
}
