# Copyright 2018-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from __future__ import annotations

import base64
import re
import typing as t
import uuid

import six
import slugify

if t.TYPE_CHECKING:
    from aos.sdk import typing as tt

    T = t.TypeVar('T')
    V = t.TypeVar('V')

    class PgSpeedValidation(t.TypedDict):
        port_group: str
        constraint: tt.PortSpeed


def compact_dict(data: t.Mapping[T, V]) -> dict[T, V]:
    """Takes dict and returns new dict with all items with None value removed."""
    return {k: v for k, v in six.iteritems(data) if v is not None}


def gen_id() -> str:
    """Returns random string to be used as unique ID"""
    return str(uuid.uuid4())


def gen_short_id(max_length: int = 0) -> str:
    """Returns short random string with at most 22 characters"""

    return slugify.slugify(
        base64.standard_b64encode(uuid.uuid4().bytes).decode('latin-1'),
        max_length=max_length
    )


def port_speed(
    value: tt.PortSpeedValue,
    unit: tt.PortSpeedUnit = 'G'
) -> tt.PortSpeed:
    """Returns JSON for port speed."""
    return {'value': value, 'unit': unit}


def normalize_port_speed(speed: tt.PortSpeedValue | tt.PortSpeed) -> tt.PortSpeed:
    if isinstance(speed, int):
        speed = port_speed(speed)

    return speed


def format_speed(speed: tt.PortSpeed) -> str:
    return '%d%s' % (speed['value'], speed['unit'])


PORT_SPEED_REGEX: t.Final[t.Pattern[str]] = re.compile('^([0-9]+)([^0-9]+)$')


def deserialize_port_speed(speed_str: str) -> tt.PortSpeed:
    mt = PORT_SPEED_REGEX.match(speed_str)
    assert mt is not None

    value = int(mt.group(1))
    unit = mt.group(2)
    if t.TYPE_CHECKING:
        unit = t.cast(tt.PortSpeedUnit, unit)

    return {'value': value, 'unit': unit}


def gen_pg_speed_validations(
    pg_speeds: t.Iterable[tuple[str, tt.PortSpeed]],
) -> list[PgSpeedValidation]:
    validation_list: list[PgSpeedValidation] = []
    for pg, speed in pg_speeds:
        validation_list.append({'port_group': pg, 'constraint': speed})
    return validation_list


def pg_validations_master_port(self, mp_id, identifier):
    if mp_id is None:
        return None
    validations= gen_pg_speed_validations([(mp_id, identifier)])
    return validations
