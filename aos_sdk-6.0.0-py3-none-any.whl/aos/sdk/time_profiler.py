# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""Simple time profiler for code segments"""

from contextlib import contextmanager
from functools import partial
import time


@contextmanager
def profile(log_func, message):
    begin = time.time()
    try:
        yield
    finally:
        end = time.time()
        log_func('[PROFILE] ' + message + ' %.3lf secs', end - begin)


def make_profiler(log_func):
    return partial(profile, log_func)
