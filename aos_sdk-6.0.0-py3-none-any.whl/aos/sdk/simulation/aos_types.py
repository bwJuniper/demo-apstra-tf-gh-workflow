# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import json

from aos.sdk.simulation.tac_types import (
    TacCollection,
    TacCollectionWithInternalKey,
    TacDateTime,
    TacDir,
    TacEntity,
    TacInstantiatingCollection,
    TacNominal,
    value_to_json,
)


class ArpKey(TacNominal):
    TacConstructingParams = dict([
        ('vrfName', str),
        ('ipAddress', str)
    ])


class BgpSession(TacNominal):
    TacConstructingParams = dict([
        ('sourceIp', str),
        ('sourceAsn', str),
        ('destIp', str),
        ('destAsn', str),
        ('vrfName', str),
        ('addrFamily', str),
    ])


class BgpStatusSession(TacEntity):
    TacConstructingParams = dict([('session', BgpSession)])
    TacEntityType = 'Aos::Device::BgpStatusSession'
    TacAttributes = {
        'flapCount' : (int, 0),
        'value': (str, 'unknown'),
    }

    def collection_key(self, key_name):
        # BgpSession should be converted to a JSON string to be used as
        # a collection key
        for idx, (name, _) in enumerate(self.TacConstructingParams.items()):
            if name == key_name:
                return json.dumps(value_to_json(self.constructing_params[idx]))
        assert False, 'key %s not found' % key_name


class BgpStatus(TacEntity):
    TacEntityType = 'Aos::Device::BgpStatus'
    TacAttributes = {
        'state': (
            TacInstantiatingCollection,
            TacInstantiatingCollection(BgpStatusSession, 'session'),
        ),
        'version' : (int, 0),
    }


class ExecCommandSimulationConfig(TacEntity):
    TacEntityType = 'Aos::Device::ExecCommandSimulationConfig'
    TacAttributes = {
        'response' : (TacCollection, TacCollection(str, str))
    }


class InterfacePfcKey(TacNominal):
    TacConstructingParams = dict([
        ('interfaceName', str),
        ('pfcPriority', str),
    ])


class InterfaceQueueKey(TacNominal):
    TacConstructingParams = dict([
        ('interfaceName', str),
        ('queueId', str),
    ])


class InterfaceQueueForwardingClass(TacNominal):
    TacConstructingParams = dict([
        ('key', InterfaceQueueKey),
        ('pfcPriority', int),
        ('className', str),
    ])

    def collection_key(self, key_name):
        for idx, (name, _) in enumerate(self.TacConstructingParams.items()):
            if name == key_name:
                return json.dumps(value_to_json(self.constructing_params[idx]))
        assert False, 'key %s not found' % key_name


class InterfaceQueueStatsSimulationConfig(TacNominal):
    TacConstructingParams = dict([('simulationType', str)])
    TacAttributes = {
        'constant' : (int, 0),
        'minValue' : (int, 0),
        'maxValue' : (int, 0),
    }


class IpPrefix(TacNominal):
    TacConstructingParams = dict([
        ('ip', str),
        ('prefix', str),
    ])


class MacAddr(TacNominal):
    TacAttributes = dict([
        ('o1', (int, 0)),
        ('o2', (int, 0)),
        ('o3', (int, 0)),
        ('o4', (int, 0)),
        ('o5', (int, 0)),
        ('o6', (int, 0)),
    ])


class MacEntry(TacNominal):
    TacConstructingParams = dict([('macAddress', MacAddr)])
    TacAttributes = {
        'type' : (str, 'dynamicMac'),
        'intfName' : (str, ''),
        'moveCount' : (int, 0),
        # TODO(dqu/rbogorodskiy) add array queue support
        # 'movetime' : (TacDateTime, TacDateTime(0, 0)),
        'lastMoveTime' : (TacDateTime, TacDateTime(0, 0)),
    }

    def collection_key(self, key_name):
        # MacEntry should be converted to a JSON string to be used as
        # a collection key
        for idx, (name, _) in enumerate(self.TacConstructingParams.items()):
            if name == key_name:
                return json.dumps(value_to_json(self.constructing_params[idx]))
        assert False, 'key %s not found' % key_name


class SimulationCounterConfig(TacNominal):
    TacConstructingParams = dict([
        ('name', str),
    ])

    TacAttributes = {
        'simulationType' : (str, 'constant'),
        'averagePktSize' : (int, 512),
        'constantValue' : (int, 0),
        'minValue' : (int, 0),
        'maxValue' : (int, 0),
        'meanValue' : (int, 0),
        'stdDeviation' : (int, 0)
    }


class CommandPollerSimulationConfig(TacEntity):
    TacEntityType = 'Aos::Device::CommandPollerSimulationConfig'
    TacAttributes = {
        'successCount' : (int, 1),
        'failureCount' : (int, 0),
        'timeoutCount' : (int, 0),
        'underrunCount' : (int, 0),
        'waitingTimeSimType' : (str, 'constant'),
        'waitingTimeMean' : (float, 0.0025),
        'waitingTimeDeviation' : (float, 0),
        'waitingTimeMin' : (float, 0),
        'waitingTimeMax' : (float, 0),
        'grpcConfigChangeResetCount' : (int, 0),
        'grpcSequenceNumberOverrun' : (int, 0),
        'grpcConnectionResetCount' : (int, 0),
        'grpcResponseProcessingFailure' : (int, 0),
        'grpcServerResetCount' : (int, 0),
        'grpcInitiateCount' : (int, 0),
        'grpcInSyncCount' : (int, 0),
    }


class ArpEntry(TacEntity):
    TacConstructingParams = dict([('arpKey', ArpKey)])
    TacEntityType = 'Aos::Device::ArpEntry'
    TacAttributes = {
        'macAddress' : (MacAddr, ''),
        'type' : (str, 'dynamicArp'),
        'l3IntfName' : (str, ''),
        'l2Info' : (str, ''),
        'lastChange' : (TacDateTime, TacDateTime(0, 0)),
        'version' : (int, 0),
    }

    def collection_key(self, key_name):
        # ArpEntry should be converted to a JSON string to be used as
        # a collection key
        for idx, (name, _) in enumerate(self.TacConstructingParams.items()):
            if name == key_name:
                return json.dumps(value_to_json(self.constructing_params[idx]))
        assert False, 'key %s not found' % key_name


class ArpConfig(TacEntity):
    TacEntityType = 'Aos::Device::ArpConfig'
    TacAttributes = {
        'entry': (
            TacInstantiatingCollection,
            TacInstantiatingCollection(ArpEntry, 'arpKey'),
        ),
        'mode' : (str, 'open'),
        'version' : (int, 0),
    }


class ArpSimulationConfig(TacEntity):
    TacEntityType = 'Aos::Device::ArpSimulationConfig'
    TacAttributes = {
        'pollerSimulationConfig' :
            (CommandPollerSimulationConfig,
             CommandPollerSimulationConfig('pollerSimulationConfig')),
        'simulationType' : (str, 'useConfig'),
        'arpConfig' : (ArpConfig, ArpConfig('arpConfig')),
        'intfNames' : (TacCollection, TacCollection(int, str)),
        'entryCount' : (int, 0),
        'baseMacAddr' : (MacAddr, MacAddr()),
        'baseIpPrefix' : (IpPrefix, IpPrefix('', '')),
        'templateVersion': (int, 0),
    }


class BgpSimulationConfig(TacEntity):
    TacEntityType = 'Aos::Device::BgpSimulationConfig'
    TacAttributes = {
        'pollerSimulationConfig' :
            (CommandPollerSimulationConfig,
             CommandPollerSimulationConfig('pollerSimulationConfig')),
        'simulationType' : (str, 'useConfig'),
        'bgpStatus' : (BgpStatus, BgpStatus('bgpStatus')),
        'pollInterval': (float, 5.0),
    }


class InterfaceEgressQueueStats(TacEntity):
    TacConstructingParams = dict([('key', InterfaceQueueKey)])
    TacEntityType = 'Aos::Device::Simulation::InterfaceEgressQueueStats'
    TacAttributes = {
        'queuedPackets' : (
            InterfaceQueueStatsSimulationConfig,
            InterfaceQueueStatsSimulationConfig('constant')
        ),
        'droppedPackets' : (
            InterfaceQueueStatsSimulationConfig,
            InterfaceQueueStatsSimulationConfig('constant')
        ),
        'txPackets': (
            InterfaceQueueStatsSimulationConfig,
            InterfaceQueueStatsSimulationConfig('constant')
        ),
        'txEcnPackets': (
            InterfaceQueueStatsSimulationConfig,
            InterfaceQueueStatsSimulationConfig('constant')
        )
    }

    def collection_key(self, key_name):
        for idx, (name, _) in enumerate(self.TacConstructingParams.items()):
            if name == key_name:
                return json.dumps(value_to_json(self.constructing_params[idx]))
        assert False, 'key %s not found' % key_name


class EgressQueueStatsSimulationConfig(TacEntity):
    TacEntityType = \
        'Aos::Device::Simulation::EgressQueueStatsSimulationConfig'
    TacAttributes = {
        'pollerSimulationConfig' : (
            CommandPollerSimulationConfig,
            CommandPollerSimulationConfig('pollerSimulationConfig')
        ),
        'interfaceEgressQueuesData' : (
            TacInstantiatingCollection,
            TacInstantiatingCollection(InterfaceEgressQueueStats, 'key')),
    }


class ForwardingClassOfServiceSimulationConfig(TacEntity):
    TacEntityType = \
        'Aos::Device::Simulation::ForwardingClassOfServiceSimulationConfig'
    TacAttributes = {
        'pollerSimulationConfig' : (
            CommandPollerSimulationConfig,
            CommandPollerSimulationConfig('pollerSimulationConfig')
        ),
        'interfaceQueuesForwardingClassData' : (
            TacCollectionWithInternalKey,
            TacCollectionWithInternalKey(
                InterfaceQueueForwardingClass, 'key')
        ),
    }


class InterfaceQueueBufferUtilization(TacEntity):
    TacConstructingParams = dict([('key', InterfaceQueueKey)])
    TacEntityType = 'Aos::Device::Simulation::InterfaceQueueBufferUtilization'
    TacAttributes = {
        'peakBufferUtilization' : (
            InterfaceQueueStatsSimulationConfig,
            InterfaceQueueStatsSimulationConfig('constant')
        ),
        'peakBufferUtilizationPercent' : (
            InterfaceQueueStatsSimulationConfig,
            InterfaceQueueStatsSimulationConfig('constant')
        ),
    }

    def collection_key(self, key_name):
        for idx, (name, _) in enumerate(self.TacConstructingParams.items()):
            if name == key_name:
                return json.dumps(value_to_json(self.constructing_params[idx]))
        assert False, 'key %s not found' % key_name


class InterfacePfcBufferUtilization(TacEntity):
    TacConstructingParams = dict([('key', InterfacePfcKey)])
    TacEntityType = 'Aos::Device::Simulation::InterfacePfcBufferUtilization'
    TacAttributes = {
        'peakBufferUtilization' : (
            InterfaceQueueStatsSimulationConfig,
            InterfaceQueueStatsSimulationConfig('constant')
        ),
    }

    def collection_key(self, key_name):
        for idx, (name, _) in enumerate(self.TacConstructingParams.items()):
            if name == key_name:
                return json.dumps(value_to_json(self.constructing_params[idx]))
        assert False, 'key %s not found' % key_name


class InterfaceBufferUtilizationSimulationConfig(TacEntity):
    TacEntityType = \
        'Aos::Device::Simulation::InterfaceBufferUtilizationSimulationConfig'
    TacAttributes = {
        'pollerSimulationConfig' : (
            CommandPollerSimulationConfig,
            CommandPollerSimulationConfig('pollerSimulationConfig')
        ),
        'interfaceQueueData' : (
            TacInstantiatingCollection,
            TacInstantiatingCollection(
                InterfaceQueueBufferUtilization, 'key')
        ),
        'interfacePfcData': (
            TacInstantiatingCollection,
            TacInstantiatingCollection(
                InterfacePfcBufferUtilization, 'key')
        ),
    }


class InterfaceErrorCount(TacEntity):
    TacConstructingParams = dict([('name', str)])
    TacEntityType = 'Aos::Device::Simulation::InterfaceErrorCount'
    TacAttributes = {
        'errorCount' : (
            InterfaceQueueStatsSimulationConfig,
            InterfaceQueueStatsSimulationConfig('constant')
        ),
    }


class InterfaceInputResourceErrorsSimulationConfig(TacEntity):
    TacEntityType = \
        'Aos::Device::Simulation::InterfaceInputResourceErrorsSimulationConfig'
    TacAttributes = {
        'pollerSimulationConfig' : (
            CommandPollerSimulationConfig,
            CommandPollerSimulationConfig('pollerSimulationConfig')
        ),
        'interfacesErrorCount' : (
            TacInstantiatingCollection,
            TacInstantiatingCollection(InterfaceErrorCount, 'name')
        ),
    }


class InterfacePfcStats(TacEntity):
    TacConstructingParams = dict([('key', InterfacePfcKey)])
    TacEntityType = 'Aos::Device::Simulation::InterfacePfcStats'
    TacAttributes = {
        'txPfc' : (
            InterfaceQueueStatsSimulationConfig,
            InterfaceQueueStatsSimulationConfig('constant')
        ),
        'rxPfc' : (
            InterfaceQueueStatsSimulationConfig,
            InterfaceQueueStatsSimulationConfig('constant')
        ),
    }

    def collection_key(self, key_name):
        for idx, (name, _) in enumerate(self.TacConstructingParams.items()):
            if name == key_name:
                return json.dumps(value_to_json(self.constructing_params[idx]))
        assert False, 'key %s not found' % key_name


class InterfacePfcStatsSimulationConfig(TacEntity):
    TacEntityType = 'Aos::Device::Simulation::InterfacePfcStatsSimulationConfig'
    TacAttributes = {
        'pollerSimulationConfig' : (
            CommandPollerSimulationConfig,
            CommandPollerSimulationConfig('pollerSimulationConfig')
        ),
        'interfacesPfcStatsData' : (
            TacInstantiatingCollection,
            TacInstantiatingCollection(InterfacePfcStats, 'key')
        ),
    }


class FdbEntry(TacEntity):
    TacConstructingParams = dict([('vlan', int)])
    TacEntityType = 'Aos::Device::FdbEntry'
    TacAttributes = {
        'macEntry': (
            TacCollectionWithInternalKey,
            TacCollectionWithInternalKey(MacEntry, 'macAddress'),
        ),
    }

    def collection_key(self, key_name):
        # FdbEntry should be converted to a JSON string to be used as
        # a collection key
        for idx, (name, _) in enumerate(self.TacConstructingParams.items()):
            if name == key_name:
                return json.dumps(value_to_json(self.constructing_params[idx]))
        assert False, 'key %s not found' % key_name


class MacConfig(TacEntity):
    TacEntityType = 'Aos::Device::MacConfig'
    TacAttributes = {
        'entry': (
            TacInstantiatingCollection,
            TacInstantiatingCollection(FdbEntry, 'vlan'),
        ),
        'mode' : (str, 'open'),
        'moveNum' : (int, 5),
        'moveInterval' : (int, 300),
        'version' : (int, 0),
    }


class MacSimulationConfig(TacEntity):
    TacEntityType = 'Aos::Device::MacSimulationConfig'
    TacAttributes = {
        'pollerSimulationConfig' :
            (CommandPollerSimulationConfig,
             CommandPollerSimulationConfig('pollerSimulationConfig')),
        'simulationType' : (str, 'useConfig'),
        'macConfig' : (MacConfig, MacConfig('macConfig')),
        'intfNames' : (TacCollection, TacCollection(int, str)),
        'entryCount' : (int, 0),
        'baseMacAddr' : (MacAddr, MacAddr()),
        'templateVersion': (int, 0),
    }


class SimulationInterfaceCountersConfig(TacEntity):
    TacEntityType = 'Aos::Device::SimulationInterfaceCountersConfig'
    TacAttributes = {
        'speed' : (int, 0),
        'counter' : (TacCollectionWithInternalKey,
                     TacCollectionWithInternalKey(SimulationCounterConfig, 'name')),
        "updatedAt" : (TacDateTime, TacDateTime(0, 0))
    }


class SimulationDeviceCountersConfig(TacEntity):
    TacEntityType = 'Aos::Device::SimulationDeviceCountersConfig'
    TacAttributes = {
        'pollerSimulationConfig' :
            (CommandPollerSimulationConfig,
             CommandPollerSimulationConfig('pollerSimulationConfig')),
        'pollInterval' : (int, 5),
        'intf' : (TacInstantiatingCollection,
                  TacInstantiatingCollection(
                      SimulationInterfaceCountersConfig, 'name')),
        "updatedAt" : (TacDateTime, TacDateTime(0, 0))
    }


class SimulationConfigRoot(TacDir):
    def __init__(self):
        super(SimulationConfigRoot, self).__init__('config')
        self.mkdir('device_info')
        self.mkdir('telemetry')
        self.mkdir('counter')
        self.mkdir('exec')

    @property
    def device_info_root(self):
        return self.entityRef['device_info']

    @property
    def telemetry_root(self):
        return self.entityRef['telemetry']

    @property
    def counter_root(self):
        return self.entityRef['counter']

    @property
    def exec_root(self):
        return self.entityRef['exec']


class OsVersion(TacNominal):
    TacConstructingParams = dict([
        ('version', str),
        ('major', str),
        ('minor', str),
        ('build', str),
    ])


class OffboxAdminStatus(TacEntity):
    TacEntityType = 'Aos::Device::OffboxAdminStatus'
    TacAttributes = {
        'connectionState' :(str, 'connected'),
        'statusMessage' : (str, ''),

        'serialNumber' : (str, ''),
        'packageInstalled' : (TacCollection, TacCollection(str, bool)),
        'installStatusMessage' : (str, ''),
        'operationMode' : (str, 'fullControl'),
        'numNetworkFailures' : (int, 0),
        'lastNetworkFailure' : (TacDateTime, TacDateTime(0, 0)),
        'numOtherFailures' : (int, 0),
        'lastOtherFailure' : (TacDateTime, TacDateTime(0, 0)),
        'updatedAt' : (TacDateTime, TacDateTime(0, 0)),
    }


class DevicePristineInfo(TacEntity):
    TacEntityType = 'Aos::SystemAgent::DevicePristineInfo'
    TacAttributes = {
        'pristineConfig' : (str, ''),
        'isPristineValid' : (bool, True),
        'pristineConfigVersion' : (int, 0),
        'updatedAt' : (TacDateTime, TacDateTime(0, 0)),
    }


class AgentStatus(TacEntity):
    TacEntityType = 'Aos::AgentStatus'
    TacAttributes = {
        'keepaliveCounter' : (int, 0),
    }


class PowerSupply(TacNominal):
    TacConstructingParams = dict([
        ('serialNumber', str),
        ('partNumber', str),
        ('version', str),
    ])


class DeviceInfo(TacEntity):
    TacEntityType = 'Aos::Device::DeviceInfo'
    TacAttributes = {
        'removed' : (bool, False),

        'aosServer' : (str, ''),
        'aosVersion' : (str, ''),
        'architecture' : (str, ''),
        'deviceUptime' : (TacDateTime, TacDateTime(0, 0)),
        'deviceStartTime' : (TacDateTime, TacDateTime(0, 0)),
        'agentStartTime' : (TacDateTime, TacDateTime(0, 0)),
        'fetchedSerialNumber' : (str, ''),
        'hwModel' : (str, ''),
        'hwVersion' : (str, ''),
        'macAddress' : (str, ''),
        'managementInterface' : (str, ''),
        'managementIp' : (str, ''),
        'chassisMacRanges' : (str, ''),
        'osVersion' : (OsVersion, OsVersion('', '', '', '')),
        'osVersionOrdinal' : (int, 0),
        'osFamily' : (str, ''),
        'osVariant' : (str, ''),
        'serialNumber' : (str, ''),
        'vendor' : (str, ''),
        'restDevice' : (bool, False),
        'powerSupplies' : (
            TacCollectionWithInternalKey,
            TacCollectionWithInternalKey(PowerSupply, 'serialNumber')
        ),
        'externalDevice' : (bool, False),
        'deviceProfileId' : (str, ''),
        'version' : (int, 0),
    }


class DeviceInfoDir(TacEntity):
    TacEntityType = 'Aos::Device::DeviceInfoDir'
    TacAttributes = {
        'device' : (TacInstantiatingCollection,
                    TacInstantiatingCollection(DeviceInfo, 'name'))
    }


class HostnameStatus(TacEntity):
    TacEntityType = 'Aos::Device::HostnameStatus'
    TacAttributes = {
        'domain' : (str, ''),
        'hostname' : (str, ''),
        'version' : (int, 0),
    }
