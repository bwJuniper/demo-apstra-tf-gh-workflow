# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from copy import copy
import time


def value_to_json(value):
    if hasattr(value, 'to_json'):
        return value.to_json()
    else:
        return value


class TacNominal:
    TacConstructingParams = dict()
    TacAttributes = {}

    def __init__(self, *args):
        assert len(args) == len(self.TacConstructingParams), \
            'Expect %d args, got %d' % (len(self.TacConstructingParams), len(args))
        idx = 0
        for idx, (name, type_) in enumerate(self.TacConstructingParams.items()):
            assert isinstance(args[idx], type_), 'Wrong type, expect %r, got %r' % (
                type_, args[idx])
        self.__dict__['constructing_params'] = args
        self.__dict__['attributes'] = {
            name: copy(value)
            for name, (_, value) in self.TacAttributes.items()
        }

    def __copy__(self):
        return self.__class__(
            *[copy(v) for v in self.__dict__['constructing_params']])

    def __getattr__(self, name):
        if name in self.TacConstructingParams:
            return self.collection_key(name)
        elif name in self.TacAttributes:
            return self.attributes[name]
        assert False, 'Unknown attribute %s' % name

    def __setattr__(self, name, value):
        assert name not in self.TacConstructingParams, \
            'Constructing parame %s is read-only' % name
        assert name in self.TacAttributes, \
            'Unknown attribute %s' % name
        assert isinstance(value, self.TacAttributes[name][0]), \
            'Wrong type, expect %r, got %r' % (self.TacAttributes[name][0], value)
        self.attributes[name] = value

    def collection_key(self, key_name):
        for idx, (name, _) in enumerate(self.TacConstructingParams.items()):
            if name == key_name:
                return value_to_json(self.constructing_params[idx])
        assert False, 'key %s not found' % key_name

    def to_json(self):
        return dict(
            list(zip(list(self.TacConstructingParams.keys()),
                     [value_to_json(param) for param in self.constructing_params])),
            **{
                name: value_to_json(value)
                for name, value in self.attributes.items()
            },
        )


class EntityTypeRegistry(type):
    TypeMap = {}

    def __init__(cls, clsname, bases, attrs):
        tac_type_string = attrs.get('TacEntityType')
        if tac_type_string:
            assert tac_type_string not in EntityTypeRegistry.TypeMap, \
                '%s is already defined by %r' % (
                    tac_type_string, EntityTypeRegistry.TypeMap[tac_type_string])
        EntityTypeRegistry.TypeMap[tac_type_string] = cls
        super(EntityTypeRegistry, cls).__init__(clsname, bases, attrs)


class TacEntity(TacNominal, metaclass=EntityTypeRegistry):
    """
    Only simple Tac::Entity keyed by name is supported
    """
    TacEntityType = None
    TacConstructingParams = dict([('name', str)])

    def __init__(self, name):
        assert self.TacEntityType, 'Please declare TacEntityType'
        super(TacEntity, self).__init__(name)

    def to_json_with_type(self):
        return dict(self.to_json(), **{"_type": self.TacEntityType})


class TacCollection:
    def __init__(self, key_type, value_type):
        self._key_type = key_type
        self._value_type = value_type
        self._collection = {}

    def __getitem__(self, key):
        return self._collection[key]

    def __setitem__(self, key, value):
        assert isinstance(key, self._key_type), \
            'wrong key type, expect %r, got %r' % (self._key_type, key)
        assert isinstance(value, self._value_type), \
            'wrong value type, expect %r, got %r' % (self._value_type, value)
        self._collection[key] = value

    def to_json(self):
        return {
            value_to_json(key): value_to_json(value)
            for key, value in self._collection.items()
        }


class TacCollectionWithInternalKey:
    def __init__(self, element_type, key):
        assert key in element_type.TacConstructingParams, \
            '%s is not a constructing parameter' % key
        self._element_type = element_type
        self._key = key
        self._collection = {}

    def __copy__(self):
        # We only use copy when instantiating a new instance from
        # a type in which case the collection should always be empty
        assert not self._collection, 'deep copy is not supported'
        return self.__class__(self._element_type, self._key)

    # pylint: disable=invalid-name
    def addMember(self, element):
        assert isinstance(element, self._element_type), \
            'Wrong element type, expect %r, got %r' % (
                self._element_type, element)
        collection_key = element.collection_key(self._key)
        self._collection[collection_key] = element

    def __getitem__(self, key):
        return self._collection[key]

    def to_json(self):
        return {
            name: element.to_json()
            for name, element in self._collection.items()
        }


class TacInstantiatingCollection(TacCollectionWithInternalKey):
    def __init__(self, element_type, key):
        assert issubclass(element_type, TacEntity)
        super(TacInstantiatingCollection, self).__init__(element_type, key)

    # pylint: disable=invalid-name
    def addMember(self, element):
        assert False, 'Use newMember instead'

    # pylint: disable=invalid-name
    def newMember(self, name):
        if name in self._collection:
            return self._collection[name]
        element = self._element_type(name)
        super(TacInstantiatingCollection, self).addMember(element)
        return element


class TacEntityRefCollection(TacCollectionWithInternalKey):
    def __init__(self, name):
        assert name == 'name', 'Entity under Tac::Dir must be keyed by name'
        super(TacEntityRefCollection, self).__init__(TacEntity, name)

    def __copy__(self):
        # We only use copy when instantiating a new instance from
        # a type in which case the collection should always be empty
        assert not self._collection, 'deep copy is not supported'
        return self.__class__(self._key)

    # pylint: disable=invalid-name
    def addMember(self, element):
        assert False, 'Use newEntity instead'

    # pylint: disable=invalid-name
    def newEntity(self, entity_type_name, name):
        assert entity_type_name in EntityTypeRegistry.TypeMap, \
            'Unknown entity type %s' % entity_type_name
        element_type = EntityTypeRegistry.TypeMap[entity_type_name]
        element = self._collection.get(name)
        if element is not None:
            assert isinstance(element, element_type), \
            f'Overriding element {name} from type {type(element)} ' \
            f'to {entity_type_name} is not supported'
            return element
        element = EntityTypeRegistry.TypeMap[entity_type_name](name)
        # The result could be a new entity (i.e. the element object that created
        # above) or an existing one
        super(TacEntityRefCollection, self).addMember(element)
        return element

    def to_json(self):
        return {
            name: element.to_json_with_type()
            for name, element in self._collection.items()
        }


class TacDir(TacEntity):
    TacEntityType = 'Tac::Dir'
    TacAttributes = {
        'entityRef' : (TacEntityRefCollection,
                       TacEntityRefCollection('name'))
    }

    # pylint: disable=invalid-name
    def mkdir(self, path):
        assert not path.startswith('/'), 'Relative path only'
        subdir = self
        for subdir_path in path.split('/'):
            subdir = subdir.entityRef.newEntity('Tac::Dir', subdir_path)
        return subdir

    # pylint: disable=invalid-name
    def newEntity(self, entity_type_name, name):
        return self.entityRef.newEntity(entity_type_name, name)


class TacDateTime(TacNominal):
    TacConstructingParams = dict([
        ('secs', int),
        ('usecs', int)
    ])

    @classmethod
    def now(cls):
        now = time.time()
        secs = int(now)
        usecs = int((now % 1) * 10 ** 6)
        return cls(secs, usecs)
