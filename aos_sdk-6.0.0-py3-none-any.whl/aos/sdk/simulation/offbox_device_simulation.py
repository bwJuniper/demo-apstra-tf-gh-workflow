#!/usr/bin/env python3
# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

# This script is used to simulate offbox devices that can be deployed in an AOS
# blueprint. To use this script, you need to provide a JSON file that contains the
# device information. The JSON file should use the following schema:
# [
#     {
#         "management_ip": <string>,
#         "series_number": <string>,
#         "hw_model": <string>,
#         "hw_version": <string>,
#         "os_family": <string>,
#         "os_version": {
#             "major": <string>,
#             "minor": <string>,
#             "build": <string>
#         },
#         "vendor": <string>,
#         "hostname": <string>,
#         "job_id": <string>
#     },
#     ...
# ]
#
# For example:
# [
#     {
#         "management_ip": "1.1.1.1",
#         "series_number": "Junos-1",
#         "hw_model": "QFX10002-72Q",
#         "hw_version": "REV 03",
#         "os_family": "Junos",
#         "os_version": {
#             "major": "23",
#             "minor": "4r2",
#             "build": "11"
#         },
#         "vendor": "Juniper",
#         "hostname": "spine1",
#         "job_id": "1cd3134b-8409-45f5-897e-1df192b371c9"
#     },
#     {
#         "management_ip": "1.1.1.2",
#         "series_number": "Junos-2",
#         "hw_model": "QFX10002-72Q",
#         "hw_version": "REV 03",
#         "os_family": "Junos",
#         "os_version": {
#             "major": "23",
#             "minor": "4r2",
#             "build": "11"
#         },
#         "vendor": "Juniper",
#         "hostname": "spine2",
#         "job_id": "e0fdd356-efa4-419f-b36a-a4e9509b5271"
#     }
# ]
#
# Note that the "<vendor>_<hw_model>_<os_family>" string that is combined by three
# field values in the JSON file must match the device profile names defined in AOS.
# The full list of device profiles can be found in the "label" field under the
# response of calling REST API GET /api/device-profiles
#
# Meanwhile, before simulating the offbox devices, corresponding offbox agents must
# be created in AOS "Managed Devices" page on web UI. The value needed for the
# "job_id" field in the JSON file can be found in the "id" field under the response
# of calling REST API GET /api/system-agents

import argparse
import json
import os
import socket

from aos.sdk.simulation.aos_types import DeviceInfoDir, OsVersion
from aos.sdk.simulation.tac_types import TacDir, TacDateTime


AGENT_DIR = 'agents'
DEVICE_PRISTINE_INFO_DIR = 'aos/v0/device/deployment/pristine'
DEVICE_TELEMETRY_INFO_DIR = 'aos/v0/device/telemetry/info'
DEVICE_TELEMETRY_STATUS_DIR = 'aos/v0/device/telemetry/status'
OFFBOX_ADMIN_STATUS_DIR = 'aos/v0/device/admin/offbox/status'

MAIN_PARTITION = 'Main'
TELEMETRY_PARTITION = 'Telemetry'


def get_my_ip_address() -> str:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.connect(('8.8.8.8', 80))
    source_ip = sock.getsockname()[0]
    sock.close()
    return source_ip


def load_json_file(file_path: str) -> list[dict]:
    assert os.path.exists(file_path), f'File {file_path} does not exist'
    with open(file_path, 'r') as file:
        content = json.load(file)
    for device in content:
        # Sanity check
        for key in ('management_ip', 'series_number', 'hw_model', 'hw_version',
                    'os_family', 'os_version', 'vendor', 'hostname', 'job_id'):
            assert key in device, f'Missing key {key} in device info {device}'
    return content


def simulate_offbox_status(devices: list[dict], path_to_json: dict[str, dict]):
    status_dir = TacDir(OFFBOX_ADMIN_STATUS_DIR.rsplit('/', maxsplit=1)[-1])
    for device in devices:
        status = status_dir.newEntity('Aos::Device::OffboxAdminStatus',
                                      device['job_id'])
        status.connectionState = 'connected'
        status.serialNumber = device['series_number']
        status.updatedAt = TacDateTime.now()
    path_to_json[MAIN_PARTITION][OFFBOX_ADMIN_STATUS_DIR] = \
        status_dir.to_json_with_type()


def simulate_pristine_config(devices: list[dict], path_to_json: dict[str, dict]):
    pristine_dir = TacDir(DEVICE_PRISTINE_INFO_DIR.rsplit('/', maxsplit=1)[-1])
    for device in devices:
        pristine = pristine_dir.newEntity('Aos::SystemAgent::DevicePristineInfo',
                                          device['series_number'])
        pristine.isPristineValid = True
        pristine.pristineConfig = 'system {}'
        pristine.pristineConfigVersion = 1
        pristine.updatedAt = TacDateTime.now()
    path_to_json[MAIN_PARTITION][DEVICE_PRISTINE_INFO_DIR] = \
        pristine_dir.to_json_with_type()


def simulate_main_sysdb_agent_status(devices: list[dict],
                                     path_to_json: dict[str, dict]):
    agents_dir = TacDir(AGENT_DIR)
    for device in devices:
        formatted_ip = device['management_ip'].replace('.', '_')
        agents_dir.newEntity('Aos::AgentStatus',
                             f'DeviceKeeperAgent@offbox,{device["job_id"]},'
                             f'aos-offbox-{formatted_ip}-t')
        agents_dir.newEntity('Aos::AgentStatus',
                             f'DeploymentProxyAgent@offbox,{device["job_id"]},'
                             f'aos-offbox-{formatted_ip}-t')
    path_to_json[MAIN_PARTITION][AGENT_DIR] = agents_dir.to_json_with_type()


def simulate_telemetry_sysdb_agent_status(devices: list[dict],
                                          path_to_json: dict[str, dict]):
    agents_dir = TacDir(AGENT_DIR)
    for device in devices:
        formatted_ip = device['management_ip'].replace('.', '_')
        agents_dir.newEntity('Aos::AgentStatus',
                             f'DeviceTelemetryAgent@offbox,{device["job_id"]},'
                             f'aos-offbox-{formatted_ip}-t')
        agents_dir.newEntity('Aos::AgentStatus',
                             f'CounterProxyAgent@offbox,{device["job_id"]},'
                             f'aos-offbox-{formatted_ip}-t')
    path_to_json[TELEMETRY_PARTITION][AGENT_DIR] = agents_dir.to_json_with_type()


def simulate_device_info(devices: list[dict],
                         path_to_json: dict[str, dict],
                         aos_ip: str):
    device_info_dir = DeviceInfoDir(
        DEVICE_TELEMETRY_INFO_DIR.rsplit('/', maxsplit=1)[-1])
    for device in devices:
        device_info = device_info_dir.device.newMember(device['series_number'])
        device_info.serialNumber = device['series_number']
        device_info.aosServer = aos_ip
        device_info.fetchedSerialNumber = device['series_number']
        device_info.hwModel = device['hw_model']
        device_info.hwVersion = device['hw_version']
        device_info.managementIp = device['management_ip']
        device_info.osFamily = device['os_family']
        device_info.osVersion = OsVersion(
            (device['os_version']['major'] + '.' +
             device['os_version']['minor'] + '.' +
             device['os_version']['build']),
            device['os_version']['major'],
            device['os_version']['minor'],
            device['os_version']['build']
        )
        device_info.vendor = device['vendor']
        device_info.version = 1
    path_to_json[TELEMETRY_PARTITION][DEVICE_TELEMETRY_INFO_DIR] = \
        device_info_dir.to_json_with_type()


def simulate_hostname(devices: list[dict], path_to_json: dict[str, dict]):
    device_status_dir = TacDir(
        DEVICE_TELEMETRY_STATUS_DIR.rsplit('/', maxsplit=1)[-1])
    for device in devices:
        device_dir = device_status_dir.mkdir(device['series_number'])
        hostname_status = device_dir.newEntity('Aos::Device::HostnameStatus',
                                               'hostname')
        hostname_status.hostname = device['hostname']
        hostname_status.version = 1
    path_to_json[TELEMETRY_PARTITION][DEVICE_TELEMETRY_STATUS_DIR] = \
        device_status_dir.to_json_with_type()


def main():
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument(
        '--input',
        required=True,
        help='The path to the json file that contains device information. '
             'See comments on the top of this script for details.'
    )
    arg_parser.add_argument(
        '--output',
        required=True,
        help='The path to the json file to be generated. It contains simulation '
             'result and can be used by commit_offbox_device_simulation.py'
    )
    args = arg_parser.parse_args()

    input_path: str = args.input
    output_path: str = args.output
    devices = load_json_file(input_path)

    path_to_json = {'Main': {}, 'Telemetry': {}}
    simulate_offbox_status(devices, path_to_json)
    simulate_pristine_config(devices, path_to_json)

    simulate_main_sysdb_agent_status(devices, path_to_json)

    simulate_telemetry_sysdb_agent_status(devices, path_to_json)

    aos_ip = get_my_ip_address()
    simulate_device_info(devices, path_to_json, aos_ip)

    simulate_hostname(devices, path_to_json)

    with open(output_path, 'w') as output_file:
        json.dump(path_to_json, output_file)

    print('Dumping device simulation completed. Please run '
          'aos_load_sysdb_state script to commit the simulation result.')


if __name__ == '__main__':
    main()
