# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from collections import defaultdict
import six
from six.moves import range


class IdPool(object):
    def __init__(self, key, min_id, max_id):
        self._key = key
        self._used_ids = set()
        self._min_id = min_id
        self._max_id = max_id
        self._min_free_id = min_id

    def check_range(self, _id):
        if _id < self._min_id or _id > self._max_id:
            raise ValueError(
                'Id %d is out of range (%d:%d) for key[%s]' % \
                (_id, self._min_id, self._max_id, self._key)
            )

    def next_id(self):
        return self._min_free_id

    def next_free_id(self, last_id):
        for _id in range(last_id+1, self._max_id+1):
            if _id not in self._used_ids:
                return _id

        return self._max_id+1

    def alloc_id(self, _id=None):
        if _id is None:
            _id = self._min_free_id
        self.check_range(_id)
        self._used_ids.add(_id)
        if _id == self._min_free_id:
            self._min_free_id = self.next_free_id(self._min_free_id)
        return _id

    def free_id(self, _id):
        self.check_range(_id)
        if _id in self._used_ids:
            self._used_ids.remove(_id)
        if _id < self._min_free_id:
            self._min_free_id = _id

    def is_allocated(self, _id):
        return _id in self._used_ids


class IdPoolManager(object):
    def __init__(self, min_id, max_id):
        self._id_pools = {}
        self._min_id = min_id
        self._max_id = max_id

    def check_range(self, _id, keys):
        if _id < self._min_id or _id > self._max_id:
            raise ValueError(
                'Id %d is out of range (%d:%d) for key[%s]' % \
                (_id, self._min_id, self._max_id, ', '.join(keys))
            )

    def alloc_id(self, keys, _id=None):
        if not isinstance(keys, list):
            keys = [keys]

        for key in keys:
            if not key in self._id_pools:
                self._id_pools[key] = IdPool(key, self._min_id, self._max_id)

        if _id is None:
            free_ids = defaultdict(set)
            for key in keys:
                free_ids[self._id_pools[key].next_id()].add(key)

            while len(free_ids) > 1:
                min_id = min(free_ids)
                for key in free_ids[min_id]:
                    free_ids[self._id_pools[key].next_free_id(min_id)].add(key)
                del free_ids[min_id]
            _id = next(six.iterkeys(free_ids))

            if _id > self._max_id:
                raise ValueError(
                    'No free id for [%s]' % ', '.join(keys)
                )
        else:
            self.check_range(_id, keys)

        for key in keys:
            self._id_pools[key].alloc_id(_id)

        return _id

    def free_id(self, keys, _id):
        if not isinstance(keys, list):
            keys = [keys]

        self.check_range(_id, keys)

        for key in keys:
            if not key in self._id_pools:
                continue
            self._id_pools[key].free_id(_id)
