# Copyright 2023-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula


"""Utilities to interact with the Apstra Audit Log API"""

import copy
import datetime
import re

from aos.sdk.utils import (
    normalize_iso8601,
    normalize_datetime,
    utcnow,
)


# This is an API limit that may be raised in the future.
MAX_RESULTS_PER_QUERY= 10000

# Regular expression matching the device config file name in the "device_config"
# field of audit log events of type "DeviceConfigChange"
DEVICE_CONFIG_FILE_NAME_REGEX = re.compile(
    r'^device_config-(?P<device_id>\w+)'
    r'-\d{4}-\d{2}-\d{2}--\d{2}-\d{2}-\d{2}\.\d+\.cfg$'
)


ISO8601_FORMAT = '%Y-%m-%dT%H:%M:%S.%f%z'

def adjust_timestamp(timestamp, forward=True):
    timestamp = normalize_datetime(timestamp)
    one_usec = datetime.timedelta(microseconds=1)
    if forward:
        new_timestamp = timestamp + one_usec
    else:
        new_timestamp = timestamp - one_usec
    return new_timestamp


def query_audit_log(client, event_types=None, begin_time=None, end_time=None,
                    max_event_count=MAX_RESULTS_PER_QUERY,
                    descending_timestamps=True,
                    should_resolve_device_configs=False):
    """Queries for audit log events (works only against Apstra >= 4.2.1)
       The chronologically first N events that match filters in the given
       timespan are returned.

       Args:
        client          An instance of aos.sdk.client.Client
        event_types     A list of audit log event types; default: None, which means
                        all event types are retrieved
        begin_time      Begin time of the query window (either a string in
                        ISO 8601 format, or timezone-aware datetime.datetime object)
                        Default: end_time - 30 days
        end_time        End time of the query window; Default: current time
        max_event_count Maximum number of events to query for; default: 10000
                        which is the maximum number of events returned by a single
                        query; set this to None to get all events in the window
                        but note that doing so may result in multiple query
                        API calls
        descending_timestamps           Whether to query events in descending
                                        timestamps, i.e. reverse chronological order
                                        default: True
        should_resolve_device_configs   Whether to expand "device_config" field
                                        for events of type "DeviceConfigChange"
                                        inline, or leave the value as the file name
                                        used in the request payload of
                                        POST /api/audit/device-config;
                                        default: leave file name as is
       Returns:
        A list of audit log events
    """
    if max_event_count is not None and max_event_count <= 0:
        raise ValueError('max_event_count must be positive or None (meaning all); '
                         'Given value is invalid: {}'.format(max_event_count))

    if max_event_count is None or max_event_count > MAX_RESULTS_PER_QUERY:
        per_page = MAX_RESULTS_PER_QUERY
    else:
        per_page = max_event_count

    end_time = normalize_datetime(end_time)
    if end_time is None:
        end_time = utcnow()

    begin_time = normalize_datetime(begin_time)
    if begin_time is None:
        begin_time = end_time - datetime.timedelta(days=30)

    if begin_time > end_time:
        raise ValueError('Begin time ({}) cannot come after end time ({})'.format(
            begin_time, end_time))

    if event_types:
        query_filter = 'type in [{}]'.format(
            ','.join('"{}"'.format(_type) for _type in event_types)
        )
    else:
        query_filter = None

    # Note that the "orderby" param does not (yet) provide the intended semantics
    # of descending_timestamps. What is desired with descending_timestamps == True
    # is that events from end_time are returned in reverse-chronological order.
    # However, the audit query API has a limitation: with orderby="timestamp:DESC",
    # it returns the first events starting from begin_time, but in reverse
    # chronological order. This behavior is a limitation of the underlying query
    # mechanism that might be enhanced in the future. But for now, these helper
    # functions are making their own adjustments to produce the desired semantics.
    params = {
        'per_page': per_page,
    }

    all_events = []
    keep_querying = True

    while keep_querying:
        query_payload = {
            'begin_time': normalize_iso8601(begin_time),
            'end_time': normalize_iso8601(end_time),
        }
        if query_filter:
            query_payload['filter'] = query_filter

        response = client.audit.events.query.run_raw(query_payload, params=params)
        events = response['items']
        all_events.extend(events)
        status = response['status']

        if max_event_count and len(all_events) >= max_event_count:
            keep_querying = False
        elif not status['is_truncated']:
            keep_querying = False
        else:
            keep_querying = True
            begin_time = adjust_timestamp(events[-1]['timestamp'])

    if max_event_count and len(all_events) > max_event_count:
        all_events = all_events[:max_event_count]

    if descending_timestamps:
        all_events.reverse()

    if should_resolve_device_configs:
        all_events = [resolve_device_config(client, e) for e in all_events]

    return all_events


def query_latest_audit_log_events(client, event_count, event_types=None,
                                  begin_time=None, end_time=None,
                                  descending_timestamps=True,
                                  should_resolve_device_configs=False):
    """Queries for latest N audit log events (works only against Apstra >= 4.2.1)
       The chronologically last N events that match filters in the given timespan
       are returned.

       Args:
        client          An instance of aos.sdk.client.Client
        event_count     How many events to return
        event_types     A list of audit log event types; default: None, which means
                        all event types are retrieved
        begin_time      Begin time of the query window (either a string in
                        ISO 8601 format, or timezone-aware datetime.datetime object)
                        Default: end_time - 365 days
        end_time        End time of the query window; Default: current time
        descending_timestamps           See query_audit_log()
        should_resolve_device_configs   See query_audit_log()

       Returns:
        A list of audit log events
    """
    if event_count <= 0:
        raise ValueError('event_count must be positive; '
                         'Given value is invalid: {}'.format(event_count))

    total_event_count = 0
    event_chunks = []

    # First query is for the last 30 days; if we do not get the required number of
    # events, keep going in 30-day chunks until we get the desired number, or if
    # we have exhausted the max timespan.
    keep_querying = True

    end_time = normalize_datetime(end_time)
    if end_time is None:
        end_time = utcnow()

    begin_time = normalize_datetime(begin_time)
    if begin_time is None:
        begin_time = end_time - datetime.timedelta(days=365)

    def get_chunk_begin_time(end):
        begin = end - datetime.timedelta(days=30)
        return max(begin, begin_time)

    chunk_begin_time = get_chunk_begin_time(end_time)
    chunk_end_time = end_time

    while keep_querying:
        events = query_audit_log(
            client, event_types=event_types,
            begin_time=chunk_begin_time, end_time=chunk_end_time,
            max_event_count=None,
            descending_timestamps=False,
            should_resolve_device_configs=should_resolve_device_configs,
        )
        if events:
            event_chunks.append(events)
            total_event_count += len(events)
        if total_event_count >= event_count:
            keep_querying = False
        else:
            chunk_end_time = adjust_timestamp(chunk_begin_time,
                                              forward=False)
            chunk_begin_time = get_chunk_begin_time(chunk_end_time)

            if chunk_end_time < begin_time:
                keep_querying = False

    # chunks in event_chunks are in reverse chronological order - so more recent
    # events come before older events. Therefore, create overall event list in
    # reverse order.
    all_events = []
    for chunk in reversed(event_chunks):
        all_events.extend(chunk)

    if len(all_events) > event_count:
        all_events = all_events[-event_count:]

    if descending_timestamps:
        all_events.reverse()

    if should_resolve_device_configs:
        all_events = [resolve_device_config(client, e) for e in all_events]

    return all_events


def resolve_device_config(client, event):
    """Given an audit log event returned from POST /api/audit/events/query,
       if it is of type DeviceConfigChange, attempt to resolve the device_config
       field to the actual device config by calling POST /api/audit/device-config.
       If the device config file is not found or the retrieval resulted in an error,
       then an error message is used as the value.
       If the device_config value in the original event does not appear to be a
       filename, the value is left untouched.
       Any unchanged input is returned as is. If any changes are made, a copy
       of the input is returned.

       Args:
        client  An instance of aos.sdk.client.Client
        event   An audit log event returned from the query API

       Returns:
        Potentially updated audit log event
    """
    if event['type'] == 'DeviceConfigChange':
        m = DEVICE_CONFIG_FILE_NAME_REGEX.match(event['device_config'])
        if not m:
            return event
        device_id = m.group('device_id')
        file_name = event['device_config']
        if device_id != event['device_id']:
            event['device_config'] = 'Error: file name has bad device_id: {}'
        else:
            response = client._raw_request(
                url='/audit/events/device-config', method='POST', data={
                    'device_id': device_id,
                    'file_name': file_name
                })
            event = copy.deepcopy(event)
            if response.status_code == 200:
                event['device_config'] = response.json()['content']
            else:
                event['device_config'] = \
                    'Error getting file: {} API Response: {}'.format(
                        file_name, response.text
                    )

    return event
