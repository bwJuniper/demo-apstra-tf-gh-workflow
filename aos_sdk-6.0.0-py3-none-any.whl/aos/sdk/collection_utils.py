# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""Collection utilities"""

import collections
import functools
import itertools
import six

try:
    from six.moves import collections_abc
except ImportError:
    collections_abc = collections


def groupby(key, items):
    """
    Returns items grouped by results of given key func.
    """
    return itertools.groupby(sorted(items, key=key), key)


def find(predicate, items):
    """
    Return first item for which predicate returns True.
    Returns None if there is no such item.
    """
    for item in items:
        if predicate(item):
            return item
    return None


def indexby(key, items):
    """
    Returns mapping of item key (obtained by applying key func to item) to item.
    """
    result = {}
    for item in items:
        k = key(item)
        assert k not in result, \
            'Duplicate key %s of item %s. Previous item %s' % (
                k, item, result[k])
        result[k] = item
    return result


def get_only_item(item_iter):
    """
    Returns the only item from a given iterator. It verifies the iterator has
    atmost one item.
    """
    items = list(item_iter)
    assert len(items) <= 1, str(locals())
    return items[0] if items else None


def compact_dict(data):
    """Takes dict and returns new dict with all items with None value removed."""
    return {k: v for k, v in six.iteritems(data) if v is not None}


def clone_dict(src, skip_keys=None):
    """
    Creates a shallow copy of the source dictionary skipping specified keys
    """
    skip_keys = skip_keys or []
    return {
        key: value
        for key, value in six.iteritems(src)
        if key not in skip_keys
    }


def _type_aware_cmp(val1, val2, key_extractor_func=None):
    """Compare two objects even if they have different types.

    If that function is used as cmp parameter of sorted, the values
    in result will first be ordered by names of their types, and after
    that by their value. That way we avoid comparing values of different
    types, which almost never work. I.e. the provided values must be
    comparable, but only with values of the same type.

    That function should not be used directly, instead use type_aware_key
    below. It is better because python3 dropped support for 'cmp' parameter
    in 'sorted' and supports only 'key'.
    """

    if key_extractor_func is not None:
        val1 = key_extractor_func(val1)
        val2 = key_extractor_func(val2)

    val1_type = type(val1)
    val2_type = type(val2)

    if val1_type is not val2_type:
        val1_typename = '%s.%s' % (val1_type.__module__, val1_type.__name__)
        val2_typename = '%s.%s' % (val2_type.__module__, val2_type.__name__)
        if val1_typename < val2_typename:
            return -1
        elif val1_typename > val2_typename:
            return 1
        else:
            raise AssertionError('Different types have the same name, uncomparable')

    if val1 < val2:
        return -1
    elif val2 < val1:
        return 1
    else:
        return 0


def type_aware_key(key_extractor_func=None):
    """Wrap key for 'sorted' function for sorting different types.

    A wrapper for key parameter of 'sorted' function. Makes key values
    comparable with each other even if they belong to different types.
    This is achieved by first comparing values by their types, and only
    if they are the same, the values are compared using their comparison
    methods like __lt__. If values' types are different, they are ordered
    based on their types' full names.

    If key_extractor_func is None, <lambda x: x> is assumed.
    """

    type_aware_cmp_with_extractor = functools.partial(
        _type_aware_cmp, key_extractor_func=key_extractor_func)
    return functools.cmp_to_key(type_aware_cmp_with_extractor)


def none_or_something_to_comparable_tuple(str_or_none):
    """Sort collection with None mixed with other types inside.

    >>> sorted(['a', None, 'b'])
    TypeError: '<' not supported between instances of 'NoneType' and 'str'

    >>> sorted(map(none_or_something_to_comparable_tuple, ['a', None, 'b']))
    [(False, None), (True, 'a'), (True, 'b')]

    >>> from operator import itemgetter
    >>> list(map(itemgetter(1),
            sorted(map(none_or_something_to_comparable_tuple, ['a', None, 'b']))
        ))
    [None, 'a', 'b']
    """
    if str_or_none is None:
        return (False, None)
    else:
        return (True, str_or_none)


def dict_sort_key(item):
    """This function should be used as a sort key for list of dictionaries
    with arbitrary values and properly supports nested data structures.
    """

    if isinstance(item, six.class_types):
        return item.__name__

    if isinstance(item, six.string_types):
        return six.ensure_str(item)

    if isinstance(item, collections_abc.Mapping):
        return tuple(
            sorted(
                (k, dict_sort_key(v))
                for k, v in item.items()))

    if isinstance(item, (collections_abc.Set, collections_abc.ValuesView)):
        return tuple(sorted(dict_sort_key(el) for el in item))

    if isinstance(item, collections_abc.Iterable):
        return tuple(dict_sort_key(el) for el in item)

    return item
