# Copyright 2020-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

from enum import Enum

# pylint: disable=too-many-return-statements


# Here in doctrings used the following abbreviations:
# Req = Required (IpRequiredStatus.MANDATORY)
# Opt = Optional (IpRequiredStatus.OPTIONAL)
# Dis = Disabled (IpRequiredStatus.FORBIDDEN)
# IC = Intention Conflict (IpRequiredStatus.INTENTION_CONFLICT)


class IpRequirementStatus(Enum):
    """
    The enum defines possible options for SVI IP allocation

    FORBIDDEN means that neither the builder should allocate SVI IP
              nor user is allowed to do it
    OPTIONAL means that the builder will not allocate SVI IP,
             but user-defined address is allowed and may be present
    MANDATORY means that SVI IP address must present and therefore
              should be provided by user or allocated by the builder
    INTENTION_CONFLICT means that conflicting requirements are imposed - SVI IP
                       is forced to be present, but it is not supported by the
                       device.
    """
    OPTIONAL = 0
    FORBIDDEN = 1
    MANDATORY = 2
    INTENTION_CONFLICT = 3

    def __str__(self):
        return self.name.lower()

    def is_allowed(self):
        return self.value in (self.MANDATORY, self.OPTIONAL)


def get_svi_ip_requirement_for_vxlan(os_family, ip_version, virtual_gw_enabled):
    """
    returns svi ip requirement for VXLAN

    The function does not consider SVI allocation mode enforcements
    and calculates the resulting value based on IP version,
    OS family and virtual gateway enablement.

    If you also need to take SVI allocation mode into account,
    use 'get_svi_ip_requirement' function.
    """

    # When virtual GW is not set, we must have at least SVI IP address configured
    if not virtual_gw_enabled:
        return IpRequirementStatus.MANDATORY

    os_family = os_family.lower() if os_family else None
    if os_family in ('eos', 'arista',):
        # Arista configuration does permit configuring unicast IP addresses
        # alongside with anycast gw addresses.
        # For IPv6, it is actually required as Arista does not yet have
        # ipv6 anycast gateway routing for VXLAN, so VRRPv3 is used instead.
        return IpRequirementStatus.MANDATORY \
            if ip_version == 'ipv6' else IpRequirementStatus.OPTIONAL
    elif os_family == 'nxos':
        return IpRequirementStatus.OPTIONAL
    elif os_family == 'cumulus':
        # On Cumulus, it is actually required to allocate an SVI IP
        # alongside with VXLAN IP, so not only is it permitted,
        # it is required for v4/v6.
        return IpRequirementStatus.MANDATORY
    elif os_family in ('junos', 'juniper',):
        return IpRequirementStatus.OPTIONAL
    elif os_family == 'sonic':
        # On sonic, cannot configure VXLAN anycast SAG at the same time
        # as interface IP. This is not possible on the platform,
        # and management server will cause a deployment failure.
        return IpRequirementStatus.FORBIDDEN
    else:
        assert os_family is None or os_family == 'unknown'
        return IpRequirementStatus.OPTIONAL


def get_svi_ip_requirement_for_mlag_vn(os_family):
    """
    return svi ip requirement for mlag vn
    """
    os_family = os_family.lower() if os_family else None

    if os_family is None:
        return IpRequirementStatus.OPTIONAL
    else:
        return IpRequirementStatus.MANDATORY


def get_svi_ip_requirement(vn_type, os_family, ip_version, allocation_mode,
                           virtual_gw_enabled=True):
    """
    +--------------------------+----------+-----------+------------+---------+
    |                          |                allocation_mode              |
    |     unicast              +----------+-----------+------------+---------+
    |   svi_ip_expectation     | disabled | link_local|   enabled  | forced  |
    +--------------------------+----------+-----------+------------+---------+
    |       Req                |    Dis   |     Dis   |     Req    |   Req   |
    |       Opt                |    Dis   |     Dis   |     Opt    |   Req   |
    |       Dis                |    Dis   |     Dis   |     Dis    |    IC   |
    +--------------------------+----------+-----------+------------+---------+
    """
    if allocation_mode in ('disabled', 'link_local'):
        return IpRequirementStatus.FORBIDDEN
    res = get_raw_svi_ip_requirement(
        vn_type, os_family, ip_version, virtual_gw_enabled)
    if allocation_mode == 'enabled':
        return res
    if allocation_mode == 'forced':
        if res == IpRequirementStatus.FORBIDDEN:
            return IpRequirementStatus.INTENTION_CONFLICT
        return IpRequirementStatus.MANDATORY
    raise AssertionError('Unknown allocation mode "%s"' % allocation_mode)


def get_raw_svi_ip_requirement(
        vn_type, os_family, ip_version, virtual_gw_enabled=True):
    """
    +-----------+-------+-----------------------------+-------+---------+
    |           |  VLAN |           VXLAN             |  MLAG |External |
    |           |       | v_gw_en = 0 |  v_gw_en = 1  |   VN  |   VN    |
    | OS Family |       |             |   IPv4/v6     |       |         |
    +-----------+-------+-------------+---------------+-------+---------+
    |    NXOS   |  Req  |     Req     |      Opt      |  Req  |   Req   |
    |    EOS    |  Req  |     Req     |    Opt/Req    |  Req  |   Req   |
    |  Cumulus  |  Req  |     Req     |      Req      |  Req  |   Req   |
    |   Junos   |  Req  |     Req     |      Opt      |  Req  |   Req   |
    |   SONiC   |  Req  |     Req     |      Dis      |  Req  |   Req   |
    |   None    |  Req  |     Req     |      Opt      |  Opt  |   Req   |
    +-----------+-------+-------------+---------------+-------+---------+
    """

    if vn_type == 'vlan':
        return IpRequirementStatus.MANDATORY
    elif vn_type == 'vxlan':
        return get_svi_ip_requirement_for_vxlan(
            os_family, ip_version, virtual_gw_enabled)
    elif vn_type == 'mlag':
        return get_svi_ip_requirement_for_mlag_vn(os_family)
    else:
        raise AssertionError('Unknown vn_type')


def get_ip_addr_type_by_ip_mode(ip_mode, svi_requirement):
    ip_addr_type = None
    if ip_mode in ('enabled', 'forced'):
        ip_addr_type = ('numbered' if
                        svi_requirement != IpRequirementStatus.FORBIDDEN else None)
    if ip_mode == 'link_local':
        ip_addr_type = 'link_local'
    return ip_addr_type
