# Copyright 2023-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import copy
import enum
import os

ConfigType = enum.Enum('ConfigType', ['section', 'config'])


class SectionNotFound(Exception):
    ''' Exception raised when queried section does not exist.
    '''
    def __init__(self, *path):
        super().__init__(f'{os.path.join(*path)} not found in config')


class ConfigIndex:
    ''' Indexes maintained for faster query execution to find subconfigs.
    '''
    def __init__(self):
        self.child = {}
        self.is_leaf = False

    def get_all_config_values(self):
        if self.is_leaf:
            yield ''

        for config_word, index in self.child.items():
            for sub_config in index.get_all_config_values():
                if sub_config:
                    yield f'{config_word} {sub_config}'
                else:
                    yield config_word

    def get_config_matches(self, *words):
        if not words:
            yield from self.get_all_config_values()
            return

        child_index = self.child.get(words[0])
        if child_index:
            yield from child_index.get_config_matches(*words[1:])


class ConfigSnippet:
    ''' Config tree for maintaining the Junos configuration.

        A Junos config has sections and configurations. For example, the following
        config snippet is marked with sections and configs. The comments are
        not maintained by the parser.
        system { # <-- Section
            host-name spine1; # <-- Config
            root-authentication { # <-- Section
                encrypted-password "$1$JwBLFSjs$dWkwk.O8BQDZrZDselQQL/"; # <-- Config
            }
        }
    '''
    def __init__(self, config_type):
        self.__config_type = config_type
        self.__config_string = None
        self.__children = {}
        self.__next_config_idx = 0

        self.__is_tokenized = False
        self.__index = None

    def __repr__(self):
        return f'Config({self.config_string})'

    def __str__(self):
        return f'Config({self.config_string})'

    def __iter__(self):
        return (
            (name, config)
            for name, config in self.__children.items()
            if config.config_type == ConfigType.section
        )

    @property
    def config_type(self):
        return self.__config_type

    @property
    def children(self):
        return self.__children

    # Config Parsing Builders
    def ensure_section_child(self, name, merge_sections=False):
        if name not in self.__children:
            self.__children[name] = ConfigSnippet(ConfigType.section)
        else:
            assert merge_sections, f'{name} already parsed'
        return self.__children[name]

    def add_section_child(self, name, child):
        assert name not in self.__children, f'{name} already parsed'
        self.__children[name] = child

    def add_config_child(self, config):
        self.__children[self.__next_config_idx] = config
        self.__next_config_idx += 1

    def remove_config_child(self, index):
        assert index in self.__children
        return self.__children.pop(index)

    def add_config(self, config):
        assert not self.__config_string
        self.__config_string = config

    # Config viewers
    def get_config_parts(self, indent_level):
        spaces = ' ' * (indent_level * 4)
        if self.config_type == ConfigType.config:
            return [f'{spaces}{self.__config_string};']

        complete_config = []
        for name, child in self.__children.items():
            if child.config_type == ConfigType.section:
                complete_config.append(f'{spaces}{name} {{')
                complete_config.extend(child.get_config_parts(indent_level + 1))
                complete_config.append(f'{spaces}}}')
            else:
                complete_config.extend(child.get_config_parts(indent_level))
        return complete_config

    def get_truncated_config_parts(self, indent_level=0, max_lines=4):
        ''' Returns truncated config with given max lines.
        '''
        # TODO(rajeev): Need to optimise this later.
        # For example, if there are 10 levels or sections within the config snippet,
        # then it is not worthwhile to generate the the entire config string
        config_parts = self.get_config_parts(indent_level=indent_level)
        if len(config_parts) > max_lines:
            config_parts = config_parts[:max_lines] + ['...<truncated>...']
        return config_parts

    @property
    def config_string(self):
        ''' Return junos configuration.
        '''
        return '\n'.join(self.get_config_parts(indent_level=0))

    # Query
    def _get_section(self, *path):
        assert path

        section_name = path[0]
        section = self.__children.get(section_name)
        if not section:
            return None

        if len(path) == 1:
            return section

        return section._get_section(*path[1:])

    def get_section(self, *path):
        section = self._get_section(*path)
        if section is None:
            raise SectionNotFound(*path)
        return section

    def get_configs(self, *path):
        section = self.get_section(*path)
        for config_snippet in section.__children.values():
            if config_snippet.config_type == ConfigType.config:
                yield config_snippet

    def build_index(self):
        ''' Build the ConfigIndex. ConfigIndex is a trie based index for tokens
            in config string. The trie is used to ease the lookup of configuration
            snippets.
        '''
        if self.__is_tokenized:
            return

        self.__is_tokenized = True
        self.__index = ConfigIndex()
        for config_snippet in self.__children.values():
            if config_snippet.config_type != ConfigType.config:
                continue

            index = self.__index
            pending = []
            # Each "token" is a meaningful word that helps in a query.
            # Ideally each token is a word, but for values, like
            # "export ( SPINE_TO_LEAF_FABRIC_OUT && POLICY)" the token is
            # ( SPINE_TO_LEAF_FABRIC_OUT && POLICY).
            for word in config_snippet.__config_string.split():
                if word in ('[', '('):
                    pending.append(word)
                    continue

                if word in (']', ')'):
                    pending.append(word)

                    final_word = ' '.join(pending)
                    sub_index = index.child.get(final_word)
                    if not sub_index:
                        sub_index = ConfigIndex()
                        index.child[final_word] = sub_index
                    index = sub_index

                    continue

                if pending:
                    pending.append(word)
                    continue

                sub_index = index.child.get(word)
                if not sub_index:
                    sub_index = ConfigIndex()
                    index.child[word] = sub_index

                index = sub_index
            index.is_leaf = True

    def get_child_config_matches(self, config_start):
        self.build_index()
        yield from self.__index.get_config_matches(*config_start.split())

    def get_config_matches(self, config_start, section_path):
        section = self.get_section(*section_path)
        yield from section.get_child_config_matches(config_start)

    def get_subconfig(self, paths):
        ''' Extract requested sections out of config.
            TODO(Rajeev): Expand implementation to filter out config snippets
                          from sections.

            The helper can be used to extract out subconfigurations. For example,
            from the following configuration, root-authentication can be extracted

            system {
                host-name spine1;
                root-authentication {
                    encrypted-password "$1$JwBLFSjs$dWkwk.O8BQDZrZDselQQL/";
                }
            }

            as

            system {
                root-authentication {
                    encrypted-password "$1$JwBLFSjs$dWkwk.O8BQDZrZDselQQL/";
                }
            }
        '''
        root_config = ConfigSnippet(ConfigType.section)
        for path in paths:
            assert path, 'Path cannot be empty'

            leaf_section = self._get_section(*path)
            if not leaf_section:
                # If the specific path doesn't exist, its okay.
                continue

            config = root_config
            for path_component in path[:-1]:
                sub_config = config.children.get(path_component)
                if not sub_config:
                    sub_config = ConfigSnippet(ConfigType.section)
                    config.add_section_child(path_component, sub_config)
                config = sub_config

            sub_config = copy.deepcopy(leaf_section)
            config.add_section_child(path[-1], sub_config)

        return root_config
