# Copyright 2023-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

import re
from aos.sdk.device_config.junos.config import ConfigSnippet, ConfigType


class ConfigParser:
    ''' Config parser for Junos configuration.

        Arguments:
            merge_sections:
                Knob to have the parser expect the same sections
                multiple times. This knob would be required when
                the Junos configuration to be parsed is handcrafted
                by appending configs to a valid config retreived from
                the device. For example,
                ```
                system {
                foo-bar value;
                }
                # ...
                # Following snippet was appended to the original configuration above.
                system {
                host-name foo;
                }
                ```

                This will be parsed as:
                ```
                system {
                foo-bar value;
                host-name foo;
                }
                ```
    '''
    multiline_comment = re.compile(r'/\*.*?\*/', flags=re.MULTILINE | re.DOTALL)
    string_literals = [
        re.compile(r'"(?:\\.|[^"\\])*"'),
        re.compile(r"'(?:\\.|[^'\\])*'"),
    ]

    def __init__(self, merge_sections=False):
        self.merge_sections = merge_sections

        self.config_snippet = None
        self.pending_config = []

    def clear(self):
        self.config_snippet = None
        self.pending_config = []

    @classmethod
    def normalize_config(cls, config_string):
        ''' Normalize the Junos configuration string. A configuration could
            have single line or multiline comments. The comments and empty lines
            are removed as part of the normalization process.

            Arugments:
                config_string: Junos configuration string.

            Yields configuration lines after removing comments and empty lines,
            one line at a time.

        '''
        def sanitize_literals(config):
            ''' Replace the literals in the configuration with '@' characters.
            '''
            def char_replacer(matched):
                start, end = matched.span()
                return '@' * (end - start)

            normalized_config = config
            for literal_pattern in cls.string_literals:
                normalized_config = literal_pattern.sub(
                    char_replacer, normalized_config)
                assert len(normalized_config) == len(config), (
                    'Size of normalized config and input config diverged '
                    f'with {literal_pattern.pattern}'
                )

            return normalized_config

        def remove_multiline_comments(normalized_config, config):
            spans = [
                match.span()
                for match in cls.multiline_comment.finditer(normalized_config)
            ]
            # Iterated in reverse so the indexes from the match are not impacted.
            for start, end in reversed(spans):
                config = config[:start] + config[end:]
                normalized_config = (
                    normalized_config[:start] + normalized_config[end:]
                )
            return normalized_config, config

        def remove_single_line_comments(normalized_config, config):
            for normalized_line, config_line in zip(
                    normalized_config.splitlines(),
                    config.splitlines(),
            ):
                comment_start_pos = normalized_line.find('#')
                line = config_line if comment_start_pos == -1 else \
                    config_line[:comment_start_pos]
                line = line.strip()
                if line:
                    yield line

        # Junos configuration uses '#' for single line commend and /* ... */
        # for multiline comments. We cannot remove all instances of these
        # as these could be used inside literals. Think of the following 3 scenarios
        # where such a solution would fail (there are no comments in this examples):
        # Example 1:
        # system {
        #   login {
        #     message "Welcome to the system #1";
        # ....
        #
        # Example 2:
        # system {
        #   login {
        #     message "Welcome to the system /*1*/";  <- No comment here.
        # ...
        #
        # Example 3:
        # system {
        #   login {
        #     user user1 {
        #      message "Welcome /* User1";
        # ,,,,
        #     user user3 {
        #      message "Welcome */ User2";
        #...
        # The above examples have chars used for denoting comments inside literals.
        # The logic here we have here is as follows
        # - Get a sanitized string were all literals are
        #   replaced with '@' characters. A literal is identified by
        #     - A value in a single line with quotes double or single.
        #     - A value in a single line with paranthesis.
        #     - A value in a single line with block brackets.
        #   It is important to note that the length of config and normalized config
        #   will be the same.
        # - From the normalized config, identify indexes of multiline comments.
        #   The indexes from multiline comments are used to remove the comments from
        #   config string. The normalized config is updated as well to maintain the
        #   same length.
        # - The same logic is used to identify single line comments.
        normalized_config = sanitize_literals(config_string)
        normalized_config, config_string = remove_multiline_comments(
            normalized_config, config_string)
        yield from remove_single_line_comments(normalized_config, config_string)

    def parse_config(self, config_string):
        # It may be possible that the same config parser is utilized
        # multiple times with different devices. Clear the config parser state
        # before processing any additional configuration.
        self.clear()

        self.config_snippet = ConfigSnippet(ConfigType.section)
        self.pending_config.append(self.config_snippet)

        for line in self.normalize_config(config_string):
            self.visit_line(line)

        assert self.pending_config == [self.config_snippet], \
            f'Parsing failed - {self.pending_config}'
        return self.config_snippet

    def visit_line(self, line):
        if line.startswith('#'):
            return

        current_config = self.pending_config[-1]
        if line.endswith(' {'):
            section_name = line[:-2]
            section_snippet = current_config.ensure_section_child(
                section_name, self.merge_sections)
            self.pending_config.append(section_snippet)
            return

        if line == '}':
            self.pending_config.pop()
            return

        # Even though Junos accepts configurations that do not end with ';',
        # the device always produces the delimiter ';'.
        assert line.endswith(';'), line
        config_snippet = ConfigSnippet(ConfigType.config)
        config_snippet.add_config(line[:-1].rstrip())
        current_config.add_config_child(config_snippet)
