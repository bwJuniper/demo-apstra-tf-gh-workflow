#!/usr/bin/env python3
# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

""" Utility functions. """

# pylint: disable=bare-except
# pylint: disable=too-many-return-statements

from __future__ import absolute_import
from __future__ import division

import aos.sdk.py3compat  # pylint: disable=unused-import

from collections import Counter
import datetime
import difflib
import copy
import iso8601
import math
import pprint
import re
import time
import uuid
import warnings

import six
from six.moves import range
from six.moves import zip
from six.moves import json

DEFAULT_ENCODING = 'utf-8'


try:
    from functools import cached_property as cachedproperty  # pylint: disable=unused-import
except ImportError:
    class cachedproperty(object):  # pylint: disable=invalid-name
        """
        Property decorator that will call function only once,
        caching returned value.
        """
        def __init__(self, func):
            self._func = func

        def __get__(self, obj, klass):
            value = obj.__dict__[self._func.__name__] = self._func(obj)
            return value


def deprecated(f):
    """
    Decorator to mark functions as deprecated. Will emit warning when function
    is used.
    """
    warning = 'Call to deprecated function %s.' % (f.__name__)

    def wrapped(*args, **kwargs):
        warnings.simplefilter('always', DeprecationWarning)
        warnings.warn(warning, category=DeprecationWarning, stacklevel=2)
        warnings.simplefilter('default', DeprecationWarning)
        return f(*args, **kwargs)

    return wrapped


def wait_for(func, timeout=60.0, description=''):
    """
    Wait until 'func' returns a true value. Raise AssertionError
    in case of timeout
    """
    delay = 1.0
    deadline = time.time() + timeout
    while True:
        try:
            result = func()
        except:
            result = None

        if result:
            return result
        else:
            if time.time() >= deadline:
                assert False, 'Timeout waiting for %s' % description
            delay = min(delay * 2, timeout / 2)
            time.sleep(delay)


def with_async_state(func=None, timeout=60, max_delay=2, min_delay=0.2):
    """
    Try running given function during given timeout time
    until it completes without exceptions. If after given timeout
    it still finishes with exception, exception is rethrown into
    calling code.


        def verify():
            self.assertEqual('foo', value)

        with_async_state(verify, timeout=5)

    Can be used as decorator. In that case it calls decorated function
    right away:

        @with_async_state(timeout=20)
        def verify():
            self.assertEqual('foo', value)

    This decorator can also be used w/o outer invocation with arguments
    preserving the same semantics (normally decorators are either plain or
    with arguments, but do not support both semantics at the same time):

        @with_async_state
        def verify():
            self.assertEqual('foo', value)

    Attempts are performed with an exponentially increasing delay
    up to given max_delay (default - 2 seconds).
    """
    max_delay = max(min_delay, max_delay)
    def wrapper(f):
        def wrapped(*args, **kwargs):
            delay = min_delay
            timeout_time = datetime.datetime.now() + \
                datetime.timedelta(seconds=timeout)
            while datetime.datetime.now() < timeout_time:
                try:
                    return f(*args, **kwargs)
                except:
                    pass

                timeleft = timeout_time - datetime.datetime.now()
                timeleft_delay = (timeleft.seconds * 1000000.0
                                  + timeleft.microseconds) / 1000000

                time.sleep(min(delay, timeleft_delay))
                delay = min(delay * 2, max_delay)

            return f(*args, **kwargs)

        if func is None:
            wrapped()
        return wrapped

    if func is not None:
        return wrapper(func)()

    return wrapper


def repeat(runs=2, delay=10.0):
    """"
    Repeat runs times the same function, return the value of the last run. Between
    consecutive runs, sleep for delay seconds. Can be used as a decorator too:
    @repeat(runs=2, delay=5.0)
    """
    def wrapper(f):
        def wrapped(*args, **kwargs):
            for _ in range(1, runs):
                f(*args, **kwargs)
                time.sleep(delay)
            return f(*args, **kwargs)
        return wrapped
    return wrapper


def encode(unicode_string):
    return six.ensure_binary(unicode_string, encoding=DEFAULT_ENCODING)


def decode(binary_string):
    return six.ensure_text(binary_string, encoding=DEFAULT_ENCODING)


def encode_if_unicode(x):
    """
        When unicode type is passed in converts into binary type with UTF-8 encoding.
        When other types are passed, returns w/o changes.
    """
    if isinstance(x, six.text_type):
        return encode(x)
    return x


def encode_unicode_in_string_list(values):
    return [encode_if_unicode(v) for v in values]


def json_unicode_to_str(obj):
    """Given a json-encoded obj, converts all instances of unicode strings into
       encoded binary strings (str). The modified json object is returned. The input
       is unchanged.

       Args:
            obj     A JSON object (Python dictionary)

       Returns:
            JSON object with binary strings (e.g. 'abc'). All unicode characters
            are encoded with UTF-8 in the resulting binary strings.
    """
    if isinstance(obj, list):
        return [json_unicode_to_str(val) for val in obj]
    elif isinstance(obj, dict):
        return {
            json_unicode_to_str(key) : json_unicode_to_str(obj[key]) \
            for key in obj
        }
    elif isinstance(obj, (six.text_type, six.binary_type)):
        return six.ensure_str(obj, encoding=DEFAULT_ENCODING)
    return obj


def gen_uuid():
    return str(uuid.uuid4())


def is_subset_of(subset, superset, response_message=False, float_places=None):
    """Verifies that the 'superset' dictionary includes the 'subset'
       dictionary.
       'superset' and 'subset' can be composed of dictionaries and lists.
       In the case of lists, all the items in the 'subset' list must be a subset of
       the corresponding items in the 'superlist'. The items of each
       list are sorted before they are compared, treating the list as a set where
       ordering doesn't matter. This means that if you mixed types that are not
       really comparable, e.g. integers and dictionary, in the same list, there
       is no guarantee for a correct answer.

       If response_message == False, returns True if and only if verification
       succeeds.

       If response_message == True, returns a 2-tuple (<success>, <message>)
       where <success> is a boolean indicating verification success,
       and <message> is a readable explanation of what failed the verification.

       Verification is done recursively. For instance, the function
       returns True for the following:

        superset = {
            'foo': 'bar',
            'bazz': {
                'alpha': 'beta',
                'delta': 'gamma'
            },
            'cat': 'dog',
            'list': ['a','b','c']
        }

        subset = {
            'cat': 'dog',
            'bazz': {
                'delta': 'gamma'
            },
            'list': ['a','b','c']
        }

        But returns False if subset was:

        subset = {
            'cat': 'dog',
            'bazz': {
                'alpha': 'foo'
            },
            'list': ['a','b']
        }
    """
    def make_response(result, message):
        if response_message:
            return result, message
        return result

    def failed(response):
        if response_message:
            return not response[0]
        return not response

    def index_of(subset_item, superset, available_indices):
        for idx in available_indices:
            response = is_subset_of(subset_item, superset[idx],
                                    response_message=response_message,
                                    float_places=float_places)
            if not failed(response):
                return idx
        return -1

    if isinstance(subset, dict):
        if not isinstance(superset, dict):
            return make_response(False, "%s is not a dict" % superset)
        for key in subset:
            if key not in superset:
                message = "%s of subset **%s** not in superset **%s**" % \
                          (key, subset, superset)
                return make_response(False, message)
            response = is_subset_of(subset[key], superset[key],
                                    response_message=response_message,
                                    float_places=float_places)
            if failed(response):
                return response
        return make_response(True, "")
    elif isinstance(subset, list):
        if not isinstance(superset, list):
            return make_response(False, "%s is not a list" % superset)
        if len(subset) > len(superset):
            return make_response(
                False,
                "Length of subset **%s** is > superset **%s**" % (subset, superset))
        available_indices = set(range(len(superset)))
        for subset_item in subset:
            superset_idx = index_of(subset_item, superset, available_indices)
            if superset_idx == -1:
                return make_response(
                    False,
                    'Item %s in subset not present in superset **%s**' % (
                        subset_item, superset))
            available_indices.remove(superset_idx)
        return make_response(True, "")
    elif isinstance(subset, float) and isinstance(superset, float) and \
        float_places is not None:
        okay = round(subset, float_places) == round(superset, float_places)
        return make_response(okay, "item: %s != %s (%d decimal places)" % \
                             (superset, subset, float_places))
    elif superset != subset:
        return make_response(False, "item: %s != %s" % (superset, subset))
    return make_response(True, "")


def diff_result(expected, actual, test_name=None, expect_out_of_order=False):
    """ Pretty-prints diff-based format to help eyeball very specific
        configuration rendering bugs, especially focusing on whitespacing,

        Faster config-rendering troubleshooting!

        Helps find missing newlines, !'s, extra whitespace, etc.
        """
    def parse_config(config):
        # Split the configuration into lines and remove leading/trailing whitespaces
        return [line.strip() for line in config.strip().split('\n')]

    def config_is_identicall(cfg1, cfg2):
        # Parse the configurations into lists of lines
        lines1 = parse_config(cfg1)
        lines2 = parse_config(cfg2)

        # Check if the configurations are identical
        if lines1 == lines2:
            return True

        # Check if the configurations are out of order but otherwise identical
        counter1 = Counter(lines1)
        counter2 = Counter(lines2)

        if counter1 == counter2:
            return True

        return False

    diffs_found = False
    if expect_out_of_order:
        diffs_found = not config_is_identicall(expected, actual)
    else:
        diffs_found = expected.strip() != actual.strip()
    if diffs_found:
        d = difflib.Differ()
        diff = d.compare(expected.splitlines(), actual.splitlines())
        pp = pprint.pformat(list(diff))
        # Long line wrap for easier visibility when unit test fails, what the
        # exact assertion is and what the error message means.
        # pylint: disable=line-too-long
        raise AssertionError('%sExpected and actual config do not match\n--EXPECTED--\n%s\n--ACTUAL--\n%s\n--DIFF--\n%s' % (
            '%s: ' % test_name if test_name else '',
            expected, actual, pp))


class SchemaObject(object):
    '''Represents a schema backed object. Exposes all schema fields as object
    attributes for read/write purposes. No support for fields of complex type yet.'''
    __MY_FIELDS = ['_schema_object_type', '_values']

    def __init__(self, schema_object_type, **initial_values):
        self._schema_object_type = schema_object_type
        self._values = {}
        for key, value in six.iteritems(initial_values):
            setattr(self, key, value)

    def __deepcopy__(self, memo):
        return self.__class__(
            self._schema_object_type,
            **copy.deepcopy(self._values)
        )

    def __hasattr__(self, name):
        return name in self.__MY_FIELDS or name in self._schema_object_type.fields

    def __getattr__(self, name):
        if name in self.__MY_FIELDS:
            return super(SchemaObject, self).__getattr__(name)
        if name in self._schema_object_type.fields:
            return self._values.get(name)

        raise AttributeError(name)

    def __delattr__(self, name):
        if name in self._schema_object_type.fields:
            self._values.pop(name, None)
            return

        raise AttributeError(name)

    def __setattr__(self, name, value):
        if name in self.__MY_FIELDS:
            super(SchemaObject, self).__setattr__(name, value)
        elif name in self._schema_object_type.fields:
            self._values[name] = value
        else:
            raise AttributeError(name)

    def validate(self):
        return self._schema_object_type.validate(self.dump())

    def dump(self):
        return self._schema_object_type.dump(self)


def sorted_alphabetical(sort_keys):
    """ Returns a sorted list of strings based on alphabetical
        ordering instead of doing it lexicographically.
        custom compare function checks for the length of the keys
        as well and returns a list of sorted keys.
        ex:
        Lexicographical interface ordering:
            Ethernet0 < Ethernet1 < Ethernet10 < Ethernet11 < Ethernet2
        Alphabetical interface ordering:
            Ethernet0 < Ethernet1 < Ethernet2 < Ethernet10 < Ethernet11
        We want the interfaces to be ordered this way in the configs
    """
    return sorted(sort_keys, key=lambda x: (len(x), x))


def opportinistic_json_loads(value):
    """ Helper function to convert json blobs into python
        primitives for visual comparison
    """
    if isinstance(value, aos.sdk.py3compat.text_and_binary_types):
        try:
            # Only attempt to deserialize dicts,
            # otherwise primitive types end up swapping between 'int' -> int, etc
            val = json.loads(value)
            if isinstance(val, dict):
                return val
        except ValueError:
            pass
    return value


def recursive_compare(item1, item2, path='', errors=None):
    path = path if path else 'root'
    errors = errors if errors else {}
    item1 = opportinistic_json_loads(item1)
    item2 = opportinistic_json_loads(item2)
    if isinstance(item1, dict) and isinstance(item2, dict):
        keys1 = set(item1.keys())
        keys2 = set(item2.keys())
        if keys1 != keys2:
            err = 'Keys differ: ' \
                  'LeftOnly: {left} RightOnly: {right} Common: {common}'.format(
                      left=keys1 - keys2,
                      right=keys2 - keys1,
                      common=keys1 & keys2)
            errors.setdefault(path, []).append(err)
        for common_key in keys1 & keys2:
            key_path = "{path}['{key}']".format(path=path,
                                                key=common_key)
            errors.update(recursive_compare(item1[common_key], item2[common_key],
                                            path=key_path,
                                            errors=errors))
    elif isinstance(item1, list) and isinstance(item2, list):
        if len(item1) != len(item2):
            err = 'Item counts differ, ' \
                  'Left {left} != Right {right}'.format(
                      left=item1, right=item2)
            errors.setdefault(path, []).append(err)
        for idx in range(min(len(item1), len(item2))):
            idx_path = '{path}[{idx}]'.format(path=path, idx=idx)
            errors.update(recursive_compare(item1[idx], item2[idx],
                                            path=idx_path,
                                            errors=errors))
    else:
        item1_type = type(item1)
        item2_type = type(item2)
        # [python 2] Compare str to unicode, which can end up happening when
        # testing dicts against json dumps. If the values are truly different,
        # then the types do not matter.
        # [python 3] str and bytes are not comparable, and so we will not try
        # to compare them. This should be fine as we intend to use only str
        # for text on that version of python.
        if (item1_type != item2_type and (not isinstance(item1, six.string_types) or
                                          not isinstance(item2, six.string_types))):
            err = 'Types differ, Left: {left} != Right {right}'.format(
                left=item1_type,
                right=item2_type)
            errors.setdefault(path, []).append(err)
        if item1 != item2:
            err = 'Items differ, ' \
                  'Left ({left_type}) {left} != Right ({right_type}) {right}'.format(
                      left=item1,
                      right=item2,
                      left_type=item1_type,
                      right_type=item2_type)
            errors.setdefault(path, []).append(err)
    return errors


def check_func_equal(func1, func2):
    """Check that two functions are equal.

    This function is not applicable to all callable objects. Only simple
    functions, such as lambdas or normal functions without closures, are
    supported. Functions with closures are always considered as different
    ones. Class methods are not supported too.

    This comparison doesn't guarantee equality of two functions in
    the terminology of mathematical analysis. Instead, this comparison
    is based on an assumption that if two functions have the same
    implementation, than these two functions are equal. This leads to
    the possibility of false-negative results, e.g. (x + y) is considered
    as a different implementation in comparison to (y + x) because they
    have different bytecode. However, this approach is free from false-positive
    results, which makes this approach suitable for practical applications in
    which this approximation is acceptable.

    In python 3 there is an additional case where we would not understand
    that two functions are equal: if functions have internal functions, then
    the functions' full names must be the same. Full names here include the
    function name, parent function(s) name and parent class name. If at least
    some of the names are different, we will find the functions being compared
    to be different. That is demonstrated in test case CheckFuncEqualTest, test
    test_equal_functions_with_different_names_and_equal_internal_functions
    To summarize, in python 3 we have one more false-negative case, but that
    fine as here the function is still free of false-positives results.

    :param func1: (function) The first function.
    :param func2: (function) The second function.
    :returns: (bool) True if two functions are equal and False otherwise.
    """

    def check_code_equal(code1, code2):
        return (
            code1.co_argcount == code2.co_argcount
            and code1.co_names == code2.co_names
            and code1.co_flags == code2.co_flags
            and code1.co_freevars == code2.co_freevars
            and code1.co_nlocals == code2.co_nlocals
            and code1.co_stacksize == code2.co_stacksize
            and code1.co_varnames == code2.co_varnames
            and len(code1.co_consts) == len(code2.co_consts)
            and all(
                check_code_equal(const1, const2)
                if hasattr(const1, 'co_code') and hasattr(const2, 'co_code')
                else const1 == const2
                for const1, const2 in zip(
                    code1.co_consts,
                    code2.co_consts,
                )
            )
            and code1.co_code == code2.co_code
        )

    return (
        not func1.__closure__
        and not func2.__closure__
        and func1.__defaults__ == func2.__defaults__
        and check_code_equal(func1.__code__, func2.__code__)
    )


def human_sort_key(string):
    """Make alphabetical order, except that multi-digit numbers are treated
    atomically, i.e., as if they were a single character."""
    if string is None:
        string = ''
    return [int(token) if token.isdigit() else token
            for token in re.split(r'(\d+)', string)]


def case_insensitive_human_sort_key(string):
    """Make alphabetical order (case insensitive), except that
    multi-digit numbers are treated atomically, i.e., as if they were
    a single character."""
    human_key_sorted = human_sort_key(string)
    # If two strings are the same case-insensitively,
    # compare them taking the case into account.
    return [
        elem.lower() if isinstance(elem, str) else elem
        for elem in human_key_sorted
    ], human_key_sorted


def strtobool(bool_as_str):
    """Returns True/False based by string, like distutils.util.strtobool.

    Returns False for "false/no/n/f/off/0" (case-insensitive)
    Returns True for "true/yes/y/t/on/1"
     """
    if bool_as_str.upper() in ('FALSE', 'NO', 'N', 'F', 'OFF', '0'):
        return False
    elif bool_as_str.upper() in ('TRUE', 'YES', 'Y', 'T', 'ON', '1'):
        return True
    else:
        raise ValueError("Cannot convert %r to True or False" % bool_as_str)



ISO8601_FORMAT = '%Y-%m-%dT%H:%M:%S.%f%z'

def normalize_iso8601(ts):
    """Converts a given datetime.datetime object into a string formatted
       according to ISO 8601.

       If the given timestamp is already a string, it is converted to the
       specific ISO format <YYYY>-<MM>-<DD>T<HH>:<MM>:<SS>.<USECS><TZ>.
       The conversion is done by first normalizing it to a datetime
       instance with normalize_datetime().
       If timezone is not specified, then a ValueError is raised.
       Any unspecified elements will be filled with default values,
       e.g. 0 for hours.

       The purpose of this helper function is to create timestamps for
       request payloads that are expected by the probe/metricdb/audit log
       query APIs.
    """
    if ts is None:
        return None

    if not isinstance(ts, datetime.datetime):
        effective_ts = normalize_datetime(ts)
    else:
        effective_ts = ts

    if not effective_ts.tzinfo:
        raise ValueError('Timestamp given has no timezone: {}'.format(ts))

    return effective_ts.strftime(ISO8601_FORMAT)


def normalize_datetime(ts):
    """Converts a given timestamp to an instance of datetime.datetime.

       If the input is not a datetime.datetime instance, it is assumed to
       be a string representation (e.g. output of normalize_iso8601()),
       and is converted to a timezone-aware datetime.datetime object.
       If the input has no timezone information, then ValueError will be raised.

       If the input is a datetime.datetime instance, then it is checked
       for timezone awareness. If a naive datetime is given, ValueError
       is raised.

       The purpose of this function is to create comparable datetime.datetime
       instances from timestamps returned by probe/metricdb/audit log query APIs,
       across multiple versions of Apstra (starting from 4.2.x).
    """
    if ts is None:
        return None

    if not isinstance(ts, datetime.datetime):
        effective_ts = iso8601.parse_date(ts, default_timezone=None)
    else:
        effective_ts = ts

    if not effective_ts.tzinfo:
        raise ValueError('Timestamp given has no timezone: {}'.format(ts))
    return effective_ts


def utcnow():
    return datetime.datetime.now(tz=datetime.timezone.utc)


def ensure_timestamp(value, round_to=None):
    def _get_datetime_now():
        datetime_now = datetime.datetime.now(datetime.timezone.utc)
        if round_to:
            epoch_round_up = math.floor(datetime_now.timestamp() + round_to / 2)
            datetime_now = datetime.datetime.fromtimestamp(
                epoch_round_up - epoch_round_up % round_to,
                datetime.timezone.utc
            )
        return datetime_now

    if value is None:
        return _get_datetime_now()
    elif isinstance(value, datetime.timedelta):
        # TODO(egor): use datetime.datetime.now(datetime.timezone.utc)
        # after completing transition to python3
        return _get_datetime_now() + value
    elif isinstance(value, datetime.datetime):
        return value
    else:
        assert False, 'Unexpected value'


def to_seconds(**kwargs) -> int:
    """Return number of seconds for specified time interval."""
    return int(datetime.timedelta(**kwargs).total_seconds())
