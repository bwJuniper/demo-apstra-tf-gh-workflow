# Copyright 2014-present, Apstra, Inc. All rights reserved.
#
# This source code is licensed under End User License Agreement found in the
# LICENSE file at http://apstra.com/eula

"""AOS SDK to help with developing application using AOS REST API"""

from __future__ import annotations

# We have multiple sub-packages sharing "aos.sdk" namespace
# https://packaging.python.org/guides/packaging-namespace-packages/
__path__ = __import__('pkgutil').extend_path(__path__, __name__)
